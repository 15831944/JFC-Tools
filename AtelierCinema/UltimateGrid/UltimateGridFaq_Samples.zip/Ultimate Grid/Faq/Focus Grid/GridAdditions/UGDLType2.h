/***********************************************
	Ultimate Grid 97
	Copyright 1994 - 1997 Dundas Software Ltd.

	Class 
		CUGDropListType2
	Purpose
	Details
************************************************/
#include "ugLstBox2.h"

class CUGDropListType2: public CUGDropListType
{
public:
	CUGDropListType2();
	~CUGDropListType2();
};
