#if !defined(AFX_GRIDRESULTAT_H__C3B63C78_ED49_406E_AA63_EECD8F786C70__INCLUDED_)
#define AFX_GRIDRESULTAT_H__C3B63C78_ED49_406E_AA63_EECD8F786C70__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GridResultat.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGridResultat window

class CGridResultat : public CGXGridWnd
{
// Construction
public:
	CGridResultat();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGridResultat)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGridResultat();

	// Generated message map functions
protected:
	//{{AFX_MSG(CGridResultat)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GRIDRESULTAT_H__C3B63C78_ED49_406E_AA63_EECD8F786C70__INCLUDED_)
