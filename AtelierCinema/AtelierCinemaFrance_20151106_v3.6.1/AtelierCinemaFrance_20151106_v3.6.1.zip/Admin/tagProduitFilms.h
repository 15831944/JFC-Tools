// tagProduitFilms.h: interface for the tagProduitFilms class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TAGPRODUITFILMS_H__7931F1F7_0F30_4A19_9F1F_A12D93F5F4C0__INCLUDED_)
#define AFX_TAGPRODUITFILMS_H__7931F1F7_0F30_4A19_9F1F_A12D93F5F4C0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Table.h"


#endif // !defined(AFX_TAGPRODUITFILMS_H__7931F1F7_0F30_4A19_9F1F_A12D93F5F4C0__INCLUDED_)
