// ConstCinema.cpp: implementation of the CConstCinema class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "admin.h"
#include "ConstCinema.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CConstCinema::CConstCinema()
{
	
}

CConstCinema::~CConstCinema()
{

}

// D�finition des constantes Atelier Cinema
const int CConstCinema::m_MaxNbSemaine = 53;