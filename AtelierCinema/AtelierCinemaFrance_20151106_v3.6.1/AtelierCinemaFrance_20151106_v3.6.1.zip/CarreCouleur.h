#if !defined(AFX_CARRECOULEUR_H__83A6C460_790C_11D4_BA64_D6E1BA8BF83D__INCLUDED_)
#define AFX_CARRECOULEUR_H__83A6C460_790C_11D4_BA64_D6E1BA8BF83D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CarreCouleur.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCarreCouleur window

class CCarreCouleur : public CStatic
{
// Construction
public:
	CCarreCouleur();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCarreCouleur)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCarreCouleur();

	// Generated message map functions
protected:
	//{{AFX_MSG(CCarreCouleur)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CARRECOULEUR_H__83A6C460_790C_11D4_BA64_D6E1BA8BF83D__INCLUDED_)
