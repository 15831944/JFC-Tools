// GridCoeffUsure.cpp : implementation file
//

#include "stdafx.h"
#include "cinema.h"
#include "GridCoeffUsure.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGridCoeffUsure

CGridCoeffUsure::CGridCoeffUsure()
{
}

CGridCoeffUsure::~CGridCoeffUsure()
{
}


BEGIN_MESSAGE_MAP(CGridCoeffUsure, CGXGridWnd)
	//{{AFX_MSG_MAP(CGridCoeffUsure)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CGridCoeffUsure message handlers
