// TableTempo.cpp: implementation of the CTableTempo class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TableTempo.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTableTempo::CTableTempo()
{
	m_NomFich="tempo.table";
	IsModified=0;
}

CTableTempo::~CTableTempo()
{

}

CTableTempo::CTableTempo(const  CTableTempo & Data)
{	
		*this=Data;
};

bool CTableTempo::LoadTable()
{

	RemoveAll();

	CFichierCinema m_Fichier;
	if(!m_Fichier.OpenFileForRead(m_NomFich,1))
	{
		return (0);
	} 

	// On lit tous les tempos que l'on place dans la table m_TableTempo
	// lecture tant que la ligne n'est pas un '#'

	while(m_Fichier.ReadLine())
	{
		bool message=0;
		CString ChaineMessage="";
		tagTempo enr;
		// On stocke d'abord le libell�
		enr.m_Libelle  = m_Fichier.GetElement(0) ;
		enr.m_Libelle.TrimRight();
		// le libell� est il valide ?: 10 caract�res max
		if(enr.m_Libelle.GetLength()>10)
		{
			message=1;
			ChaineMessage="\nLe libell� tempo n'est pas d�fini sur 10 caract�res";
			enr.m_Libelle = enr.m_Libelle.Left(10);
		}

		enr.m_periode  = atoi(m_Fichier.GetElement(1));
		// controle de la p�riode
		if((enr.m_periode<0)||(enr.m_periode>9))
		{
			message=1;
			ChaineMessage="\nLa p�riode du tempo est invalide";
			enr.m_periode=0;
		}
		// chaine de d�finition
		enr.m_Definition  = m_Fichier.GetElement(2) ;
		
		// la chaine doit etre d�finie sur 10 caract�res!!
		if(enr.m_Definition.GetLength()!=10)
		{
			message=1;
			ChaineMessage="\nLa chaine de d�finition du tempo ne compte pas sur 10 caract�res";
			if(enr.m_Definition.GetLength()>10)
			{
				enr.m_Definition = enr.m_Definition.Left(10);
				enr.m_periode=10;
			}
		}

		if(message)
		{
			AfxMessageBox("le format du fichier: "+m_NomFich+ " n'est pas valide"+ChaineMessage,MB_OK);   
		}

		// On ajoute l'enregistrement dans le tableau
		int index = Add(enr);
	}
	if(GetSize()==0)
	{
		AfxMessageBox("La table des tempos est vide",MB_OK | MB_APPLMODAL);	
	}
	// fermeture du fichier
	m_Fichier.Close(); 
	return (1);

	// la table des tempos est constitu�e en dur
	/*tagTempo tmp;
	tmp.m_Libelle = "�clair";
	tmp.m_Definition = "3000000000";
	tmp.m_periode = 0;
	Add(tmp);
	tmp.m_Libelle = "alternatif";
	tmp.m_Definition = "3000000000";
	tmp.m_periode = 1;
	Add(tmp);
	tmp.m_Libelle = "continu";
	tmp.m_Definition = "1200000000";
	tmp.m_periode = 1;
	Add(tmp);
	tmp.m_Libelle = "semi-alternatif";
	tmp.m_Definition = "0120000000";
	tmp.m_periode = 2;

	Add(tmp);
	tmp.m_Libelle = "ralenti";
	tmp.m_Definition = "0102000000";
	tmp.m_periode = 3;

	Add(tmp);
	return(1);*/

}

int CTableTempo::GetPeriode(int position)
{
	return(GetAt(position).m_periode);
}



bool tagTempo::GetPassage(int numsemaine, int park)
{
	int s=numsemaine%m_Definition.GetLength();
	int code=atoi(m_Definition.Mid(s,1));
	if(park==0)
	{
		if(code==1 || code==3)return 1;
		else return 0;
	}
	if(park==1)
	{
		if(code==2 || code==3)return 1;
		else return 0;
	}
	
	// PB
	ASSERT(0);
	return(0);
}

bool CTableTempo::SaveTable()
{
	CString txt;
	// sauvegarde

	// la table a �t� modifi�
	IsModified = 0;

	CFichierCinema Fichier;
	
	if(!Fichier.OpenFileForWrite(m_NomFich))
	{
		return (0);	
	}
	for(int i=0;i<GetSize();i++)
	{
		txt="";
		CString periode;
		// sauvegarde du libell� tempo (chaine 10 carat�res)
		CString def = GetLibelle(i);
		// ajout d'espace
		while(def.GetLength()!=10)
		{
			def+=" ";
		}
		txt+=def;
		txt+="|";

		// sauvegarde de la p�riode active
		periode.Format("%d",GetAt(i).m_periode);
		txt+=periode;
		txt+="|";

		// sauvegarde de la d�finiton (chaine 10 carat�res)
		def = GetAt(i).m_Definition;
		// ajout de "0"
		while(def.GetLength()!=10)
		{
			def+="0";
		}
		txt+=def;
		txt+="\n";
		if(!Fichier.WriteLine(txt))return(0);
		

	}
	// caract�re de fin de fichier
	if(!Fichier.WriteLine("#"))return(0);
	// fermeture du fichier
	Fichier.Close(); 
	return (1);

}

int CTableTempo::ExisteLibelleTempo(CString libelle)
{
	// On boucle sur les tempos
	for(int tempo=0;tempo<GetSize();tempo++)
	{
		tagTempo T=GetAt(tempo);
		if(T.m_Libelle==libelle)return(1);
	}
	return(0);
}
