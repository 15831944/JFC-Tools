// TableProduit.h: interface for the CTableProduit class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TABLEPRODUIT_H__66A1830E_CA82_4B58_9FFC_CAED061A8F0F__INCLUDED_)
#define AFX_TABLEPRODUIT_H__66A1830E_CA82_4B58_9FFC_CAED061A8F0F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Table.h"


// On d�finit une structure contenant les param�tres du produit : code et libell�
class tagProduit : public CtagTable
{
private:

	// dur�e du produit
	int m_Duree;

public:
	
	// code du produit
	CString m_Code;

	// libell� du produit
	CString m_Libelle;

	// produit fig�
	bool m_flagProduitFige;

	
	CWordArray  * m_DescriptionIndexComplexe;	// [m_Duree]
	CWordArray  * m_DescriptionIndexBac;		// [m_Duree]
	CStringArray * m_DescriptionCode;			// [m_Duree]

	tagProduit & operator=(const  tagProduit & Data)
	{
		m_Libelle=Data.m_Libelle;
		m_Code=Data.m_Code;
		m_Duree=Data.m_Duree;
		m_flagProduitFige=Data.m_flagProduitFige;
		SetDuree(m_Duree); 

		// Copie des tableaux 
		for(int duree=0;duree<m_Duree;duree++)
		{
			m_DescriptionCode[duree].RemoveAll();
			m_DescriptionIndexComplexe[duree].RemoveAll();
			m_DescriptionIndexBac[duree].RemoveAll();
			m_DescriptionIndexComplexe[duree].Copy(Data.m_DescriptionIndexComplexe[duree]);
			m_DescriptionIndexBac[duree].Copy(Data.m_DescriptionIndexBac[duree]);
			m_DescriptionCode[duree].Copy(Data.m_DescriptionCode[duree]); 
		}
		return *this;
	};
	
	// Neutral constructor
	tagProduit()
	{
		m_Duree=1;
		m_flagProduitFige=0;
		m_DescriptionCode=NULL;
		m_DescriptionIndexBac=NULL;
		m_DescriptionIndexComplexe=NULL;
	};

	// Copy constructor
	tagProduit(const  tagProduit & Data)
	{
		m_DescriptionCode=NULL;
		m_DescriptionIndexBac=NULL;
		m_DescriptionIndexComplexe=NULL;
		*this=Data;
	};



	~tagProduit()
	{
		for(int duree=0;duree<m_Duree;duree++)
		{
			m_DescriptionCode[duree].RemoveAll();
			m_DescriptionIndexBac[duree].RemoveAll();
			m_DescriptionIndexComplexe[duree].RemoveAll();
		}
		if(m_DescriptionCode!=NULL)
		{
			delete[] m_DescriptionCode;
		}
		if(m_DescriptionIndexBac!=NULL)delete[] m_DescriptionIndexBac;
		if(m_DescriptionIndexComplexe!=NULL)delete[] m_DescriptionIndexComplexe;
	}

	void SetDuree(int duree){
		ASSERT(duree>0);
		m_Duree=duree;
		if(m_DescriptionCode!=NULL)delete[] m_DescriptionCode;
		if(m_DescriptionIndexBac!=NULL)delete[] m_DescriptionIndexBac;
		if(m_DescriptionIndexComplexe!=NULL)delete[] m_DescriptionIndexComplexe;
		m_DescriptionIndexComplexe = new CWordArray [duree];
		m_DescriptionIndexBac = new CWordArray  [duree];
		m_DescriptionCode = new CStringArray [duree];
	};

	int GetDuree(){return(m_Duree);};

	LPCSTR GetCodeComplexeBac(int periode,int index){return m_DescriptionCode[periode].GetAt(index); }

	int GetIndexBac(int periode,int index){return m_DescriptionIndexBac[periode].GetAt(index);}

	int GetIndexComplexe(int periode,int index){return m_DescriptionIndexComplexe[periode].GetAt(index);}

	// Particularisation des fonctions de CtagTable
	LPCSTR GetLibelle(){return(m_Libelle);};
	LPCSTR GetCode(){return(m_Code);};
	

	
};

// Tableau de BAC
//typedef CArray<tagBAC,tagBAC&> CTabBAC;
typedef CTable<tagProduit,tagProduit&> CTableProduitMere;
class CTableProduit : public CTableProduitMere   
{
public:
	void RemplaceCodeComposition(CString oldcode,CString newcode);
	void Tri();
	bool SaveTable();
	bool LoadTable();
	CTableProduit();
	virtual ~CTableProduit();

	// copy constructor
	CTableProduit::CTableProduit(const  CTableProduit & Data);
	CTableProduit & operator=(const  CTableProduit & Data)
	{
		Copy(Data);
		IsModified=Data.IsModified;
		m_NomFich=Data.m_NomFich;
		return *this;
	};
	int IsModif()
	{
		return IsModified; 
	};
	void SetModified(int modif)
	{
		IsModified = modif;
	};

private:
	void Decale(int idproduit);
	bool VerifTable();
	CString m_NomFich;
	int IsModified;
};

#endif // !defined(AFX_TABLEPRODUIT_H__66A1830E_CA82_4B58_9FFC_CAED061A8F0F__INCLUDED_)
