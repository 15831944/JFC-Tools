// SelectionProduit.cpp: implementation of the CSelectionProduit class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "cinema.h"
#include "SelectionProduit.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSelectionProduit::CSelectionProduit()
{

}

CSelectionProduit::~CSelectionProduit()
{

}
