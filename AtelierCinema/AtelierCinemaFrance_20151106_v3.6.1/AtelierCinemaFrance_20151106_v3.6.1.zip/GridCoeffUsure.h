#if !defined(AFX_GRIDCOEFFUSURE_H__308556D2_EEF1_43CF_A2A9_65E5590B63A9__INCLUDED_)
#define AFX_GRIDCOEFFUSURE_H__308556D2_EEF1_43CF_A2A9_65E5590B63A9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GridCoeffUsure.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGridCoeffUsure window

class CGridCoeffUsure : public CGXGridWnd
{
// Construction
public:
	CGridCoeffUsure();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGridCoeffUsure)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGridCoeffUsure();

	// Generated message map functions
protected:
	//{{AFX_MSG(CGridCoeffUsure)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GRIDCOEFFUSURE_H__308556D2_EEF1_43CF_A2A9_65E5590B63A9__INCLUDED_)
