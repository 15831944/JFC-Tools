// Testgrid.cpp : implementation file
//

#include "stdafx.h"
#include "cinema.h"
#include "Testgrid.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestgrid dialog


CTestgrid::CTestgrid(CWnd* pParent /*=NULL*/)
	: CDialog(CTestgrid::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestgrid)
	//}}AFX_DATA_INIT
}


void CTestgrid::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestgrid)
	DDX_Control(pDX, IDC_CIBLES, m_Cibles);
	DDX_Control(pDX, IDOK, m_Ok);
	DDX_Control(pDX, IDCANCEL, m_Cancel);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTestgrid, CDialog)
	//{{AFX_MSG_MAP(CTestgrid)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_LBUTTONDBLCLK()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestgrid message handlers

int CTestgrid::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	BOOL RET = m_grid.CreateGrid(WS_CHILD | WS_VISIBLE, CRect(0,0,0,0), this, IDC_UGRID);

	return 0;
}

void CTestgrid::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	if (cx > 480) cx = 480;
	if (cy > 350) cy = 350;

	m_grid.MoveWindow (150, 150, cx, cy);	
}

void CTestgrid::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	m_grid.StartEdit();

	// appelle le gestionnaire de base
	CDialog::OnLButtonDblClk(nFlags, point);
}

BOOL CTestgrid::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	m_Cibles.ResetContent();

	m_Cibles.AddString ("Ensemble 15-24 ans");
	m_Cibles.AddString ("6 ans et +");
	m_Cibles.AddString ("15 ans et +");
	return TRUE; 
}
