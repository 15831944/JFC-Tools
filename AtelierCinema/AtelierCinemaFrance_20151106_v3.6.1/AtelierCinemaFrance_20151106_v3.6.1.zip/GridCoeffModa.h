#if !defined(AFX_GRIDCOEFFMODA_H__FD6F2E14_72CC_4C65_80FF_48B2CD0DD018__INCLUDED_)
#define AFX_GRIDCOEFFMODA_H__FD6F2E14_72CC_4C65_80FF_48B2CD0DD018__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GridCoeffModa.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGridCoeffModa window

class CGridCoeffModa : public CGXGridWnd
{
// Construction
public:
	CGridCoeffModa();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGridCoeffModa)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGridCoeffModa();

	// Generated message map functions
protected:
	//{{AFX_MSG(CGridCoeffModa)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GRIDCOEFFMODA_H__FD6F2E14_72CC_4C65_80FF_48B2CD0DD018__INCLUDED_)
