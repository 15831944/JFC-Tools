// Tarif.cpp: implementation of the CTarif class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Tarif.h"
#include "locale.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#include "CAlendrierHebdoCinema.h"
#include "CFichierCinema.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTarif::CTarif()
{
	m_flagErreurFic=0;
}

CTarif::~CTarif()
{
	FreeTarif();
}

// importation d'un fichier de tarif dans la table des tarifs
bool CTarif::ImportFile()
{
	return (1);
}

bool CTarif::InitialiseExercice(COleDateTime date, int nbsemaine)
{

	FreeTarif();

	// initalisation de la date de l'exercice
	m_Exercice = date;
	// initalisation de la dur�e de l'exercice
	m_Duree = nbsemaine;
	return(1);

}
CByteArray *  CTarif::GetTarif(LPCSTR Code)
{
	int index;
	if(!m_MapCodeToIndex.Lookup(Code,index))
	{
		// Chargement du tarif
		 index = LoadTarif(Code);
	}
	return m_TarifSemaine.GetAt(index);
}

double  CTarif::GetTarif(LPCSTR Code,int semaine,int park)
{

	double  tarif;
	int index;
	if(!m_MapCodeToIndex.Lookup(Code,index))
	{
		// Chargement du tarif
		index = LoadTarif(Code);
	}
	tarif = m_TarifLoaded[index]->GetAt(semaine);
	
	// TODO gestion du park
	tarif/=2; // AVIRER
	// --------------------
	
	return tarif;
}
	

// Retourne l'index du tarif charg�
// Si le Code n'est pas trouv�, un tarif � -1 est construit

int CTarif::LoadTarif(LPCSTR Code)
{
	setlocale( LC_ALL, "C" );
	// tableau pour le stockage de l'indication tarif
	CByteArray  * indictarif=new CByteArray();
	indictarif->SetSize(53);
	// tableau pour le stockage des tarifs
	CDoubleArray * tarifs=new CDoubleArray;

	CDoubleArray tarifsTemp;
	tarifsTemp.SetSize(53);

	COleDateTime newDate;

	// l'ann�e du fichier charg�
	int an=-1;

	// le calendrier pour savoir quelle semaine on est
	CCAlendrierHebdoCinema cal;

	// recherche du Code
	for(int i=0;i<m_Duree;i++)
	{
		COleDateTimeSpan span(7*i,0,0,0);	
		newDate = m_Exercice + span;
		int neewannee=cal.GetAnnee(newDate);
		if(an!=neewannee)
		{
			
			an = cal.GetAnnee(newDate);

			// Pour simplifier le code on commence � initialiser
			// le tarifs par de -1.
			for(int j=0;j<53;j++)
			{
				double d=-1;
				tarifsTemp.SetAt(j,d);
				indictarif->SetAt(j,0);
			}
		
			// on charge le fichier					
			CString nomFich,txt;
			if(m_flagErreurFic!=an)
			{
				nomFich.Format("Tarif%d.table",an);		
				// Le fichier
				CFichierCinema Fichier;

#ifdef _DEBUG
				if(Fichier.OpenFileForRead(nomFich,1))
#else
				if(Fichier.OpenFileForRead(nomFich,0))
#endif
				{
					while(Fichier.ReadLine())
					{	
						
						txt = Fichier.GetElement(0);

						// lecture du Code et controle
						if(Code==txt)
						{
						
							for(int j=1;j<54;j++)
							{
								double d = atof(Fichier.GetElement(j));	
								tarifsTemp.SetAt(j-1,d);
								indictarif->SetAt(j-1,1);
							}
							break;
						}
						
					}
					// fermeture du fichier	
					Fichier.Close(); 	
				}
				else m_flagErreurFic=an;
			}
		
		}		
	
		// ici Le fichier charg� est bon
		int semaine = cal.GetIndexSemaine(newDate);

		float TmpTarif = tarifsTemp[semaine];

		tarifs->Add(tarifsTemp[semaine]); 
	}

	// Maintenant on ajoute ce tarif dans le gros tableau
	int index=m_TarifLoaded.Add(tarifs);

	// Ajoute dans le map ce tarif
	m_MapCodeToIndex.SetAt(Code,index);
	setlocale(LC_ALL,"");
	// Ajout indication de tarif
	m_TarifSemaine.Add(indictarif);
	return(index);
}

void CTarif::FreeTarif()
{
	ASSERT(AfxCheckMemory());


	// Lib�ration des instances des tarifs qui ont �t� charg�s
	for(int i=0;i<m_TarifLoaded.GetSize();i++)
	{
		CDoubleArray *p=m_TarifLoaded[i];
		delete [] p;
	}
	// indication de tarif
	for(i=0;i<m_TarifSemaine.GetSize();i++)
	{
		m_TarifSemaine.GetAt(i)->RemoveAll();
		delete m_TarifSemaine.GetAt(i);
	}
	m_TarifSemaine.RemoveAll();
	// reset tableau et du map.
	m_TarifLoaded.RemoveAll();
	m_MapCodeToIndex.RemoveAll();

	// pour vraiment provoquer un plantage s'il y a d'autres acc�s
	m_Duree=0;
}


// sauvegarde des tarifs: employ�e exclusivvement pour la maintenance
// tous les tarifs ont �t� charg�s

int CTarif::SaveTarif()
{

/*	int size = m_TarifLoaded.GetSize();
		
	// on charge le fichier					
	CString nomFich,txt;				
	//nomFich.Format("Tarif%d.table",an);		

	// Le fichier		
	CFichierCinema Fichier;		
	Fichier.OpenFileForRead(nomFich);		

	// bouclage sur tous les codes
	if(Fichier.OpenFileForWrite(nomFich))
	{

	for(int i=0;i<m_TarifLoaded.GetSize();i++)
	{
		
	}
	FreeTarif();
	}*/
	return(0);
}
