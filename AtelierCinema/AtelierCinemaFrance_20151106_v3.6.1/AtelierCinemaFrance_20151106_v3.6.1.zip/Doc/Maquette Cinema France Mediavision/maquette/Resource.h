//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by maquette.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MAQUETTE_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDC_LIST1                       1000
#define IDC_BUTTON2                     1002
#define IDC_BUTTON3                     1003
#define IDC_BUTTON4                     1004
#define IDC_BUTTON5                     1005
#define IDC_BUTTON6                     1006
#define IDC_EDIT1                       1006
#define IDC_BUTTON7                     1007
#define IDC_EDIT2                       1007
#define IDC_SPIN1                       1008
#define IDC_CHECK1                      1009
#define IDC_CHECK2                      1013
#define IDC_CHECK3                      1014
#define IDC_CHECK4                      1015
#define IDC_CHECK5                      1016
#define IDC_CHECK6                      1017
#define IDC_CHECK7                      1018
#define IDC_CHECK8                      1019
#define IDC_CHECK9                      1020
#define IDC_CHECK10                     1021
#define IDC_CHECK11                     1022
#define IDC_CHECK12                     1023
#define IDC_CHECK13                     1024
#define IDC_CHECK14                     1025
#define IDC_CHECK15                     1026
#define IDC_CHECK16                     1027
#define IDC_CHECK17                     1028
#define IDC_CHECK18                     1029
#define IDC_CHECK19                     1030
#define IDC_CHECK20                     1031

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
