// TableRegie.h: interface for the CTableRegie class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TABLEREGIE_H__C917DC15_08B5_44C7_9A05_B5C7525FF63B__INCLUDED_)
#define AFX_TABLEREGIE_H__C917DC15_08B5_44C7_9A05_B5C7525FF63B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// On d�finit une structure contenant les param�tres du BAC : code et libell�

class CTableRegie 
{
private:
	class tagRegie
	{
	public:
		CString m_Regie;
		CString m_Libelle;
	};

	tagRegie m_RegieA;
	tagRegie m_RegieM;
	tagRegie m_RegieN;
	tagRegie m_Proba;
	tagRegie m_Tous;
public:
	// constructeur
	CTableRegie()
	{
		m_RegieA.m_Regie = "A";
		m_RegieA.m_Libelle="Canal +";
		m_RegieM.m_Regie = "M";
		m_RegieM.m_Libelle = "M�diavision";
		m_RegieN.m_Regie = "N";
		m_RegieN.m_Libelle = "Ind�pendants";
		m_Proba.m_Regie  = "P";
		m_Proba.m_Libelle = "Probabilis�";
		m_Tous.m_Libelle = "Tous";
	};

	// destructeur
	~CTableRegie(){};

	// r�cup�ration de la r�gie
	CString GetRegie(const CString &type) 
	{
		if(type=="A")return m_RegieA.m_Regie;
		if(type=="M")return m_RegieM.m_Regie;
		if(type=="N")return m_RegieN.m_Regie;
		if(type=="P")return m_Proba.m_Regie;
		return "";
	}
	// r�cup�ration du libell�
	CString GetLibelle(const CString &type)
	{
		if(type=="A")return m_RegieA.m_Libelle;
		if(type=="M")return m_RegieM.m_Libelle;
		if(type=="N")return m_RegieN.m_Libelle;
		if(type=="P")return m_Proba.m_Libelle;
		if(type=="T")return m_Tous.m_Libelle;
		else return "";
	}

};

#endif // !defined(AFX_TABLEREGIE_H__C917DC15_08B5_44C7_9A05_B5C7525FF63B__INCLUDED_)
