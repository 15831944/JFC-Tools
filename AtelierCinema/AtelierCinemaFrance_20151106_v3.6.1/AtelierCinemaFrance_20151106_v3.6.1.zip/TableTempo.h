// TableTempo.h: interface for the CTableTempo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TABLETEMPO_H__052554D9_EF06_4FD8_BCE1_CF7782D8E752__INCLUDED_)
#define AFX_TABLETEMPO_H__052554D9_EF06_4FD8_BCE1_CF7782D8E752__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Table.h"

// On d�finit une structure contenant les tempos
class tagTempo : public CtagTable
{
public:
	bool GetPassage(int numsemaine,int park);
	
	// d�finition du tempo
	CString m_Definition;

	// p�riode active
	int m_periode;

	// libell� du tempo
	CString m_Libelle;

	tagTempo & operator=(const  tagTempo & Data)
	{
		m_Libelle=Data.m_Libelle;
		m_Definition=Data.m_Definition;
		m_periode = Data.m_periode;
		return *this;
	};
	
	// Neutral constructor
	tagTempo(){};
	// Copy constructor
	tagTempo(const  tagTempo & Data)
	{
		*this=Data;
	};

	// Particularisation des fonctions de CtagTable
	LPCSTR GetLibelle(){return(m_Libelle);};
	LPCSTR GetCode(){return(0);};


	
};

// Tableau de BAC
//typedef CArray<tagTempo,tagTempo&> CTabBAC;
typedef CTable<tagTempo,tagTempo&> CTableTempoMere;

class CTableTempo : public  CTableTempoMere
{
public:
	int ExisteLibelleTempo(CString libelle);
	bool SaveTable();
	int GetPeriode(int position);
	bool LoadTable();
	CTableTempo & operator=(const  CTableTempo & Data)
	{
			Copy(Data);
			m_NomFich=Data.m_NomFich;
			IsModified=Data.IsModified;
			return *this;
	};

	CTableTempo();
	// copy constructor
	CTableTempo(const  CTableTempo & Data);
	virtual ~CTableTempo();
	int IsModif()
	{
		return IsModified; 
	};
	void SetModified(int modif)
	{
		IsModified = modif;
	};


private:
	CString m_NomFich;
	int IsModified;
};

#endif // !defined(AFX_TABLETEMPO_H__052554D9_EF06_4FD8_BCE1_CF7782D8E752__INCLUDED_)
