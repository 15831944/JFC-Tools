// TableProduit.cpp: implementation of the CTableProduit class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TableProduit.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTableProduit::CTableProduit()
{
	m_NomFich="produit.table";
	SetName(m_NomFich);
	IsModified=0;

}

CTableProduit::~CTableProduit()
{
}

// copy constructor
CTableProduit::CTableProduit(const  CTableProduit & Data)
{	
		*this=Data;
};

bool CTableProduit::LoadTable()
{
	RemoveAll();
	// On charge le fichier des produits dans la table
	CString nomdef;
	CString Code;


	// NOTE DE REMI (CORRECTION BUG DU 19/01/2004)
	// On n'utilise pas de noms de variables m_ pour des variables locales !!!!
	CFichierCinema Fichier;

	if(!Fichier.OpenFileForRead(m_NomFich,1))
	{
		return (0);
	} 
	
	// On lit toutes les entr�es que l'on place dans la table 
	// lecture tant que la ligne n'est pas un '#'
	while(Fichier.ReadLine())
	{
		tagProduit enr;
		CString ChaineMessage;
		bool message=0;
		// On stocke d'abord le code du produit
		enr.m_Code = Fichier.GetElement(0) ;
		// le code est il valide ?: 6 caract�res
		if(enr.m_Code.GetLength()>6)
		{
			message=1;
			ChaineMessage="\nLe code est sup�rieur � 6 caract�res";
			enr.m_Code = enr.m_Code.Left(6);
		}
		// le libell� est limit� � 30 caract�res
		enr.m_Libelle = Fichier.GetElement(1);
		if(enr.m_Libelle.GetLength()>30)
		{
			message=1;
			ChaineMessage+="\nLe libell� est sup�rieur � 30 caract�res";
			enr.m_Libelle = enr.m_Libelle.Left(30);
		}

		// On enl�ve les espaces se trouvant apr�s le libell�
		enr.m_Libelle.TrimRight();

		// l'indicateur : produit libre ou fig� : 1 caract�re
		int duree = atoi(Fichier.GetElement(2));
		// le produit est-il fig�?
		if(duree!=0)
		{
			enr.m_flagProduitFige = 1;
			enr.SetDuree(duree);

		}
		else{

			enr.m_flagProduitFige = 0;
			enr.SetDuree(1);
		}


		// Ouverture du fichier de d�finition
		nomdef = "Definition"+	enr.m_Code + ".table"; 
		CFichierCinema FichierDef;

		if(!FichierDef.OpenFileForRead(nomdef,1))
		{
			return (0);
		} 
		int semaine=0;
		while(FichierDef.ReadLine()) //le # stoppe la lecture
		{
			// pour les produits, le s�parateur de description est une "*" 
			// dans ce cas on passe � la semaine suivante
			if(FichierDef.GetElement(0)[0]=='*')
			{
				semaine++;
				ASSERT(semaine<enr.GetDuree());
			}
			else
			{
				// on ajoute tous les �l�ments du fichier de d�finition
				ASSERT(semaine<enr.GetDuree());
				enr.m_DescriptionCode[semaine].Add(FichierDef.GetElement(0));   
				
			}
		}
		// Si le produit est fig�, on controle que le fichier contient bien le nombre de semaines indiqu�es  
		if((enr.GetDuree()>1)&&((semaine+1)!=enr.GetDuree()))
		{
			CString txt;
			txt.Format("Ce produit fig� est mal d�crit dans le fichier:%s !!",nomdef); 
			AfxMessageBox(txt,MB_OK | MB_APPLMODAL);	
			return(1);

		}
		if(message)
		{
			AfxMessageBox("le format du fichier: "+m_NomFich+" n'est pas valide"+ChaineMessage,MB_OK | MB_APPLMODAL);   
		}
		FichierDef.Close(); 
		// On ajoute l'enregistrement dans le tableau
		int index = Add(enr);
		// on ajoute l'index de l'�l�ment dans un map m�moire
		Code = enr.GetCode();
		m_MapCodeToIndex.SetAt(enr.GetCode(),index);
	}

	if(GetSize()==0)
	{
		AfxMessageBox("La table des produits est vide",MB_OK | MB_APPLMODAL);	
	}

	// fermeture du fichier
	Fichier.Close(); 
	return (1);

	VerifTable();
}

bool CTableProduit::VerifTable()
{

	// Pas deux fois le m�me complexe:OK

	for(int p=0;p<GetSize();p++)
	{
		tagProduit Prod=GetAt(p);
		for(int s=0;s<Prod.GetDuree();s++)
		{
			for(int c=0;c<Prod.m_DescriptionIndexComplexe->GetSize();c++)
			{
				for(int c2=c+1;c2<Prod.m_DescriptionIndexComplexe->GetSize();c2++)
				{
					if(Prod.m_DescriptionIndexComplexe->GetAt(c)==Prod.m_DescriptionIndexComplexe->GetAt(c2))
					{
						AfxMessageBox("PB dans v�rifTable de CTableProduit: un complexe est repr�sent� 2 fois.");
						return 0;
					}
				}
			}
			// Pas deux fois le m�me bac

			for(int bac=0;bac<Prod.m_DescriptionIndexBac->GetSize();bac++)
			{
				for(int bac2=bac+1;bac2<Prod.m_DescriptionIndexBac->GetSize();bac2++)
				{
					if(Prod.m_DescriptionIndexBac->GetAt(bac)==Prod.m_DescriptionIndexBac->GetAt(bac2))
					{
						AfxMessageBox("PB dans v�rifTable de CTableProduit: un bac est repr�sent� 2 fois.");
						return 0;
					}
				}
			}
		}
	}
	return 1;
}



bool CTableProduit::SaveTable()
{
	// sauvegarde
	CString txt;

	// la table a �t� modifi�
	IsModified = 0;

	CString momdef;
	CFichierCinema Fichier;

	if(!Fichier.OpenFileForWrite(m_NomFich))
	{
		return (0);	
	}
	for(int i=0;i<GetSize();i++)
	{
		// sauvegarde du code de produit
		txt=GetCode(i);
		// s�parateur
		txt+="|";
		// sauvegarde du libell� de produit
		CString Libelle = GetLibelle(i);
		if(Libelle.GetLength()>=30)
		{
			txt+=Libelle.Left(30); 
		}
		// on ajoute des espaces
		else
		{	while(Libelle.GetLength()!=30)
			{
				Libelle+=" ";
			}
			txt+=Libelle;
		}
		txt+="|";
		// sauvegarde de la dur�e
		if(!GetAt(i).m_flagProduitFige) 
		{
			txt.Format(txt+"0");
		}
		else
		{
			txt.Format(txt+"%d",GetAt(i).GetDuree());
		}
		txt+="\n";
		if(!Fichier.WriteLine(txt))return(0);
		
		momdef ="Definition";	
		momdef+=GetCode(i) ;
		momdef+=".table"; 
		CFichierCinema FichierDef;
		if(!FichierDef.OpenFileForWrite(momdef))
		{
			return (0);
		} 
		// On boucle sur la dur�e pour les produits fig�s
		// si le produit n'est pas fig�, la dur�e vaut 1
		int duree = GetAt(i).GetDuree();
		for(int d=0;d<duree;d++)
		{
			int size = GetAt(i).m_DescriptionCode[d].GetSize();
			for(int j=0;j<size;j++)
			{
				// On �crit tous les codes de complexe dans le fichier
				if(!FichierDef.WriteLine(GetAt(i).m_DescriptionCode[d].GetAt(j)+"\n")) return(0);
			}
			// caract�re de s�paration 
			if((duree!=1)&&(d<duree-1))
			{
				if(!FichierDef.WriteLine("*\n"))return(0);
			}
		
		}
		// caract�re de fin de fichier
		if(!FichierDef.WriteLine("#"))return(0);
			
		// fermeture du fichier
		FichierDef.Close(); 
	}
	// caract�re de fin de fichier
	if(!Fichier.WriteLine("#"))return(0);
	// fermeture du fichier
	Fichier.Close(); 
	return (1);
}

// Tri des produits par code
// Tri par ordre croissant

void CTableProduit::Tri()
{
	// tableau pour le stockage des codes alphanum�riques
	tagProduit * tabAlpha = new tagProduit[GetSize()];
	int count=0;
	
	for(int p=0;p<GetSize();p++)
	{

		tagProduit enr;
		enr = GetAt(p);
		for(int p2=p+1;p2<GetSize();p2++)
		{
			tagProduit enr2;
			enr2 = GetAt(p2);
			int code1,code2;
			CString chainecode1,chainecode2;

			chainecode1 = enr.m_Code.Right(5);
			chainecode2 = enr.m_Code.Right(5);
			
			code1 = atoi(chainecode1);
			code2 = atoi(chainecode2);

			for(int c=0;c<5;c++)
			{
				// les codes alphanum�riques sont ajout�s � la fin
				if((chainecode1.GetAt(c)<=47)||(chainecode1.GetAt(c)>=58))
				{
					tabAlpha[count]=enr;
					Decale(p);
					count++;
					IsModified=1;
					goto label;
				}
				if((chainecode2.GetAt(c)<=47)||(chainecode2.GetAt(c)>=58))
				{
					tabAlpha[count]=enr2;
					Decale(p2);
					count++;
					IsModified=1;
					break;
				}
				
			}

			if(code2<code1)
			{
				SetAt(p,enr2);
				SetAt(p2,enr);
				IsModified=1;

			}
		}
label:;
	}
	// On ajoute ensuite les codes alphanum�riques
	for(int code=0;code<count;code++)
	{
		SetAt(GetSize()-code-1,tabAlpha[code]);
	}

/*	for(int c2=0;c2<GetSize();c2++)
	{
		TRACE("code n�%d:%s\n",c2,GetAt(c2).m_Code);
	}*/
	delete [] tabAlpha;
}

void CTableProduit::Decale(int idproduit)
{
	for(int id=idproduit+1;id<GetSize();id++)
	{
		tagProduit enr=GetAt(id);
		SetAt(id-1,enr);
	}
}

// cherche dans la table que sont les produits utilisant le code
// remplace l'ancien code par le nouveau
void CTableProduit::RemplaceCodeComposition(CString oldcode, CString newcode)
{
	// On boucle sur les produits
	for(int idxprod=0;idxprod<GetSize();idxprod++)
	{
		tagProduit produit = GetAt(idxprod);
		// On boucle sur la dur�e
		for(int duree=0;duree<produit.GetDuree();duree++)
		{

			// On boucle sur la composition en complexe
			int size = produit.m_DescriptionCode[duree].GetSize(); 
			for(int code=0;code<size;code++)
			{
				CString m_code = produit.m_DescriptionCode[duree].GetAt(code);
				if(oldcode==m_code)
				{
					// remplacement du code
					produit.m_DescriptionCode[duree].SetAt(code,newcode);
					SetAt(idxprod,produit);
					// la table est modifi�e
					SetModified(1);
					break; // changement de semaine
				}
			}
		}
	}	
}
