// TableProduitFilm.cpp: implementation of the CTableProduitFilm class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "cinema.h"
#include "ProduitFilm.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTableProduitFilm::CTableProduitFilm()
{
}

CTableProduitFilm::~CTableProduitFilm()
{
}

///////////////////////////////////////////////////////////////////////////////////////
// Initialise tableau produit-films
//
void CTableProduitFilm::InitTabProduitFilm()
{
	
	// Init crit�re et nb modalit�s pour coeff fr�q et pluri-fr�q.
	m_NrCritCoeff     = 0;
	m_NbModaliteCoeff = 0;

}

///////////////////////////////////////////////////////////////////////////////////////
// Ajout d'un produit films
//
bool CTableProduitFilm::AddFilm(CProduitFilm ProduitFilm)
{
	(*this).Add(ProduitFilm); 
	return true;
}

///////////////////////////////////////////////////////////////////////////////////////
// Suppression d'un produit film
//
void CTableProduitFilm::SuppFilm(CString LibelleFilm)
{
	CProduitFilm ProduitFilm;
//	int InxFilmSupp;

	// Recherche index de l'�l�ment
	for (int i = (*this).GetSize()-1; i >= 0;i--)
	{
		// Capte le produit
		ProduitFilm = (*this).GetAt(i);

		// Libell� produit trouv�, on le vire
		if (ProduitFilm.m_Libelle == LibelleFilm)
			(*this).RemoveAt(i);
	}

}

