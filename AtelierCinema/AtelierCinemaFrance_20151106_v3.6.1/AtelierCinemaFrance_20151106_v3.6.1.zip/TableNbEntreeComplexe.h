// TableNbEntreeComplexe.h: interface for the CTableNbEntreeComplexe class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TABLENBENTREECOMPLEXE_H__4807F846_94E4_4FF2_B77D_75E13AF7B8EE__INCLUDED_)
#define AFX_TABLENBENTREECOMPLEXE_H__4807F846_94E4_4FF2_B77D_75E13AF7B8EE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Table.h"

// On d�finit une structure contenant le nombre d'entr�es pour un complexe donn�
class tagNbEntree : public CtagTable
{
public:
	
	// code du complexe
	CString m_CodeComplexe;
	// nb d'entr�e associ�e au complexe
	int m_NbEntree;
	tagNbEntree & operator=(const  tagNbEntree & Data)
	{
		m_CodeComplexe=Data.m_CodeComplexe;
		m_NbEntree=Data.m_NbEntree;
		return *this;
	};
	// Neutral constructor
	tagNbEntree(){
		m_NbEntree=0;
	}
	// Copy constructor
	tagNbEntree(const  tagNbEntree & Data)
	{
		*this=Data;
	};

	int GetNbEntree(){return(m_NbEntree);};
	LPCSTR GetLibelle(){return(0);};
	LPCSTR GetCode(){return(m_CodeComplexe);};
	void SetNbEntree(int NbEntree)
	{
		m_NbEntree=NbEntree;
	};

};
typedef CTable<tagNbEntree,tagNbEntree&> CTableEntreeMere;

class CTableNbEntreeComplexe : public  CTableEntreeMere
{
public:
	void Decale(int idnbentree);
	void Tri();
	CTableNbEntreeComplexe & operator=(const  CTableNbEntreeComplexe & Data)
	{
		Copy(Data);
		IsModified=Data.IsModified;
		m_NomFich=Data.m_NomFich;
		return *this;
	};

	bool SaveTable();
	bool LoadTable();
	CTableNbEntreeComplexe();
	virtual ~CTableNbEntreeComplexe();
	CTableNbEntreeComplexe(const  CTableNbEntreeComplexe & Data);
	int IsModif()
	{
		return IsModified; 
	};
	void SetModified(int modif)
	{
		IsModified = modif;
	};


private:
	CString m_NomFich;
	int IsModified;
};

#endif // !defined(AFX_TABLENBENTREECOMPLEXE_H__4807F846_94E4_4FF2_B77D_75E13AF7B8EE__INCLUDED_)
