// CarreCouleur.cpp : implementation file
//

#include "stdafx.h"
#include "cinema.h"
#include "CarreCouleur.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCarreCouleur

CCarreCouleur::CCarreCouleur()
{
}

CCarreCouleur::~CCarreCouleur()
{
}


BEGIN_MESSAGE_MAP(CCarreCouleur, CStatic)
	//{{AFX_MSG_MAP(CCarreCouleur)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCarreCouleur message handlers
