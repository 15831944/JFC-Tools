#if !defined(AFX_TESTGRID_H__E6EBE022_9820_44CF_B05C_E8CD31CA1AD9__INCLUDED_)
#define AFX_TESTGRID_H__E6EBE022_9820_44CF_B05C_E8CD31CA1AD9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Testgrid.h : header file
//

#include "myCUG.h"

/////////////////////////////////////////////////////////////////////////////
// CTestgrid dialog

class CTestgrid : public CDialog
{
// Construction
public:
	CTestgrid(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTestgrid)
	enum { IDD = IDD_TESTUGRID };
	CComboBox	m_Cibles;
	CButton	m_Ok;
	CButton	m_Cancel;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestgrid)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTestgrid)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	// Grid object
	MyCug m_grid;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTGRID_H__E6EBE022_9820_44CF_B05C_E8CD31CA1AD9__INCLUDED_)
