// SelectionProduit.h: interface for the CSelectionProduit class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SELECTIONPRODUIT_H__5BF03057_DC9A_4AA0_8922_4A5A58E2187F__INCLUDED_)
#define AFX_SELECTIONPRODUIT_H__5BF03057_DC9A_4AA0_8922_4A5A58E2187F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CSelectionProduit  
{
public:
	CSelectionProduit();
	virtual ~CSelectionProduit();

};

#endif // !defined(AFX_SELECTIONPRODUIT_H__5BF03057_DC9A_4AA0_8922_4A5A58E2187F__INCLUDED_)
