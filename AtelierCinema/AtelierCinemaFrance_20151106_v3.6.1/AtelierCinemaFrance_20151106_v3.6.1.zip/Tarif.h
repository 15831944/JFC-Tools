// Tarif.h: interface for the CTarif class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TARIF_H__182EB195_B10B_4820_BF83_065B5F89AD9A__INCLUDED_)
#define AFX_TARIF_H__182EB195_B10B_4820_BF83_065B5F89AD9A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

typedef CArray<double,double&> CDoubleArray;

class CTarif  
{
public:
	int SaveTarif();
	double GetTarif(LPCSTR code,int semaine,int park);
	// retourne une indication de pr�sence du tarif pour un code 
	CByteArray * GetTarif(LPCSTR code);

	bool InitialiseExercice(COleDateTime date,int nbsemaine);
	bool ImportFile();
	CTarif();
	virtual ~CTarif();

private:
	COleDateTime m_Exercice;
	int m_Duree;
	// flag pour la gestion d'erreur lors de l'ouverture des fichiers
	// par ex: Si l'exercice de la campagne est tr�s long et que l'on ne dispose du fichier correspondant � l'ann�e
	// Un message d'erreur apparait �  chaque fois que l'on charge le tarif d'un code
	// Ca flag permet l'unicit� du message d'erreur
	int m_flagErreurFic;
	// map indication pr�sence de tarif d�finie par [indexcode][semaine] 
	CArray <CByteArray*,CByteArray*> m_TarifSemaine;
	CMap<CString,LPCSTR,int,int&> m_MapCodeToIndex;
	int LoadTarif(LPCSTR code);
	CArray<CDoubleArray*,CDoubleArray*> m_TarifLoaded;
	//CArray<CDoubleArray*,CDoubleArray*> m_TarifLoaded2; // TODO lorsque l'on dispose des tarifs par parcs
	void FreeTarif();
};

#endif // !defined(AFX_TARIF_H__182EB195_B10B_4820_BF83_065B5F89AD9A__INCLUDED_)
