// TestPSGeoView.h : interface of the CTestPSGeoView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TESTPSGEOVIEW_H__2D0B1CC2_A5BF_11D2_81F5_00C04F646E9F__INCLUDED_)
#define AFX_TESTPSGEOVIEW_H__2D0B1CC2_A5BF_11D2_81F5_00C04F646E9F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

USE_GEOMETRY_TEMPLATES;
/////////////////////////////////////////////////////////////////////////////
// CAddedPage dialog

class CAddedPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CAddedPage)
	DECLARE_GEOMETRY_RTSUPPORT();

// Construction
public:
	CAddedPage();
	~CAddedPage();

// Dialog Data
	//{{AFX_DATA(CAddedPage)
	enum { IDD = IDD_DIALOG1 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CAddedPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CAddedPage)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
/////////////////////////////////////////////////////////////////////////////
// CAddedPage2 dialog

class CAddedPage2 : public CPropertyPage
{
	DECLARE_DYNCREATE(CAddedPage2)
	DECLARE_GEOMETRY_RTSUPPORT();

// Construction
public:
	CAddedPage2();
	~CAddedPage2();

// Dialog Data
	//{{AFX_DATA(CAddedPage2)
	enum { IDD = IDD_DIALOG2 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CAddedPage2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CAddedPage2)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////
// CProp

class CProp : public CPropertySheet
{
	DECLARE_DYNAMIC(CProp)
	DECLARE_GEOMETRY_RTSUPPORT();

// Construction
public:
	CProp(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CProp(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes
public:
	CGeometryWnd<CAddedPage>	m_page1;
	CGeometryWnd<CAddedPage2>	m_page2;
//	CAddedPage	m_page1;
//	CAddedPage2	m_page2;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProp)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CProp();

	// Generated message map functions
protected:
	//{{AFX_MSG(CProp)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
class CTestPSGeoView : public CFormView
{
protected: // create from serialization only
	CTestPSGeoView();
	DECLARE_DYNCREATE(CTestPSGeoView)
	DECLARE_GEOMETRY_RTSUPPORT();

	CGeometryWnd<CProp>	m_ps;

// Attributes
public:
	CTestPSGeoDoc* GetDocument();

// Operations
public:

	enum { IDD = IDD_DIALOG0 };
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestPSGeoView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTestPSGeoView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTestPSGeoView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

DECLARE_GEOMETRY_DYNCREATE(CTestPSGeoView);

#ifndef _DEBUG  // debug version in TestPSGeoView.cpp
inline CTestPSGeoDoc* CTestPSGeoView::GetDocument()
   { return (CTestPSGeoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTPSGEOVIEW_H__2D0B1CC2_A5BF_11D2_81F5_00C04F646E9F__INCLUDED_)
