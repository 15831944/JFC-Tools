//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestPSGeo.rc
//
#define IDD_ABOUTBOX                    100
#define ID_VIEW_ARRANGE                 127
#define IDR_MAINFRAME                   128
#define IDR_TESTPSTYPE                  129
#define IDD_DIALOG1                     130
#define IDD_DIALOG2                     131
#define IDD_DIALOG0                     132
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_LIST1                       1002
#define IDC_LIST2                       1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
