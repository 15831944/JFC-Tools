// TestPSGeoDoc.cpp : implementation of the CTestPSGeoDoc class
//

#include "stdafx.h"
#include "TestPSGeo.h"

#include "TestPSGeoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestPSGeoDoc

IMPLEMENT_DYNCREATE(CTestPSGeoDoc, CDocument)

BEGIN_MESSAGE_MAP(CTestPSGeoDoc, CDocument)
	//{{AFX_MSG_MAP(CTestPSGeoDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestPSGeoDoc construction/destruction

CTestPSGeoDoc::CTestPSGeoDoc()
{
	// TODO: add one-time construction code here

}

CTestPSGeoDoc::~CTestPSGeoDoc()
{
}

BOOL CTestPSGeoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CTestPSGeoDoc serialization

void CTestPSGeoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTestPSGeoDoc diagnostics

#ifdef _DEBUG
void CTestPSGeoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTestPSGeoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestPSGeoDoc commands
