// TestPSGeoView.cpp : implementation of the CTestPSGeoView class
//

#include "stdafx.h"
#include "TestPSGeo.h"

#include "TestPSGeoDoc.h"
#include "TestPSGeoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CProp

IMPLEMENT_DYNAMIC(CProp, CPropertySheet)

CProp::CProp(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
}

CProp::CProp(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	AddPage(&m_page1);
	AddPage(&m_page2);
}

CProp::~CProp()
{
}

BEGIN_MESSAGE_MAP(CProp, CPropertySheet)
	//{{AFX_MSG_MAP(CProp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProp message handlers


/////////////////////////////////////////////////////////////////////////////
// CTestPSGeoView

IMPLEMENT_DYNCREATE(CTestPSGeoView, CFormView)
IMPLEMENT_GEOMETRY_DYNCREATE(CTestPSGeoView)

BEGIN_MESSAGE_MAP(CTestPSGeoView, CFormView)
	//{{AFX_MSG_MAP(CTestPSGeoView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	// Standard printing commands
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestPSGeoView construction/destruction

CTestPSGeoView::CTestPSGeoView() : CFormView(IDD), m_ps("")
{
}

CTestPSGeoView::~CTestPSGeoView()
{
}

BOOL CTestPSGeoView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CFormView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTestPSGeoView drawing

void CTestPSGeoView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	GetParentFrame()->RecalcLayout();
	ResizeParentToFit(FALSE);

	m_ps.SetWindowPos(NULL,0,0,0,0,SWP_NOZORDER|SWP_NOSIZE|SWP_SHOWWINDOW);

	AddConstraint(GetWindowLong(m_ps.GetSafeHwnd(),GWL_ID),CConstraint("CX+CY"));
}

/////////////////////////////////////////////////////////////////////////////
// CTestPSGeoView diagnostics

#ifdef _DEBUG
void CTestPSGeoView::AssertValid() const
{
	CFormView::AssertValid();
}

void CTestPSGeoView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CTestPSGeoDoc* CTestPSGeoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTestPSGeoDoc)));
	return (CTestPSGeoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestPSGeoView message handlers

int CTestPSGeoView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	CRect	rectPS;

	if (CFormView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	m_ps.Create(this,WS_CHILD);
	m_ps.GetWindowRect(rectPS);
	SetWindowPos(NULL,0,0,rectPS.Width(),rectPS.Height(),SWP_NOZORDER|SWP_NOMOVE);

	return 0;
}
/////////////////////////////////////////////////////////////////////////////
// CAddedPage property page

IMPLEMENT_DYNCREATE(CAddedPage, CPropertyPage)

CAddedPage::CAddedPage() : CPropertyPage(CAddedPage::IDD)
{
	//{{AFX_DATA_INIT(CAddedPage)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CAddedPage::~CAddedPage()
{
}

void CAddedPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddedPage)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddedPage, CPropertyPage)
	//{{AFX_MSG_MAP(CAddedPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddedPage message handlers
/////////////////////////////////////////////////////////////////////////////
// CAddedPage2 property page

IMPLEMENT_DYNCREATE(CAddedPage2, CPropertyPage)

CAddedPage2::CAddedPage2() : CPropertyPage(CAddedPage2::IDD)
{
	//{{AFX_DATA_INIT(CAddedPage2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CAddedPage2::~CAddedPage2()
{
}

void CAddedPage2::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddedPage2)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddedPage2, CPropertyPage)
	//{{AFX_MSG_MAP(CAddedPage2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddedPage2 message handlers

void CTestPSGeoView::OnSize(UINT nType, int cx, int cy) 
{
	CFormView::OnSize(nType, cx, cy);
	
	if (!GetSafeHwnd())
		return;
}

BOOL CAddedPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	AddConstraint(IDOK,CConstraint("X"));
	AddConstraint(IDCANCEL,CConstraint("X"));
	AddConstraint(IDC_EDIT1,CConstraint("CX"));
	AddConstraint(IDC_EDIT2,CConstraint("CX"));
	AddConstraint(IDC_LIST1,CConstraint("CX[0.5]+CY"));
	AddConstraint(IDC_LIST2,CConstraint("X[0.5]+CX[0.5]+CY"));

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CAddedPage2::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	AddConstraint(IDOK,CConstraint(1));
	AddConstraint(IDCANCEL,CConstraint(1));
	AddConstraint(IDC_EDIT1,CConstraint(0,0,1,0));
	AddConstraint(IDC_EDIT2,CConstraint(0,0,1,0));
	AddConstraint(IDC_LIST1,CConstraint(0,0,1,0.5));
	AddConstraint(IDC_LIST2,CConstraint(0,0.5,1,0.5));

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
