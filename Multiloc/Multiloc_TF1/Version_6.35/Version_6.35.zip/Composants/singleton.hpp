#ifndef SINGLETON_H
#define SINGLETON_H

/**
*	Classe singleton g�n�rique
*/
template <class T>
class Singleton : private T
{
private:
	Singleton();
	~Singleton();

public:
	static T &GetInstance();
};


template <class T>
inline Singleton<T>::Singleton()
{
}

template <class T>
inline Singleton<T>::~Singleton()
{	
}

template <class T>
/*static*/ T &Singleton<T>::GetInstance()
{
	static Singleton<T> s_oT;
	return(s_oT);
}

#endif //!SINGLETON_H