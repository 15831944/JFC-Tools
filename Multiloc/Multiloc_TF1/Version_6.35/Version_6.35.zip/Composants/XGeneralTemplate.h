#ifndef XGENERALTEMPLATE_H
#define XGENERALTEMPLATE_H

#include "XTemplate.h"

///////////////////////////////////////////////////////////////////////////////
//  CXGeneralTemplate class

/**
*	Template Gen�ral � appliquer � tous les contr�les
*/
struct CXGeneralTemplate
{
	COLORREF darkcolor_;			// couleur fonc�e
	COLORREF lightcolor_;			// couleur claire
	COLORREF highlightcolor_;		// couleur de surbrillance

	// type opaque repr�sentant un template visuel g�nral
	typedef unsigned int Handle;

	static const CXGeneralTemplate GetDefaultTemplate()
	{
		CXGeneralTemplate defaultTemplate;
		defaultTemplate.darkcolor_		= RGB(165, 191, 225);
		defaultTemplate.lightcolor_		= RGB(227, 239, 255);
		defaultTemplate.highlightcolor_ = RGB(255, 220, 120);
		return defaultTemplate;
	}
};

// on cr�e un type pour le manager de templates visuels g�n�raux
typedef Singleton<CXGenericTemplateManager<CXGeneralTemplate> > CXGeneralTemplateMgr;

#endif //!XGENERALTEMPLATE_H