#ifndef XTEMPLATE_H
#define XTEMPLATE_H

#include <vector>
#include "singleton.hpp"

//#include <Windows.h>

/**
 *	CXGenericTemplateManager class
 */
	template<typename _TempType>
class CXGenericTemplateManager
{
	friend class Singleton<CXGenericTemplateManager<_TempType> >;
public:

	typedef typename _TempType::Handle _Handle;

	_Handle CreateTemplate(const _TempType Template)
	{
		// on ajoute un nouveau template
		m_Templates.push_back(Template);

		// on retourne son index
		return static_cast<CXGenericTemplateManager::_Handle>(m_Templates.size());
	}

	const _TempType GetTemplate(const _Handle hTemplate) const
	{
		// on r�cup�re l'index correspondant au handle du template
		const size_t IdxTemplate = static_cast<size_t>(hTemplate - 1);

		// on verifie la validit� de l'index
		ASSERT(IdxTemplate < m_Templates.size());

		// on retourne le template
		return m_Templates[IdxTemplate];	
	}

	static const _TempType GetDefaultTemplate()
	{
		//if (m_hxDefaultTemplate == InvalidHandle)
		//{
		//	// le template par defaut doit absolument exister ici
		//	ASSERT(FALSE);
		//}
		return Singleton<CXGenericTemplateManager>::GetInstance().
			GetTemplate(GetDefaultTemplateHandle());
	}

	static const _Handle GetDefaultTemplateHandle()
	{
		if (m_hxDefaultTemplate == InvalidHandle)
		{
			m_hxDefaultTemplate = Singleton<CXGenericTemplateManager>::GetInstance().
				CreateTemplate(_TempType::GetDefaultTemplate());
		}
		return m_hxDefaultTemplate;
	}

		static const _Handle InvalidHandle = -1;

private:

	// constructeurs et destructeurs priv�s : classe accessible uniquement par Singleton<CXGenericTemplateManager>
	CXGenericTemplateManager()	{}
	~CXGenericTemplateManager()	{}

	typedef std::vector<_TempType> TemplateTable;
	TemplateTable m_Templates;

	static _Handle	m_hxDefaultTemplate;
};


template<typename _TempType>
	typename CXGenericTemplateManager<_TempType>::_Handle
		CXGenericTemplateManager<_TempType>::m_hxDefaultTemplate =
			CXGenericTemplateManager::InvalidHandle;

#endif //!XTEMPLATE_H
