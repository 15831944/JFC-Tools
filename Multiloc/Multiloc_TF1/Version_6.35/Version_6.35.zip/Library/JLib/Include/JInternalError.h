//
// Fichier: JInternalError.h
// Auteur:  Sylvain SAMMURI
// Date:    04/06/2002
//

// on inclut les d�finitions n�cessaires
#include "JException.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_INTERNAL_ERROR_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_INTERNAL_ERROR_H

class JInternalError : public JException
{
private:
	// le constructeur
	JInternalError();

private:
	// l'unique instance de l'exception
	static JInternalError m_Instance;

public:
	// la fonction pour r�cup�rer l'instance de l'exception
	static JInternalError* GetInstance();

public:
	// la fonction pour r�cup�rer le message
	virtual const JChar* GetMessage() const;

	// le destructeur
	virtual ~JInternalError();

private:
	// l'op�rateur d'affectation
	JInternalError & operator =(const JInternalError & Source);

	// le constructeur copie
	JInternalError(const JInternalError & Source);
};

// fin de l'inclusion conditionnelle
#endif
