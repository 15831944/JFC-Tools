//
// Fichier: JNetworkError.h
// Auteur:  Sylvain SAMMURI
// Date:    04/06/2002
//

// on inclut les d�finitions n�cessaires
#include "JException.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_NETWORK_ERROR_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_NETWORK_ERROR_H

class JNetworkError : public JException
{
private:
	// le constructeur
	JNetworkError();

private:
	// l'unique instance de l'exception
	static JNetworkError m_Instance;

public:
	// la fonction pour r�cup�rer l'instance de l'exception
	static JNetworkError* GetInstance();

public:
	// la fonction pour r�cup�rer le message
	virtual const JChar* GetMessage() const;

	// le destructeur
	virtual ~JNetworkError();

private:
	// l'op�rateur d'affectation
	JNetworkError & operator =(const JNetworkError & Source);

	// le constructeur copie
	JNetworkError(const JNetworkError & Source);
};

// fin de l'inclusion conditionnelle
#endif
