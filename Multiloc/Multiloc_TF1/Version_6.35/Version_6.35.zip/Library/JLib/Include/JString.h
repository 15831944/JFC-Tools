//
// Fichier: JString.h
// Auteur:  Sylvain SAMMURI
// Date:    04/06/2002
//

// on inclut les d�finitions n�cessaires
#include "JLib.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_STRING_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_STRING_H

class JString
{
public:
	// les constructeurs
	JString();
	JString(const JString & Source);

	// la fonction pour tester la cha�ne
	JBool IsEmpty() const;

	// les fonctions pour s�rialiser la cha�ne
	JVoid Send(JStream & Stream) const;
	JVoid Recv(JStream & Stream);

	// la fonction pour r�cup�rer la cha�ne
	const JChar* AsString() const;

	// les op�rateurs d'affectation
	JString & operator =(const JChar* pSource);
	JString & operator =(const JString & Source);

	// les op�rateurs de comparaison
	JBool operator ==(const JString & Reference) const;
	JBool operator !=(const JString & Reference) const;
	JBool operator < (const JString & Reference) const;
	JBool operator <=(const JString & Reference) const;
	JBool operator > (const JString & Reference) const;
	JBool operator >=(const JString & Reference) const;

	// les fonctions pour mettre en forme la cha�ne
	JVoid TrimRight();
	JVoid TrimLeft();

	// la fonction pour r�initialiser la cha�ne
	JVoid Reset();

	// le destructeur
	~JString();

private:
	// la fonction pour tester la cha�ne
	JInt32 OnCheckString(const JChar* pSource) const;

private:
	JChar m_String[JSTRING_MAX]; // la cha�ne
};

// fin de l'inclusion conditionnelle
#endif
