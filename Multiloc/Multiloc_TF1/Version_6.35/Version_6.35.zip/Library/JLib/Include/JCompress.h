//
// Fichier: JCompress.h
// Auteur:  Sylvain SAMMURI
// Date:    26/06/2002
//

// on inclut les d�finitions n�cessaires
#include "JSerialize.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_COMPRESS_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_COMPRESS_H

class JCompress : public JSerialize
{
private:
	// le constructeur
	JCompress(JSerialize* pNext);

public:
	// la fonction pour cr�er une instance
	static JCompress* Create(JSerialize* pNext);

public:
	// la fonction pour tester le tampon
	virtual JBool IsEmpty();

	// les fonctions pour transf�rer les donn�es
	virtual JVoid  Send(JUnt08 Data);
	virtual JUnt08 Recv();

	// la fonction pour vider le tampon
	virtual JVoid Flush();

	// le destructeur
	virtual ~JCompress();

private:
	// l'op�rateur d'affectation
	JCompress & operator =(const JCompress & Source);

	// le constructeur copie
	JCompress(const JCompress & Source);

private:
	JSerialize* m_pNext; // le suivant
};

// fin de l'inclusion conditionnelle
#endif
