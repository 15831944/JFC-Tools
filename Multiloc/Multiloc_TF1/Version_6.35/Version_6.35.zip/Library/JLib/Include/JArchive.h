//
// Fichier: JArchive.h
// Auteur:  Sylvain SAMMURI
// Date:    26/06/2002
//

// on inclut les d�finitions n�cessaires
#include "JStream.h"
#include "JSerialize.h"
#include "JCompress.h"
#include "JEncrypt.h"
#include "JDecrypt.h"
#include "JExpand.h"
#include "JFile.h"
#include "JPath.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_ARCHIVE_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_ARCHIVE_H

class JArchive : public JStream
{
private:
	// le constructeur
	JArchive(JSerialize* pPrev, JSerialize* pNext);

public:
	// la fonction pour cr�er une instance
	static JArchive* Create(const JPath & Path, JBool Update = false);

	// le destructeur
	virtual ~JArchive();

private:
	// l'op�rateur d'affectation
	JArchive & operator =(const JArchive & Source);

	// le constructeur copie
	JArchive(const JArchive & Source);

private:
	JCompress* m_pCompress; // la compression des donn�es
	JEncrypt*  m_pEncrypt;  // l'encryptage des donn�es
	JDecrypt*  m_pDecrypt;  // le d�cryptage des donn�es
	JExpand*   m_pExpand;   // la d�compression des donn�es
	JFile*     m_pFile;     // le fichier
};

// fin de l'inclusion conditionnelle
#endif
