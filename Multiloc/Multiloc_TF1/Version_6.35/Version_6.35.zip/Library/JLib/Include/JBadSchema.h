//
// Fichier: JBadSchema.h
// Auteur:  Sylvain SAMMURI
// Date:    20/08/2002
//

// on inclut les d�finitions n�cessaires
#include "JException.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_BAD_SCHEMA_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_BAD_SCHEMA_H

class JBadSchema : public JException
{
private:
	// le constructeur
	JBadSchema();

private:
	// l'unique instance de l'exception
	static JBadSchema m_Instance;

public:
	// la fonction pour r�cup�rer l'instance de l'exception
	static JBadSchema* GetInstance();

public:
	// la fonction pour r�cup�rer le message
	virtual const JChar* GetMessage() const;

	// le destructeur
	virtual ~JBadSchema();

private:
	// l'op�rateur d'affectation
	JBadSchema & operator =(const JBadSchema & Source);

	// le constructeur copie
	JBadSchema(const JBadSchema & Source);
};

// fin de l'inclusion conditionnelle
#endif
