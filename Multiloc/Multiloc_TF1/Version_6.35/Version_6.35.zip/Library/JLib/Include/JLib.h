//
// Fichier: JLib.h
// Auteur:  Sylvain SAMMURI
// Date:    04/06/2002
//

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_H

// on inclut la d�finition des types
#include "JTypes.h"

// on inclut la d�finition des limites
#include "JLimits.h"

// on inclut la d�finition des exceptions
#include "JException.h"
#include "JInternalError.h"
#include "JSystemError.h"
#include "JNetworkError.h"
#include "JInvalidCall.h"
#include "JMemoryFull.h"
#include "JBadSchema.h"
#include "JTimeout.h"

// on inclut la d�finition des composants de base
#include "JFpu.h"
#include "JDate.h"
#include "JTime.h"
#include "JString.h"
#include "JHost.h"
#include "JPath.h"

// on inclut la d�finition des collections
#include "JList.h"
#include "JArray.h"
#include "JMatrix.h"
#include "JVector.h"
#include "JHash.h"
#include "JMap.h"

// on inclut la d�finition du gestionnaire des chemins
#include "JPathManager.h"

// on inclut la d�finition de la s�rialisation des flots
#include "JSerialize.h"
#include "JCompress.h"
#include "JEncrypt.h"
#include "JDecrypt.h"
#include "JExpand.h"
#include "JMemory.h"
#include "JFile.h"
#include "JPipe.h"

// on inclut la d�finition des fa�ades des flots
#include "JStream.h"
#include "JArchive.h"
#include "JConnection.h"
#include "JMemento.h"

// on inclut la d�finition des parseurs
#include "JLexeme.h"
#include "JReader.h"
#include "JParser.h"

// fin de l'inclusion conditionnelle
#endif
