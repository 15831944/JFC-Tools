//
// Fichier: JPathManager.h
// Auteur:  Sylvain SAMMURI
// Date:    21/10/2002
//

// on inclut les d�finitions n�cessaires
#include "JLib.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_PATH_MANAGER_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_PATH_MANAGER_H

class JPathManager
{
private:
	// les constructeurs
	JPathManager();
	JPathManager(const JPathManager & Source);

public:
	// la fonction pour cr�er un r�pertoire
	static JVoid CreateDirectory(const JPath & Path);

	// la fonction pour tester un r�pertoire
	static JBool IsDirectoryExists(const JPath & Path);

	// la fonction pour tester un fichier
	static JBool IsFileExists(const JPath & Path);

	// la fonction pour valider une mise � jour de fichier
	static JVoid UpdateFile(const JPath & Path);

	// la fonction pour d�truire un fichier
	static JVoid DeleteFile(const JPath & Path);

private:
	// le destructeur
	~JPathManager();
};

// fin de l'inclusion conditionnelle
#endif
