//
// Fichier: JException.h
// Auteur:  Sylvain SAMMURI
// Date:    04/06/2002
//

// on inclut les d�finitions n�cessaires
#include "JLib.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_EXCEPTION_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_EXCEPTION_H

class JException
{
protected:
	// le constructeur
	JException();

public:
	// la fonction pour r�cup�rer le message
	virtual const JChar* GetMessage() const = 0;

	// le destructeur
	virtual ~JException();

private:
	// l'op�rateur d'affectation
	JException & operator =(const JException & Source);

	// le constructeur copie
	JException(const JException & Source);
};

// fin de l'inclusion conditionnelle
#endif
