//
// Fichier: JPath.h
// Auteur:  Sylvain SAMMURI
// Date:    04/06/2002
//

// on inclut les d�finitions n�cessaires
#include "JLib.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_PATH_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_PATH_H

class JPath
{
public:
	// les constructeurs
	JPath();
	JPath(const JPath & Source);

	// les fonctions pour tester le chemin
	JBool IsFilename() const;
	JBool IsDirectory() const;

	// la fonction pour ajouter un �l�ment
	JVoid Add(const JChar* pSource);

	// les fonctions pour s�rialiser le chemin
	JVoid Send(JStream & Stream) const;
	JVoid Recv(JStream & Stream);

	// la fonction pour r�cup�rer le chemin
	const JChar* AsString() const;

	// les op�rateurs d'affectation
	JPath & operator =(const JChar* pSource);
	JPath & operator =(const JPath & Source);

	// les op�rateurs de comparaison
	JBool operator ==(const JPath & Reference) const;
	JBool operator !=(const JPath & Reference) const;
	JBool operator < (const JPath & Reference) const;
	JBool operator <=(const JPath & Reference) const;
	JBool operator > (const JPath & Reference) const;
	JBool operator >=(const JPath & Reference) const;

	// la fonction pour enlever des �l�ments du chemin
	JVoid Remove(JInt32 Count = 1);

	// la fonction pour r�initialiser le chemin
	JVoid Reset();

	// le destructeur
	~JPath();

private:
	// la fonction pour tester le chemin
	JInt32 OnCheckPath(const JChar* pSource) const;

private:
	JChar m_Path[JPATH_MAX]; // le chemin
};

// fin de l'inclusion conditionnelle
#endif
