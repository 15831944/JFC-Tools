//
// Fichier: JReader.h
// Auteur:  Sylvain SAMMURI
// Date:    12/08/2002
//

// on inclut les d�finitions n�cessaires
#include "JLib.h"
#include "JSerialize.h"
#include "JLexeme.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_READER_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_READER_H

class JReader
{
private:
	// le constructeur
	JReader(JSerialize* pSerialize);

public:
	// la fonction pour cr�er une instance
	static JReader* Create(JSerialize* pSerialize);

public:
	// la fonction pour tester le tampon
	virtual JBool IsEmpty();

	// la fonction pour r�cup�rer la ligne
	virtual JInt32 GetLine() const;

	// les fonctions pour r�cup�rer les lex�mes
	virtual JLexeme RecvString(JInt32 Count);
	virtual JLexeme RecvInteger(JInt32 Count);
	virtual JLexeme RecvFloat(JInt32 Count);
	virtual JLexeme RecvEndOfLine();

	// le destructeur
	virtual ~JReader();

private:
	// on d�finit le contexte du parseur
	class JContext
	{
	public:
		JInt32  m_Type;   // le type
		JInt32  m_Line;   // la ligne
		JInt32  m_Count;  // le compteur
		JInt32  m_Retain; // la retenue
		JLexeme m_Lexeme; // le lex�me
	};

private:
	// la fonction pour construire le contexte
	JBool OnMakeContext();

private:
	// les fonctions pour recevoir les donn�es
	JVoid OnFlushRetain(JSerialize* pSerialize, JContext* pContext);
	JVoid OnRecvLexeme(JSerialize* pSerialize, JContext* pContext, JInt32 Node, JInt32 Count);

private:
	// la fonction pour lib�rer le contexte
	JVoid OnRemContext();

private:
	// l'op�rateur d'affectation
	JReader & operator =(const JReader & Source);

	// le constructeur copie
	JReader(const JReader & Source);

private:
	JSerialize* m_pSerialize; // le flot d'entr�e
	JContext*   m_pContext;   // le contexte
};

// fin de l'inclusion conditionnelle
#endif
