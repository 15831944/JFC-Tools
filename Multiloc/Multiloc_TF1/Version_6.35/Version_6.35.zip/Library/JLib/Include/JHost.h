//
// Fichier: JHost.h
// Auteur:  Sylvain SAMMURI
// Date:    04/06/2002
//

// on inclut les d�finitions n�cessaires
#include "JLib.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_HOST_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_HOST_H

class JHost
{
public:
	// les constructeurs
	JHost();
	JHost(const JHost & Source);

	// la fonction pour tester le serveur
	JBool IsLocal() const;

	// les fonctions pour s�rialiser le serveur
	JVoid Send(JStream & Stream) const;
	JVoid Recv(JStream & Stream);

	// la fonction pour r�cup�rer le serveur
	const JChar* AsString() const;

	// les op�rateurs d'affectation
	JHost & operator =(const JChar* pSource);
	JHost & operator =(const JHost & Source);
	
	// les op�rateurs de comparaison
	JBool operator ==(const JHost & Reference) const;
	JBool operator !=(const JHost & Reference) const;
	JBool operator < (const JHost & Reference) const;
	JBool operator <=(const JHost & Reference) const;
	JBool operator > (const JHost & Reference) const;
	JBool operator >=(const JHost & Reference) const;

	// la fonction pour r�initialiser le serveur
	JVoid Reset();

	// le destructeur
	~JHost();

private:
	// la fonction pour tester le serveur
	JInt32 OnCheckHost(const JChar* pSource) const;

private:
	JChar m_Host[JHOST_MAX]; // le serveur
};

// fin de l'inclusion conditionnelle
#endif
