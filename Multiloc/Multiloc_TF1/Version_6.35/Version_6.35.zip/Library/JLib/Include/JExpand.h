//
// Fichier: JExpand.h
// Auteur:  Sylvain SAMMURI
// Date:    26/06/2002
//

// on inclut les d�finitions n�cessaires
#include "JSerialize.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_EXPAND_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_EXPAND_H

class JExpand : public JSerialize
{
private:
	// le constructeur
	JExpand(JSerialize* pPrev);

public:
	// la fonction pour cr�er une instance
	static JExpand* Create(JSerialize* pPrev);

public:
	// la fonction pour tester le tampon
	virtual JBool IsEmpty();

	// les fonctions pour transf�rer les donn�es
	virtual JVoid  Send(JUnt08 Data);
	virtual JUnt08 Recv();

	// la fonction pour vider le tampon
	virtual JVoid Flush();

	// le destructeur
	virtual ~JExpand();

private:
	// l'op�rateur d'affectation
	JExpand & operator =(const JExpand & Source);

	// le constructeur copie
	JExpand(const JExpand & Source);

private:
	JSerialize* m_pPrev; // le pr�c�dent
};

// fin de l'inclusion conditionnelle
#endif
