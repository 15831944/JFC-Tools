#if !defined(AFX_VILLEDLG_H__9DBF07C2_884C_11D2_AAF8_0000E86750A8__INCLUDED_)
#define AFX_VILLEDLG_H__9DBF07C2_884C_11D2_AAF8_0000E86750A8__INCLUDED_

#include "DataVille.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// VilleDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CVilleDlg dialog

class CVilleDlg : public CDialog
{
// Construction
public:
	CVilleDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CVilleDlg)
	enum { IDD = IDD_VILLE_DLG };
	CListBox	m_ListBox;
	CString	m_String;
	int		m_Habitants;
	int		m_Commune;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVilleDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void SetData();
	void GetData();
	void UpdateButtons();
	bool m_Mode_Modify;
	CVille m_DataCopy;
	int m_CurData;
	bool m_Mode_New;
	CDataVille m_Data;
	void SetupData(bool Load);

	// Generated message map functions
	//{{AFX_MSG(CStationDlg)
	afx_msg void OnBnAjouter();
	afx_msg void OnBnSupprimer();
	virtual void OnCancel();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeList();
	afx_msg void OnBnModifier();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VILLEDLG_H__9DBF07C2_884C_11D2_AAF8_0000E86750A8__INCLUDED_)
