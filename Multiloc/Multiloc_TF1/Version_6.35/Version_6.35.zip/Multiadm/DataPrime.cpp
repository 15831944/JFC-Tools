// DataPrime.cpp: implementation of the CDataPrime class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiadm.h"
#include "DataPrime.h"

#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataPrime::CDataPrime()
{

}

CDataPrime::~CDataPrime()
{

}

bool CDataPrime::Load()
{
	m_Primes.RemoveAll();
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",FALSE,TRUE);
		CTblPrimes Table(&Db);
		Table.Open();
		while(!Table.IsEOF()) 
		{
			CPrime Prime;
			Prime=Table;
			m_Primes.Add(Prime);
			Table.MoveNext();
		}
		while(!Table.IsEOF())
		Table.Close();
		Db.Close();
		CPrime *pPrime=m_Primes.GetData();
		if(pPrime) std::sort(pPrime,(pPrime+m_Primes.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataPrime::Modify(CPrime &Prime, int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblPrimes Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("DateDebut = %s",m_Primes[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table=Prime;
				Table.Update();
				m_Primes[Index]=Prime;
//				CPrime *pPrime=m_Primes.GetData();
//				if(pPrime) std::sort(pPrime,(pPrime+m_Primes.GetSize()));
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataPrime::Add(CPrime &Prime)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblPrimes Table(&Db);
		Table.Open();
		Table.AddNew();
		Table=Prime;
		Table.Update();
		Table.Close();
		Db.Close();
		m_Primes.Add(Prime);
//		CPrime *pPrime=m_Primes.GetData();
//		if(pPrime) std::sort(pPrime,(pPrime+m_Primes.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataPrime::Delete(int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblPrimes Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("DateDebut = %s",m_Primes[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Delete();
				m_Primes.RemoveAt(Index);
//				CPrime *pPrime=m_Primes.GetData();
//				if(pPrime) std::sort(pPrime,(pPrime+m_Primes.GetSize()));
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}