// multiadm.h : main header file for the MULTIADM application
//

#if !defined(AFX_MULTIADM_H__8880D338_7D52_11D2_9B0D_004005327F6C__INCLUDED_)
#define AFX_MULTIADM_H__8880D338_7D52_11D2_9B0D_004005327F6C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMultiadmApp:
// See multiadm.cpp for the implementation of this class
//

class CMultiadmApp : public CWinApp
{
public:
	CMultiadmApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMultiadmApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMultiadmApp)
	afx_msg void OnStations();
	afx_msg void OnTarifs();
	afx_msg void OnVilles();
	afx_msg void OnGrps();
	afx_msg void OnCibles();
	afx_msg void OnFormat();
	afx_msg void OnPrime();
	afx_msg void OnVolumes();
	afx_msg void OnTarifsImport();
	afx_msg void OnGrpsImport();
	afx_msg void OnFaxmail();
	afx_msg void OnConvEuro();
	afx_msg void OnTarifseuroImport();
	afx_msg void OnTarifsMatricestf1Import();
	afx_msg void OnPrimeregion();
	afx_msg void OnVolumesregion();
	afx_msg void OnGrpsImportglobal();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MULTIADM_H__8880D338_7D52_11D2_9B0D_004005327F6C__INCLUDED_)
