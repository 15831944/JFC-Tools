// DataPrimeRegion.h: interface for the CDataPrimeRegion class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATAPRIMEREGION_H__715B4B61_C4B9_11D5_8A63_0010B5865AAB__INCLUDED_)
#define AFX_DATAPRIMEREGION_H__715B4B61_C4B9_11D5_8A63_0010B5865AAB__INCLUDED_

#include "primeregion.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataPrimeRegion  
{
public:
	int Delete(int Index);
	int Add(CPrimeRegion &PrimeRegion);
	int Modify(CPrimeRegion &PrimeRegion, int Index);
	bool Load();
	CPrimeRegionArray m_PrimesRegion;
	
	CDataPrimeRegion();
	virtual ~CDataPrimeRegion();

};

#endif // !defined(AFX_DATAPRIMEREGION_H__715B4B61_C4B9_11D5_8A63_0010B5865AAB__INCLUDED_)
