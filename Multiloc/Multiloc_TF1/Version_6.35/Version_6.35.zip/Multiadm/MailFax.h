// MailFax.h: interface for the CMailFax class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAILFAX_H__CC50D6AD_E94F_49F2_825C_CDD360A0BCE5__INCLUDED_)
#define AFX_MAILFAX_H__CC50D6AD_E94F_49F2_825C_CDD360A0BCE5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>		// MFC template library
#include "TblMailFax.h"

class CMailFax  
{
public:
	CMailFax();
	virtual ~CMailFax();

	long	m_NrStation;
	long	m_NrVille;
	CString	m_AdrMail;
	CString	m_Fax;

	CMailFax & operator=(const CMailFax &Source);// Copy operator
	CMailFax & operator=(const CTblMailFax &Source);// Copy operator
	bool operator<(const CMailFax &Source);


};

typedef	CArray<CMailFax,CMailFax&> CMailFaxArray;

#endif // !defined(AFX_MAILFAX_H__CC50D6AD_E94F_49F2_825C_CDD360A0BCE5__INCLUDED_)
