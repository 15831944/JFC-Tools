// DataVolume.h: interface for the CDataVolume class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATAVOLUME_H__F3536060_89D6_11D2_AAF8_0000E86750A8__INCLUDED_)
#define AFX_DATAVOLUME_H__F3536060_89D6_11D2_AAF8_0000E86750A8__INCLUDED_

#include "volume.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataVolume  
{
public:
	int Delete(int Index);
	int Add(CVolume &Volume);
	int Modify(CVolume &Volume, int Index);
	bool Load();
	CVolumeArray m_Volumes;

	CDataVolume();
	virtual ~CDataVolume();

};

#endif // !defined(AFX_DATAVOLUME_H__F3536060_89D6_11D2_AAF8_0000E86750A8__INCLUDED_)
