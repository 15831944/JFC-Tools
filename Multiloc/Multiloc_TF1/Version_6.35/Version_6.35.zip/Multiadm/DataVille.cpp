// DataVille.cpp: implementation of the CDataVille class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiadm.h"
#include "DataVille.h"
#include "TblVilles.h"

#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataVille::CDataVille()
{
}

CDataVille::~CDataVille()
{

}

bool CDataVille::Load()
{
	m_Villes.RemoveAll();
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",FALSE,TRUE);
		CTblVilles Table(&Db);
		Table.Open();
		while(!Table.IsEOF()) 
		{
			CVille Ville;
			Ville=Table;
			m_Villes.Add(Ville);
			Table.MoveNext();
		}
		Table.Close();
		Db.Close();
		CVille *pVille=m_Villes.GetData();
		if(pVille) std::sort(pVille,(pVille+m_Villes.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

// Recherche code ville d'apr�s le libell�
int CDataVille::CodeVille(CString LibelleVille)
{
	int CodeTrouve = 0;

	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblVilles Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("Libelle = %s",LibelleVille);
			if(Table.FindFirst(Search))
			{
				CodeTrouve = Table.m_NrUnique; 
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return CodeTrouve;
}


// Recherche code ville d'apr�s le libell�
int CDataVille::CodeVilleExist(int CodeVille)
{
	bool CodeTrouve = false;

	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblVilles Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrUnique = %d",CodeVille);
			if(Table.FindFirst(Search))
			{
				CodeTrouve = true;
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return CodeTrouve;
}

int CDataVille::Modify(CVille &Ville, int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblVilles Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrUnique = %d",m_Villes[Index].m_NrUnique);

			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table=Ville;
				Table.Update();
				m_Villes[Index]=Ville;
				CVille *pVille=m_Villes.GetData();
				if(pVille) std::sort(pVille,(pVille+m_Villes.GetSize()));
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataVille::Add(CVille &Ville)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblVilles Table(&Db);
		Table.Open();
		Table.AddNew();
		Table=Ville;
		Table.Update();
		Ville=Table;
		Table.Close();
		Db.Close();
		m_Villes.Add(Ville);
		CVille *pVille=m_Villes.GetData();
		if(pVille) std::sort(pVille,(pVille+m_Villes.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataVille::Delete(int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblVilles Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrUnique = %d",m_Villes[Index].m_NrUnique);
			if(Table.FindFirst(Search))
			{
				Table.Delete();
				m_Villes.RemoveAt(Index);
				CVille *pVille=m_Villes.GetData();
				if(pVille) std::sort(pVille,(pVille+m_Villes.GetSize()));
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}
