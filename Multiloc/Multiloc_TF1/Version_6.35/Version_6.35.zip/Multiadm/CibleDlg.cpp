// CibleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "multiadm.h"
#include "CibleDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCibleDlg dialog


CCibleDlg::CCibleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCibleDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCibleDlg)
	m_String = _T("");
	//}}AFX_DATA_INIT
	m_Mode_Modify=false;
	m_Mode_New=false;
	m_CurData=-1;
}


void CCibleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCibleDlg)
	DDX_Control(pDX, IDC_LIST, m_ListBox);
	DDX_Text(pDX, IDC_EDIT, m_String);
	DDV_MaxChars(pDX, m_String, 30);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCibleDlg, CDialog)
	//{{AFX_MSG_MAP(CCibleDlg)
	ON_BN_CLICKED(IDC_BN_AJOUTER, OnBnAjouter)
	ON_BN_CLICKED(IDC_BN_SUPPRIMER, OnBnSupprimer)
	ON_LBN_SELCHANGE(IDC_LIST, OnSelchangeList)
	ON_BN_CLICKED(IDC_BN_MODIFIER, OnBnModifier)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCibleDlg message handlers
void CCibleDlg::OnBnModifier() 
{
	m_Mode_Modify=true;
	UpdateButtons();
	UpdateData(false);
}

void CCibleDlg::OnBnAjouter() 
{
	m_Mode_New=true;
	m_DataCopy.m_NrUnique=-1;
	m_DataCopy.m_Libelle="Nouvelle Cible";
	SetData();
	UpdateButtons();
	UpdateData(false);
}

void CCibleDlg::OnBnSupprimer() 
{
	if(m_CurData<0) return;
	if(m_Mode_Modify || m_Mode_New) return;
	if(m_Data.Delete(m_CurData))
	{
		SetupData(false);
		UpdateButtons();
		UpdateData(false);
	}
}

void CCibleDlg::OnCancel() 
{
	if(m_Mode_New || m_Mode_Modify)
	{
		m_Mode_New=false;
		m_Mode_Modify=false;
		SetupData(false);
		UpdateButtons();
		UpdateData(false);
	}
	else CDialog::OnCancel();
}

void CCibleDlg::OnOK() 
{
	if(m_Mode_Modify)
	{
		GetData();
		if(m_Data.Modify(m_DataCopy,m_CurData))
		{
			m_Mode_Modify=false;
			m_DataCopy=m_Data.m_Cibles[m_CurData];
			SetupData(false);
		}
		UpdateButtons();
		return;
	}
	if(m_Mode_New)
	{
		GetData();
		m_DataCopy.m_NrUnique=0;
		if(m_Data.Add(m_DataCopy))
		{
			m_Mode_New=false;
			SetupData(true);
		}
		UpdateButtons();
		return;
	}
	CDialog::OnOK();
}

BOOL CCibleDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	SetupData(true);
	UpdateButtons();
	UpdateData(false);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCibleDlg::OnSelchangeList() 
{
	m_Mode_New=false;
	m_Mode_Modify=false;
	m_DataCopy=m_Data.m_Cibles[m_ListBox.GetCurSel()];
	SetData();
	UpdateButtons();
	UpdateData(false);
}

void CCibleDlg::SetupData(bool Load)
{
	if(Load) m_Data.Load();
	m_ListBox.ResetContent();
	if(m_Data.m_Cibles.GetSize())
	{
		for(int x=0;x<m_Data.m_Cibles.GetSize();x++)
		{
			CString String;
			String.Format("%4d\t%s",m_Data.m_Cibles[x].m_NrUnique,m_Data.m_Cibles[x].m_Libelle);
			m_ListBox.AddString(String);
		}
		m_ListBox.SetCurSel(0);
		m_DataCopy=m_Data.m_Cibles[0];
		m_CurData=0;

	}
	else
	{
		m_DataCopy.m_NrUnique=0;
		m_DataCopy.m_Libelle="";
		m_CurData=-1;

	}
	SetData();
	UpdateData(false);
}

void CCibleDlg::UpdateButtons()
{
	if(m_Mode_Modify || m_Mode_New)
	{
		if(m_Mode_Modify) GetDlgItem(IDC_BN_SUPPRIMER)->EnableWindow(true); 
		else GetDlgItem(IDC_BN_SUPPRIMER)->EnableWindow(false); 
		GetDlgItem(IDC_BN_AJOUTER)->EnableWindow(false); 
		GetDlgItem(IDC_BN_MODIFIER)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT)->EnableWindow(true); 
		GetDlgItem(IDC_LIST)->EnableWindow(false); 
		GetDlgItem(IDCANCEL)->EnableWindow(true); 
		GetDlgItem(IDOK)->EnableWindow(true); 
	}
	else
	{
		if(m_CurData<0)
		{
			GetDlgItem(IDC_BN_SUPPRIMER)->EnableWindow(false); 
			GetDlgItem(IDC_BN_MODIFIER)->EnableWindow(false); 
		}
		else
		{
			GetDlgItem(IDC_BN_SUPPRIMER)->EnableWindow(true); 
			GetDlgItem(IDC_BN_MODIFIER)->EnableWindow(true); 
		}
		GetDlgItem(IDC_BN_AJOUTER)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT)->EnableWindow(true); 
		GetDlgItem(IDC_LIST)->EnableWindow(true); 

		GetDlgItem(IDCANCEL)->EnableWindow(false); 
		GetDlgItem(IDOK)->EnableWindow(true); 
	}
}

void CCibleDlg::SetData()
{
	m_String=m_DataCopy.m_Libelle;
	UpdateData(false);
}

void CCibleDlg::GetData()
{
	UpdateData(true);
	m_String.TrimLeft();
	m_String.TrimRight();
	m_DataCopy.m_Libelle=m_String;
}

