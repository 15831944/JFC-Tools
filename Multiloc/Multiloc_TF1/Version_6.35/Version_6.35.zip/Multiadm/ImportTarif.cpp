// ImportTarif.cpp: implementation of the CImportTarif class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiadm.h"
#include "ImportTarif.h"
#include "DataStation.h"
#include "DataVille.h"
#include "TarifMessage.h"
#include "DataTarifMessage.h"
#include "DataTarifBase.h"
#include "DataTarifSaison.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CImportTarif::CImportTarif()
{

}

CImportTarif::~CImportTarif()
{

}

bool CImportTarif::ImportFile()
{

	CFileDialog Dialog(true,NULL,NULL,OFN_NOCHANGEDIR|OFN_ALLOWMULTISELECT,NULL,NULL);
	char *Buffer=new char[5050];
	Buffer[0]=0;
	Dialog.m_ofn.lpstrFile=Buffer;
	Dialog.m_ofn.nMaxFile=5000;
	if(Dialog.DoModal()==IDOK)
	{
		CWaitCursor Wait;
		POSITION Pos=Dialog.GetStartPosition();
		while(Pos)
		{
			CString FileName;
			FileName=Dialog.GetNextPathName(Pos);
			if(!Import(FileName))
			{
				CString Error;
				Error.Format("Error de chargement du fichier %s",FileName);
				AfxMessageBox(Error);
			}
		}
		AfxMessageBox("Import des Tarifs Termin�");
	}
	delete Buffer;
	return true;
}

bool CImportTarif::AddReplace(CTarif &Tarif)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifs Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation = %d AND NrVille = %d AND DateDebut = %s",Tarif.m_NrStation,Tarif.m_NrVille,
				Tarif.m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table=Tarif;
				Table.Update();
			}
			else
			{
				Table.AddNew();
				Table=Tarif;
				Table.Update();
			}
		}
		else
		{
			Table.AddNew();
			Table=Tarif;
			Table.Update();
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

/////////////////////////////////////////////////////////////////////////////////////
// Mise � jour des tarifications de base
bool CImportTarif::AddReplaceTarifBase    (CTarifBase &TarifBase)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifBase Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation = %d AND NrVille = %d AND DateDebut = %s",
				           TarifBase.m_NrStation,
						   TarifBase.m_NrVille,
				           TarifBase.m_DateDebut.Format("#%m/%d/%y#"));

			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table = TarifBase;
				Table.Update();
			}
			else
			{
				Table.AddNew();
				Table = TarifBase;
				Table.Update();
			}
		}
		else
		{
			Table.AddNew();
			Table = TarifBase;
			Table.Update();
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}	

/////////////////////////////////////////////////////////////////////////////////////
// Ajout/Replace via tableau des tarifs (Tarif de Base)
bool CImportTarif::AddReplaceAllTarifBase    (CTarifBaseArray   &TarifBaseArray)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifBase Table(&Db);
		Table.Open();

		for (int InxTarif=0;InxTarif<TarifBaseArray.GetSize();InxTarif++)
		{
			if(!Table.IsEOF())
			{
				Table.MoveFirst();
				CString Search;
				Search.Format("NrStation = %d AND NrVille = %d AND DateDebut = %s",
							   TarifBaseArray[InxTarif].m_NrStation,
							   TarifBaseArray[InxTarif].m_NrVille,
							   TarifBaseArray[InxTarif].m_DateDebut.Format("#%m/%d/%y#"));

				if(Table.FindFirst(Search))
				{
					Table.Edit();
					Table = TarifBaseArray[InxTarif];
					Table.Update();
				}
				else
				{
					Table.AddNew();
					Table = TarifBaseArray[InxTarif];
					Table.Update();
				}
			}
			else
			{
				Table.AddNew();
				Table = TarifBaseArray[InxTarif];
				Table.Update();
				Table.MoveFirst();
			}
		}
	
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

/////////////////////////////////////////////////////////////////////////////////////
// Mise � jour des tarifications message
bool CImportTarif::AddReplaceTarifMessage (CTarifMessage &TarifMessage)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifMessage Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation = %d AND NrJour = %d AND NrTrh = %d AND DateDebut = %s",
				          TarifMessage.m_NrStation,
						  TarifMessage.m_NrJour,
						  TarifMessage.m_NrTrh,
						  TarifMessage.m_DateDebut.Format("#%m/%d/%y#"));

			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table = TarifMessage;
				Table.Update();
			}
			else
			{
				Table.AddNew();
				Table = TarifMessage;
				Table.Update();
			}
		}
		else
		{
			Table.AddNew();
			Table = TarifMessage;
			Table.Update();
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

/////////////////////////////////////////////////////////////////////////////////////
// Ajout/Replace via tableau des tarifs (Tarif Message)
bool CImportTarif::AddReplaceAllTarifMessage (CTarifMessageArray &TarifMessageArray, CProgressCtrl *ProgressBar)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifMessage Table(&Db);
		Table.Open();

		int Taille = TarifMessageArray.GetSize();

		// Mise � 0 du compteur de progression
		if (ProgressBar != NULL) ProgressBar->SetPos(0);
		if (ProgressBar != NULL) ProgressBar->RedrawWindow();

		for (int InxTarif=0;InxTarif<TarifMessageArray.GetSize();InxTarif++)
		{
			// Mise � jour barre de progression 
			if (InxTarif % 1000 == 0)
			{
				int ValProgress = int((float(InxTarif)/float(Taille))*100);
				if (ProgressBar != NULL) ProgressBar->SetPos(ValProgress);
				if (ProgressBar != NULL) ProgressBar->RedrawWindow();
			}

			// Verif champs
			long NrStation			= TarifMessageArray[InxTarif].m_NrStation;

			// ATTENTION POUR NRJ
			// if (NrStation > 26 && NrStation < 128) continue;

			if (!(NrStation == 1 ||
				NrStation == 2 ||
				NrStation == 3 ||
				NrStation == 4 ||
				NrStation == 1 ||
				NrStation == 6 ||
				NrStation == 10 ||
				NrStation == 11 ||
				NrStation == 12 ||
				NrStation == 20 ||
				NrStation == 21 ||
				NrStation == 25 ||
				NrStation == 26 ||
				NrStation == 27 ||
				NrStation == 80 ||
				NrStation == 128 ||
				NrStation == 129 ||
				NrStation == 130 ||
				NrStation == 143)) continue;

			if (NrStation == 80)
			{
				Taille = 0;
			}

			long NrVille			= TarifMessageArray[InxTarif].m_NrVille;
			short NrJour			= TarifMessageArray[InxTarif].m_NrJour;
			short NrTrh				= TarifMessageArray[InxTarif].m_NrTrh;
			COleDateTime DateDebut	= TarifMessageArray[InxTarif].m_DateDebut;
			COleDateTime DateFin	= TarifMessageArray[InxTarif].m_DateFin;
			short Coeff 			= TarifMessageArray[InxTarif].m_CoeffTranche;

			// Pas d'archivage des elmts neutres
			if (NrStation == 0 && NrVille == 0)
				continue;

			if(!Table.IsEOF())
			{
				Table.MoveFirst();
				CString Search;
				Search.Format("NrStation = %d AND NrVille = %d AND NrJour = %d AND NrTrh = %d AND DateDebut = %s",
							  TarifMessageArray[InxTarif].m_NrStation,
							  TarifMessageArray[InxTarif].m_NrVille,
							  TarifMessageArray[InxTarif].m_NrJour,
							  TarifMessageArray[InxTarif].m_NrTrh,
							  TarifMessageArray[InxTarif].m_DateDebut.Format("#%m/%d/%y#"));

				if(Table.FindFirst(Search))
				{
					Table.Edit();
					Table = TarifMessageArray[InxTarif];
					Table.Update();
				}
				else
				{
					Table.AddNew();
					Table = TarifMessageArray[InxTarif];
					Table.Update();
				}
			}
			else
			{
				Table.AddNew();
				Table = TarifMessageArray[InxTarif];
				Table.Update();
				Table.MoveFirst();
			}
		}
	
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

/////////////////////////////////////////////////////////////////////////////////////
// Ajout/Replace via tableau des tarifs (Tarif Message)
bool CImportTarif::AddReplaceAllTarifMessage1SeuleMatrice (CTarifMessageArray &TarifMessageArray, CProgressCtrl *ProgressBar)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifMessage Table(&Db);
		Table.Open();

		int Taille = TarifMessageArray.GetSize();

		// Mise � 0 du compteur de progression
		if (ProgressBar != NULL) ProgressBar->SetPos(0);
		if (ProgressBar != NULL) ProgressBar->RedrawWindow();

		// Bidouille pour ne faire que le premier couple station-ville
		// et codifi� avec 999 pour station et 999 pour ville
		// modif � faire dans le programme

		int FirstVille		= TarifMessageArray[0].m_NrVille;
		int FirstStation	= TarifMessageArray[0].m_NrStation;

		CTarifMessage TarifMessage;

		for (int InxTarif=0;InxTarif<TarifMessageArray.GetSize();InxTarif++)
		{
			// Mise � jour barre de progression 
			if (InxTarif % 1000 == 0)
			{
				int ValProgress = int((float(InxTarif)/float(Taille))*100);
				if (ProgressBar != NULL) ProgressBar->SetPos(ValProgress);
				if (ProgressBar != NULL) ProgressBar->RedrawWindow();
			}

			if (TarifMessageArray[InxTarif].m_NrStation == FirstStation &&
				TarifMessageArray[InxTarif].m_NrVille == FirstVille)
			{
				// Special Tarif Message si 1 seule matrice coeff
				TarifMessage				= TarifMessageArray[InxTarif];
				TarifMessage.m_NrStation	= 999;
				TarifMessage.m_NrVille		= 999;

				// Verif champs
				// long NrStation			= TarifMessageArray[InxTarif].m_NrStation;
				long NrStation = TarifMessage.m_NrStation;

				// ATTENTION POUR NRJ
				// if (NrStation > 26 && NrStation < 128) continue;

				// long NrVille			= TarifMessageArray[InxTarif].m_NrVille;
				long NrVille			= TarifMessage.m_NrVille;

				short NrJour			= TarifMessage.m_NrJour;
				short NrTrh				= TarifMessage.m_NrTrh;
				COleDateTime DateDebut	= TarifMessage.m_DateDebut;
				COleDateTime DateFin	= TarifMessage.m_DateFin;
				short Coeff 			= TarifMessage.m_CoeffTranche;

				// Pas d'archivage des elmts neutres
				if (NrStation == 0 && NrVille == 0)
					continue;

				if(!Table.IsEOF())
				{
					Table.MoveFirst();
					CString Search;
					/*
					Search.Format("NrStation = %d AND NrVille = %d AND NrJour = %d AND NrTrh = %d AND DateDebut = %s",
								  TarifMessageArray[InxTarif].m_NrStation,
								  TarifMessageArray[InxTarif].m_NrVille,
								  TarifMessageArray[InxTarif].m_NrJour,
								  TarifMessageArray[InxTarif].m_NrTrh,
								  TarifMessageArray[InxTarif].m_DateDebut.Format("#%m/%d/%y#"));
					*/

					Search.Format("NrStation = %d AND NrVille = %d AND NrJour = %d AND NrTrh = %d AND DateDebut = %s",
								  999,
								  999,
								  TarifMessage.m_NrJour,
								  TarifMessage.m_NrTrh,
								  TarifMessage.m_DateDebut.Format("#%m/%d/%y#"));

					if(Table.FindFirst(Search))
					{
						Table.Edit();
						Table = TarifMessage;
						Table.Update();
					}
					else
					{
						Table.AddNew();
						Table = TarifMessage;
						Table.Update();
					}
				}
				else
				{
					Table.AddNew();
					Table = TarifMessage;
					Table.Update();
					Table.MoveFirst();
				}
			}
		}
	
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}


/////////////////////////////////////////////////////////////////////////////////////
// Mise � jour des tarifications saison
bool CImportTarif::AddReplaceTarifSaison  (CTarifSaison &TarifSaison)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifSaison Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation = %d AND NrVille = %d AND DateDebut = %s",
				           TarifSaison.m_NrStation,
						   TarifSaison.m_NrVille,
				           TarifSaison.m_DateDebut.Format("#%m/%d/%y#"));

			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table = TarifSaison;
				Table.Update();
			}
			else
			{
				Table.AddNew();
				Table = TarifSaison;
				Table.Update();
			}
		}
		else
		{
			Table.AddNew();
			Table = TarifSaison;
			Table.Update();
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

/////////////////////////////////////////////////////////////////////////////////////
// Ajout/Replace via tableau des tarifs (Tarif Saison)
bool CImportTarif::AddReplaceAllTarifSaison  (CTarifSaisonArray &TarifSaisonArray,CProgressCtrl *ProgressBar,CString &ProgSave)
{

	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifSaison Table(&Db);
		Table.Open();

		int NbTarifSaison = TarifSaisonArray.GetSize();
		for (int InxTarif=0;InxTarif<NbTarifSaison;InxTarif++)
		{	

			if(!Table.IsEOF())
			{
				Table.MoveFirst();
				CString Search;
				Search.Format("NrStation = %d AND NrVille = %d AND DateDebut = %s",
							   TarifSaisonArray[InxTarif].m_NrStation,
							   TarifSaisonArray[InxTarif].m_NrVille,
							   TarifSaisonArray[InxTarif].m_DateDebut.Format("#%m/%d/%y#"));

				if(Table.FindFirst(Search))
				{
					Table.Edit();
					Table = TarifSaisonArray[InxTarif];
					Table.Update();
				}
				else
				{
					Table.AddNew();
					Table = TarifSaisonArray[InxTarif];
					Table.Update();
				}
			}
			else
			{
				Table.AddNew();
				Table = TarifSaisonArray[InxTarif];
				Table.Update();
				Table.MoveFirst();
			}

			ProgSave.Format("%d / %d",InxTarif,NbTarifSaison);
			int Progress = int((float(InxTarif)/float(NbTarifSaison))*80)+25;
			if (Progress > 80) Progress = 100;
			if (ProgressBar != NULL)
			{
				ProgressBar->SetPos(Progress);
				ProgressBar->RedrawWindow();
			}
		}

		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

bool CImportTarif::Import(CString FileName)
{
	// A REFAIRE avec nouveau format d'import
	AfxMessageBox("Fonction supprim�e pour le moment !!!!");
	return true;

	CStdioFile File;
	if(!File.Open(FileName,CFile::modeRead|CFile::typeText))
	{
		AfxMessageBox("Ouverture du fichier impossible!");
		return false;
	}
	CString Data;
	if(!File.ReadString(Data))
	{
		AfxMessageBox("Invalid fin du fichier!");
		return false;
	}
	
	int NrStation=atoi(Data);
	CDataStation Sta;
	if(!Sta.Load()) return false;
	int x=0;
	for(;x<Sta.m_Stations.GetSize();x++)
	{
		if(Sta.m_Stations[x].m_NrUnique==NrStation) break;
	}
	if(x>=Sta.m_Stations.GetSize())
	{
		AfxMessageBox("Numero de la station invalide, import abandonn�! /" + NrStation);
		return false;
	}
	if(!File.ReadString(Data))
	{
		AfxMessageBox("Invalid fin du fichier!");
		return false;
	}
	
	int NrVille=atoi(Data);
	CDataVille Vil;
	if(!Vil.Load()) return false;
	for(x=0;x<Vil.m_Villes.GetSize();x++)
	{
		if(Vil.m_Villes[x].m_NrUnique==NrVille) break;
	}
	if(x>=Vil.m_Villes.GetSize())
	{
		AfxMessageBox("Numero de la Ville invalide, import abandonn�! / NrVille = " + NrVille);
		return false;
	}
	if(!File.ReadString(Data))
	{
		AfxMessageBox("Invalid fin du fichier!");
		return false;
	}

	int NbTarifs=atoi(Data);

	CTarif Tarif;
	Tarif.m_NrStation=NrStation;
	Tarif.m_NrVille=NrVille;
	for(x=0;x<NbTarifs;x++)
	{

		do
		{
			if(!File.ReadString(Data))
			{
				AfxMessageBox("Invalid fin du fichier!");
				return false;
			}


		} while(Data.IsEmpty());


		if(!Tarif.m_DateDebut.ParseDateTime(Data,VAR_DATEVALUEONLY))
		{
			AfxMessageBox("Date invalide, import abandonn�!");
			return false;
		}
		for(int Jour=0;Jour<7;Jour++)
		{
			Tarif.m_Tarif[Jour].RemoveAll();
			if(!File.ReadString(Data))
			{
				AfxMessageBox("Invalid fin du fichier!");
				return false;
			}
			int Pos=0;
			int Next=0;
			for(int Hor=0;Hor<48;Hor++,Next++)
			{
				LPCTSTR ptr=Data;
				ptr+=Pos;
				int t=atoi(ptr);
				Tarif.m_Tarif[Jour].Add(t);
				Pos=Data.Find(_T("\t"),Next);
				Next=Pos;
			}
		}

		// Alain / Test si Frais Annonce (pr�c�de si existant ligne vide existante)
		Tarif.m_FraisAntenne = 335;   // attention � diviser par 100

		if ( x != (NbTarifs-1))
		{
			// ce n'est pas le dernier tarif
			if (!File.ReadString(Data))
			{
				AfxMessageBox("Invalid fin du fichier!");
				return false;			
			}
			if (!Data.IsEmpty())
			{	
				// Frais annonce existant dans fichier import
				Tarif.m_FraisAntenne = atoi(Data);
			}
		}
		
		else
		{
			// dernier tarif
			if (File.ReadString(Data))
			{
				if (!Data.IsEmpty())
					Tarif.m_FraisAntenne = atoi(Data);
				
			}
		}


		if(!AddReplace(Tarif)) return false;
	}
	File.Close();
	return true;
}

// Cr�ation du fichier tarif import � partir du fichier global tarifs
/*
3
A;1,6
B;1
C;0,6
<Ligne vide>
nrj;L;M;Me;J;V;S;D;cfm;L;M;Me;J;V;S;D;nost;L;M;Me;J;V;S;D
05H-06H;C;C;C;C;C;C;C;05H-06H;C;C;C;C;C;C;C;05H-06H;C;C;C;C;C;C;C
06H-07H;B;B;B;B;B;C;C;06H-07H;C;C;B;B;B;C;C;06H-07H;B;B;A;A;A;B;C
etc .......
<Ligne vide>
4
ROUGE;1,2
BLANCHE;1
BLEUE;0,8
JAUNE;1,3
<Ligne vide>
443
15/10/2001;ROUGE;;
16/10/2001;ROUGE;;
17/10/2001;ROUGE;;
18/10/2001;ROUGE;;
19/10/2001;ROUGE;;
20/10/2001;ROUGE;;
etc.......
<Ligne vide>
128
ABBEVILLE;17;20;
AIX EN PROVENCE;;;26
AJACCIO;60;24;24
ALBERTVILLE;;;29
ALBI;;16;
ALES;;;25
etc........
*/

bool CImportTarif::CreerFicImport(CString &FileTarif,CProgressCtrl *ProgressBar)
{
	CStdioFile File,FileTmp;
	CString Data;
	CString FileName;
	CString Txt;
	int i,j;
	int Jour,Mois,Annee;
	int NoStation,NoVille;

	CFileDialog Dialog(true,NULL,NULL,OFN_NOCHANGEDIR|OFN_ALLOWMULTISELECT,NULL,NULL);
	char *Buffer=new char[5050];
	Buffer[0]=0;
	Dialog.m_ofn.lpstrFile=Buffer;
	Dialog.m_ofn.nMaxFile=5000;
	
	if(Dialog.DoModal()==IDOK)
	{
		CWaitCursor Wait;
		POSITION Pos=Dialog.GetStartPosition();
		while(Pos)
		{
			
			FileName=Dialog.GetNextPathName(Pos);
		}

		// Verification si c'est bien un fichier englobant tous les tarifs
		if (FileName.Right(3) != "csv")
		{
			AfxMessageBox("Fichier non csv !!!");
			return false;
		}
		else
		{
			if(!File.Open(FileName,CFile::modeRead|CFile::typeText))
			{
				AfxMessageBox("Ouverture du fichier impossible!");
				return false;
			}
	
			if(!File.ReadString(Data))
			{
				AfxMessageBox("Ouverture du fichier impossible!");
				return false;
			}
			else
			{
				if (Data.Left(15) != "Tarifs Multiloc")
				{
					AfxMessageBox("Ouverture du fichier impossible!");
					return false;
				}	
				else
				{
					// Lecture des formats JN/TH
					if(!File.ReadString(Data))
					{
						AfxMessageBox("Erreur formats JN/TH");
						return false;
					}
					int NbFormatJNQH = atoi(Data);
					CStringArray FormatJNQH;
					FormatJNQH.SetSize(NbFormatJNQH);
					
					CArray <float,float&> ValFormatJNQH;
					ValFormatJNQH.SetSize(NbFormatJNQH);

					for (i=0;i<NbFormatJNQH;i++)
					{
						if (!File.ReadString(Data))
						{
							AfxMessageBox("Erreur formats JN/TH");
							return false;	
						}
						int ReplaceVirgule = Data.Replace(",",".");
						FormatJNQH[i] = Data.Left(1);
						ValFormatJNQH[i] = atof(Data.Mid(2));
						float Val = ValFormatJNQH[i];
					}
					
					// Saute une ligne
					if (!File.ReadString(Data)) return false;

					if (ProgressBar != NULL) ProgressBar->SetPos(5);

					// Code station / toujours 1,2,3,4
					if (!File.ReadString(Data)) return false;

					int NbStation = 24;
					CArray <int,int&> CodeStation; 
					CodeStation.SetSize(NbStation);
					CodeStation[0]  = 1;
					CodeStation[1]  = 2;
					CodeStation[2]  = 3;
					CodeStation[3]  = 4;
					CodeStation[4]  = 5;
					CodeStation[5]  = 6;
					CodeStation[6]  = 7;
					CodeStation[7]  = 8;
					CodeStation[8]  = 9;
					CodeStation[9]  = 10;
					CodeStation[10] = 11;
					CodeStation[11] = 12;
					CodeStation[12] = 13;
					CodeStation[13] = 14;
					CodeStation[14] = 15;
					CodeStation[15] = 16;
					CodeStation[16] = 17;
					CodeStation[17] = 18;
					CodeStation[18] = 19;
					CodeStation[19] = 20;
					CodeStation[20] = 21;
					CodeStation[21] = 22;
					CodeStation[22] = 23;
					CodeStation[23] = 24;

					// Nb tranches horaires
					if (!File.ReadString(Data))
					{	
						AfxMessageBox("Manque Nb tranches horaires");
						return false;
					}
					
					int NbTranche = atoi(Data);
					if (NbTranche <= 0 || NbTranche > 48)
					{
						AfxMessageBox("Erreur Nb tranches horaires");
						return false;
					}

					// Dur�e de chaque tranche
					if (!File.ReadString(Data))
					{	
						AfxMessageBox("Manque Dur�e tranches horaires");
						return false;
					}
					int DureeTranche = atoi(Data);
					if (DureeTranche < 30 || DureeTranche > 60)
					{	
						AfxMessageBox("Dur�e tranche horaire incorrecte");
						return false;
					}

					// Remplissage tableau des formats (sur 48 demi-heures)
					CStringArray TabFormatJNQHStation;
					TabFormatJNQHStation.SetSize(48);
					for (i=0;i<NbTranche;i++)
					{
						if (!File.ReadString(Data))
						{
							AfxMessageBox("Tranches horaires d�fectueuses");
							return false;
						}
						if (DureeTranche == 30)
							TabFormatJNQHStation[i] = Data;

						else if (DureeTranche == 60)
						{
							// on vire les ;
							Data.Remove(';');
							TabFormatJNQHStation[i*2] = Data;
							TabFormatJNQHStation[i*2+1] = Data;
						}

					}

					// Saute une ligne
					if (!File.ReadString(Data)) return false;

					if (ProgressBar != NULL) ProgressBar->SetPos(10);

					// Lecture des zones periode
					if(!File.ReadString(Data))
					{
						AfxMessageBox("Erreur zone periode");
						return false;
					}
					int NbZonePeriode = atoi(Data);
					CStringArray ZonePeriode;
					ZonePeriode.SetSize(NbZonePeriode);
					
					CArray <float,float&> ValZonePeriode;
					ValZonePeriode.SetSize(NbZonePeriode);

					for (i=0;i<NbZonePeriode;i++)
					{
						if (!File.ReadString(Data))
						{
							AfxMessageBox("Erreur zone periode JN/TH");
							return false;	
						}
						int ReplaceVirgule = Data.Replace(",",".");
						int Pos = Data.Find(';');
						ZonePeriode[i] = Data.Left(Pos);
						ValZonePeriode[i]=atof(Data.Mid(Pos+1));
						float Val = ValZonePeriode[i];
					}
					
					// Saute une ligne
					if (!File.ReadString(Data)) return false;

					if (ProgressBar != NULL) ProgressBar->SetPos(15);

					// Lecture des zones periodes par date
					if (!File.ReadString(Data)) 
					{
						AfxMessageBox("Manque nombre de dates");
						return false;															
					}

					int NbDate;
					COleDateTime DateTime1erJour;
					NbDate = atoi(Data);
					if (NbDate <0 || NbDate > 700) 
					{
						AfxMessageBox("Nombre de dates erron�");
						return false;															
					}
					
					// Tableau des coeffs � appliquer par jour
					CArray <float,float&> TCoeffJour;
					TCoeffJour.SetSize(NbDate);

					int NbIntervalleDate = 0;
					CArray <PeriodeTarif,PeriodeTarif&> TPeriode;
					TPeriode.SetSize(NbDate);

					float CoeffCur = -1;
					for (i=0;i<NbDate;i++)
					{
						if (!File.ReadString(Data)) 
						{
							AfxMessageBox("Manque une date");
							return false;
						}

						if (Data.GetLength() < 12)
						{
							AfxMessageBox("Ligne date incorrecte");
							return false;
						}
						// Premier jour / on stocke la date
						Jour = atoi(Data.Left(2));
						Mois = atoi(Data.Mid(3,2));
						Annee=atoi(Data.Mid(6,4));
						if (i==0)
						{
							Jour = atoi(Data.Left(2));
							Mois = atoi(Data.Mid(3,2));
							Annee=atoi(Data.Mid(6,4));
							DateTime1erJour = COleDateTime::GetCurrentTime();
							DateTime1erJour.SetDate(Annee,Mois,Jour);
						}
						
						// puis stockage coeff selon p�riode
						int  PosVirg = Data.Find(';');
						if (PosVirg <= 0)
						{
							AfxMessageBox("Ligne date incorrecte");
							return false;
						}
						CString Periode = Data.Mid(PosVirg+1);
						Periode.TrimLeft();
						Periode.TrimRight();
						float CoeffPeriode = -1;
						for (j=0;j<NbZonePeriode;j++)
						{
							if (Periode.Compare(ZonePeriode[j]) == 0)
							{
								CoeffPeriode = ValZonePeriode[j];
								break;
							}
						}

						if (CoeffPeriode == -1)
						{
							AfxMessageBox("Coefficient p�riode incorrecte / " + Data);
							return false;
						}
						TCoeffJour[i]= CoeffPeriode;

						if (CoeffPeriode!=CoeffCur)
						{
							TPeriode[NbIntervalleDate].DateDeb.Format("%2d/%2d/%4d",Jour,Mois,Annee);
							TPeriode[NbIntervalleDate].CoeffPeriode = CoeffPeriode;
							NbIntervalleDate++;
							CoeffCur = CoeffPeriode;
						}

					}

					
					// Saute une ligne
					if (!File.ReadString(Data)) return false;
					
					// Gestion des exceptions date par villes // Lecture des zones periode sp�cifiques villes
					if(!File.ReadString(Data))
					{
						AfxMessageBox("Erreur zone periode exception, manque ligne EXCEPT");
						return false;
					}

					// Saute une ligne
					if (!File.ReadString(Data)) return false;
					if (ProgressBar != NULL) ProgressBar->SetPos(30);

					// Lecture nombre de villes
					if(!File.ReadString(Data))
					{
						AfxMessageBox("Manque nombre de ville");
						return false;
					}
					int NbVille = atoi(Data);
					if (NbVille <= 0)
					{
						AfxMessageBox("Nombre de villes erron�");
						return false;
					}

					CArray<TarifVilleReg,TarifVilleReg&> T_TarifVilleReg;
					T_TarifVilleReg.SetSize(NbVille);
				

					// Lecture des coefficients tarif villes
					for (i=0;i<NbVille;i++)
					{
						Txt.Format("%d",i+1); 
						if(!File.ReadString(Data))
						{
							AfxMessageBox("Manque infos tarif ville n� " + Txt);
							return false;
						}

						int ReplaceVirgule = Data.Replace(",",".");

						// Infos tarif et ville
						int PosSep = Data.Find(';');
						if (PosSep == 0)
						{
							AfxMessageBox("Ligne ville " + Txt + " incorrecte");
							return false;
						}	
						
						// Code de la ville
						T_TarifVilleReg[i].Code = atoi(Data.Left(PosSep));


						// Test si Code Ville existant
						CDataVille Vil;
						if(!Vil.Load()) 
							return false;

						int x=0;
						for(;x<Vil.m_Villes.GetSize();x++)
						{
							if(Vil.m_Villes[x].m_NrUnique==T_TarifVilleReg[i].Code) break;
						}
						if(x>=Vil.m_Villes.GetSize())
						{
							AfxMessageBox("Numero de la Ville invalide, import global abandonn�! / " + Data);
							return false;
						}					
						
						PosSep = Data.Find(';',PosSep+1);

						// Libelle de la ville
						CString txt;
						txt = Data.Left(PosSep);
						T_TarifVilleReg[i].Libelle = txt;
					
						for (j=0;j<NbStation;j++)
							T_TarifVilleReg[i].TarifReg[j] = 0.0;

						int NoReg = 0;
						while (PosSep >= 0 && PosSep < Data.GetLength())
						{
							int	PosSepSuiv = Data.Find(';',PosSep+1);
							
							float Valeur;
							if (PosSepSuiv == PosSep+1)
								T_TarifVilleReg[i].TarifReg[NoReg] =0.0;
							else if (PosSepSuiv <= 0)
							{
								Valeur = atof(Data.Mid(PosSep+1));
								T_TarifVilleReg[i].TarifReg[NoReg] = atof(Data.Mid(PosSep+1)); 
							}
							else
							{
								Valeur = atof(Data.Mid(PosSep+1,PosSepSuiv-PosSep-1));
								T_TarifVilleReg[i].TarifReg[NoReg] =atof(Data.Mid(PosSep+1,PosSepSuiv-PosSep-1));
							}

							PosSep = PosSepSuiv;
							NoReg++;
						}
						
					}
				
					if (ProgressBar != NULL) ProgressBar->SetPos(40);


					// Creation du fichier de transfert
					FileTarif = FileName.Left(FileName.GetLength()-3) + "txt";
					if(!FileTmp.Open(FileTarif,CFile::modeWrite|CFile::modeCreate|CFile::typeText))
					{
						AfxMessageBox("Impossible de cr�er le fichier de transfert " + FileTarif);
					}

					// Ecriture nombre total de couples station/ville valide
					long NbStaVilValide = 0;
					for (NoStation=0;NoStation<NbStation;NoStation++)
					{
						for (NoVille=0;NoVille<NbVille;NoVille++)
						{
							if (T_TarifVilleReg[NoVille].TarifReg[NoStation] > 0)
								NbStaVilValide++; 
						}
					}

					Data.Format("%d\n",NbStaVilValide);	
					FileTmp.WriteString(Data);


					for (NoStation=0;NoStation<NbStation;NoStation++)
					{
						for (NoVille=0;NoVille<NbVille;NoVille++)
						{
							if (T_TarifVilleReg[NoVille].TarifReg[NoStation] > 0)
							{

								// Ecriture Code Station
								Data.Format("%d\n",CodeStation[NoStation]);
								FileTmp.WriteString(Data);

								// Ecriture Code Ville
								Data.Format("%d\n",T_TarifVilleReg[NoVille].Code);
								FileTmp.WriteString(Data);
								
								// Nombre de bloc p�riode tarif et saut de ligne suppl.
								Data.Format("%d\n\n",NbIntervalleDate);
								FileTmp.WriteString(Data);
							
								// Les diff�rentes p�riodes
								for (int NoPeriode=0;NoPeriode <NbIntervalleDate;NoPeriode++)
								{
									// Ecriture date tarif
									FileTmp.WriteString(TPeriode[NoPeriode].DateDeb +"\n");

									// Ecriture des valeurs tarifs par jour semaine (en ligne) et 1/2h (en colonne)
									float ValTarif = T_TarifVilleReg[NoVille].TarifReg[NoStation];
									CString StrTarif;
									for (int JS = 0;JS<7;JS++)
									{
										Data = "";
										
										for (int TH=0;TH<48;TH++)
										{
											// Chaine format tarif pour les stations et tous les jours semaine									
											CString FormatCur;
											FormatCur = TabFormatJNQHStation[TH];
											FormatCur = FormatCur.Mid((NoStation*7),7);
										
											// valeur coeff format
											float CoeffFormat = 1;
											for (i=0;i<NbFormatJNQH;i++)
											{
												if (FormatJNQH[i]==FormatCur.Mid(JS,1))
													CoeffFormat = ValFormatJNQH[i] ;
											}

											// Tarif = Tarif * CoeffFormat
											float ValTarifFinal = ValTarif * CoeffFormat;

											// Multiplie par 100 pour ne pas perdre de pr�cision
											ValTarifFinal *= 100;

											// Tarif = Tarif * CoeffPeriode
											ValTarifFinal*= TPeriode[NoPeriode].CoeffPeriode;

											// Sp�cial pour plan type
											CString LibVille;
											LibVille = T_TarifVilleReg[NoVille].Libelle;
											int PosSep = LibVille.Find(';',1);
											LibVille = LibVille.Mid(PosSep+1);
											LibVille.MakeUpper();
											if (LibVille == "*** AUCUNE VILLE")
											{
												ValTarifFinal = 1;
											}


											if (TH < 47)
												StrTarif.Format("%d\t",int(ValTarifFinal+0.5));
											else
												StrTarif.Format("%d\n",int(ValTarifFinal+0.5));


											Data = Data + StrTarif;
										}		

										// Ecriture chaine tarif demi-heures
										FileTmp.WriteString(Data);

									}
									// Saut de ligne apr�s bloc p�riode
									FileTmp.WriteString("\n");

								} // fin NoPeriode

							}
						}
					}
					

					if (ProgressBar != NULL) ProgressBar->SetPos(50);

					FileTmp.Close();
					
					// Succ�s Transfert 
					//AfxMessageBox("Transfert fichier g�n�rale tarif OK");
					return true;
				}
			}
		}	
		File.Close();
		return true;
	}
	
	delete Buffer;

}

/*
Rappel structure fichier
	Ligne 1 : Nb Stations * Nb Villes

		// Bloc global Station 1 / Ville 1
		Ligne 2 : No Station
		Ligne 3 : No Ville
		Ligne 4 : Nb Tarifs
			Bloc Tarif N�1
			Ligne 4 : Ligne vide
			Ligne 5 : Date format dd/mm/yy
			Ligne 6 / Lundi    : Les tarifs 48 demi-heures
			Ligne 7 / Mardi    :  "    "     "   "    "
			Ligne 8 / Mercredi :  "    "     "   "    "	
			Ligne 9 / Jeudi    :  "    "     "   "    "	
			Ligne 10/ Vendredi :  "    "     "   "    "	
			Ligne 11/ Samedi   :  "    "     "   "    "	
			Ligne 12/ Dimanche :  "    "     "   "    "	
			Ligne vide
			Bloc Tarif N�2 ....
			.......
		// Bloc global Station suivante / Ville suivante
		.......
*/
///////////////////////////////////////////////////////////////////////////////
//						New Import du fichier global tarif
///////////////////////////////////////////////////////////////////////////////
//	   Import Table Tarif de Base
//     Import Table Tarif Message
//     Import Table Tarif Saison
bool CImportTarif::ImportGeneEuro(CString FileName,CProgressCtrl *ProgressBar,CString &ProgSave)
{
	/* Rappel structure fichier

	1er ligne d'info

	///////////////////////////// Infos Tarif Message /////////////////////////
	6
	A;1,3
	B;1
	C;0,6
	D;0,4
	S;1,5
	E;0		>> ce format permet de d�valider une tranche horaire par station

	11;1,2,3,4,5,6,7,8,9,10,11
	48   // avant 24
	30   // avant 60
	C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;
	C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;C;
	A;A;A;A;A;B;C;A;A;A;A;A;B;C;A;A;A;A;A;B;C;A;A;A;A;A;B;C;A;A;A;A;A;B;C;A;A;A;A;A;B;C;A;A;A;A;A;B;C;A;A;A;A;A;B;C;A;A;A;A;A;B;C;A;A;A;A;A;B;C;A;A;A;A;A;B;C;
	A;A;A;A;A;B;C;A;A;A;A;A;B;C;A;A;A;A;A;B;C;A;A;A;A;A;B;C;A;A;A;A;A;B;C;A;A;A;A;A;B;C;A;A;A;A;A;B;C;A;A;A;A;A;B;C;A;A;A;A;A;B;C;A;A;A;A;A;B;C;A;A;A;A;A;B;C;

	etc ....
	
	Ligne 1			: N Nb de type tarification message
	Ligne 2 � 2+N	: Code type message suivi du coeff tarification
	<SAUT DE LIGNE>
	Ligne suivante  :  Nb stations, suivi des codes stations
	Ligne suivante  :  Nb lignes tarification
	Ligne suivante  :  en minutes d�coupage journ�e 
	Lignes suivantes:  Nb Lignes tarification x nb colonnes code tarif (bloc de 7 colonnes (L-D) pour station 1,
					   .............. bloc de 7 colonnes (L-D) pour derni�re station) 											
	

	<SAUT DE LIGNE>

	///////////////////////////// Infos Tarif Saison /////////////////////////
	3
	ROUGE;1,2
	BLANCHE;1
	BLEUE;0,7

	365
	01/01/2003;04/01/2003;BLANCHE,
	05/01/2003;05/01/2003;BLEUE, EXCEPT(3,1,2,3)
	05/01/2003;05/01/2003;ROUGE, ONLY(3,1,2,3)			(*** ici uniquement pour ville cod� 1,2,3)
	etc ........

	Ligne 1             : N , Nb Tarif Saison
	Ligne 2 � N+1		: Code Couleur tarif suivi du coeff
	<SAUT DE LIGNE>
	Ligne 1				: Nb de p�riodes tarifaires
	Lignes suivante		: Date d�but p�riode, date fin p�riode, suivi du code coeff, suivi de
						  EXCEPT(n,code1,code2...)  >> tarif p�riode sauf pour les n villes indiqu�es
						  ou
						  ONLY(n,code1,code2.....)  >> tarif p�riode seulement pour les n villes indiqu�es

	<SAUT DE LIGNE>

	///////////////////////////// Infos Tarif de Base /////////////////////////
	133;01/01/2003;31/01/2003  
	11;1,2,3,4,5,6,7,8,9,10,11
	207;ABBEVILLE;18;21;;;;;;;;;
	1;AIX EN PROVENCE;;;34;;;;;;;;
	2;AJACCIO;68;29,73;29,73;;;;;;;;
	115;ALBERTVILLE;;;15;;;;;;;;
	82;ALBI;;18;;;;;;;;;
	
	Ligne 1 : Nb de villes, suivi de date d�but et fin validit� tarifs de base
	Ligne 2 : Nb stations prises en compte, et liste des codes stations
	Puis Nb lignes tarif
		>>> Code ville;Libelle ville,Nb colonnes tarif (= nb stations)
		
	*/  

	/////////////////////////////////////////////////////////////////////////////////
	// Ouverture et lecture ligne description fichier
	CStdioFile File;
	int Pos;
	int i;

	if(!File.Open(FileName,CFile::modeRead|CFile::typeText))
	{
		AfxMessageBox("Ouverture du fichier impossible!");
		return false;
	}


	CString Data;
	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Invalid fin du fichier!");
		return false;
	}

	/////////////////////////////////////////////////////////////////////////////////
	// Chargement des stations existantes
	CDataStation Sta;
	if(!Sta.Load()) return false;

	/////////////////////////////////////////////////////////////////////////////////
	// Chargement des villes existantes
	CDataVille Vil;
	if(!Vil.Load()) return false;

	// Mise � 0 du compteur de progression
	if (ProgressBar != NULL) ProgressBar->SetPos(0);
	ProgSave = "";

	/////////////////////////////////////////////////////////////////////////////////
	//							Import Tarification Message						   //				
	/////////////////////////////////////////////////////////////////////////////////
	// Lecture nombre de tarifications message diff�rentes et date validit�
	// if(!File.ReadString(Data))
	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Invalid fin du fichier!");
		return false;
	}
	Pos = Data.Find(";");
	if (Pos == -1)
	{
		AfxMessageBox("Manque date validit� systeme tarification!");
		return false;
	}
	
	int NbTarifMessage = atoi(Data.Left(Pos));
	if (NbTarifMessage == 0) return true;

	// Verif date validit�
	CString IntervalleDate,DateDeb,DateFin;
	IntervalleDate = Data.Mid(Pos+1);

	if (IntervalleDate.GetLength() < 21)
	{
		AfxMessageBox("Format date validit� systeme tarification invalide !");
		return false;
	}
	DateDeb = IntervalleDate.Left(10);
	DateFin = IntervalleDate.Mid(11,10);

	// Dates en COleDateTime
	COleDateTime DateTimeDeb(atoi(DateDeb.Mid(6,4)),atoi(DateDeb.Mid(3,2)),atoi(DateDeb.Left(2)),0,0,0);
	COleDateTime DateTimeFin(atoi(DateFin.Mid(6,4)),atoi(DateFin.Mid(3,2)),atoi(DateFin.Left(2)),0,0,0);
	
	// Remplissage tableau des tarifications messages
	CArray <InfoTarifMessage,InfoTarifMessage&> T_TarifMessage;
	T_TarifMessage.SetSize(NbTarifMessage);

	for (i=0;i<NbTarifMessage;i++)
	{
		// Lecture tarification message
		if (!LireLigne(File,Data))
		{
			AfxMessageBox("Manque une info tarification message!");
			return false;
		}	
		
		// Recherche s�parateur code tarif et coeff tarif
		int Pos = Data.Find(";");
		if (Pos == -1)
		{
			AfxMessageBox("Manque une info tarification message!");
			return false;
		}

		// Code Tarification
		Data.Replace(",",".");
		CString Txt = Data.Left(Pos);
		T_TarifMessage[i].TypeMessage = Data.Left(Pos);

		// Coeff Tarifiaction
		Txt = Data.Mid(Pos+1);
		double dbl = atof(Data.Mid(Pos+1)) * 100;
		T_TarifMessage[i].CoeffMessage = int(dbl+0.5);
		
	}

	// Saut de ligne
	// Lecture tarification message
	// if(!File.ReadString(Data))
	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Manque saut de ligne!");
		return false;
	}	

	if (Data != "")
	{
		AfxMessageBox("Manque saut de ligne!");
		return false;
	}

	// Lecture des stations et nb tranches et dur�e tranche
	CArray <long,long&> T_StationTarifMessage;
	int NbStation;
	int NbTrancheTrh;
	int DureeTrh;
	// if(!File.ReadString(Data))
	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Manque info stations pour tarification message!");
		return false;
	}

	// Nb stations valides
	Pos = Data.Find(";");
	if (Pos == -1)
	{
		AfxMessageBox("Manque nb stations pour tarification message!");
		return false;
	}
	NbStation = atoi(Data.Left(Pos));
	T_StationTarifMessage.SetSize(NbStation);

	// Liste des stations
	CString TxtStations = Data.Mid(Pos+1);
	Pos = 1;
	for (i=0;i<NbStation;i++)
	{
		Pos = TxtStations.Find(",",Pos);		
		if (Pos != -1)
		{
			T_StationTarifMessage[i] = atoi(TxtStations.Left(Pos));
			TxtStations = TxtStations.Mid(Pos+1);
		}
		else
		{
			T_StationTarifMessage[i] = atoi(TxtStations);
		}

	}

	// V�rification codes stations trouv�s
	for (i=0;i<NbStation;i++)
	{
		if (T_StationTarifMessage[i] == 0)
		{
			AfxMessageBox("Infos stations pour tarification message invalide!");
			return false;
		}
		else
		{
			// V�rifie code station existant
			int x=0;
			for(;x<Sta.m_Stations.GetSize();x++)
			{
				int NoSta = T_StationTarifMessage[i];
				int NoStaUnique = Sta.m_Stations[x].m_NrUnique;

				if(Sta.m_Stations[x].m_NrUnique==T_StationTarifMessage[i]) break;
			}


			// Ne plus faire
			/*
			if(x>=Sta.m_Stations.GetSize())
			{
				CString TxtMess = "";
				TxtMess.Format("%s%s%d%s","Code stations pour tarification message invalide!","(Station n�",T_StationTarifMessage[i],")");
				AfxMessageBox(TxtMess);
				// return false;
			}
			*/
		}
	}		

	// Lecture nb tranches tarification
	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Manque info nombre de tranches pour tarification message!");
		return false;
	}
	NbTrancheTrh = atoi(Data);
	if (NbTrancheTrh == 0)
	{
		AfxMessageBox("Info nombre de tranches pour tarification message invalide!");
		return false;
	}

    // Lecture dur�e tranche tarification
	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Manque info dur�e tranche pour tarification message!");
		return false;
	}
	DureeTrh = atoi(Data);
	if (DureeTrh != 30 && DureeTrh != 60)
	{
		AfxMessageBox("Dur�e tranches pour tarification message invalide!");
		return false;
	}

	// Nombre d'enregistrement (NbTranche * (DureeTrh/30) * NbStations * NbJour)
	CTarifMessageArray TarifMessageArray;
	int NbEnrgt = NbTrancheTrh * (DureeTrh/30) * 7 * NbStation;
	CTarifMessage TarifMessage;

	// Lecture des lignes tarification (on doit avoir (7 x Nb stations codes par lignes))
	int Cpt = 0;
	for (i=0; i<NbTrancheTrh; i++)
	{
		// Lecture ligne code tranche horaire
		if (!LireLigne(File,Data))
		{
			AfxMessageBox("Manque ligne tranche pour tarification message!");
			return false;
		}

		// Test longueur ligne codification
		int Taille = Data.GetLength();
		if (Data.GetLength() < ((7*NbStation*2)-1))
		{
			AfxMessageBox("Longueur ligne tarification message incorrecte, manque des infos !!!");
			return false;
		}

		// Nombre de r�partition tranche 30 mns
		int NbTrh30 = DureeTrh/30;

		// D�composition de cette ligne par jour et chaine
		CString LigneTrh = Data;
		for (int j=0;j<7*NbStation;j++)
		{
			Pos = LigneTrh.Find(";"); 
			if (Pos != -1)
			{
				CString CodeTarif = LigneTrh.Left(Pos);
				TarifMessage.m_DateDebut    = DateTimeDeb;
				TarifMessage.m_DateFin      = DateTimeFin;

				// Pour Nrj N� de ville toujours identique / mettre 0
				TarifMessage.m_NrVille = 0;

				int k=0;
				for (;k<T_TarifMessage.GetSize();k++)
				{
					if (CodeTarif == T_TarifMessage[k].TypeMessage)
					{
						TarifMessage.m_CoeffTranche = T_TarifMessage[k].CoeffMessage;
						break;
					}
				}

				if (k >= T_TarifMessage.GetSize())
				{
					bool Avoir = false;
					// AfxMessageBox(CodeTarif + "  code tarif non valide !!!");
					// return false;
				}
				else
				{
					TarifMessage.m_NrJour       = j%7;
					TarifMessage.m_NrStation    = T_StationTarifMessage[int(j/7)];

					// Attention � la dur�e tranche fichier
					for (int x=0;x<NbTrh30;x++)
					{
						// Info n� tranche
						TarifMessage.m_NrTrh =  (i*NbTrh30) + x;

						// Stocke info tarification message
						TarifMessageArray.Add(TarifMessage);
					}
				}	

				// Traitment code suivant
				LigneTrh = LigneTrh.Mid(Pos+1);
			}
			else
			{
				// dernier code normalement
				CString CodeTarif = LigneTrh;
				TarifMessage.m_DateDebut    = DateTimeDeb;
				TarifMessage.m_DateFin      = DateTimeFin;
				int k=0;
				for (;k<T_TarifMessage.GetSize();k++)
				{
					if (CodeTarif == T_TarifMessage[k].TypeMessage)
					{
						TarifMessage.m_CoeffTranche = T_TarifMessage[k].CoeffMessage;
						break;
					}
				}
				if (k >= T_TarifMessage.GetSize())
				{
					bool Avoir = false;
					// AfxMessageBox("Ligne tarification incorrecte, code tarif non valide !!!");
					// return false;
				}
				else
				{
					TarifMessage.m_NrJour       = j%7;
					TarifMessage.m_NrStation    = T_StationTarifMessage[int(j/7)];

					// Attention � la dur�e tranche fichier
					for (int x=0;x<NbTrh30;x++)
					{
						// Info n� tranche
						TarifMessage.m_NrTrh =  (i*NbTrh30) + x;

						// Stocke info tarification message
						TarifMessageArray.Add(TarifMessage);
					}
				}
			}
		}
	}

	// Mise � 0 du compteur de progression
	if (ProgressBar != NULL) ProgressBar->SetPos(3);
	if (ProgressBar != NULL) ProgressBar->RedrawWindow();


	// Saut de ligne obligatoire
	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Manque saut de ligne!");
		return false;
	}

	/////////////////////////////////////////////////////////////////////////////////
	//						Import Tarification de base					           //				
	/////////////////////////////////////////////////////////////////////////////////
	//
	//
	/*
	// Lecture nb blocs tarif villes
	if(!File.ReadString(Data))
	{
		AfxMessageBox("Invalid fin du fichier!");
		return false;
	}
	

	int NbBlocTarif = 1;
	for (int iBlocTarif = 1;iBlocTarif <= NbBlocTarif; iBlocTarif++)
	{		
	*/


	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Invalid fin du fichier!");
		return false;
	}

	Pos = Data.Find(";");
	if (Pos == -1)
	{
		AfxMessageBox("Manque date d�but validit� systeme tarification de base !!!");
		return false;
	}

	// Lecture nombre de villes tarif�es
	int NbVilleTarifBase = atoi(Data.Left(Pos));
	Data = Data.Mid(Pos+1);	

	// P�riode validit� tarification de base
	if (Data.GetLength() < 21)
	{
		AfxMessageBox("Mauvais format de date validit� systeme tarification de base !!!");
		return false;
	}		
	DateDeb = Data.Left(10);
	DateFin = Data.Mid(11,10);

	// Dates en COleDateTime
	COleDateTime DateTimeDebTarifBase(atoi(DateDeb.Mid(6,4)),atoi(DateDeb.Mid(3,2)),atoi(DateDeb.Left(2)),0,0,0);
	COleDateTime DateTimeFinTarifBase(atoi(DateFin.Mid(6,4)),atoi(DateFin.Mid(3,2)),atoi(DateFin.Left(2)),0,0,0);
	
	CArray <StationTarifee,StationTarifee&> T_StationTarifee;
	/*
	struct StationTarifee{
		int CodeVille;
		CArray <int,int&> TabCodeStation;
	};
	*/

	// Codage des stations
	CArray <int,int&> CodeStation; 
	CodeStation.SetSize(NbStation);
	for (i=0;i<NbStation;i++)
		CodeStation[i]  = i+1;

	// Dimensionne tableau des stations tarif�es par ville
	T_StationTarifee.SetSize(NbVilleTarifBase);

	// 
	CTarifBaseArray TarifBaseArray;
	CTarifBase TarifBase;

	// Lecture de tous les tarifs de base
	for (i=0;i<NbVilleTarifBase;i++)
	{
		// lecture ligne tarif de base
		// if(!File.ReadString(Data))
		if (!LireLigne(File,Data))
		{
			AfxMessageBox("Manque un tarif de base !!!");
			return false;
		}

		// D�codage Code ville
		Pos = Data.Find(";");
		if (Pos == -1)
		{
			AfxMessageBox("Mauvais format ligne tarif de base !!!" + Data);
			return false;
		}
		int CodeVille = atoi(Data.Left(Pos));

		// Verif ville existante
		int j=0;
		for (;j<Vil.m_Villes.GetSize();j++) 
		{
			if (Vil.m_Villes[j].m_NrUnique == CodeVille)
			{
				break;
			}
		}
		if (j>=Vil.m_Villes.GetSize())
		{
			AfxMessageBox(CodeVille + " >> Code ville inconnue !!!!");
			return false;
		}

		// Sauve code de la ville
		T_StationTarifee[i].CodeVille = CodeVille;

		// Dimensionne le tableau validit� stations
		T_StationTarifee[i].TabCodeStation.SetSize(NbStation);

		// Stocke code ville
		TarifBase.m_NrVille = CodeVille;

		// Stocke date d�but et fin
		TarifBase.m_DateDebut = DateTimeDebTarifBase;
		TarifBase.m_DateFin   = DateTimeFinTarifBase;

		// D�codage Libell� ville
		Data = Data.Mid(Pos+1);

		// D�codage tarif de base par station
		Pos = Data.Find(";");
		if (Pos == -1)
		{
			AfxMessageBox(Data + "  Manque information tarif de base par stations !!!!");
			return false;
		};
		Data = Data.Mid(Pos+1);

		int InxStation = 0;
		Data.Replace(",",".");
		while (Data != "")
		{
			Pos = Data.Find(";"); 
			int Tarif = 0;
			if (Pos != -1)
			{
				if (Data.Left(Pos) == "x" || Data.Left(Pos) == "X")
					// Cas d'un arr�t tarifaire
					Tarif = -1;
				else
					Tarif = int(atof(Data.Left(Pos))*100);

				Data = Data.Mid(Pos+1);
			}
			else
			{
				if (Data.Mid(Pos+1) == "x" || Data.Mid(Pos+1) == "X")
					Tarif = -1;
				else
					Tarif = int(atoi(Data.Mid(Pos+1))*100);
				Data = "";
			}			

			// Stocke validit� station
			/*
			if (Tarif != 0)
			{
				T_StationTarifee[i].TabCodeStation[InxStation] = 1;
				TarifBase.m_NrStation = CodeStation[InxStation];
			}
			else
				T_StationTarifee[i].TabCodeStation[InxStation] = 0;
			*/

			// Modif Octobre 2003 pour g�rer les tarifs qui disparaissent (ex Bouche du Rhone)
			if (Tarif > 0)
			{
				// Tarif de base existant pour cette p�riode
				T_StationTarifee[i].TabCodeStation[InxStation] = 1;
				TarifBase.m_NrStation = CodeStation[InxStation];
			}
			else if (Tarif == -1)
			{
				// Arr�t du tarif de base
				T_StationTarifee[i].TabCodeStation[InxStation] = 1;
				TarifBase.m_NrStation = CodeStation[InxStation];
			}
			else 
				// Pas de tarif de base
				T_StationTarifee[i].TabCodeStation[InxStation] = 0;

			// Sauve tarif de base
			TarifBase.m_TarifBase = Tarif;

			// Frais d'antenne (fixe 30 euros H.T)
			TarifBase.m_FraisAntenne = 3000;			// (* 100)

			// Si tarif , on stocke dans tableau final
			if (Tarif > 0)
				// Stocke tarif de base
				TarifBaseArray.Add(TarifBase);		
			else if (Tarif == -1)
			{
				// Si -1, force arr�t tarif
				TarifBase.m_TarifBase = 0;
				TarifBaseArray.Add(TarifBase);		
			}

			// passe � la station suivante
			InxStation++;
		}

		if (InxStation < CodeStation.GetSize()-1)
		{
			AfxMessageBox(Data + "  Manque information tarif base par stations!!!!");
			return false;
		}

	}

	// Mise � 0 du compteur de progression
	if (ProgressBar != NULL) ProgressBar->SetPos(6);
	if (ProgressBar != NULL) ProgressBar->RedrawWindow();
	
	// Saut de ligne obligatoire
	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Manque saut de ligne!");
		return false;
	}
	
	// Fermeture du fichier import des tarifs
	// File.Close();


	/////////////////////////////////////////////////////////////////////////////////
	//						Import Tarification Saisonni�re					       //				
	/////////////////////////////////////////////////////////////////////////////////
	// Lecture nombre de p�riode tarification
	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Invalid fin du fichier!");
		return false;
	}

	int NbTarifPeriode = atoi(Data);
	if (NbTarifMessage == 0) return true;

	// Remplissage tableau des tarifications messages
	CArray <InfoTarifPeriode,InfoTarifPeriode&> T_TarifPeriode;
	T_TarifPeriode.SetSize(NbTarifPeriode);

	for (i=0;i<NbTarifPeriode;i++)
	{
		// Lecture tarification p�riode
		if (!LireLigne(File,Data))
		{
			AfxMessageBox("Manque une info tarification p�riode!");
			return false;
		}	
		
		// Recherche s�parateur code tarif p�riode et coeff tarif p�riode
		int Pos = Data.Find(";");
		if (Pos == -1)
		{
			AfxMessageBox("Manque une info tarification p�riode!");
			return false;
		}

		// Code Tarification P�riode
		Data.Replace(",",".");
		CString Txt = Data.Left(Pos);
		T_TarifPeriode[i].LibPeriode = Data.Left(Pos);

		// Coeff Tarification
		Txt = Data.Mid(Pos+1);
		double dbl = atof(Data.Mid(Pos+1)) * 100;
		T_TarifPeriode[i].CoeffPeriode = int(dbl+0.5);
	}

	// Saut de ligne
	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Manque saut de ligne!");
		return false;
	}	

	// Lecture nombre de p�riode tarification
	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Manque nombre de p�riode tarification !!!");
		return false;
	}

	int NbPeriodeTarif = atoi(Data);
	CTarifSaisonArray TarifSaisonArray;
	CTarifSaison      TarifSaison;

	// Lecture des lignes p�riode de tarification
	for (i=0;i<NbPeriodeTarif;i++)
	{
		if (!LireLigne(File,Data))
		{
			AfxMessageBox("Manque ligne p�riode tarification !!!");
			return false;
		}

		if (Data.GetLength() < 23)
		{
			AfxMessageBox("Ligne p�riode tarification invalide!!!");
			return false;
		}
				
		// Dates en COleDateTime
		DateDeb = Data.Left(10);
		DateFin = Data.Mid(11,10);
		COleDateTime DateTimeDeb(atoi(DateDeb.Mid(6,4)),atoi(DateDeb.Mid(3,2)),atoi(DateDeb.Left(2)),0,0,0);
		COleDateTime DateTimeFin(atoi(DateFin.Mid(6,4)),atoi(DateFin.Mid(3,2)),atoi(DateFin.Left(2)),0,0,0);
		TarifSaison.m_DateDebut		= DateTimeDeb;
		TarifSaison.m_DateFin		= DateTimeFin;

		// Lecture codification p�riode (ROUGE,BLEUE,BLANCHE etc.....)
		Pos = Data.Find(";");
		if (Pos == -1)
		{
			AfxMessageBox("Manque suite codification p�riode tarification !!!");
			return false;
		}
		Data = Data.Mid(Pos+1);

		// Exceptions villes
		CArray <int,int&> TExceptVille;

		// Seulement certaines villes
		CArray <int,int&> TOnlyVille;
		
		CString NomPeriode;
		Pos = Data.Find(";");
		if (Pos==-1)
		{	
			Data.TrimRight();
			NomPeriode = Data;
		}
		else
		{
			NomPeriode = Data.Left(Pos);
			Data = Data.Mid(Pos+1);

			// Remplissage tableau des villes exception
			int Parenthese1,Parenthese2;
			Parenthese1 = Data.Find("(");
			Parenthese2 = Data.Find(")");
			if (Parenthese1 == -1 || Parenthese2 == -1)
			{
				AfxMessageBox("Manque suite info EXCEPTION OU ONLY p�riode tarification !!!");
				return false;
			}
			
			// D�tection des EXCEPTIONS OU UNICITE DE PRISE EN COMPTE VILLES
			if (Data.Left(6) == "EXCEPT")
			{
				Data = Data.Mid(6);
				Parenthese1 = Data.Find("(");
				Parenthese2 = Data.Find(")");
				Data = Data.Left(Parenthese2);
				Data = Data.Mid(Parenthese1+1);
				while (Data != "")
				{
					Pos = Data.Find(","); 
					if (Pos != -1)
					{
						int CodeVille = atoi(Data.Left(Pos));
						TExceptVille.Add(CodeVille);
						Data = Data.Mid(Pos+1);
					}
					else
					{
						int CodeVille = atoi(Data.Mid(Pos+1));
						TExceptVille.Add(CodeVille);
						Data = "";
					}
				}					
			}
			// Remplissage des villes seulement � prende en compte
			else if (Data.Left(4) == "ONLY")
			{
				Data = Data.Mid(4);
				Parenthese1 = Data.Find("(");
				Parenthese2 = Data.Find(")");
				Data = Data.Left(Parenthese2);
				Data = Data.Mid(Parenthese1+1);
				while (Data != "")
				{
					Pos = Data.Find(","); 
					if (Pos != -1)
					{
						int CodeVille = atoi(Data.Left(Pos));
						TOnlyVille.Add(CodeVille);
						Data = Data.Mid(Pos+1);
					}
					else
					{
						int CodeVille = atoi(Data.Mid(Pos+1));
						TOnlyVille.Add(CodeVille);
						Data = "";
					}
				}									
			}
			else
			{	
				AfxMessageBox("Manque suite info EXCEPTION OU ONLY p�riode tarification !!!");
				return false;
			}

		}

		// Recherche code coefficient
		int j=0;
		for (;j<NbTarifPeriode;j++)
		{
			if (T_TarifPeriode[j].LibPeriode == NomPeriode)
			{
				TarifSaison.m_CoeffSaison	= T_TarifPeriode[j].CoeffPeriode;
				break;
			}
		}
		if (j >= NbTarifPeriode)
		{
			AfxMessageBox(NomPeriode + "  Nom p�riode tarification non trouv�e!!!");
			return false;
		}

		// A VIRER
		int NbOnly   = TOnlyVille.GetSize();
		int NbExcept = TExceptVille.GetSize();

		// A VIRER
		int NbStations = Sta.m_Stations.GetSize();
		int NbVilles   = Vil.m_Villes.GetSize();

		for (int InxSta=0;InxSta<Sta.m_Stations.GetSize();InxSta++)
		{	

			if (Sta.m_Stations[InxSta].m_Libelle != "COUPLAGES")
			{
				for (int InxVil=0;InxVil<Vil.m_Villes.GetSize();InxVil++)
				{			

					int CodeStation = Sta.m_Stations[InxSta].m_NrUnique;
					int CodeVille   = Vil.m_Villes[InxVil].m_NrUnique;

					if (CodeVille == 286 && CodeStation == 128)
						bool OkStop = true;

					// Validit� ou pas de cette p�riode pour la ville en cours en traitement
					bool PeriodeVilleOk = true;
					
					if (TExceptVille.GetSize() > 0)
					{
						PeriodeVilleOk = true;
						for (int k=0;k<TExceptVille.GetSize();k++)
						{					
							if (Vil.m_Villes[InxVil].m_NrUnique == TExceptVille[k])
							{
								PeriodeVilleOk = false;
								break;
							}
						}
					}
					else if (TOnlyVille.GetSize() > 0)
					{
						PeriodeVilleOk = false;
						for (int k=0;k<TOnlyVille.GetSize();k++)
						{					
							if (Vil.m_Villes[InxVil].m_NrUnique == TOnlyVille[k])
							{
								PeriodeVilleOk = true;
								break;
							}
						}
					}

					if (PeriodeVilleOk == true)
					{
						// Voir si cette ville starif�e pour cette station
						bool StationTarifee = false;

						for (int v=0;v<T_StationTarifee.GetSize();v++)
						{
							int NoVille = T_StationTarifee[v].CodeVille;
							// int Val = T_StationTarifee[v].TabCodeStation[InxSta];
							// int Val2 = T_StationTarifee[v].TabCodeStation[CodeStation-1];	

							int ReelInxSta = CodeStation-1;

							/* avant
							if (CodeVille == T_StationTarifee[v].CodeVille)
								if (T_StationTarifee[v].TabCodeStation[InxSta] != 0)
									StationTarifee = true;
							*/
							if (CodeVille == T_StationTarifee[v].CodeVille)
								if (T_StationTarifee[v].TabCodeStation[ReelInxSta] != 0)
									StationTarifee = true;

						}

						// R�cup code statio et code ville
						TarifSaison.m_NrVille		= CodeVille;
						TarifSaison.m_NrStation		= CodeStation;

						if (TarifSaison.m_NrStation > 128)
						{
							int Ok = true;
						}
							

						// Ajoute �lmt tarification
						if (StationTarifee == true)
							TarifSaisonArray.Add(TarifSaison);

					}
				} // fin boucle villes
			}
		} // fin boucke station
	}

	// Mise � 0 du compteur de progression
	if (ProgressBar != NULL) ProgressBar->SetPos(10);
	if (ProgressBar != NULL) ProgressBar->RedrawWindow();
	

	/////////////////////////////////////////////////////////////////////////////////////
	//     Stockage des infos dans les 3 tables tarifaires (Message,Saison,Base)
	/////////////////////////////////////////////////////////////////////////////////////
	//
	// Stockage dans la base table tarif message
	CDataTarifMessage DataTarifMessage;
	if (TarifMessageArray.GetSize() > 0)
	{
		// Ajout ou modif info tarif message
		AddReplaceAllTarifMessage(TarifMessageArray, ProgressBar); 
	}		
	if (ProgressBar != NULL) ProgressBar->SetPos(15);
	if (ProgressBar != NULL) ProgressBar->RedrawWindow();


	// Stockage dans table tarif de base
	CDataTarifBase DataTarifBase;
	int Nb = TarifBaseArray.GetSize();
	if (TarifBaseArray.GetSize() > 0)
	{

		// Ajout ou modif info tarif message
		AddReplaceAllTarifBase(TarifBaseArray); 
	}		

	if (ProgressBar != NULL) ProgressBar->SetPos(25);
	if (ProgressBar != NULL) ProgressBar->RedrawWindow();

	// Stockage dans la base tarif saisonnier
	int NbTarif = TarifSaisonArray.GetSize();
	CDataTarifSaison DataTarifSaison;
	if (TarifSaisonArray.GetSize() > 0)
	{
		// Ajout ou modif info tarif saison
		AddReplaceAllTarifSaison(TarifSaisonArray,ProgressBar,ProgSave); 
	}		
	if (ProgressBar != NULL) ProgressBar->SetPos(100);
	if (ProgressBar != NULL) ProgressBar->RedrawWindow();
	
	// Fermeture du fichier import des tarifs
	File.Close();

	AfxMessageBox ("FIN TRANSFERT FICHIER GLOBAL TARIF EN EUROS");
	return true;
}

///////////////////////////////////////////////////////////////////////////////////////
// Decomposition coefficients tranche horaire
bool CImportTarif::LireTrhCoeff(CString Data, int &NoDebTrh, int &NoFinTrh, CArray <float,float> &TabCoeffTrh)
{
	// Lecture de l'intervlle tranche horaire
	int Pos = Data.Find(";");
	if (Pos != 11)
	{
		// Manque intervalle tranche horaire
		AfxMessageBox("Manque intervalle tranche horaire");
		return false;
	}
	
	// R�cup intervall tranche horaire
	CString IntervalleTrh = Data.Left(Pos);
	Data = Data.Mid(Pos+1);

	CString DebTrh, FinTrh; 

	// Controle de l'intervalle tranche horaire
	Pos = IntervalleTrh.Find("/");
	if (Pos != 5)
	{
		// Mauvais format de intervalle tranche horaire
		AfxMessageBox("Mauvais format de intervalle tranche horaire");
		return false;
	}

	// Debut et fin intervalle
	DebTrh = IntervalleTrh.Left(Pos);
	FinTrh = IntervalleTrh.Mid(Pos+1);

	// Test debut et fin intervalle ranche horaire, et convertit en n� de tranche
	Pos = DebTrh.Find("h");
	if (Pos != 2)
	{
		// Mauvais format de intervalle tranche horaire
		AfxMessageBox("Mauvais format d�but intervalle tranche horaire");
	}


	// Attention au clacul n� tranche (1ere tranche commence � 05h30)
	NoDebTrh = atoi(DebTrh.Left(Pos));
	NoDebTrh = NoDebTrh * 2;

	if (atoi(DebTrh.Mid(Pos)) != 30 && atoi(DebTrh.Mid(Pos)) != 0)
	{
		// Mauvais format d�but intervalle tranche horaire
		AfxMessageBox("Mauvais format d�but intervalle tranche horaire");
	}

	NoDebTrh = NoDebTrh + atoi(DebTrh.Mid(Pos+1)) / 30;	
	
	Pos = FinTrh.Find("h");
	if (Pos != 2)
	{
		// Mauvais format de intervalle tranche horaire
		AfxMessageBox("Mauvais format d�but intervalle tranche horaire");
	}
	NoFinTrh = atoi(FinTrh.Left(Pos));
	NoFinTrh = NoFinTrh * 2;
	if (atoi(FinTrh.Mid(Pos)) != 30 && atoi(FinTrh.Mid(Pos)) != 0)
	{
		// Mauvais format d�but intervalle tranche horaire
		AfxMessageBox("Mauvais format fin intervalle tranche horaire");
	}

	NoFinTrh = NoFinTrh + atoi(FinTrh.Mid(Pos+1)) / 30;	

	// R�cup les coefficients
	int MaxCoeff = 7;
	float ValTrh = 0.0;
	
	// Boucle sur les 7 coefficients
	for (int InxTrh = 0; InxTrh < MaxCoeff; InxTrh++)
	{
		Pos = Data.Find(";");
		if (Pos != 0)
		{
			// R�cup�re le coefficient
			CString StrValTrh = Data.Left(Pos);
			StrValTrh.Replace(",",".");
			Data = Data.Mid(Pos+1);
			ValTrh = atof(StrValTrh);

			// Stocke le coefficeint
			TabCoeffTrh[InxTrh] = ValTrh;
		}
		else
		{
			// Manque intervalle tranche horaire
			AfxMessageBox("Manque coefficient tranche horaire");
			return false;
		}
	}

	return true;
}

///////////////////////////////////////////////////////////////////////////////////////
//						Import du fichier global tarif (via les matrices tf1)
///////////////////////////////////////////////////////////////////////////////////////
//	   Import Table Tarif de Base
//     Import Table Tarif Message
//     Import Table Tarif Saison
bool CImportTarif::ImportGeneEuroFormatTf1(CString FileName,CProgressCtrl *ProgressBar,CString &ProgSave)
{
	/////////////////////////////////////////////////////////////////////////////////
	// Ouverture et lecture ligne description fichier
	CStdioFile File;
	int Pos;
	int i;

 	if(!File.Open(FileName,CFile::modeRead|CFile::typeText))
	{
		AfxMessageBox("Ouverture du fichier impossible!");
		return false;
	}

	CString Data;
	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Invalid fin du fichier!");
		return false;
	}

	Pos = Data.Find(";");
	if (Pos == -1)
	{
		AfxMessageBox("Manque date validit� systeme tarification!");
		return false;
	}

	/////////////////////////////////////////////////////////////////////////////////
	// Chargement des stations existantes
	CDataStation Sta;
	if(!Sta.Load()) return false;

	/////////////////////////////////////////////////////////////////////////////////
	// Chargement des villes existantes
	CDataVille Vil;
	if(!Vil.Load()) return false;

	// Mise � 0 du compteur de progression
	if (ProgressBar != NULL) ProgressBar->SetPos(0);
	ProgSave = "";

	// Verif date validit� des tarifs
	CString IntervalleDate,DateDeb,DateFin;
	IntervalleDate = Data.Mid(Pos+1);

	if (IntervalleDate.GetLength() < 21)
	{
		AfxMessageBox("Format date validit� systeme tarification invalide !");
		return false;
	}
	DateDeb = IntervalleDate.Left(10);
	DateFin = IntervalleDate.Mid(11,10);

	// Dates en COleDateTime
	COleDateTime DateTimeDeb(atoi(DateDeb.Mid(6,4)),atoi(DateDeb.Mid(3,2)),atoi(DateDeb.Left(2)),0,0,0);
	COleDateTime DateTimeFin(atoi(DateFin.Mid(6,4)),atoi(DateFin.Mid(3,2)),atoi(DateFin.Left(2)),0,0,0);

	// Lecture des tranches horaires coefficients message
	if (!LireLigne(File,Data))
	{
		return false;
	}
	
	// Nombre de tranches coeff message
	int NbTrhCoeffMessage = atoi(Data);

	CTarifMessageArray TarifMessageArray;
	int NbEnrgt = 48;
	int NbJour  = 7;
	CTarifMessage TarifMessage;

	// Boucle sur les tranches coefficients message
	CArray <float,float> T_CoeffTrh;
	T_CoeffTrh.SetSize(NbJour);
	int NoDebTrh = 0;
	int NoFinTrh = 0;

	for (int InxTrh = 0; InxTrh < NbTrhCoeffMessage; InxTrh++)
	{
		if (!LireLigne(File,Data))
		{
			AfxMessageBox("Manque ligne tranche pour tarification message!");
			return false;
		}

		// R�cup la tranche horaire et coefficients
		if (!LireTrhCoeff(Data,NoDebTrh, NoFinTrh, T_CoeffTrh))
		{
			AfxMessageBox("Longueur ligne coefficients message incorrecte, manque des infos !!!");
			return false;
		}
		else
		{
			// Stocke les diff�rents coeffs sur toutes les tranches de la ligne
			for (int InxNoTrh = NoDebTrh; InxNoTrh <= NoFinTrh; InxNoTrh++)
			{
				// Attention au recacalage la journ�e commence � 5h00   (de 05h00 � 23h30 indice 0 � 37, de 00h00 � 04h30 indice de 38 � 47)
				int RealNoTrh = InxNoTrh;
				if (InxNoTrh < 10)
					RealNoTrh = 38 + InxNoTrh;
				else
					RealNoTrh = InxNoTrh - 10; 

				// Boucle sur les jours
				for (int InxJour = 0; InxJour<7; InxJour++)
				{
					TarifMessage.m_NrStation	= 0;
					TarifMessage.m_NrVille		= 0;
					TarifMessage.m_DateDebut    = DateTimeDeb;
					TarifMessage.m_DateFin		= DateTimeFin;
					TarifMessage.m_NrTrh		= RealNoTrh;
					TarifMessage.m_NrJour		= InxJour;
					TarifMessage.m_CoeffTranche	= (T_CoeffTrh[InxJour]+ 0.001) * 100;


					// Stocke info tarification message
					TarifMessageArray.Add(TarifMessage);
				}
			}
		}
	}
	
	// Mise � 0 du compteur de progression
	if (ProgressBar != NULL) ProgressBar->SetPos(3);
	if (ProgressBar != NULL) ProgressBar->RedrawWindow();

	// Saut de ligne obligatoire
	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Manque saut de ligne!");
		return false;
	}

	/////////////////////////////////////////////////////////////////////////////////
	//						Import Tarification de base					           //				
	/////////////////////////////////////////////////////////////////////////////////
	//
	//
	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Invalid fin du fichier!");
		return false;
	}

	Pos = Data.Find(";");
	if (Pos == -1)
	{
		AfxMessageBox("Manque date d�but validit� systeme tarification de base !!!");
		return false;
	}

	// Lecture nombre de villes tarif�es
	int NbVilleTarifBase = atoi(Data.Left(Pos));
	Data = Data.Mid(Pos+1);	

	// P�riode validit� tarification de base
	if (Data.GetLength() < 21)
	{
		AfxMessageBox("Mauvais format de date validit� systeme tarification de base !!!");
		return false;
	}		
	DateDeb = Data.Left(10);
	DateFin = Data.Mid(11,10);

	// Dates en COleDateTime
	COleDateTime DateTimeDebTarifBase(atoi(DateDeb.Mid(6,4)),atoi(DateDeb.Mid(3,2)),atoi(DateDeb.Left(2)),0,0,0);
	COleDateTime DateTimeFinTarifBase(atoi(DateFin.Mid(6,4)),atoi(DateFin.Mid(3,2)),atoi(DateFin.Left(2)),0,0,0);

	CArray <StationTarifee,StationTarifee&> T_StationTarifee;

	// Dimensionne tableau des stations tarif�es par ville
	T_StationTarifee.SetSize(NbVilleTarifBase);

	CTarifBaseArray TarifBaseArray;
	CTarifBase TarifBase;

	// Nombre de stations totales
	int NbStations = Sta.m_Stations.GetSize();

	// Table generale des coeffs messages
	CTarifMessageArray TarifMessageArrayGlobal;


	// A VIRER
	int MaxInxStation = 0;

	// Lecture de tous les tarifs de base
	for (i=0; i<NbVilleTarifBase; i++)
	{
		// lecture ligne tarif de base
		if (!LireLigne(File,Data))
		{
			AfxMessageBox("Manque un tarif de base !!!");
			return false;
		}
		
		// D�codage Code ville
		Pos = Data.Find(";");
		if (Pos == -1)
		{
			AfxMessageBox("Mauvais format ligne tarif de base !!!" + Data);
			return false;
		}
		int CodeVille = atoi(Data.Left(Pos));

		if (i%10 == 0)
		{
			bool Ok = true;
		}

		// Verif ville existante
		int j;
		for (j=0;j<Vil.m_Villes.GetSize();j++) 
		{
			if (Vil.m_Villes[j].m_NrUnique == CodeVille)
			{
				break;
			}
		}
		if (j>=Vil.m_Villes.GetSize())
		{
			AfxMessageBox(CodeVille + " >> Code ville inconnue !!!!");
			return false;
		}
		
		// D�codage Libell� ville
		Data = Data.Mid(Pos+1);

		// D�codage tarif de base par station
		Pos = Data.Find(";");
		if (Pos == -1)
		{
			AfxMessageBox(Data + "  Manque information tarif de base par stations !!!!");
			return false;
		};
		Data = Data.Mid(Pos+1);

		// D�codage Code station
		Pos = Data.Find(";");
		if (Pos == -1)
		{
			AfxMessageBox("Mauvais format ligne tarif de base / manque info station!!!" + Data);
			return false;
		}
		int CodeStation = atoi(Data.Left(Pos));
		Data = Data.Mid(Pos+1);

		// Verif station existante
		for (j= 0; j<NbStations; j++) 
		{
			if (Sta.m_Stations[j].m_NrUnique == CodeStation)
			{
				break;
			}
		}
		if (j>=Sta.m_Stations.GetSize())
		{
			AfxMessageBox(CodeStation + " >> Code station inconnue !!!!");
			return false;
		}

		// Decodage libell� de la station
		Pos = Data.Find(";");
		Data = Data.Mid(Pos+1);
		if (Pos < 0)
		{
			AfxMessageBox("Manque libell� station !!!!");
			return false;
		}

		// Sauve code de la ville
		T_StationTarifee[i].CodeVille = CodeVille;

		// Dimensionne le tableau validit� stations
		T_StationTarifee[i].TabCodeStation.SetSize(NbStations);

		// Stocke code ville
		TarifBase.m_NrVille = CodeVille;

		// Stocke code ville
		TarifBase.m_NrStation = CodeStation;

		// Stocke date d�but et fin
		TarifBase.m_DateDebut = DateTimeDebTarifBase;
		TarifBase.m_DateFin   = DateTimeFinTarifBase;

		// A FAIRE
		// Sauve code de la station
		T_StationTarifee[i].TabCodeStation[j] = 1;
		// T_StationTarifee[i].TabCodeStation[CodeStation-1] = 1;

		int InxStation = j;

		if (InxStation > MaxInxStation)
		{
			MaxInxStation = InxStation;
		}

		Data.Replace(",",".");
		
		Pos = Data.Find(";"); 
		int Tarif = 0;
		if (Pos != -1)
		{
			if (Data.Left(Pos) == "x" || Data.Left(Pos) == "X")
				// Cas d'un arr�t tarifaire
				Tarif = -1;
			else
				Tarif = int(atof(Data.Left(Pos))*100);

			Data = Data.Mid(Pos+1);
		}
		else
		{
			if (Data.Mid(Pos+1) == "x" || Data.Left(Pos) == "X")
				Tarif = -1;
			else
				Tarif = int(atoi(Data.Mid(Pos+1))*100);
			Data = "";
		}			

		// Stocke validit� station
		// Modif Octobre 2003 pour g�rer les tarifs qui disparaissent (ex Bouche du Rhone)
		if (Tarif > 0)
		{
			// Tarif de base existant pour cette p�riode
			T_StationTarifee[i].TabCodeStation[InxStation] = 1;
			TarifBase.m_NrStation = CodeStation;
		}
		else if (Tarif == -1)
		{
			// Arr�t du tarif de base
			T_StationTarifee[i].TabCodeStation[InxStation] = 1;
			TarifBase.m_NrStation = CodeStation;
		}
		else 
			// Pas de tarif de base
			T_StationTarifee[i].TabCodeStation[CodeStation-1] = 0;
			// T_StationTarifee[i].TabCodeStation[InxStation] = 0;

		// Sauve tarif de base
		TarifBase.m_TarifBase = Tarif;

		// Frais d'antenne (fixe 30 euros H.T)
		TarifBase.m_FraisAntenne = 3000;			// (* 100)

		// Si tarif , on stocke dans tableau final
		if (Tarif > 0)
			// Stocke tarif de base
			TarifBaseArray.Add(TarifBase);		
		else if (Tarif == -1)
		{
			// Si -1, force arr�t tarif
			TarifBase.m_TarifBase = 0;
			TarifBaseArray.Add(TarifBase);		
		}

		// Reprend la grille coefficients pour le code station et code ville en cours
		for (int Inx = 0; Inx < TarifMessageArray.GetSize(); Inx++)
		{
			CTarifMessage TarifMessage = TarifMessageArray[Inx];
			TarifMessage.m_NrStation = CodeStation;
			TarifMessage.m_NrVille = CodeVille;
			TarifMessageArrayGlobal.Add(TarifMessage);
		}	
	}

	// Mise � 0 du compteur de progression
	if (ProgressBar != NULL) ProgressBar->SetPos(6);
	if (ProgressBar != NULL) ProgressBar->RedrawWindow();

	// Saut de ligne obligatoire
	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Manque saut de ligne!");
		return false;
	}

	int ValInx = MaxInxStation;


	/////////////////////////////////////////////////////////////////////////////////
	//						Import Tarification Saisonni�re					       //				
	/////////////////////////////////////////////////////////////////////////////////
	// Lecture nombre de p�riode tarification
	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Invalid fin du fichier!");
		return false;
	}

	int NbTarifPeriode = atoi(Data);
	// if (NbTarifMessage == 0) return true;

	// Remplissage tableau des tarifications messages
	CArray <InfoTarifPeriode,InfoTarifPeriode&> T_TarifPeriode;
	T_TarifPeriode.SetSize(NbTarifPeriode);



	// TEST A VIRER
	int Vals = T_StationTarifee.GetSize();
	
	for (int s = 0; s < T_StationTarifee.GetSize(); s++)
	{
		int Valx = T_StationTarifee[s].TabCodeStation.GetSize();

		for (int x=0;x<T_StationTarifee[s].TabCodeStation.GetSize(); x++)
		{
			int Code = T_StationTarifee[s].TabCodeStation[x];

			if (Code != 0)
				bool Ok = true;
		}
	}		
			



	for (i=0;i<NbTarifPeriode;i++)
	{
		// Lecture tarification p�riode
		if (!LireLigne(File,Data))
		{
			AfxMessageBox("Manque une info tarification p�riode!");
			return false;
		}	

		// Recherche s�parateur code tarif p�riode et coeff tarif p�riode
		int Pos = Data.Find(";");
		if (Pos == -1)
		{
			AfxMessageBox("Manque une info tarification p�riode!");
			return false;
		}

		// Code Tarification P�riode
		Data.Replace(",",".");
		CString Txt = Data.Left(Pos);
		T_TarifPeriode[i].LibPeriode = Data.Left(Pos);

		// Coeff Tarification
		Txt = Data.Mid(Pos+1);
		double dbl = atof(Data.Mid(Pos+1)) * 100;
		T_TarifPeriode[i].CoeffPeriode = int(dbl+0.5);
	}

	// Saut de ligne
	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Manque saut de ligne!");
		return false;
	}	

	// Lecture nombre de p�riode tarification
	if (!LireLigne(File,Data))
	{
		AfxMessageBox("Manque nombre de p�riode tarification !!!");
		return false;
	}

	int NbPeriodeTarif = atoi(Data);
	CTarifSaisonArray TarifSaisonArray;
	CTarifSaison      TarifSaison;

	// Lecture des lignes p�riode de tarification
	for (i=0;i<NbPeriodeTarif;i++)
	{
		if (!LireLigne(File,Data))
		{
			AfxMessageBox("Manque ligne p�riode tarification !!!");
			return false;
		}

		if (Data.GetLength() < 23)
		{
			AfxMessageBox("Ligne p�riode tarification invalide!!!");
			return false;
		}

		// Dates en COleDateTime
		DateDeb = Data.Left(10);
		DateFin = Data.Mid(11,10);
		COleDateTime DateTimeDeb(atoi(DateDeb.Mid(6,4)),atoi(DateDeb.Mid(3,2)),atoi(DateDeb.Left(2)),0,0,0);
		COleDateTime DateTimeFin(atoi(DateFin.Mid(6,4)),atoi(DateFin.Mid(3,2)),atoi(DateFin.Left(2)),0,0,0);
		TarifSaison.m_DateDebut		= DateTimeDeb;
		TarifSaison.m_DateFin		= DateTimeFin;

		// Lecture codification p�riode (ROUGE,BLEUE,BLANCHE etc.....)
		Pos = Data.Find(";");
		if (Pos == -1)
		{
			AfxMessageBox("Manque suite codification p�riode tarification !!!");
			return false;
		}
		Data = Data.Mid(Pos+1);

		// Exceptions villes
		CArray <int,int&> TExceptVille;

		// Seulement certaines villes
		CArray <int,int&> TOnlyVille;

		CString NomPeriode;
		Pos = Data.Find(";");
		int PosExcept = Data.Find("EXCEPT");
		int PosOnly	  = Data.Find("ONLY");	

		if (Pos==-1 || (Pos != 0 && PosExcept==-1 && PosOnly==-1))
		{	
			Data.Replace(";","");
			Data.TrimRight();
			NomPeriode = Data;
		}
		else
		{
			NomPeriode = Data.Left(Pos);
			Data = Data.Mid(Pos+1);

			// Remplissage tableau des villes exception
			int Parenthese1,Parenthese2;
			Parenthese1 = Data.Find("(");
			Parenthese2 = Data.Find(")");
			if (Parenthese1 == -1 || Parenthese2 == -1)
			{
				AfxMessageBox("Manque suite info EXCEPTION OU ONLY p�riode tarification !!!");
				return false;
			}

			// D�tection des EXCEPTIONS OU UNICITE DE PRISE EN COMPTE VILLES
			if (Data.Left(6) == "EXCEPT")
			{
				Data = Data.Mid(6);
				Parenthese1 = Data.Find("(");
				Parenthese2 = Data.Find(")");
				Data = Data.Left(Parenthese2);
				Data = Data.Mid(Parenthese1+1);
				while (Data != "")
				{
					Pos = Data.Find(","); 
					if (Pos != -1)
					{
						int CodeVille = atoi(Data.Left(Pos));
						TExceptVille.Add(CodeVille);
						Data = Data.Mid(Pos+1);
					}
					else
					{
						int CodeVille = atoi(Data.Mid(Pos+1));
						TExceptVille.Add(CodeVille);
						Data = "";
					}
				}					
			}
			// Remplissage des villes seulement � prende en compte
			else if (Data.Left(4) == "ONLY")
			{
				Data = Data.Mid(4);
				Parenthese1 = Data.Find("(");
				Parenthese2 = Data.Find(")");
				Data = Data.Left(Parenthese2);
				Data = Data.Mid(Parenthese1+1);
				while (Data != "")
				{
					Pos = Data.Find(","); 
					if (Pos != -1)
					{
						int CodeVille = atoi(Data.Left(Pos));
						TOnlyVille.Add(CodeVille);
						Data = Data.Mid(Pos+1);
					}
					else
					{
						int CodeVille = atoi(Data.Mid(Pos+1));
						TOnlyVille.Add(CodeVille);
						Data = "";
					}
				}									
			}
			else
			{	
				AfxMessageBox("Manque suite info EXCEPTION OU ONLY p�riode tarification !!!");
				return false;
			}

		}

		// Recherche code coefficient
		int j=0;
		for (;j<NbTarifPeriode;j++)
		{
			if (T_TarifPeriode[j].LibPeriode == NomPeriode)
			{
				TarifSaison.m_CoeffSaison	= T_TarifPeriode[j].CoeffPeriode;
				break;
			}
		}
		if (j >= NbTarifPeriode)
		{
			AfxMessageBox(NomPeriode + "  Nom p�riode tarification non trouv�e!!!");
			return false;
		}

		int NbOnly   = TOnlyVille.GetSize();
		int NbExcept = TExceptVille.GetSize();

		// A VIRER
		int NbStations = Sta.m_Stations.GetSize();
		int NbVilles   = Vil.m_Villes.GetSize();

		for (int InxSta=0;InxSta<Sta.m_Stations.GetSize();InxSta++)
		{	
			int CodeStation = Sta.m_Stations[InxSta].m_NrUnique;
			
			if (CodeStation == 116)
			{
				bool Ok = true;
			}

			if (Sta.m_Stations[InxSta].m_Libelle != "COUPLAGES")
			{
				for (int InxVil=0;InxVil<Vil.m_Villes.GetSize();InxVil++)
				{			

					// int CodeStation = Sta.m_Stations[InxSta].m_NrUnique;
					int CodeVille   = Vil.m_Villes[InxVil].m_NrUnique;

					// Validit� ou pas de cette p�riode pour la ville en cours en traitement
					bool PeriodeVilleOk = true;

					if (TExceptVille.GetSize() > 0)
					{
						PeriodeVilleOk = true;
						for (int k=0;k<TExceptVille.GetSize();k++)
						{					
							if (Vil.m_Villes[InxVil].m_NrUnique == TExceptVille[k])
							{
								PeriodeVilleOk = false;
								break;
							}
						}
					}
					else if (TOnlyVille.GetSize() > 0)
					{
						PeriodeVilleOk = false;
						for (int k=0;k<TOnlyVille.GetSize();k++)
						{					
							if (Vil.m_Villes[InxVil].m_NrUnique == TOnlyVille[k])
							{
								PeriodeVilleOk = true;
								break;
							}
						}
					}

					if (PeriodeVilleOk == true)
					{
						// Voir si cette ville starif�e pour cette station
						bool StationTarifee = false;

						for (int v=0;v<T_StationTarifee.GetSize();v++)
						{
							int ReelInxSta = CodeStation-1;

							/*
							if (CodeVille == T_StationTarifee[v].CodeVille)
							{
								if (T_StationTarifee[v].TabCodeStation[ReelInxSta] != 0)
									StationTarifee = true;
							}
							*/

							if (CodeVille == T_StationTarifee[v].CodeVille)
								if (T_StationTarifee[v].TabCodeStation[InxSta] != 0)
									StationTarifee = true;
						}

						// R�cup code statio et code ville
						TarifSaison.m_NrVille		= CodeVille;
						TarifSaison.m_NrStation		= CodeStation;

						// Ajoute �lmt tarification
						if (StationTarifee == true)
							TarifSaisonArray.Add(TarifSaison);

					}
				} // fin boucle villes
			}
		} // fin boucke station
	}

	// Mise � 0 du compteur de progression
	if (ProgressBar != NULL) ProgressBar->SetPos(10);
	if (ProgressBar != NULL) ProgressBar->RedrawWindow();

	/////////////////////////////////////////////////////////////////////////////////////
	//     Stockage des infos dans les 3 tables tarifaires (Message,Saison,Base)
	/////////////////////////////////////////////////////////////////////////////////////
	//
	// Stockage dans la base table tarif message
	CDataTarifMessage DataTarifMessage;
	if (TarifMessageArray.GetSize() > 0)
	{
		// Ajout ou modif info tarif message
		// AddReplaceAllTarifMessage(TarifMessageArrayGlobal,ProgressBar); 

		// Cas d'1 seule matrice
		AddReplaceAllTarifMessage1SeuleMatrice(TarifMessageArrayGlobal,ProgressBar);		
	}

	if (ProgressBar != NULL) ProgressBar->SetPos(15);
	if (ProgressBar != NULL) ProgressBar->RedrawWindow();

	// Stockage dans table tarif de base
	CDataTarifBase DataTarifBase;
	int Nb = TarifBaseArray.GetSize();
	if (TarifBaseArray.GetSize() > 0)
	{

		// Ajout ou modif info tarif message
		AddReplaceAllTarifBase(TarifBaseArray); 
	}		

	if (ProgressBar != NULL) ProgressBar->SetPos(25);
	if (ProgressBar != NULL) ProgressBar->RedrawWindow();

	// Stockage dans la base tarif saisonnier
	int NbTarif = TarifSaisonArray.GetSize();
	CDataTarifSaison DataTarifSaison;
	if (TarifSaisonArray.GetSize() > 0)
	{
		// Ajout ou modif info tarif saison
		AddReplaceAllTarifSaison(TarifSaisonArray,ProgressBar,ProgSave); 
	}

	if (ProgressBar != NULL) ProgressBar->SetPos(100);
	if (ProgressBar != NULL) ProgressBar->RedrawWindow();

	// Fermeture du fichier import des tarifs
	File.Close();

	AfxMessageBox ("FIN TRANSFERT FICHIER GLOBAL TARIF EN EUROS");
	return true;
}

///////////////////////////////////////////////////////////////////////
// Lecture d'une ligne du fichier tarif g�n�ral
//
// on �vitera toutes les lignes commentaires (commen�ant par //)
//
bool CImportTarif::LireLigne(CStdioFile &File, 	CString &Data)
{
	// Voir si tout d'abord si ligne valide
	while (File.ReadString(Data))
	{
		int Pos = Data.Find("//");
		if (Pos != 0)
		{
			// Ce n'est pas une ligne commentaire, on la prend
			return true;
		}
	}

	// pas de ligne valide
	return false;
}	