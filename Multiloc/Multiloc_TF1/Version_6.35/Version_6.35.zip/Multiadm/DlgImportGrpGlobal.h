#if !defined(AFX_DLGIMPORTGRPGLOBAL_H__65EC52C1_DCDC_11D5_8A64_0010B5865AAB__INCLUDED_)
#define AFX_DLGIMPORTGRPGLOBAL_H__65EC52C1_DCDC_11D5_8A64_0010B5865AAB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgImportGrpGlobal.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgImportGrpGlobal dialog

class CDlgImportGrpGlobal : public CDialog
{
// Construction
public:
	CDlgImportGrpGlobal(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgImportGrpGlobal)
	enum { IDD = IDD_IMPORT_GRPGLOBAL };
	CProgressCtrl	m_ProgressImportGrp;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgImportGrpGlobal)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgImportGrpGlobal)
	afx_msg void OnImportgrp();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGIMPORTGRPGLOBAL_H__65EC52C1_DCDC_11D5_8A64_0010B5865AAB__INCLUDED_)
