#if !defined(AFX_VOLUMEDLG_H__E3234542_8A97_11D2_AAF8_0000E86750A8__INCLUDED_)
#define AFX_VOLUMEDLG_H__E3234542_8A97_11D2_AAF8_0000E86750A8__INCLUDED_

#include "DataVolume.h"	
#include "DataVolumeRegion.h"	
#include "Volume.h"	
#include "VolumeRegion.h"	

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// VolumeDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CVolumeDlg dialog

class CVolumeDlg : public CDialog
{
// Construction
public:
	bool m_Mode_Modify;
	bool m_Mode_New;
	int m_CurData;
	int m_CurPalier;

	CDataVolume m_Data;
	CDataVolumeRegion m_DataRegion;
	CVolumeDlg(CWnd* pParent = NULL);   // standard constructor

	// Remise finani�re Nationale ou R�gionale (0 : National, 1 : Regional)
	int m_TypeVolume;		

// Dialog Data
	//{{AFX_DATA(CVolumeDlg)
	enum { IDD = IDD_VOLUME_DIALOG };
	CListBox	m_CtrlPaliers;
	float	m_Coef;
	COleDateTime	m_DateDebut;
	float	m_Palier;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVolumeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void GetData();
	void UpdatePalier();
	void UpdateList();
	void UpdateButtons();

	CVolume m_DataCopy;
	CVolumeRegion m_DataRegionCopy;
	CPalier m_PalierCopy;
	// Generated message map functions
	//{{AFX_MSG(CVolumeDlg)
	afx_msg void OnBnAjouter();
	afx_msg void OnBnAjouterPalier();
	afx_msg void OnBnModifier();
	afx_msg void OnBnModifierPalier();
	afx_msg void OnBnSupprimerPalier();
	afx_msg void OnBnSupprimer1();
	afx_msg void OnRecBack();
	afx_msg void OnRecBegin();
	afx_msg void OnRecEnd();
	afx_msg void OnRecNext();
	virtual void OnCancel();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeList1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VOLUMEDLG_H__E3234542_8A97_11D2_AAF8_0000E86750A8__INCLUDED_)
