#if !defined(AFX_GRPDLG_H__17113560_83C7_11D2_AAF8_0000E86750A8__INCLUDED_)
#define AFX_GRPDLG_H__17113560_83C7_11D2_AAF8_0000E86750A8__INCLUDED_

#include "DataCible.h"	// Added by ClassView
#include "DataStation.h"	// Added by ClassView
#include "DataVille.h"	// Added by ClassView
#include "DataGrp.h"	// Added by ClassView
#include "Grp.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GrpDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGrpDlg dialog

class CGrpDlg : public CDialog
{
// Construction

public:
	void SetDay();
	void SetupGrps();
	void UpdateGrps(bool Load);
	bool m_Mode_Modify;
	bool m_Mode_New;
	int m_CurGrp;
	int m_CurCible;
	int m_CurVille;
	int m_CurStation;
	int m_CurDay;
	CDataGrp m_Grps;
	CDataVille m_Villes;
	CDataStation m_Stations;
	CDataCible m_Cibles;
	CGrpDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CGrpDlg)
	enum { IDD = IDD_GRP_DLG };
	CComboBox	m_Ctrl_Ville;
	CComboBox	m_Ctrl_Station;
	CComboBox	m_Ctrl_Cible;
	COleDateTime	m_DateDebut;
	DWORD	m_Edit1;
	DWORD	m_Edit2;
	DWORD	m_Edit3;
	DWORD	m_Edit4;
	DWORD	m_Edit5;
	DWORD	m_Edit6;
	DWORD	m_Edit7;
	DWORD	m_Edit8;
	DWORD	m_Edit9;
	DWORD	m_Edit10;
	DWORD	m_Edit11;
	DWORD	m_Edit12;
	DWORD	m_Edit13;
	DWORD	m_Edit14;
	DWORD	m_Edit15;
	DWORD	m_Edit16;
	DWORD	m_Edit17;
	DWORD	m_Edit18;
	DWORD	m_Edit19;
	DWORD	m_Edit20;
	DWORD	m_Edit21;
	DWORD	m_Edit22;
	DWORD	m_Edit23;
	DWORD	m_Edit24;
	DWORD	m_Edit25;
	DWORD	m_Edit26;
	DWORD	m_Edit27;
	DWORD	m_Edit28;
	DWORD	m_Edit29;
	DWORD	m_Edit30;
	DWORD	m_Edit31;
	DWORD	m_Edit32;
	DWORD	m_Edit33;
	DWORD	m_Edit34;
	DWORD	m_Edit35;
	DWORD	m_Edit36;
	DWORD	m_Edit37;
	DWORD	m_Edit38;
	DWORD	m_Edit39;
	DWORD	m_Edit40;
	DWORD	m_Edit41;
	DWORD	m_Edit42;
	DWORD	m_Edit43;
	DWORD	m_Edit44;
	DWORD	m_Edit45;
	DWORD	m_Edit46;
	DWORD	m_Edit47;
	DWORD	m_Edit48;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGrpDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void ClearGrps();
	void UpdateButtons();
	void GetGrpData();
	CGrp m_GrpCopy;
	// Generated message map functions
	//{{AFX_MSG(CGrpDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnBnDupliquer();
	afx_msg void OnBnMemoriser();
	afx_msg void OnBnModifier();
	afx_msg void OnBnSupprimer();
	afx_msg void OnBnSupprimerAll();
	afx_msg void OnSelchangeCbStation();
	afx_msg void OnSelchangeCbVille();
	afx_msg void OnSelchangeCbCible();
	afx_msg void OnRadDimanche();
	afx_msg void OnRadJeudi();
	afx_msg void OnRadLundi();
	afx_msg void OnRadMardi();
	afx_msg void OnRadMercredi();
	afx_msg void OnRadSamedi();
	afx_msg void OnRadVendredi();
	afx_msg void OnRecBack();
	afx_msg void OnRecBegin();
	afx_msg void OnRecEnd();
	afx_msg void OnRecNew();
	afx_msg void OnRecNext();
	virtual void OnCancel();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GRPDLG_H__17113560_83C7_11D2_AAF8_0000E86750A8__INCLUDED_)
