// DataGrp.cpp: implementation of the CDataGrp class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiadm.h"
#include "DataGrp.h"

#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataGrp::CDataGrp()
{

}

CDataGrp::~CDataGrp()
{

}

bool CDataGrp::Load(long NrStation, long NrVille, long NrCible)
{
	m_Grps.RemoveAll();
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",FALSE,TRUE);
		CTblGrps Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation = %d AND NrVille = %d AND NrCible = %d",NrStation,NrVille,NrCible);
			if(Table.FindFirst(Search))
			{
				do
				{
					CGrp Grp;
					Grp=Table;
					m_Grps.Add(Grp);
				}
				while(Table.FindNext(Search));
			}
		}
		Table.Close();
		Db.Close();
		CGrp *pGrp=m_Grps.GetData();
		if(pGrp) std::sort(pGrp,(pGrp+m_Grps.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataGrp::Modify(CGrp &Grp, int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblGrps Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation= %d AND NrVille = %d AND NrCible = %d AND DateDebut = %s",m_Grps[Index].m_NrStation,m_Grps[Index].m_NrVille,
				m_Grps[Index].m_NrCible, m_Grps[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table=Grp;
				Table.Update();
				m_Grps[Index]=Grp;
//				CGrp *pGrp=m_Grps.GetData();
//				if(pGrp) std::sort(pGrp,(pGrp+m_Grps.GetSize()));
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataGrp::Add(CGrp &Grp)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblGrps Table(&Db);
		Table.Open();
		Table.AddNew();
		Table=Grp;
		Table.Update();
		Table.Close();
		Db.Close();
		m_Grps.Add(Grp);
//		CGrp *pGrp=m_Grps.GetData();
//		if(pGrp) std::sort(pGrp,(pGrp+m_Grps.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataGrp::Delete(int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblGrps Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation= %d AND NrVille = %d AND NrCible = %d AND DateDebut = %s",m_Grps[Index].m_NrStation,m_Grps[Index].m_NrVille,
				m_Grps[Index].m_NrCible, m_Grps[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Delete();
				m_Grps.RemoveAt(Index);
//				CGrp *pGrp=m_Grps.GetData();
//				if(pGrp) std::sort(pGrp,(pGrp+m_Grps.GetSize()));
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}
