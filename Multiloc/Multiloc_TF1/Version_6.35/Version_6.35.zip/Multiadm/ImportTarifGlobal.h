#if !defined(AFX_IMPORTTARIFGLOBAL_H__55D9B7C1_BEFE_11D5_8A63_0010B5865AAB__INCLUDED_)
#define AFX_IMPORTTARIFGLOBAL_H__55D9B7C1_BEFE_11D5_8A63_0010B5865AAB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ImportTarifGlobal.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CImportTarifGlobal dialog

class CImportTarifGlobal : public CDialog
{
// Construction
public:
	CImportTarifGlobal(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CImportTarifGlobal)
	enum { IDD = IDD_IMPORT_TARIFGLOBAL };
	CProgressCtrl	m_ProgressImport;
	CString	m_ProgSave;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CImportTarifGlobal)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CImportTarifGlobal)
	afx_msg void OnImportTarif_TypeNrj();
	afx_msg void OnImportTarif_TypeTf1();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IMPORTTARIFGLOBAL_H__55D9B7C1_BEFE_11D5_8A63_0010B5865AAB__INCLUDED_)
