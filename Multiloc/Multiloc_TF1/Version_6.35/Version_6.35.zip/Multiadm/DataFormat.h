// DataFormat.h: interface for the CDataFormat class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATAFORMAT_H__F3536062_89D6_11D2_AAF8_0000E86750A8__INCLUDED_)
#define AFX_DATAFORMAT_H__F3536062_89D6_11D2_AAF8_0000E86750A8__INCLUDED_

#include "format.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataFormat  
{
public:
	int Delete(int Index);
	int Add(CFormat &Format);
	int Modify(CFormat &Format, int Index);
	bool Load(long NrStation);
	CFormatArray m_Formats;
	CDataFormat();
	virtual ~CDataFormat();

};

#endif // !defined(AFX_DATAFORMAT_H__F3536062_89D6_11D2_AAF8_0000E86750A8__INCLUDED_)
