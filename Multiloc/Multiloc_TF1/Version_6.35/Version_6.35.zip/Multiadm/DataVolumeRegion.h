// DataVolumeRegion.h: interface for the CDataVolumeRegion class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATAVOLUMEREGION_H__715B4B62_C4B9_11D5_8A63_0010B5865AAB__INCLUDED_)
#define AFX_DATAVOLUMEREGION_H__715B4B62_C4B9_11D5_8A63_0010B5865AAB__INCLUDED_

#include "volumeregion.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataVolumeRegion  
{
public:
	int Delete(int Index);
	int Add(CVolumeRegion &VolumeRegion);
	int Modify(CVolumeRegion &VolumeRegion, int Index);
	bool Load();
	CVolumeRegionArray m_VolumesRegion;

	CDataVolumeRegion();
	virtual ~CDataVolumeRegion();

};

#endif // !defined(AFX_DATAVOLUMEREGION_H__715B4B62_C4B9_11D5_8A63_0010B5865AAB__INCLUDED_)
