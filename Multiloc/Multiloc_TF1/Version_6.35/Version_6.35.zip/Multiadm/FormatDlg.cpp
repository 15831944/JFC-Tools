// FormatDlg.cpp : implementation file
//

#include "stdafx.h"
#include "multiadm.h"
#include "FormatDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFormatDlg dialog


CFormatDlg::CFormatDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFormatDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFormatDlg)
	m_Format = _T("");
	m_Coef = 0.0f;
	m_DateDebut = COleDateTime::GetCurrentTime();
	//}}AFX_DATA_INIT
	m_Mode_New=false;
	m_Mode_Modify=false;
}


void CFormatDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFormatDlg)
	DDX_Control(pDX, IDC_COMBO2, m_CtrlStation);
	DDX_Control(pDX, IDC_LIST1, m_CtrlFormats);
	DDX_Text(pDX, IDC_EDIT1, m_Format);
	DDV_MaxChars(pDX,m_Format,5);
	DDX_Text(pDX, IDC_EDIT2, m_Coef);
	DDV_MinMaxFloat(pDX, m_Coef, 0.f, 1000.f);
	DDX_DateTimeCtrl(pDX, IDC_DATE_DEBUT, m_DateDebut);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFormatDlg, CDialog)
	//{{AFX_MSG_MAP(CFormatDlg)
	ON_BN_CLICKED(IDC_BN_AJOUTER, OnBnAjouter)
	ON_BN_CLICKED(IDC_BN_AJOUTER_PALIER, OnBnAjouterFormat)
	ON_BN_CLICKED(IDC_BN_MODIFIER, OnBnModifier)
	ON_BN_CLICKED(IDC_BN_MODIFIER_PALIER, OnBnModifierFormat)
	ON_BN_CLICKED(IDC_BN_SUPPRIMER_PALIER, OnBnSupprimerFormat)
	ON_BN_CLICKED(IDC_BN_SUPPRIMER1, OnBnSupprimer1)
	ON_BN_CLICKED(IDC_REC_BACK, OnRecBack)
	ON_BN_CLICKED(IDC_REC_BEGIN, OnRecBegin)
	ON_BN_CLICKED(IDC_REC_END, OnRecEnd)
	ON_BN_CLICKED(IDC_REC_NEXT, OnRecNext)
	ON_LBN_SELCHANGE(IDC_LIST1, OnSelchangeList1)
	ON_CBN_SELCHANGE(IDC_COMBO2, OnSelchangeCombo2)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, &CFormatDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDOK_ALLSTATIONS, &CFormatDlg::OnBnClickedAllstations)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFormatDlg message handlers
void CFormatDlg::OnBnAjouter() 
{
	m_Mode_New=TRUE;
	m_DataCopy=CFormat();
	UpdateList();
	UpdateButtons();
}

void CFormatDlg::OnBnAjouterFormat() 
{
	GetData();
	int nb = 0;
	// Warning : modifier cette fonction entrainera des problemes certains dans la
	// fonction CMultilocDoc::TesterCombinaison du projet Multiloc
	for(int i=0;i<m_FormatCopy.m_Libelle.GetLength();i++)
	{
		if(m_FormatCopy.m_Libelle[i]>='0' && m_FormatCopy.m_Libelle[i]<='9')
			nb++;
		if(m_FormatCopy.m_Libelle[i]>='a' && m_FormatCopy.m_Libelle[i]<='z')
			nb++;
		if(m_FormatCopy.m_Libelle[i]>='A' && m_FormatCopy.m_Libelle[i]<='Z')
			nb++;
		if(m_FormatCopy.m_Libelle[i]==' ')
			nb++;
	}
	if(nb==0 || nb!=m_FormatCopy.m_Libelle.GetLength())
	{
		AfxMessageBox("Le nom du format est invalide.");
		return;
	}
	int x=0;
	for(;x<m_DataCopy.m_Format.GetSize();x++)
	{
		if(m_DataCopy.m_Format[x].m_Libelle==m_FormatCopy.m_Libelle) break;
	}
	if(x>=m_DataCopy.m_Format.GetSize())
	{
		m_DataCopy.m_Format.Add(m_FormatCopy);
	}
	else
	{
		CString Message="Un format avec le m�me nom existe d�j�";
		AfxMessageBox(Message);
	}
	UpdateList();
	UpdateButtons();
}

void CFormatDlg::OnBnModifier() 
{
	if(m_CurData>=0)
	{
		m_Mode_Modify=TRUE;
		m_DataCopy=m_Data.m_Formats[m_CurData];
		UpdateList();
		UpdateButtons();
	}
}

void CFormatDlg::OnBnModifierFormat() 
{
	GetData();
	if(m_CurFormat>=0)
	{
		m_DataCopy.m_Format[m_CurFormat]=m_FormatCopy;
		UpdateList();
		UpdateButtons();
	}
}

void CFormatDlg::OnBnSupprimerFormat() 
{
	if(m_CurFormat>=0)
	{
		m_DataCopy.m_Format.RemoveAt(m_CurFormat);
		if(m_DataCopy.m_Format.GetSize())
		{
			if(m_CurFormat) m_CurFormat--;
			m_FormatCopy=m_DataCopy.m_Format[m_CurFormat];
		}
		else
		{
			m_CurFormat=-1;
			m_FormatCopy=CFormatD();
		}
		UpdateList();
		UpdateButtons();
	}
}

void CFormatDlg::OnBnSupprimer1() 
{
	if(m_CurData<0) return;
	if(m_Mode_Modify || m_Mode_New) return;
	if(m_Data.Delete(m_CurData))
	{
		if(m_Data.m_Formats.GetSize())
		{
			if(m_CurData>0) m_CurData--;
			m_DataCopy=m_Data.m_Formats[m_CurData];
		}
		else
		{
			m_CurData=-1;
			m_DataCopy=CFormat();
		}
		UpdateList();
		UpdateButtons();
	}
}

void CFormatDlg::OnRecBack() 
{
	if(m_CurData>0) m_CurData--;
	m_DataCopy=m_Data.m_Formats[m_CurData];
	UpdateList();
	UpdateButtons();
}

void CFormatDlg::OnRecBegin() 
{
	if(m_CurData>0) m_CurData=0;
	m_DataCopy=m_Data.m_Formats[m_CurData];
	UpdateList();
	UpdateButtons();
}

void CFormatDlg::OnRecEnd() 
{
	m_CurData=m_Data.m_Formats.GetSize()-1;
	m_DataCopy=m_Data.m_Formats[m_CurData];
	UpdateList();
	UpdateButtons();
}

void CFormatDlg::OnRecNext() 
{
	if(m_CurData<m_Data.m_Formats.GetSize()-1) m_CurData++;
	m_DataCopy=m_Data.m_Formats[m_CurData];
	UpdateList();
	UpdateButtons();
}

void CFormatDlg::OnCancel() 
{
	if(m_Mode_New || m_Mode_Modify)
	{
		m_Mode_New=false;
		m_Mode_Modify=false;
		UpdateList();
		UpdateButtons();
	}
	else CDialog::OnCancel();
}

////////////////////////////////////////////////////////////////////////////////////////////
// Valide le(s) format(s) sur la station s�lectionn�e
void CFormatDlg::OnOK() 
{
	GetData();
	if(m_Mode_Modify)
	{
		if(m_Data.Modify(m_DataCopy,m_CurData))
		{
			m_Data.m_Formats[m_CurData]=m_DataCopy;
			m_Mode_Modify=false;
			UpdateList();
		}
		UpdateButtons();
		return;
	}
	if(m_Mode_New)
	{
		m_DataCopy.m_NrStation=m_CurStation;
		int x=0;
		for(;x<m_Data.m_Formats.GetSize();x++)
		{
			if(m_Data.m_Formats[x].m_DateDebut==m_DataCopy.m_DateDebut) break;
		}
		if(x>=m_Data.m_Formats.GetSize())
		{
			if(m_Data.Add(m_DataCopy))
			{
				m_CurData++;
				m_Mode_New=false;
				UpdateList();
			}
		}
		else
		{
			CString Message="Une liste de Formats avec le m�me date existe d�j�";
			AfxMessageBox(Message);
		}

		UpdateButtons();
		return;
	}
	CDialog::OnOK();
}

////////////////////////////////////////////////////////////////////////////////////////////
// Valide le(s) format(s) sur toutes les stations
void CFormatDlg::OnOkAllStations()
{
	GetData();
	if(m_Mode_Modify)
	{
		if(m_Data.Modify(m_DataCopy,m_CurData))
		{
			m_Data.m_Formats[m_CurData]=m_DataCopy;
			m_Mode_Modify=false;
			UpdateList();
		}
		UpdateButtons();
		return;
	}
	if(m_Mode_New)
	{
		int x=0;
		for(;x<m_Data.m_Formats.GetSize();x++)
		{
			if(m_Data.m_Formats[x].m_DateDebut==m_DataCopy.m_DateDebut) break;
		}
		if(x>=m_Data.m_Formats.GetSize())
		{
			// Sur toutes les stations
			int NbStations = m_Stations.m_Stations.GetSize() + 1;
			for (int InxSta = 1; InxSta < NbStations; InxSta++)
			{
				m_DataCopy.m_NrStation=InxSta ;

				if(m_Data.Add(m_DataCopy))
				{
					m_CurData++;
					m_Mode_New=false;
					UpdateList();
				}
			}
		}
		else
		{
			CString Message="Une liste de Formats avec le m�me date existe d�j�";
			AfxMessageBox(Message);
		}

		UpdateButtons();
		return;
	}
	CDialog::OnOK();
}

BOOL CFormatDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_Mode_New=false;
	m_Mode_Modify=false;
	if(!m_Stations.Load())
	{
		AfxMessageBox("Il faut cr�er au moins une Station");
		EndDialog(false);
	}
	for(int x=0;x<m_Stations.m_Stations.GetSize();x++)
	{
		m_CtrlStation.AddString(m_Stations.m_Stations[x].m_Libelle);
	}
	m_CurStation=m_Stations.m_Stations[0].m_NrUnique;
	m_CtrlStation.SetCurSel(0);
	m_Data.Load(m_CurStation);
	if(m_Data.m_Formats.GetSize())
	{
		m_CurData=0;
		m_DataCopy=m_Data.m_Formats[m_CurData];
	}
	else
	{
		m_CurData=-1;
		m_DataCopy=CFormat();
	}
	UpdateList();
	UpdateButtons();
	UpdateData(false);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CFormatDlg::UpdateButtons()
{
	if(m_Mode_Modify || m_Mode_New)
	{
		if(m_Mode_Modify)
		{
			GetDlgItem(IDC_DATE_DEBUT)->EnableWindow(false); 
			GetDlgItem(IDC_BN_SUPPRIMER1)->EnableWindow(true); 
		}
		else
		{
			GetDlgItem(IDC_DATE_DEBUT)->EnableWindow(true); 
			GetDlgItem(IDC_BN_SUPPRIMER1)->EnableWindow(false); 
		}
		GetDlgItem(IDC_REC_BACK)->EnableWindow(false); 
		GetDlgItem(IDC_REC_NEXT)->EnableWindow(false); 
		GetDlgItem(IDC_REC_BEGIN)->EnableWindow(false); 
		GetDlgItem(IDC_REC_END)->EnableWindow(false); 

		GetDlgItem(IDC_BN_AJOUTER)->EnableWindow(false); 
		GetDlgItem(IDC_BN_MODIFIER)->EnableWindow(false); 

		if(m_CurFormat<0)
		{
			GetDlgItem(IDC_BN_AJOUTER_PALIER)->EnableWindow(true); 
			GetDlgItem(IDC_BN_MODIFIER_PALIER)->EnableWindow(false); 
			GetDlgItem(IDC_BN_SUPPRIMER_PALIER)->EnableWindow(false); 
		}
		else
		{
			GetDlgItem(IDC_BN_AJOUTER_PALIER)->EnableWindow(true); 
			GetDlgItem(IDC_BN_MODIFIER_PALIER)->EnableWindow(true); 
			GetDlgItem(IDC_BN_SUPPRIMER_PALIER)->EnableWindow(true); 
		}
		GetDlgItem(IDOK)->EnableWindow(true); 
		GetDlgItem(IDCANCEL)->EnableWindow(true); 

		GetDlgItem(IDC_EDIT1)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT2)->EnableWindow(true);  
	}
	else
	{
		if(m_CurData<0)
		{
			GetDlgItem(IDC_BN_SUPPRIMER1)->EnableWindow(false); 
			GetDlgItem(IDC_BN_MODIFIER)->EnableWindow(false); 
			GetDlgItem(IDC_REC_BACK)->EnableWindow(false); 
			GetDlgItem(IDC_REC_BEGIN)->EnableWindow(false); 
			GetDlgItem(IDC_REC_END)->EnableWindow(false); 
			GetDlgItem(IDC_REC_NEXT)->EnableWindow(false); 
		}
		else
		{
			GetDlgItem(IDC_BN_SUPPRIMER1)->EnableWindow(true); 
			GetDlgItem(IDC_BN_MODIFIER)->EnableWindow(true); 
			if(m_CurData==0)
			{
				GetDlgItem(IDC_REC_BACK)->EnableWindow(false); 
				GetDlgItem(IDC_REC_BEGIN)->EnableWindow(false);
			}
			else
			{
				GetDlgItem(IDC_REC_BACK)->EnableWindow(true); 
				GetDlgItem(IDC_REC_BEGIN)->EnableWindow(true);
			}
			if(m_CurData==m_Data.m_Formats.GetSize()-1)
			{
				GetDlgItem(IDC_REC_END)->EnableWindow(false); 
				GetDlgItem(IDC_REC_NEXT)->EnableWindow(false);
			}
			else 
			{
				GetDlgItem(IDC_REC_END)->EnableWindow(true); 
				GetDlgItem(IDC_REC_NEXT)->EnableWindow(true);
			}
		}
		GetDlgItem(IDC_BN_AJOUTER)->EnableWindow(true); 

		GetDlgItem(IDC_BN_AJOUTER_PALIER)->EnableWindow(false); 
		GetDlgItem(IDC_BN_MODIFIER_PALIER)->EnableWindow(false); 
		GetDlgItem(IDC_BN_SUPPRIMER_PALIER)->EnableWindow(false); 

		GetDlgItem(IDOK)->EnableWindow(true); 
		GetDlgItem(IDCANCEL)->EnableWindow(false); 

		GetDlgItem(IDC_DATE_DEBUT)->EnableWindow(false); 

		GetDlgItem(IDC_EDIT1)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT2)->EnableWindow(false);  
	}
}

void CFormatDlg::UpdateList()
{
	m_CtrlFormats.ResetContent();
	m_CtrlFormats.SetTabStops(70);
	if(!m_DataCopy.m_Format.GetSize())
	{
		m_CurFormat=-1;
		m_DateDebut=COleDateTime::GetCurrentTime();
		m_FormatCopy=CFormatD();
	}
	else
	{
		if(!m_DataCopy.m_Format.GetSize())
		{
			m_CurFormat=-1;
			m_FormatCopy=CFormatD();
		}
		else
		{
			for(int x=0;x<m_DataCopy.m_Format.GetSize();x++)
			{
				CString String;
				String.Format("%s\t%3.02f%%",m_DataCopy.m_Format[x].m_Libelle,m_DataCopy.m_Format[x].m_Coef);
				m_CtrlFormats.AddString(String);
			}
			m_CurFormat=0;
			m_CtrlFormats.SetCurSel(m_CurFormat);
			m_FormatCopy=m_DataCopy.m_Format[m_CurFormat];
		}
		m_DateDebut=m_DataCopy.m_DateDebut;
	}
	UpdateFormat();
	UpdateData(false);
}

void CFormatDlg::UpdateFormat()
{
	m_Format=m_FormatCopy.m_Libelle;
	m_Coef=m_FormatCopy.m_Coef;
	UpdateData(false);
}

void CFormatDlg::GetData()
{
	UpdateData(true);
	m_DataCopy.m_DateDebut.SetDate(m_DateDebut.GetYear(),m_DateDebut.GetMonth(),m_DateDebut.GetDay());
	m_Format.TrimLeft();
	m_Format.TrimRight();
	m_FormatCopy.m_Libelle=m_Format;
	m_FormatCopy.m_Coef=m_Coef;
}

void CFormatDlg::OnSelchangeList1() 
{
	m_CurFormat=m_CtrlFormats.GetCurSel();
	if(m_CurFormat==LB_ERR)
	{
		m_CurFormat=-1;
		m_FormatCopy=CFormatD();
	}
	else
	{
		m_FormatCopy=m_DataCopy.m_Format[m_CurFormat];
	}
	UpdateFormat();
	UpdateButtons();
}

void CFormatDlg::OnSelchangeCombo2() 
{
	m_Mode_New=false;
	m_Mode_Modify=false;

	int Pos=m_CtrlStation.GetCurSel();
	if(Pos!=CB_ERR)
	{
		m_CurStation=m_Stations.m_Stations[Pos].m_NrUnique;
	}
	m_Data.Load(m_CurStation);
	if(m_Data.m_Formats.GetSize())
	{
		m_CurData=0;
		m_DataCopy=m_Data.m_Formats[m_CurData];
	}
	else
	{
		m_CurData=-1;
		m_DataCopy=CFormat();
	}
	UpdateList();
	UpdateButtons();
	UpdateData(false);
}

void CFormatDlg::OnBnClickedOk()
{
	// Valide format sur la station et la date en cours
	OnOK();
}

void CFormatDlg::OnBnClickedAllstations()
{
	// Valide format sur toutes les stations et la date en cours
	OnOkAllStations();
}
