// DataFormat.cpp: implementation of the CDataFormat class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiadm.h"
#include "DataFormat.h"

#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataFormat::CDataFormat()
{

}

CDataFormat::~CDataFormat()
{

}

bool CDataFormat::Load(long NrStation)
{
	m_Formats.RemoveAll();
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",FALSE,TRUE);
		CTblFormats Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation = %d",NrStation);
			if(Table.FindFirst(Search))
			{
				do
				{
					CFormat Format;
					Format=Table;
					m_Formats.Add(Format);
				}
				while(Table.FindNext(Search));
			}
		}
		Table.Close();
		Db.Close();
		CFormat *pFormat=m_Formats.GetData();
		if(pFormat) std::sort(pFormat,(pFormat+m_Formats.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataFormat::Modify(CFormat &Format, int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblFormats Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation= %d AND DateDebut = %s",m_Formats[Index].m_NrStation,
				m_Formats[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table=Format;
				Table.Update();
				m_Formats[Index]=Format;
//				CFormat *pFormat=m_Formats.GetData();
//				if(pFormat) std::sort(pFormat,(pFormat+m_Formats.GetSize()));
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataFormat::Add(CFormat &Format)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblFormats Table(&Db);
		Table.Open();
		Table.AddNew();
		Table=Format;
		Table.Update();
		Table.Close();
		Db.Close();
		m_Formats.Add(Format);
//		CFormat *pFormat=m_Formats.GetData();
//		if(pFormat) std::sort(pFormat,(pFormat+m_Formats.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataFormat::Delete(int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblFormats Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation= %d AND DateDebut = %s",m_Formats[Index].m_NrStation,
				m_Formats[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Delete();
				m_Formats.RemoveAt(Index);
//				CFormat *pFormat=m_Formats.GetData();
//				if(pFormat) std::sort(pFormat,(pFormat+m_Formats.GetSize()));
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}
