// MailFax.cpp: implementation of the CMailFax class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiadm.h"
#include "MailFax.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMailFax::CMailFax()
{

}

CMailFax::~CMailFax()
{

}

CMailFax &CMailFax :: operator=(const CMailFax &Source)
{
	m_NrStation = Source.m_NrStation;
	m_NrVille = Source.m_NrVille;
	m_AdrMail = Source.m_AdrMail;
	m_Fax = Source.m_Fax;
	return(*this);
}

CMailFax &CMailFax :: operator=(const CTblMailFax &Source)
{
	m_NrStation = Source.m_NrStation;
	m_NrVille = Source.m_NrVille;
	m_AdrMail = Source.m_AdrMail;
	m_Fax = Source.m_Fax;
	return(*this);
}

bool CMailFax ::operator<(const CMailFax &Source)
{
	if(m_AdrMail<Source.m_AdrMail) return(TRUE);
	else return(FALSE);
}
