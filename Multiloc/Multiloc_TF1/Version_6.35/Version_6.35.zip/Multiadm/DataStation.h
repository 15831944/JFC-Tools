// DataStation.h: interface for the CDataStation class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATASTATION_H__A3EB53E2_7EFD_11D2_9B0D_004005327F6C__INCLUDED_)
#define AFX_DATASTATION_H__A3EB53E2_7EFD_11D2_9B0D_004005327F6C__INCLUDED_

#include "Station.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataStation  
{
public:
	int Delete(int Index);
	int Add(CStation &Station);
	int Modify(CStation &Station, int Index);
	CStationArray m_Stations;
	bool Load();
	CDataStation();
	virtual ~CDataStation();

protected:
};

#endif // !defined(AFX_DATASTATION_H__A3EB53E2_7EFD_11D2_9B0D_004005327F6C__INCLUDED_)
