// ImportGrp.h: interface for the CImportGrp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IMPORTGRP_H__0A654562_B1E2_11D2_AAF8_0000E86750A8__INCLUDED_)
#define AFX_IMPORTGRP_H__0A654562_B1E2_11D2_AAF8_0000E86750A8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DataGrp.h"

class CImportGrp  
{
public:
	bool ImportFile();
	bool ImportGeneGRP(CString FileGrp,CProgressCtrl *ProgressBar);
	bool ChoixFicGeneGRP(CString FileGrp,CProgressCtrl *ProgressBar);
	CImportGrp();
	virtual ~CImportGrp();

protected:
	bool Import(CString FileName);
	bool AddReplace(CGrp &Grp);
	bool AddReplace2(CGrp &Grp, CDaoDatabase &Db);

};

#endif // !defined(AFX_IMPORTGRP_H__0A654562_B1E2_11D2_AAF8_0000E86750A8__INCLUDED_)
