// VolumeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "multiadm.h"
#include "VolumeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVolumeDlg dialog


CVolumeDlg::CVolumeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVolumeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CVolumeDlg)
	m_Coef = 0.0f;
	m_DateDebut = COleDateTime::GetCurrentTime();
	m_Palier = 0.0f;
	//}}AFX_DATA_INIT
	m_Mode_New=false;
	m_Mode_Modify=false;
}


void CVolumeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CVolumeDlg)
	DDX_Control(pDX, IDC_LIST1, m_CtrlPaliers);
	DDX_Text(pDX, IDC_EDIT2, m_Coef);
	DDV_MinMaxFloat(pDX, m_Coef, 0.f, 100.f);
	DDX_DateTimeCtrl(pDX, IDC_DATE_DEBUT, m_DateDebut);
	DDX_Text(pDX, IDC_EDIT1, m_Palier);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CVolumeDlg, CDialog)
	//{{AFX_MSG_MAP(CVolumeDlg)
	ON_BN_CLICKED(IDC_BN_AJOUTER, OnBnAjouter)
	ON_BN_CLICKED(IDC_BN_AJOUTER_PALIER, OnBnAjouterPalier)
	ON_BN_CLICKED(IDC_BN_MODIFIER, OnBnModifier)
	ON_BN_CLICKED(IDC_BN_MODIFIER_PALIER, OnBnModifierPalier)
	ON_BN_CLICKED(IDC_BN_SUPPRIMER_PALIER, OnBnSupprimerPalier)
	ON_BN_CLICKED(IDC_BN_SUPPRIMER1, OnBnSupprimer1)
	ON_BN_CLICKED(IDC_REC_BACK, OnRecBack)
	ON_BN_CLICKED(IDC_REC_BEGIN, OnRecBegin)
	ON_BN_CLICKED(IDC_REC_END, OnRecEnd)
	ON_BN_CLICKED(IDC_REC_NEXT, OnRecNext)
	ON_LBN_SELCHANGE(IDC_LIST1, OnSelchangeList1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVolumeDlg message handlers
void CVolumeDlg::OnBnAjouter() 
{
	m_Mode_New=TRUE;

	if (m_TypeVolume == 0)
		// mode national
		m_DataCopy=CVolume();
	else
		// mode r�gional
		m_DataRegionCopy=CVolumeRegion();

	UpdateList();
	UpdateButtons();
}

void CVolumeDlg::OnBnAjouterPalier() 
{
	GetData();

	if (m_TypeVolume == 0)
	{
		// mode nationale
		int x=0;
		for(;x<m_DataCopy.m_Palier.GetSize();x++)
		{
			if(m_DataCopy.m_Palier[x].m_Palier==m_PalierCopy.m_Palier) break;
		}
		if(x>=m_DataCopy.m_Palier.GetSize()) m_DataCopy.m_Palier.Add(m_PalierCopy);
		else
		{
			CString Message="Un palier avec le m�me chiffre exist d�j�";
			AfxMessageBox(Message);
		}
	}

	else
	{
		// mode r�gional
		int x=0;
		for(;x<m_DataRegionCopy.m_Palier.GetSize();x++)
		{
			if(m_DataRegionCopy.m_Palier[x].m_Palier==m_PalierCopy.m_Palier) break;
		}
		if(x>=m_DataRegionCopy.m_Palier.GetSize()) m_DataRegionCopy.m_Palier.Add(m_PalierCopy);
		else
		{
			CString Message="Un palier avec le m�me chiffre exist d�j�";
			AfxMessageBox(Message);
		}
	}

	UpdateList();
	UpdateButtons();
}

void CVolumeDlg::OnBnModifier() 
{
	if(m_CurData>=0)
	{
		m_Mode_Modify=TRUE;

		if (m_TypeVolume == 0)
			// mode national
			m_DataCopy=m_Data.m_Volumes[m_CurData];
		else
			// mode r�gional
			m_DataRegionCopy=m_DataRegion.m_VolumesRegion[m_CurData];
			
		UpdateList();
		UpdateButtons();
	}
}

void CVolumeDlg::OnBnModifierPalier() 
{
	GetData();
	if(m_CurPalier>=0)
	{
		if (m_TypeVolume == 0)
			// mode national
			m_DataCopy.m_Palier[m_CurPalier]=m_PalierCopy;
		else
			// mode r�gional
			m_DataRegionCopy.m_Palier[m_CurPalier]=m_PalierCopy;

		UpdateList();
		UpdateButtons();
	}
}

void CVolumeDlg::OnBnSupprimerPalier() 
{
	if(m_CurPalier>=0)
	{

		if (m_TypeVolume == 0)
		{
			// mode national
			m_DataCopy.m_Palier.RemoveAt(m_CurPalier);
			if(m_DataCopy.m_Palier.GetSize())
			{
				if(m_CurPalier) m_CurPalier--;
				m_PalierCopy=m_DataCopy.m_Palier[m_CurPalier];
			}
			else
			{
				m_CurPalier=-1;
				m_PalierCopy=CPalier();
			}
		}

		else
		{
			// mode r�gional
			m_DataRegionCopy.m_Palier.RemoveAt(m_CurPalier);
			if(m_DataRegionCopy.m_Palier.GetSize())
			{
				if(m_CurPalier) m_CurPalier--;
				m_PalierCopy=m_DataRegionCopy.m_Palier[m_CurPalier];
			}
			else
			{
				m_CurPalier=-1;
				m_PalierCopy=CPalier();
			}
		}

		UpdateList();
		UpdateButtons();
	}
}

void CVolumeDlg::OnBnSupprimer1() 
{
	if(m_CurData<0) return;
	if(m_Mode_Modify || m_Mode_New) return;

	if (m_TypeVolume == 0)
	{
		// mode national
		if(m_Data.Delete(m_CurData))
		{
			if(m_Data.m_Volumes.GetSize())
			{
				if(m_CurData>0) m_CurData--;
				m_DataCopy=m_Data.m_Volumes[m_CurData];
			}
			else
			{
				m_CurData=-1;
				m_DataCopy=CVolume();
			}
			UpdateList();
			UpdateButtons();
		}
	}

	else
	{
		// mode r�gional
		if(m_DataRegion.Delete(m_CurData))
		{
			if(m_DataRegion.m_VolumesRegion.GetSize())
			{
				if(m_CurData>0) m_CurData--;
				m_DataRegionCopy=m_DataRegion.m_VolumesRegion[m_CurData];
			}
			else
			{
				m_CurData=-1;
				m_DataRegionCopy=CVolumeRegion();
			}
			UpdateList();
			UpdateButtons();
		}
	}

}

void CVolumeDlg::OnRecBack() 
{
	if(m_CurData>0) m_CurData--;

	if (m_TypeVolume == 0)
		// mode national
		m_DataCopy=m_Data.m_Volumes[m_CurData];
	else
		// mode r�gional
		m_DataRegionCopy=m_DataRegion.m_VolumesRegion[m_CurData];

	UpdateList();
	UpdateButtons();
}

void CVolumeDlg::OnRecBegin() 
{
	if(m_CurData>0) m_CurData=0;

	if (m_TypeVolume == 0)
		// mode national
		m_DataCopy=m_Data.m_Volumes[m_CurData];
	else
		// mode r�gional
		m_DataRegionCopy=m_DataRegion.m_VolumesRegion[m_CurData];

	UpdateList();
	UpdateButtons();
}


void CVolumeDlg::OnRecEnd() 
{
	if (m_TypeVolume == 0)
	{
		// mode national
		m_CurData=m_Data.m_Volumes.GetSize()-1;
		m_DataCopy=m_Data.m_Volumes[m_CurData];
	}	
	else
	{	
		// mode r�gional
		m_CurData=m_DataRegion.m_VolumesRegion.GetSize()-1;
		m_DataRegionCopy=m_DataRegion.m_VolumesRegion[m_CurData];
	}	

	UpdateList();
	UpdateButtons();
}

void CVolumeDlg::OnRecNext() 
{
	if (m_TypeVolume == 0)
	{
		// mode national
		if(m_CurData<m_Data.m_Volumes.GetSize()-1) m_CurData++;
		m_DataCopy=m_Data.m_Volumes[m_CurData];
	}
	else
	{
		// mode r�gional
		if(m_CurData<m_DataRegion.m_VolumesRegion.GetSize()-1) m_CurData++;
		m_DataRegionCopy=m_DataRegion.m_VolumesRegion[m_CurData];
	}

	UpdateList();
	UpdateButtons();
}

void CVolumeDlg::OnCancel() 
{
	if(m_Mode_New || m_Mode_Modify)
	{
		m_Mode_New=false;
		m_Mode_Modify=false;
		UpdateList();
		UpdateButtons();
	}
	else CDialog::OnCancel();
}

void CVolumeDlg::OnOK() 
{
	GetData();
	if(m_Mode_Modify)
	{
		if (m_TypeVolume == 0)
		{
			// mode national
			if(m_Data.Modify(m_DataCopy,m_CurData))
			{
				// A VIRER
				//float Temp;
				//Temp = m_DataCopy.m_Palier[0].m_Palier;
				m_Data.m_Volumes[m_CurData]=m_DataCopy;

				m_Mode_Modify=false;
				UpdateList();
			}
			UpdateButtons();
			return;
		}
		else
		{
			// mode r�gional
			if(m_DataRegion.Modify(m_DataRegionCopy,m_CurData))
			{
				m_DataRegion.m_VolumesRegion[m_CurData]=m_DataRegionCopy;
				m_Mode_Modify=false;
				UpdateList();
			}
			UpdateButtons();
			return;
		}	
	}



	if(m_Mode_New)
	{
		if (m_TypeVolume == 0)
		{
			// mode national
			int x=0;
			for(;x<m_Data.m_Volumes.GetSize();x++)
			{
				if(m_Data.m_Volumes[x].m_DateDebut==m_DataCopy.m_DateDebut) break;
			}
			if(x>=m_Data.m_Volumes.GetSize())
			{
				if(m_Data.Add(m_DataCopy))
				{
					m_CurData++;
					m_Mode_New=false;
					UpdateList();
				}
			}
			else
			{
				CString Message="Un Volume avec le m�me date exist d�j�";
				AfxMessageBox(Message);
			}
		}
		
		else
		{
			// mode r�gional
			int x=0;
			for(;x<m_DataRegion.m_VolumesRegion.GetSize();x++)
			{
				if(m_DataRegion.m_VolumesRegion[x].m_DateDebut==m_DataRegionCopy.m_DateDebut) break;
			}
			if(x>=m_DataRegion.m_VolumesRegion.GetSize())
			{
				if(m_DataRegion.Add(m_DataRegionCopy))
				{
					m_CurData++;
					m_Mode_New=false;
					UpdateList();
				}
			}
			else
			{
				CString Message="Un Volume avec le m�me date exist d�j�";
				AfxMessageBox(Message);
			}
		}

		UpdateButtons();
		return;
	}


	CDialog::OnOK();
}

BOOL CVolumeDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_Mode_New=false;
	m_Mode_Modify=false;

	if (m_TypeVolume == 0)
	{
		// Remise financi�re nationale
		m_Data.Load();
		if(m_Data.m_Volumes.GetSize())
		{
			m_CurData=0;
			m_DataCopy=m_Data.m_Volumes[m_CurData];
		}
		else
		{

			m_CurData=-1;
			m_DataCopy=CVolume();
		}
		// Titre de la fenetre dialogue
		this->SetWindowText("Remise Financi�re Nationale");
	}
	else
	{
		// Remise financi�re r�gionale
		m_DataRegion.Load();
		if(m_DataRegion.m_VolumesRegion.GetSize())
		{
			m_CurData=0;
			m_DataRegionCopy=m_DataRegion.m_VolumesRegion[m_CurData];
		}
		else
		{

			m_CurData=-1;
			m_DataRegionCopy=CVolumeRegion();
		}
		// Titre de la fenetre dialogue
		this->SetWindowText("Remise Financi�re R�gionale");
	}
	
	UpdateList();
	UpdateButtons();
	UpdateData(false);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CVolumeDlg::UpdateButtons()
{
	if(m_Mode_Modify || m_Mode_New)
	{
		if(m_Mode_Modify)
		{
			GetDlgItem(IDC_DATE_DEBUT)->EnableWindow(false); 
			GetDlgItem(IDC_BN_SUPPRIMER1)->EnableWindow(true); 
		}
		else
		{
			GetDlgItem(IDC_DATE_DEBUT)->EnableWindow(true); 
			GetDlgItem(IDC_BN_SUPPRIMER1)->EnableWindow(false); 
		}
		GetDlgItem(IDC_REC_BACK)->EnableWindow(false); 
		GetDlgItem(IDC_REC_NEXT)->EnableWindow(false); 
		GetDlgItem(IDC_REC_BEGIN)->EnableWindow(false); 
		GetDlgItem(IDC_REC_END)->EnableWindow(false); 

		GetDlgItem(IDC_BN_AJOUTER)->EnableWindow(false); 
		GetDlgItem(IDC_BN_MODIFIER)->EnableWindow(false); 

		if(m_CurPalier<0)
		{
			GetDlgItem(IDC_BN_AJOUTER_PALIER)->EnableWindow(true); 
			GetDlgItem(IDC_BN_MODIFIER_PALIER)->EnableWindow(false); 
			GetDlgItem(IDC_BN_SUPPRIMER_PALIER)->EnableWindow(false); 
		}
		else
		{
			GetDlgItem(IDC_BN_AJOUTER_PALIER)->EnableWindow(true); 
			GetDlgItem(IDC_BN_MODIFIER_PALIER)->EnableWindow(true); 
			GetDlgItem(IDC_BN_SUPPRIMER_PALIER)->EnableWindow(true); 
		}
		GetDlgItem(IDOK)->EnableWindow(true); 
		GetDlgItem(IDCANCEL)->EnableWindow(true); 

		GetDlgItem(IDC_EDIT1)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT2)->EnableWindow(true);  
	}
	else
	{
		if(m_CurData<0)
		{
			GetDlgItem(IDC_BN_SUPPRIMER1)->EnableWindow(false); 
			GetDlgItem(IDC_BN_MODIFIER)->EnableWindow(false); 
			GetDlgItem(IDC_REC_BACK)->EnableWindow(false); 
			GetDlgItem(IDC_REC_BEGIN)->EnableWindow(false); 
			GetDlgItem(IDC_REC_END)->EnableWindow(false); 
			GetDlgItem(IDC_REC_NEXT)->EnableWindow(false); 
		}
		else
		{
			GetDlgItem(IDC_BN_SUPPRIMER1)->EnableWindow(true); 
			GetDlgItem(IDC_BN_MODIFIER)->EnableWindow(true); 
			if(m_CurData==0)
			{
				GetDlgItem(IDC_REC_BACK)->EnableWindow(false); 
				GetDlgItem(IDC_REC_BEGIN)->EnableWindow(false);
			}
			else
			{
				GetDlgItem(IDC_REC_BACK)->EnableWindow(true); 
				GetDlgItem(IDC_REC_BEGIN)->EnableWindow(true);
			}

			if (m_TypeVolume == 0)
			{
				// mode national
				if(m_CurData==m_Data.m_Volumes.GetSize()-1)
				{
					GetDlgItem(IDC_REC_END)->EnableWindow(false); 
					GetDlgItem(IDC_REC_NEXT)->EnableWindow(false);
				}
				else 
				{
					GetDlgItem(IDC_REC_END)->EnableWindow(true); 
					GetDlgItem(IDC_REC_NEXT)->EnableWindow(true);
				}
			}
			else
			{
				// mode r�gional
				if(m_CurData==m_DataRegion.m_VolumesRegion.GetSize()-1)
				{
					GetDlgItem(IDC_REC_END)->EnableWindow(false); 
					GetDlgItem(IDC_REC_NEXT)->EnableWindow(false);
				}
				else 
				{
					GetDlgItem(IDC_REC_END)->EnableWindow(true); 
					GetDlgItem(IDC_REC_NEXT)->EnableWindow(true);
				}
			}

		}
		GetDlgItem(IDC_BN_AJOUTER)->EnableWindow(true); 

		GetDlgItem(IDC_BN_AJOUTER_PALIER)->EnableWindow(false); 
		GetDlgItem(IDC_BN_MODIFIER_PALIER)->EnableWindow(false); 
		GetDlgItem(IDC_BN_SUPPRIMER_PALIER)->EnableWindow(false); 

		GetDlgItem(IDOK)->EnableWindow(true); 
		GetDlgItem(IDCANCEL)->EnableWindow(false); 

		GetDlgItem(IDC_DATE_DEBUT)->EnableWindow(false); 

		GetDlgItem(IDC_EDIT1)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT2)->EnableWindow(false);  
	}
}

void CVolumeDlg::UpdateList()
{
	m_CtrlPaliers.ResetContent();
	m_CtrlPaliers.SetTabStops(70);

	if (m_TypeVolume == 0)
	{
		// mode national
		if(!m_DataCopy.m_Palier.GetSize())
		{
			m_CurPalier=-1;
			m_DateDebut=COleDateTime::GetCurrentTime();
			m_PalierCopy=CPalier();
		}
		else
		{
			if(!m_DataCopy.m_Palier.GetSize())
			{
				m_CurPalier=-1;
				m_PalierCopy=CPalier();
			}
			else
			{
				for(int x=0;x<m_DataCopy.m_Palier.GetSize();x++)
				{
					CString String;
					
					// Modif CGV 2002
					//String.Format("%d\t%3.02f%%",m_DataCopy.m_Palier[x].m_Palier,m_DataCopy.m_Palier[x].m_Coef);
					String.Format("%9.2f\t%3.02f%%",m_DataCopy.m_Palier[x].m_Palier,m_DataCopy.m_Palier[x].m_Coef);
					m_CtrlPaliers.AddString(String);
				}
				m_CurPalier=0;
				m_CtrlPaliers.SetCurSel(m_CurPalier);
				m_PalierCopy=m_DataCopy.m_Palier[m_CurPalier];
			}
			m_DateDebut=m_DataCopy.m_DateDebut;
		}
	}
	else
	{
		// mode r�gional
		if(!m_DataRegionCopy.m_Palier.GetSize())
		{
			m_CurPalier=-1;
			m_DateDebut=COleDateTime::GetCurrentTime();
			m_PalierCopy=CPalier();
		}
		else
		{
			if(!m_DataRegionCopy.m_Palier.GetSize())
			{
				m_CurPalier=-1;
				m_PalierCopy=CPalier();
			}
			else
			{
				for(int x=0;x<m_DataRegionCopy.m_Palier.GetSize();x++)
				{
					CString String;
					//Modif CGV 2002
					//String.Format("%d\t%3.02f%%",m_DataRegionCopy.m_Palier[x].m_Palier,m_DataRegionCopy.m_Palier[x].m_Coef);
					String.Format("%9.2f\t%3.02f%%",m_DataRegionCopy.m_Palier[x].m_Palier,m_DataRegionCopy.m_Palier[x].m_Coef);
					m_CtrlPaliers.AddString(String);
				}
				m_CurPalier=0;
				m_CtrlPaliers.SetCurSel(m_CurPalier);
				m_PalierCopy=m_DataRegionCopy.m_Palier[m_CurPalier];
			}
			m_DateDebut=m_DataRegionCopy.m_DateDebut;
		}
	}
	
	UpdatePalier();
	UpdateData(false);
}

void CVolumeDlg::UpdatePalier()
{
	m_Palier=m_PalierCopy.m_Palier;
	m_Coef=m_PalierCopy.m_Coef;
	UpdateData(false);
}

void CVolumeDlg::GetData()
{
	UpdateData(true);

	if (m_TypeVolume == 0)
		// mode nationale
		m_DataCopy.m_DateDebut.SetDate(m_DateDebut.GetYear(),m_DateDebut.GetMonth(),m_DateDebut.GetDay());
	else
		// mode r�gionale
		m_DataRegionCopy.m_DateDebut.SetDate(m_DateDebut.GetYear(),m_DateDebut.GetMonth(),m_DateDebut.GetDay());

	m_PalierCopy.m_Palier=m_Palier;
	m_PalierCopy.m_Coef=m_Coef;
}

void CVolumeDlg::OnSelchangeList1() 
{
	m_CurPalier=m_CtrlPaliers.GetCurSel();
	if(m_CurPalier==LB_ERR)
	{
		m_CurPalier=-1;
		m_PalierCopy=CPalier();
	}
	else
	{
		if (m_TypeVolume == 0)
			// mode national
			m_PalierCopy=m_DataCopy.m_Palier[m_CurPalier];
		else
			// mode r�gional
			m_PalierCopy=m_DataRegionCopy.m_Palier[m_CurPalier];

	}

	UpdatePalier();
	UpdateButtons();
}
