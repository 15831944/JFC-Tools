// DataVolume.cpp: implementation of the CDataVolume class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiadm.h"
#include "DataVolume.h"

#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataVolume::CDataVolume()
{

}

CDataVolume::~CDataVolume()
{

}

bool CDataVolume::Load()
{
	m_Volumes.RemoveAll();
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",FALSE,TRUE);
		CTblVolumes Table(&Db);
		Table.Open();
		while(!Table.IsEOF()) 
		{
			CVolume Volume;
			Volume=Table;
			m_Volumes.Add(Volume);
			Table.MoveNext();
		}
		while(!Table.IsEOF())
		Table.Close();
		Db.Close();
		CVolume *pVolume=m_Volumes.GetData();
		if(pVolume) std::sort(pVolume,(pVolume+m_Volumes.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataVolume::Modify(CVolume &Volume, int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblVolumes Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("DateDebut = %s",m_Volumes[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table=Volume;
				Table.Update();
				m_Volumes[Index]=Volume;
//				CVolume *pVolume=m_Volumes.GetData();
//				if(pVolume) std::sort(pVolume,(pVolume+m_Volumes.GetSize()));
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataVolume::Add(CVolume &Volume)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblVolumes Table(&Db);
		Table.Open();
		Table.AddNew();
		Table=Volume;
		Table.Update();
		Table.Close();
		Db.Close();
		m_Volumes.Add(Volume);
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataVolume::Delete(int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblVolumes Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("DateDebut = %s",m_Volumes[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Delete();
				m_Volumes.RemoveAt(Index);
//				CVolume *pVolume=m_Volumes.GetData();
//				if(pVolume) std::sort(pVolume,(pVolume+m_Volumes.GetSize()));
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}