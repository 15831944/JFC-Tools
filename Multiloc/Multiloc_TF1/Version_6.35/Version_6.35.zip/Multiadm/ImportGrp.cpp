// ImportGrp.cpp: implementation of the CImportGrp class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiadm.h"
#include "ImportGrp.h"
#include "DataStation.h"
#include "DataVille.h"
#include "DataCible.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CImportGrp::CImportGrp()
{

}

CImportGrp::~CImportGrp()
{

}

bool CImportGrp::ImportFile()
{
/*	CFileDialog( BOOL bOpenFileDialog, LPCTSTR lpszDefExt = NULL, 
		LPCTSTR lpszFileName = NULL, 
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, 
		LPCTSTR lpszFilter = NULL, CWnd* pParentWnd = NULL );
*/

	CFileDialog Dialog(true,NULL,NULL,OFN_NOCHANGEDIR|OFN_ALLOWMULTISELECT,NULL,NULL);
	char *Buffer=new char[5050];
	Buffer[0]=0;
	Dialog.m_ofn.lpstrFile=Buffer;
	Dialog.m_ofn.nMaxFile=5000;
	if(Dialog.DoModal()==IDOK)
	{
		CWaitCursor Wait;
		POSITION Pos=Dialog.GetStartPosition();
		while(Pos)
		{
			CString FileName;
			FileName=Dialog.GetNextPathName(Pos);
			if(!Import(FileName))
			{
				CString Error;
				Error.Format("Error de chargement du fichier %s",FileName);
				AfxMessageBox(Error);
			}
		}
		AfxMessageBox("Import des Grps Termin�");
	}
	delete Buffer;
	return true;
}

/*
bool CImportGrp::ImportFileMultiGRP()
{

	CFileDialog Dialog(true,NULL,NULL,OFN_NOCHANGEDIR|OFN_ALLOWMULTISELECT,NULL,NULL);
	char *Buffer=new char[5050];
	Buffer[0]=0;
	Dialog.m_ofn.lpstrFile=Buffer;
	Dialog.m_ofn.nMaxFile=5000;
	if(Dialog.DoModal()==IDOK)
	{
		CWaitCursor Wait;
		POSITION Pos=Dialog.GetStartPosition();
		while(Pos)
		{
			CString FileName;
			FileName=Dialog.GetNextPathName(Pos);
			if(!ImportGeneGRP(FileName))
			{
				CString Error;
				Error.Format("Error de chargement du fichier %s",FileName);
				AfxMessageBox(Error);
			}
		}
		AfxMessageBox("Import de tous les Grps Termin�");
	}
	delete Buffer;
	return true;
}
*/

bool CImportGrp::AddReplace(CGrp &Grp)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblGrps Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation = %d AND NrVille = %d AND NrCible = %d AND DateDebut = %s",Grp.m_NrStation,Grp.m_NrVille,Grp.m_NrCible,
				Grp.m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table=Grp;
				Table.Update();
			}
			else
			{
				Table.AddNew();
				Table=Grp;
				Table.Update();
			}
		}
		else
		{
			Table.AddNew();
			Table=Grp;
			Table.Update();
		}
		Table.Close();

		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

bool CImportGrp::AddReplace2(CGrp &Grp, CDaoDatabase &Db)
{
	try
	{
		CTblGrps Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation = %d AND NrVille = %d AND NrCible = %d AND DateDebut = %s",Grp.m_NrStation,Grp.m_NrVille,Grp.m_NrCible,
				Grp.m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table=Grp;
				Table.Update();
			}
			else
			{
				Table.AddNew();
				Table=Grp;
				Table.Update();
			}
		}
		else
		{
			Table.AddNew();
			Table=Grp;
			Table.Update();
		}
		Table.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

bool CImportGrp::Import(CString FileName)
{
	CStdioFile File;
	if(!File.Open(FileName,CFile::modeRead|CFile::typeText))
	{
		AfxMessageBox("Ouverture du fichier impossible!");
		return false;
	}
	CString Data;

	if(!File.ReadString(Data))
	{
		AfxMessageBox("Invalid fin du fichier!");
		return false;
	}
	int NrStation=atoi(Data);
	CDataStation Sta;
	if(!Sta.Load()) return false;
	int x=0;
	for(;x<Sta.m_Stations.GetSize();x++)
	{
		if(Sta.m_Stations[x].m_NrUnique==NrStation) break;
	}
	if(x>=Sta.m_Stations.GetSize())
	{
		AfxMessageBox("Numero de la station invalide, import abandonn�! /" + NrStation);
		return false;
	}

	if(!File.ReadString(Data))
	{
		AfxMessageBox("Invalid fin du fichier!");
		return false;
	}
	int NrVille=atoi(Data);
	CDataVille Vil;
	if(!Vil.Load()) return false;
	for(x=0;x<Vil.m_Villes.GetSize();x++)
	{
		if(Vil.m_Villes[x].m_NrUnique==NrVille) break;
	}
	if(x>=Vil.m_Villes.GetSize())
	{
		AfxMessageBox("Numero de la Ville invalide, import abandonn�!");
		return false;
	}

	if(!File.ReadString(Data))
	{
		AfxMessageBox("Invalid fin du fichier!");
		return false;
	}
	int NrCible=atoi(Data);
	CDataCible Cib;

	
	Cib.Load();
	for(x=0;x<Cib.m_Cibles.GetSize();x++)
	{
		if(Cib.m_Cibles[x].m_NrUnique==NrCible) break;
	}
	if(x>=Cib.m_Cibles.GetSize())
	{
		AfxMessageBox("Numero de la Cible invalide, import abandonn�!");
		return false;
	}
	
	
	if(!File.ReadString(Data))
	{
		AfxMessageBox("Invalid fin du fichier!");
		return false;
	}
	int NbGrps=atoi(Data);
	CGrp Grp;
	Grp.m_NrStation=NrStation;
	Grp.m_NrVille=NrVille;
	Grp.m_NrCible=NrCible;
	for(x=0;x<NbGrps;x++)
	{
		do
		{
			if(!File.ReadString(Data))
			{
				AfxMessageBox("Invalid fin du fichier!");
				return false;
			}
		} while(Data.IsEmpty());

		if(!Grp.m_DateDebut.ParseDateTime(Data,VAR_DATEVALUEONLY))
		{
			AfxMessageBox("Date invalide, import abandonn�!");
			return false;
		}
		for(int Jour=0;Jour<7;Jour++)
		{
			Grp.m_Grp[Jour].RemoveAll();
			if(!File.ReadString(Data))
			{
				AfxMessageBox("Invalid fin du fichier!");
				return false;
			}
			int Pos=0;
			int Next=0;
			for(int Hor=0;Hor<48;Hor++,Next++)
			{
				LPCTSTR ptr=Data;
				ptr+=Pos;
				int t=atoi(ptr);
				Grp.m_Grp[Jour].Add(t);
				Pos=Data.Find(_T("\t"),Next);
				Next=Pos;
			}
		}
		if(!AddReplace(Grp)) return false;
	}
	File.Close();
	return true;
}

// Import de plusieurs bloc GRP (en d�but de fichier Nb blocs total)
bool CImportGrp::ImportGeneGRP(CString FileName,CProgressCtrl *ProgressBar)
{

	/* Rappel structure fichier multi-GRP

		Ligne 1 : Nb Stations * Nb Villes * NbCibles (nombre de blocs total)

		// Bloc global Station 1 / Ville 1 / Cible 1
		Ligne 2 : No Station
		Ligne 3 : No Ville
		Ligne 3 : No Cible
		Ligne 4 : Nb Tarifs (par date)
			Bloc Tarif N�1
			Ligne 4 : Ligne vide
			Ligne 5 : Date format dd/mm/yy
			Ligne 6 / Lundi    : Les 48 GRP (par demi-heure)
			Ligne 7 / Mardi    :  "    "     "   "    "
			Ligne 8 / Mercredi :  "    "     "   "    "	
			Ligne 9 / Jeudi    :  "    "     "   "    "	
			Ligne 10/ Vendredi :  "    "     "   "    "	
			Ligne 11/ Samedi   :  "    "     "   "    "	
			Ligne 12/ Dimanche :  "    "     "   "    "	
			Ligne vide
			Bloc Tarif N�2 ....
			.......
		// Bloc global Station suivante / Ville suivante
		.......
	*/
	CStdioFile File;
	if(!File.Open(FileName,CFile::modeRead|CFile::typeText))
	{
		AfxMessageBox("Ouverture du fichier impossible!");
		return false;
	}
	CString Data;

	if(!File.ReadString(Data))
	{
		AfxMessageBox("Invalid fin du fichier!");
		return false;
	}


	// Lecture nombre de bloc stations/villes totales
	int NbBlocStationVilleCible = atoi(Data);
	if (NbBlocStationVilleCible == 0) return true;


	//////////////////// En attente de r�soudre probleme MDAC  ////////////////
	/*
	for (int NoBloc = 0;NoBloc < NbBlocStationVilleCible;NoBloc++)
	{
		// Lecture Bloc Station/Ville/Cible
		if(!File.ReadString(Data))
		{
			AfxMessageBox("Invalid fin du fichier!");
			return false;
		}

		if (NoBloc % 100 == 0)
			bool Ok = true;


		if(!File.ReadString(Data))
		{
			AfxMessageBox("Invalid fin du fichier!");
			return false;
		}

		// Num�ro de la cible
		if(!File.ReadString(Data))
		{
			AfxMessageBox("Invalid fin du fichier!");
			return false;
		}

		if(!File.ReadString(Data))
		{
			AfxMessageBox("Invalid fin du fichier!");
			return false;
		}
		int NbGrps=atoi(Data);
		for(int y=0;y<NbGrps;y++)
		{
			do
			{
				if(!File.ReadString(Data))
				{
					AfxMessageBox("Invalid fin du fichier!");
					return false;
				}
			} while(Data.IsEmpty());

			
			for(int Jour=0;Jour<7;Jour++)
			{
				if(!File.ReadString(Data))
				{
					AfxMessageBox("Invalid fin du fichier!");
					return false;
				}
			}

			if(!File.ReadString(Data))
			{
				AfxMessageBox("Invalid fin du fichier!");
				return false;
			}
			
		}
	}
	*/
	///////////////////////////////////////////////////////////////////////////


	CDaoDatabase Db;
	Db.Open("multiloc.mdb",TRUE,FALSE);		



	for (int NoBloc = 0;NoBloc < NbBlocStationVilleCible;NoBloc++)
	{

		/*for (int Delay = 0; Delay < 1000000; Delay++)
		{
		}*/

		// Lecture Bloc Station/Ville/Cible
		if(!File.ReadString(Data))
		{
			AfxMessageBox("Invalid fin du fichier!");
			return false;
		}

		if (NoBloc % 1000 == 0)
			bool Ok = true;

		int NrStation=atoi(Data);
		CDataStation Sta;
		if(!Sta.Load()) return false;
		int x=0;
		for(;x<Sta.m_Stations.GetSize();x++)
		{
			if(Sta.m_Stations[x].m_NrUnique==NrStation) break;
		}
		if(x>=Sta.m_Stations.GetSize())
		{
			AfxMessageBox("Numero de la station invalide, import abandonn�! /" + NrStation);
			return false;
		}

		if(!File.ReadString(Data))
		{
			AfxMessageBox("Invalid fin du fichier!");
			return false;
		}
		int NrVille=atoi(Data);
		CDataVille Vil;

		if(!Vil.Load()) return false;

		for(x=0;x<Vil.m_Villes.GetSize();x++)
		{
			
			if(Vil.m_Villes[x].m_NrUnique==NrVille) break;
		}
		if(x>=Vil.m_Villes.GetSize())
		{
			AfxMessageBox("Numero de la Ville invalide, import abandonn�! / NrVille = " + NrVille);
			return false;
		}

		// Num�ro de la cible
		if(!File.ReadString(Data))
		{
			AfxMessageBox("Invalid fin du fichier!");
			return false;
		}
		int NrCible = atoi(Data);
		CDataCible Cible;
		if(!Cible.Load()) return false;
		for(x=0;x<Cible.m_Cibles.GetSize();x++)
		{
			if(Cible.m_Cibles[x].m_NrUnique==NrCible) break;
		}
		if(x>=Cible.m_Cibles.GetSize())
		{
			AfxMessageBox("Numero de la Cible invalide, import abandonn�! / NrCible = " + NrCible);
			return false;
		}

		if(!File.ReadString(Data))
		{
			AfxMessageBox("Invalid fin du fichier!");
			return false;
		}

		int NbGrps=atoi(Data);
		CGrp Grp;
		Grp.m_NrStation=NrStation;
		Grp.m_NrVille=NrVille;
		Grp.m_NrCible=NrCible;
		for(x=0;x<NbGrps;x++)
		{
			do
			{
				if(!File.ReadString(Data))
				{
					AfxMessageBox("Invalid fin du fichier!");
					return false;
				}
			} while(Data.IsEmpty());

			if(!Grp.m_DateDebut.ParseDateTime(Data,VAR_DATEVALUEONLY))
			{
				AfxMessageBox("Date invalide, import abandonn�!");
				return false;
			}
			for(int Jour=0;Jour<7;Jour++)
			{
				Grp.m_Grp[Jour].RemoveAll();
				if(!File.ReadString(Data))
				{
					AfxMessageBox("Invalid fin du fichier!");
					return false;
				}
				int Pos=0;
				int Next=0;
				for(int Hor=0;Hor<48;Hor++,Next++)
				{
					LPCTSTR ptr=Data;
					ptr+=Pos;
					int t=atoi(ptr);
					Grp.m_Grp[Jour].Add(t);
					Pos=Data.Find(_T("\t"),Next);
					Next=Pos;
				}
			}

			// if(!AddReplace(Grp)) return false;
			if(!AddReplace2(Grp,Db)) return false;

			if(!File.ReadString(Data))
			{
				AfxMessageBox("Invalid fin du fichier!");
				return false;
			}
			
		}


		float Ratio = (float)NbBlocStationVilleCible/(float)50;
		int Progress = int(50 + int((float)NoBloc/Ratio));
		if (Progress > 100) Progress = 100;
		if (ProgressBar != NULL) ProgressBar->SetPos(Progress);
	}	

	Db.Close();

	if (ProgressBar != NULL) ProgressBar->SetPos(100);

	File.Close();

	AfxMessageBox ("FIN TRANSFERT FICHIER GLOBAL GRP");
	ProgressBar->SetPos(0);
	return true;
	
}

bool CImportGrp::ChoixFicGeneGRP(CString FileGrp,CProgressCtrl *ProgressBar)
{
	CFileDialog Dialog(true,NULL,NULL,OFN_NOCHANGEDIR|OFN_ALLOWMULTISELECT,NULL,NULL);
	char *Buffer=new char[5050];
	Buffer[0]=0;
	Dialog.m_ofn.lpstrFile=Buffer;
	Dialog.m_ofn.nMaxFile=5000;
	if(Dialog.DoModal()==IDOK)
	{
		CWaitCursor Wait;
		POSITION Pos=Dialog.GetStartPosition();
		while(Pos)
		{
			CString FileName;
			FileName=Dialog.GetNextPathName(Pos);
			if(!ImportGeneGRP(FileName,ProgressBar))
			{
				CString Error;
				Error.Format("Error de chargement du fichier %s",FileName);
				AfxMessageBox(Error);
			}
		}
	}
	delete Buffer;
	return true;
}
