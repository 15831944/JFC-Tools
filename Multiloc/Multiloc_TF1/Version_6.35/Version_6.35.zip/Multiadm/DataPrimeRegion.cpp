// DataPrimeRegion.cpp: implementation of the CDataPrimeRegion class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiadm.h"
#include "DataPrimeRegion.h"
#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataPrimeRegion::CDataPrimeRegion()
{

}

CDataPrimeRegion::~CDataPrimeRegion()
{

}

bool CDataPrimeRegion::Load()
{
	m_PrimesRegion.RemoveAll();
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",FALSE,TRUE);
		CTblPrimesRegion Table(&Db);
		Table.Open();
		while(!Table.IsEOF()) 
		{
			CPrimeRegion PrimeRegion;
			PrimeRegion=Table;
			m_PrimesRegion.Add(PrimeRegion);
			Table.MoveNext();
		}
		while(!Table.IsEOF())
		Table.Close();
		Db.Close();
		CPrimeRegion *pPrimeRegion=m_PrimesRegion.GetData();
		if(pPrimeRegion) std::sort(pPrimeRegion,(pPrimeRegion+m_PrimesRegion.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataPrimeRegion::Modify(CPrimeRegion &PrimeRegion, int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblPrimesRegion Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("DateDebut = %s",m_PrimesRegion[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table=PrimeRegion;
				Table.Update();
				m_PrimesRegion[Index]=PrimeRegion;
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataPrimeRegion::Add(CPrimeRegion &PrimeRegion)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblPrimesRegion Table(&Db);
		Table.Open();
		Table.AddNew();
		Table=PrimeRegion;
		Table.Update();
		Table.Close();
		Db.Close();
		m_PrimesRegion.Add(PrimeRegion);
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataPrimeRegion::Delete(int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblPrimesRegion Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("DateDebut = %s",m_PrimesRegion[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Delete();
				m_PrimesRegion.RemoveAt(Index);
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}