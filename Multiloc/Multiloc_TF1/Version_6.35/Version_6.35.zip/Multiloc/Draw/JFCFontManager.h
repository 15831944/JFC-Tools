//============================
// fichier: JFCFontManager.h
//
// date: 08/03/2002
// auteur: JB
//----------------------------

// on teste si la macro qui identifie le fichier est d�j� d�finie
#ifndef _JFCFONTMANAGER_H_

// on d�finit une macro pour identifier le fichier
#define _JFCFONTMANAGER_H_

// on inclut les fichiers n�cessaires
#include "JFCFont.h"

class FontManager
{
public:
	// le constructeur
	FontManager();

	// la fonction pour fixer le nombre de fontes
	static void SetNbFont(long nbfont);

	// la fonction pour r�cup�rer le nombre de fontes
	static long GetNbFont();

	// la fonction pour fixer la fonte en fonction d'un indice
	static void SetFont(long indice, JFCFont font);

	// la fonction pour r�cup�rer la fonte en fonction de l'indice
	static JFCFont GetFont(long indice);

	// le destructeur
	~FontManager();
protected:
	// le tableau de fontes
	static JFCFont * m_TabFont;

	// le nombre de fontes dans le tableau
	static long m_NbFont;
};
// fin du test sur la macro
#endif