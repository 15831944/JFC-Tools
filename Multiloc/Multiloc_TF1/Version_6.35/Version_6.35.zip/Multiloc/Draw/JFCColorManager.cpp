//================================
// fichier: JFCColorManager.cpp
// 
// date: 08/03/2001
// auteur: JB
//--------------------------------

// on inclut les fichiers n�cessaires
#include "stdafx.h"
#include "JFCColorManager.h"

long ColorManager::m_Luminosite     = 0;
long ColorManager::m_NbColor        = 0;
COLORREF * ColorManager::m_TabColor = 0;

//===============================================================
// le constructeur:
//---------------------------------------------------------------
ColorManager::ColorManager()
{
	// on initialise les param�tres
	m_Luminosite = 0;
	m_NbColor    = 0;
	m_TabColor   = 0;
}

//===============================================================
// la fonction pour fixer le nombre de couleurs:
//---------------------------------------------------------------
void ColorManager::SetNbColor(long nbcolor)
{
	// on r�initialise le tableau
	delete [] m_TabColor;

	// on alloue le tableau
	m_TabColor = new COLORREF[nbcolor];

	// on teste l'allocation
	if (m_TabColor == 0)
	{
		// on fixe le nombre de couleurs � 0
		m_NbColor = 0;
	}
	else
	{
		// on fixe le nombre de couleurs � nbcolor
		m_NbColor = nbcolor;
	}
}

//===============================================================
// la fonction pour r�cup�rer le nombre de couleurs:
//---------------------------------------------------------------
long ColorManager::GetNbColor()
{
	// on renvoie le nombre de couleurs
	return (m_NbColor);
}

//===============================================================
// la fonction pour fixer la couleur d'un indice:
//---------------------------------------------------------------
void ColorManager::SetColor(long indice, COLORREF couleur)
{
	// on teste l'indice
	if (indice>=0 && indice < m_NbColor)
	{
		m_TabColor[indice] = couleur;
	}
}

//===============================================================
// la fonction pour r�cup�rer la couleur d'un indice:
//---------------------------------------------------------------
COLORREF ColorManager::GetColor(long indice)
{
	// on teste l'indice
	if (indice>=0 && indice < m_NbColor)
	{
		// on renvoie la couleur
		return (m_TabColor[indice]);
	}
	else return (0xFF0000);
}

//===============================================================
// la fonction pour r�cup�rer la couleur d'un indice:
//---------------------------------------------------------------
COLORREF ColorManager::GetLumColor(long indice)
{
	// on teste l'indice
	if (indice>=0 && indice < m_NbColor)
	{
		// on r�cup�re les couleurs
		char red    = (char) ((m_TabColor[indice] & 0x0000FF) >> 0 );
		char green  = (char) ((m_TabColor[indice] & 0x00FF00) >> 8 );
		char blue   = (char) ((m_TabColor[indice] & 0xFF0000) >> 16);

		// on renvoie la valeur affect�e par la luminosite
		COLORREF couleur = (char) (red+m_Luminosite) + ((char) (green+m_Luminosite))*256 + ((char)(blue+m_Luminosite)) * 65536;
		return (couleur);
	}
	else return (0xFF0000);
}

//===============================================================
// le destructeur:
//---------------------------------------------------------------
ColorManager::~ColorManager()
{
	// on lib�re le tableau
	delete [] m_TabColor;
}
