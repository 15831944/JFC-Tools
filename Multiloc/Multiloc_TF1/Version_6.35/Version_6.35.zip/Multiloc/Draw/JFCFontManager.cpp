//==============================
// fichier: JFCFontManager.cpp
// 
// date: 08/03/2002
// auteur: JB
//------------------------------


// on inclut les fichiers n�cessaires
#include "stdafx.h"
#include "JFCFontManager.h"

long      FontManager::m_NbFont  = 0;
JFCFont * FontManager::m_TabFont = 0;

//==========================================================================
// le constructeur:
//--------------------------------------------------------------------------
FontManager::FontManager()
{
	// on initialise les param�tres
	m_NbFont  = 0;
	m_TabFont = 0;
}

//==========================================================================
// la fonction pour fixer le nombre de fontes:
//--------------------------------------------------------------------------
void FontManager::SetNbFont(long nbfont)
{
	// on lib�re le tableau
	delete [] m_TabFont;

	// on r�alloue le tableau
	m_TabFont = new JFCFont[nbfont];

	// on teste l'allocation
	m_NbFont = (m_TabFont == 0)	? 0 : nbfont;
}

//==========================================================================
// la fonction pour r�cup�rer le nombre de fontes:
//--------------------------------------------------------------------------
long FontManager::GetNbFont()
{
	// on renvoie le nombre de fonte dans le tableau
	return (m_NbFont);
}

//==========================================================================
// la fonction pour fixer une fonte en fonction de l'indice:
//--------------------------------------------------------------------------
void FontManager::SetFont(long indice, JFCFont font)
{
	// on teste l'indice
	if (indice>=0 && indice < m_NbFont)
	{
		m_TabFont[indice] = font;
	}
}

//==========================================================================
// la fonction pour recup�rer une fonte en fonction de l'indice:
//--------------------------------------------------------------------------
JFCFont FontManager::GetFont(long indice)
{
	// on teste l'indice
	if (indice>=0 && indice < m_NbFont)
	{
		// on renvoie la fonte indic�e
		return (m_TabFont[indice]);
	}
	else return (JFCFont(0, 0, false, false));
}

//==========================================================================
// le destructeur:
//--------------------------------------------------------------------------
FontManager::~FontManager()
{
	// on lib�re le tableau
	delete [] m_TabFont;
}