//========================
// fichier: JFCFont.h
// 
// date: 08/03/2002
// auteur: JB
//------------------------

// on teste si la macro qui identifie le fichier est d�j� d�finie
#ifndef _JFCFONT_H_

// on d�finit une macro pour identifier le fichier
#define _JFCFONT_H_

class JFCFont
{
	friend class FontManager;
public:
	enum{ TIMES = 0, COURIER, HELVETICA };

private:
	// le constructeur g�n�rique
	JFCFont();
public:
	// le constructeur
	JFCFont(long fontname, long size, bool bold, bool italic);

	// le constructeur de recopie
	JFCFont(const JFCFont & source);

	// l'op�rateur d'affectation
	JFCFont & operator = (const JFCFont & operande);

	// la fonction pour r�cup�rer le nom GDI
	const char * GetGDIName();
	const char * GetPDFName();

	// la fonction pour r�cup�rer la taille
	long GetSize();

	// la fonction 
	bool IsBold();
	bool IsItalic();
	
	// le destructeur
	~JFCFont();
protected:
	// la fonte
	long m_Fontname;

	// la taille
	long m_Size;

	// le param�tre gras
	bool m_Bold;

	// le param�tre italique
	bool m_Italic;

private:
	// les noms des polices GDI
	static const char * m_GDICourier;
	static const char * m_GDITimes;
	static const char * m_GDIHelvetica;

	// les noms des polices PDF
	static const char * m_PDFTimes;
	static const char * m_PDFTimesBold;
	static const char * m_PDFTimesItalic;
	static const char * m_PDFTimesBoldItalic;

	static const char * m_PDFCourier;
	static const char * m_PDFCourierBold;
	static const char * m_PDFCourierItalic;
	static const char * m_PDFCourierBoldItalic;

	static const char * m_PDFHelvetica;
	static const char * m_PDFHelveticaBold;
	static const char * m_PDFHelveticaItalic;
	static const char * m_PDFHelveticaBoldItalic;
};
// fin du test sur la macro
#endif