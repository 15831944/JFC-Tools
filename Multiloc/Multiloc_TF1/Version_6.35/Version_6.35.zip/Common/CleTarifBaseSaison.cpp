// CleTarifBaseSaison.cpp: implementation of the CCleTarifBaseSaison class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CleTarifBaseSaison.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCleTarifBaseSaison::CCleTarifBaseSaison()
{
	// Init Cle
	m_NrVille	= 0;
	m_NrStation = 0;
	m_DateDeb.GetCurrentTime();
}

CCleTarifBaseSaison::~CCleTarifBaseSaison()
{

}

////////////////////////////////////////////////////////////////////////////////////////////
//   Fonction constructeur copy
CCleTarifBaseSaison::CCleTarifBaseSaison(const CCleTarifBaseSaison &Source)
{
	*this=Source;
}

////////////////////////////////////////////////////////////////////////////////////////////
//   Fonction d'affectation
CCleTarifBaseSaison & CCleTarifBaseSaison::operator=(const CCleTarifBaseSaison &Source)
{
	m_NrVille	= Source.m_NrVille;
	m_NrStation	= Source.m_NrStation;
	m_DateDeb	= Source.m_DateDeb; 
	
	return(*this);
}

////////////////////////////////////////////////////////////////////////////////////////////
//   Fonction de comparaison <
bool CCleTarifBaseSaison::operator < (const CCleTarifBaseSaison &Source)const
{
	if (m_NrStation < Source.m_NrStation) return (true);
	if (m_NrStation > Source.m_NrStation) return (false);

	if (m_NrVille   < Source.m_NrVille)   return (true);
	if (m_NrVille   > Source.m_NrVille)   return (false);

	if (m_DateDeb	< Source.m_DateDeb)   return (true);
	
	return (false);
}

////////////////////////////////////////////////////////////////////////////////////////////
//   Fonction de comparaison >
bool CCleTarifBaseSaison::operator > (const CCleTarifBaseSaison &Source)const
{
	if (m_NrStation > Source.m_NrStation) return (true);
	if (m_NrStation < Source.m_NrStation) return (false);

	if (m_NrVille   > Source.m_NrVille)   return (true);
	if (m_NrVille   < Source.m_NrVille)   return (false);

	if (m_DateDeb	> Source.m_DateDeb)   return (true);
	
	return (false);
}
