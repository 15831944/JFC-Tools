// Mois.cpp: implementation of the CMois class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Mois.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMois::CMois()
{

	NoMois = 1;
	NoAnnee = 2000;
	NoJour = 1;
	NbJour = 0;
	IndexJourPeriode = 0;
}

CMois::~CMois()
{

}
