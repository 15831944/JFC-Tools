// TblTarifBase.cpp : implementation file
//

#include "stdafx.h"
#include "TblTarifBase.h"
#include "TarifBase.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTblTarifBase

IMPLEMENT_DYNAMIC(CTblTarifBase, CDaoRecordset)

CTblTarifBase::CTblTarifBase(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CTblTarifBase)
	m_NrStation = 0;
	m_NrVille = 0;
	m_DateDebut = (DATE)0;
	m_DateFin = (DATE)0;
	m_TarifBase = 0;
	m_FraisAntenne = 0;
	m_nFields = 6;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CTblTarifBase::GetDefaultDBName()
{
	return _T("Multiloc.mdb");
}

CString CTblTarifBase::GetDefaultSQL()
{
	return _T("[TarifBase]");
}

void CTblTarifBase::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CTblTarifBase)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Long(pFX, _T("[NrStation]"), m_NrStation);
	DFX_Long(pFX, _T("[NrVille]"), m_NrVille);
	DFX_DateTime(pFX, _T("[DateDebut]"), m_DateDebut);
	DFX_DateTime(pFX, _T("[DateFin]"), m_DateFin);
	DFX_Long(pFX, _T("[TarifBase]"), m_TarifBase);
	DFX_Short(pFX, _T("[FraisAntenne]"), m_FraisAntenne);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CTblTarifBase diagnostics

#ifdef _DEBUG
void CTblTarifBase::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CTblTarifBase::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG

CTblTarifBase & CTblTarifBase::operator=(const CTarifBase &Source)
{
	// Date d�but/date fin p�riode tarif
	m_DateDebut.SetDate(Source.m_DateDebut.GetYear(),Source.m_DateDebut.GetMonth(),Source.m_DateDebut.GetDay());
	m_DateFin.SetDate(Source.m_DateFin.GetYear(),Source.m_DateFin.GetMonth(),Source.m_DateFin.GetDay());

	// N� ville et station
	m_NrVille		= Source.m_NrVille;
	m_NrStation		= Source.m_NrStation;

	// Tarif de base
	m_TarifBase	= Source.m_TarifBase;  

	// Frais mise � l'antenne
	m_FraisAntenne = Source.m_FraisAntenne;

	return(*this);
}