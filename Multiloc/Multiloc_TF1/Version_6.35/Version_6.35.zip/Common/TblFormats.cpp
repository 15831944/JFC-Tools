// TblFormats.cpp : implementation file
//

#include "stdafx.h"
#include "TblFormats.h"
#include "Format.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTblFormats

IMPLEMENT_DYNAMIC(CTblFormats, CDaoRecordset)

CTblFormats::CTblFormats(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CTblFormats)
	m_NrStation = 0;
	m_DateDebut = (DATE)0;
	m_nFields = 3;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CTblFormats::GetDefaultDBName()
{
	return _T("C:\\multiloc\\multiloc.mdb");
}

CString CTblFormats::GetDefaultSQL()
{
	return _T("[Formats]");
}

void CTblFormats::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CTblFormats)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Long(pFX, _T("[NrStation]"), m_NrStation);
	DFX_DateTime(pFX, _T("[DateDebut]"), m_DateDebut);
	DFX_Binary(pFX, _T("[Data]"), m_Data,100,AFX_DAO_ENABLE_FIELD_CACHE);
	//}}AFX_FIELD_MAP
//	DFX_LongBinary(pFX, _T("[Data]"), m_Data);
}

/////////////////////////////////////////////////////////////////////////////
// CTblFormats diagnostics

#ifdef _DEBUG
void CTblFormats::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CTblFormats::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG

CTblFormats & CTblFormats::operator=(const CFormat &Source)
{
	m_NrStation=Source.m_NrStation;
	m_DateDebut.SetDate(Source.m_DateDebut.GetYear(),Source.m_DateDebut.GetMonth(),Source.m_DateDebut.GetDay());
	m_Data.RemoveAll();
	int Size=Source.m_Format.GetSize();
	BYTE *pByte=(BYTE *)&Size;
	for(int x=0;x<sizeof(int);x++) m_Data.Add(pByte[x]);
	for(int x=0;x<Source.m_Format.GetSize();x++)
	{
		int y=0;
		CFormatD Format=Source.m_Format[x];
		for(y=0,pByte=(BYTE *)(LPCSTR)Format.m_Libelle;y<Format.m_Libelle.GetLength();y++) m_Data.Add(pByte[y]);
		m_Data.Add(0);
		for(y=0,pByte=(BYTE *)&Format.m_Coef;y<sizeof(Format.m_Coef);y++) m_Data.Add(pByte[y]);
	}
	return(*this);
}
