// CleCorrespondanceTraffic.h: interface for the CCleCorrespondanceTraffic class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CLECORRESPONDANCETRAFFIC_H__54D68FCB_3315_46CF_A7FC_75955F345553__INCLUDED_)
#define AFX_CLECORRESPONDANCETRAFFIC_H__54D68FCB_3315_46CF_A7FC_75955F345553__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCleCorrespondanceTraffic  
{
public:
	CCleCorrespondanceTraffic();
	virtual ~CCleCorrespondanceTraffic();

	CCleCorrespondanceTraffic(const CCleCorrespondanceTraffic &Source);				// Copy constructor
	CCleCorrespondanceTraffic & operator=(const CCleCorrespondanceTraffic &Source);	// Affectation operator
	bool operator<(const CCleCorrespondanceTraffic &Source)const;					// Operator <
	bool operator>(const CCleCorrespondanceTraffic &Source)const;					// Operator <

public:
	// �lmts de la cl�
	long m_NrStation;				// N� de la station radio
	long m_NrVille;					// N� de la ville radio

};

#endif // !defined(AFX_CLECORRESPONDANCE_H__54D68FCB_3315_46CF_A7FC_75955F345553__INCLUDED_)
