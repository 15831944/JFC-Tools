// CorrespondanceTraffic.cpp: implementation of the CCorrespondanceTraffic class.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "CorrespondanceTraffic.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCorrespondanceTraffic::CCorrespondanceTraffic()
{

}

CCorrespondanceTraffic::~CCorrespondanceTraffic()
{

}

CCorrespondanceTraffic::CCorrespondanceTraffic(const CCorrespondanceTraffic &Source)
{
	*this=Source;
}

CCorrespondanceTraffic & CCorrespondanceTraffic::operator=(const CCorrespondanceTraffic &Source)
{
	// N� station
	m_NrStation			= Source.m_NrStation;

	// N� ville
	m_NrVille			= Source.m_NrVille;

	// Traffic Code
	m_TrafficCode		= Source.m_TrafficCode;

	// Libelle Traffic
	m_TrafficLibelle	= Source.m_TrafficLibelle;

	return(*this);
}

CCorrespondanceTraffic & CCorrespondanceTraffic::operator=(const CTblCorrespondanceTraffic &Source)
{
	// No station
	m_NrStation			= Source.m_NrStation;

	// No ville
	m_NrVille			= Source.m_NrVille;

	// Traffic Code
	m_TrafficCode		= Source.m_TrafficCode;

	// Libelle Traffic
	m_TrafficLibelle	= Source.m_TrafficLibelle;

	return(*this);
}

bool CCorrespondanceTraffic::operator<(const CCorrespondanceTraffic &Source)
{
    if(m_NrStation	<	Source.m_NrStation)	return(TRUE);
	if(m_NrVille	<	Source.m_NrVille)	return(TRUE);
    
    return(FALSE);
}

