// RemiseStaVil.h: interface for the CRemiseStaVil class.
//
//////////////////////////////////////////////////////////////////////

#pragma once
// _MSC_VER > 1000

#include <afxtempl.h>		// MFC template library
#include "TblRemiseStaVils.h"
#include "Palier.h"			// Added by ClassView

class CRemiseStaVil  
{
public:
	CRemiseStaVil  ();
	virtual ~CRemiseStaVil  ();

	CRemiseStaVil  (const CRemiseStaVil   &Source);					// Copy constructor
	CRemiseStaVil   & operator=(const CRemiseStaVil   &Source);		// Copy operator
	CRemiseStaVil   & operator=(const CTblRemiseStaVils   &Source);	// Copy operator
	bool operator<(const CRemiseStaVil   &Source);					// Operator <

	COleDateTime m_DateDebut;						// Date debut
	CPalierArray m_Palier;							// Liste de Paliers
};

typedef	CArray<CRemiseStaVil  ,CRemiseStaVil  &> CRemiseStaVilArray;


