// InfoStaVil.cpp: implementation of the CInfoStaVil class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "InfoStaVil.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CInfoStaVil::CInfoStaVil()
{
	m_NrStation = 0;
	m_NrVille = 0;
	m_AdrMail = "";
	m_Fax = "";
}

CInfoStaVil::~CInfoStaVil()
{
}

CInfoStaVil & CInfoStaVil::operator=(const CInfoStaVil &Source)
{
	m_NrStation = Source.m_NrStation;
	m_NrVille = Source.m_NrVille;
	m_AdrMail = Source.m_AdrMail;
	m_Fax = Source.m_Fax;
	return (*this);
}

CInfoStaVil & CInfoStaVil::operator=(const CTblInfoStaVil &Source)
{
	m_NrStation = Source.m_NrStation;
	m_NrVille = Source.m_NrVille;
	m_AdrMail = Source.m_AdrMail;
	m_Fax = Source.m_Fax;
	return (*this);
}
