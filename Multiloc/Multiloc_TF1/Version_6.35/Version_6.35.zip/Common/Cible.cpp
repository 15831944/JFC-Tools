// Cible.cpp: implementation of the CCible class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Cible.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCible::CCible()
{
	m_NrUnique=0;
	m_Libelle=_T("");
}

CCible::~CCible()
{

}

CCible::CCible(const CCible &Source)
{
	*this=Source;
}

CCible & CCible::operator=(const CCible &Source)
{
	m_NrUnique=Source.m_NrUnique;
	m_Libelle=Source.m_Libelle;
	return(*this);
}

CCible & CCible::operator=(const CTblCibles &Source)
{
	m_NrUnique=Source.m_NrUnique;
	m_Libelle=Source.m_Libelle;
	return(*this);
}

bool CCible::operator<(const CCible &Source)
{
	if(m_Libelle<Source.m_Libelle) return(TRUE);
	else return(FALSE);
}
