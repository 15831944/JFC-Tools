#if !defined(AFX_TBLVILLES_H__CF0FDC80_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
#define AFX_TBLVILLES_H__CF0FDC80_7E12_11D2_9B0D_004005327F6C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TblVilles.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTblVilles DAO recordset
class CVille;

class CTblVilles : public CDaoRecordset
{
public:
	CTblVilles(CDaoDatabase* pDatabase = NULL);
	CTblVilles & operator=(const CVille &Source);// Copy operator
	DECLARE_DYNAMIC(CTblVilles)

// Field/Param Data
	//{{AFX_FIELD(CTblVilles, CDaoRecordset)
	long	m_NrUnique;
	CString	m_Libelle;
	long	m_Commune;
	long	m_NbHabitantsInsee;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTblVilles)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TBLVILLES_H__CF0FDC80_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
