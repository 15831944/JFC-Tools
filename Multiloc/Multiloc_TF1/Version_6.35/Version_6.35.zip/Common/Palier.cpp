// Palier.cpp: implementation of the CPalier class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Palier.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPalier::CPalier()
{
	m_Coef=0.0;
	m_Palier=0;
}

CPalier::~CPalier()
{

}

CPalier::CPalier(const CPalier &Source)
{
	*this=Source;
}

CPalier & CPalier::operator=(const CPalier &Source)
{
	m_Palier=Source.m_Palier;
	m_Coef=Source.m_Coef;
	return(*this);
}

bool CPalier::operator<(const CPalier &Source)
{
	if(m_Palier<Source.m_Palier) return(TRUE);
	else return(FALSE);
}
