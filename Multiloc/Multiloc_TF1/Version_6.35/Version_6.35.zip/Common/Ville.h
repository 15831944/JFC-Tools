// Ville.h: interface for the CVille class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VILLE_H__CF0FDC88_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
#define AFX_VILLE_H__CF0FDC88_7E12_11D2_9B0D_004005327F6C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>		// MFC template library
#include "TblVilles.h"

class CVille  
{
public:
	int m_NbHabitantsInsee;
	int m_Commune;
	int m_NrIndex;
	CVille();
	virtual ~CVille();

	CVille(const CVille &Source); // Copy constructor
	CVille & operator=(const CVille &Source);// Copy operator
	CVille & operator=(const CTblVilles &Source);// Copy operator
	bool operator<(const CVille &Source);// Operator <

	long m_NrUnique; // Numero de la Ville
	CString m_Libelle;// Libelle de la Ville
};

typedef	CArray<CVille,CVille&> CVilleArray;

#endif // !defined(AFX_VILLE_H__CF0FDC88_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
