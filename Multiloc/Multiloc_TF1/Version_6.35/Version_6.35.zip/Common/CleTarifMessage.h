// CleTarifMessage.h: interface for the CCleTarifMessage class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CLETARIFMESSAGE_H__54D68FCB_3315_46CF_A7FC_75955F345553__INCLUDED_)
#define AFX_CLETARIFMESSAGE_H__54D68FCB_3315_46CF_A7FC_75955F345553__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCleTarifMessage  
{
public:
	CCleTarifMessage();
	virtual ~CCleTarifMessage();

	CCleTarifMessage(const CCleTarifMessage &Source);				// Copy constructor
	CCleTarifMessage & operator=(const CCleTarifMessage &Source);	// Affectation operator
	bool operator<(const CCleTarifMessage &Source)const;			// Operator <
	bool operator>(const CCleTarifMessage &Source)const;			// Operator <

public:
	// �lmts de la cl�
	long m_NrStation;				// N� de la station radio
	long m_NrVille;					// N� de la ville radio
	int	 m_NrJour;					// index du jour (0-6)
	int  m_NrTrh;					// index tranche horaire (0-47)
	COleDateTime m_DateDeb;			// date d�but prise en compte tarif



};

#endif // !defined(AFX_CLETARIFMESSAGE_H__54D68FCB_3315_46CF_A7FC_75955F345553__INCLUDED_)
