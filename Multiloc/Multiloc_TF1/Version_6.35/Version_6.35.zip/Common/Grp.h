// Grp.h: interface for the CGrp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GRP_H__CF0FDC89_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
#define AFX_GRP_H__CF0FDC89_7E12_11D2_9B0D_004005327F6C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>		// MFC template library
#include "TblGrps.h"
//class CTblGrps;

class CGrp  
{
	#define NB_JOURS 7
	#define NB_DEMIHEURE 48
public:
	CGrp();
	virtual ~CGrp();

	CGrp(const CGrp &Source); // Copy constructor
	CGrp & operator=(const CGrp &Source);// Copy operator
	CGrp & operator=(const CTblGrps &Source);// Copy operator
	bool operator<(const CGrp &Source);// Operator <

	long m_NrCible; // Numero unique de la cible
	long m_NrVille; // Numero unique de la ville
	long m_NrStation; // Numero unique de la station
	COleDateTime m_DateDebut; // Date debut
	CWordArray m_Grp[NB_JOURS]; // Grps en Centi�me NB_JOURS * NB_QHEURES
};

typedef	CArray<CGrp,CGrp&> CGrpArray;

#endif // !defined(AFX_GRP_H__CF0FDC89_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
