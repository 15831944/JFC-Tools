// Format.cpp: implementation of the CFormat class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Format.h"

#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFormat::CFormat()
{
	m_Format.RemoveAll();
	m_NrStation=0;
	COleDateTime Date=COleDateTime::GetCurrentTime();
	m_DateDebut.SetDate(Date.GetYear(),Date.GetMonth(),Date.GetDay());
}

CFormat::~CFormat()
{

}

CFormat::CFormat(const CFormat &Source)
{
	*this=Source;
}

CFormat & CFormat::operator=(const CFormat &Source)
{
	m_DateDebut=Source.m_DateDebut;
	m_NrStation=Source.m_NrStation;
	m_Format.Copy(Source.m_Format);
	return(*this);
}

CFormat & CFormat::operator=(const CTblFormats &Source)
{
	m_DateDebut=Source.m_DateDebut;
	m_NrStation=Source.m_NrStation;
	m_Format.RemoveAll();
	int *pPtr=(int *)Source.m_Data.GetData();
	int Count=*pPtr; pPtr++;
	for(int x=0;x<Count;x++)
	{
		CFormatD Format;
		char *pChar=(char *)pPtr;
		Format.m_Libelle=pChar;
		while(*pChar) pChar++;
		pChar++;
		float *pFloat=(float*)pChar;
		Format.m_Coef=*pFloat;
		pFloat++;
		pPtr=(int *)pFloat;
		m_Format.Add(Format);
	}
	CFormatD *pFormat=m_Format.GetData();
	if(pFormat) std::sort(pFormat,(pFormat+m_Format.GetSize()));
	return(*this);
}

bool CFormat::operator<(const CFormat &Source)
{
	if(m_NrStation<Source.m_NrStation) return(TRUE);
	if(m_DateDebut<Source.m_DateDebut) return(TRUE);
	else return(FALSE);
}
