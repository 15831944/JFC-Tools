// InfoStaVil.h: interface for the CInfoStaVil class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INFOSTAVIL_H__44CFC643_634B_4AA1_965E_0ABA68B0813A__INCLUDED_)
#define AFX_INFOSTAVIL_H__44CFC643_634B_4AA1_965E_0ABA68B0813A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>		// MFC template library
#include "TblInfoStaVil.h"

class CInfoStaVil  
{
public:
	CInfoStaVil();
	virtual ~CInfoStaVil();

	long	m_NrStation;
	long	m_NrVille;
	CString	m_AdrMail;
	CString	m_Fax;

	CInfoStaVil & operator=(const CInfoStaVil &Source);// Copy operator
	CInfoStaVil & operator=(const CTblInfoStaVil &Source);// Copy operator

};

typedef	CArray<CInfoStaVil,CInfoStaVil&> CInfoStaVilArray;

#endif // !defined(AFX_INFOSTAVIL_H__44CFC643_634B_4AA1_965E_0ABA68B0813A__INCLUDED_)
