// TblStations.cpp : implementation file
//

#include "stdafx.h"
#include "TblStations.h"
#include "Station.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTblStations

IMPLEMENT_DYNAMIC(CTblStations, CDaoRecordset)

CTblStations::CTblStations(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CTblStations)
	m_NrUnique = 0;
	m_Libelle = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CTblStations::GetDefaultDBName()
{
	return _T("multiloc.mdb");
}

CString CTblStations::GetDefaultSQL()
{
	return _T("[Stations]");
}

void CTblStations::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CTblStations)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Long(pFX, _T("[NrUnique]"), m_NrUnique);
	DFX_Text(pFX, _T("[Libelle]"), m_Libelle);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CTblStations diagnostics

#ifdef _DEBUG
void CTblStations::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CTblStations::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG

CTblStations & CTblStations::operator=(const CStation &Source)
{
//	m_NrUnique=Source.m_NrUnique;
	m_Libelle=Source.m_Libelle;
	return(*this);
}
