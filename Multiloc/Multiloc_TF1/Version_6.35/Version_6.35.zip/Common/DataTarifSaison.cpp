// DataTarifSaison.cpp: implementation of the CDataTarifSaison class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DataTarifSaison.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataTarifSaison::CDataTarifSaison()
{
	// Init Datas
	m_CoeffSaison = 0.0;
	m_DateFin.GetCurrentTime(); 
}

CDataTarifSaison::~CDataTarifSaison()
{

}

////////////////////////////////////////////////////////////////////////////////////////////
//   Fonction constructeur copy
CDataTarifSaison::CDataTarifSaison(const CDataTarifSaison &Source)
{
	*this=Source;
}

////////////////////////////////////////////////////////////////////////////////////////////
//   Fonction d'affectation
CDataTarifSaison & CDataTarifSaison::operator=(const CDataTarifSaison &Source)
{
	m_CoeffSaison   = Source.m_CoeffSaison; 
	m_DateFin		= Source.m_DateFin; 
	return(*this);
}