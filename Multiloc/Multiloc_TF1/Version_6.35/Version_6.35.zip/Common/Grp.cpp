// Grp.cpp: implementation of the CGrp class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Grp.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGrp::CGrp()
{
	m_NrStation=0;
	m_NrCible=0;
	m_NrVille=0;
	COleDateTime Date=COleDateTime::GetCurrentTime();
	m_DateDebut.SetDate(Date.GetYear(),Date.GetMonth(),Date.GetDay());
	for(int x=0;x<NB_JOURS;x++)
	{
		m_Grp[x].SetSize(NB_DEMIHEURE);
		for(int y=0;y<NB_DEMIHEURE;y++)
		{
			m_Grp[x][y]=0;
		}
	}
}

CGrp::~CGrp()
{

}

CGrp::CGrp(const CGrp &Source)
{
	*this=Source;
}

CGrp & CGrp::operator=(const CGrp &Source)
{
	m_DateDebut=Source.m_DateDebut;
	m_NrCible=Source.m_NrCible;
	m_NrVille=Source.m_NrVille;
	m_NrStation=Source.m_NrStation;
	for(int x=0;x<NB_JOURS;x++)
	{
		m_Grp[x].Copy(Source.m_Grp[x]);
	}
	return(*this);
}

CGrp & CGrp::operator=(const CTblGrps &Source)
{
	m_DateDebut=Source.m_DateDebut;
	m_NrCible=Source.m_NrCible;
	m_NrVille=Source.m_NrVille;
	m_NrStation=Source.m_NrStation;

	WORD *pWord=(WORD *)Source.m_Binary.GetData();
	for(int x=0;x<NB_JOURS;x++)
	{
		for(int y=0;y<NB_DEMIHEURE;y++)
		{
			m_Grp[x][y]=*pWord;
			pWord++;
		}
	}
	return(*this);
}

bool CGrp::operator<(const CGrp &Source)
{
	if(m_NrStation<Source.m_NrStation) return(TRUE);
	if(m_NrVille<Source.m_NrVille) return(TRUE);
	if(m_NrCible<Source.m_NrCible) return(TRUE);
	if(m_DateDebut<Source.m_DateDebut) return(TRUE);
	else return(FALSE);
}
