#if !defined(AFX_TBLTARIFSAISON_H__76339AF4_59DD_4794_A014_979455DCA2F5__INCLUDED_)
#define AFX_TBLTARIFSAISON_H__76339AF4_59DD_4794_A014_979455DCA2F5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TblTarifSaison.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTblTarifSaison DAO recordset

class CTarifSaison;

class CTblTarifSaison : public CDaoRecordset
{
public:
	CTblTarifSaison(CDaoDatabase* pDatabase = NULL);
	CTblTarifSaison & operator=(const CTarifSaison &Source);	// Copy operator
	DECLARE_DYNAMIC(CTblTarifSaison)

// Field/Param Data
	//{{AFX_FIELD(CTblTarifSaison, CDaoRecordset)
	long	m_NrVille;
	long	m_NrStation;
	COleDateTime	m_DateDebut;
	COleDateTime	m_DateFin;
	short	m_CoeffSaison;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTblTarifSaison)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TBLTARIFSAISON_H__76339AF4_59DD_4794_A014_979455DCA2F5__INCLUDED_)
