#if !defined(AFX_TBLCIBLES_H__CF0FDC84_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
#define AFX_TBLCIBLES_H__CF0FDC84_7E12_11D2_9B0D_004005327F6C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TblCibles.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTblCibles DAO recordset
class CCible;

class CTblCibles : public CDaoRecordset
{
public:
	CTblCibles(CDaoDatabase* pDatabase = NULL);
	CTblCibles & operator=(const CCible &Source);// Copy operator
	DECLARE_DYNAMIC(CTblCibles)

// Field/Param Data
	//{{AFX_FIELD(CTblCibles, CDaoRecordset)
	long	m_NrUnique;
	CString	m_Libelle;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTblCibles)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TBLCIBLES_H__CF0FDC84_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
