// Cible.h: interface for the CCible class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CIBLE_H__CF0FDC8B_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
#define AFX_CIBLE_H__CF0FDC8B_7E12_11D2_9B0D_004005327F6C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>		// MFC template library
#include "TblCibles.h"

class CCible  
{
public:
	CCible();
	virtual ~CCible();

	CCible(const CCible &Source); // Copy constructor
	CCible & operator=(const CCible &Source);// Copy operator
	CCible & operator=(const CTblCibles &Source);// Copy operator
	bool operator<(const CCible &Source);// Operator <

	long m_NrUnique; // Numero de la Cible
	CString m_Libelle;// Libelle de la Cible
};

typedef	CArray<CCible,CCible&> CCibleArray;

#endif // !defined(AFX_CIBLE_H__CF0FDC8B_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
