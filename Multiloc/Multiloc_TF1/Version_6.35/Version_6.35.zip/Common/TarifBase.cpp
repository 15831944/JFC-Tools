// TarifBase.cpp: implementation of the CTarifBase class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TarifBase.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTarifBase::CTarifBase()
{

}

CTarifBase::~CTarifBase()
{

}

CTarifBase::CTarifBase(const CTarifBase &Source)
{
	*this=Source;
}

CTarifBase & CTarifBase::operator=(const CTarifBase &Source)
{
	// Date d�but et fin 
	m_DateDebut		= Source.m_DateDebut;
	m_DateFin		= Source.m_DateFin;

	// Ville et station
	m_NrVille		= Source.m_NrVille;
	m_NrStation		= Source.m_NrStation;

	// Tarif de base
	m_TarifBase	= Source.m_TarifBase; 

	// Les frais d'antenne
	m_FraisAntenne	= Source.m_FraisAntenne;

	return(*this);
}

CTarifBase & CTarifBase::operator=(const CTblTarifBase &Source)
{
	// Date d�but et fin p�riode
	m_DateDebut		= Source.m_DateDebut;
	m_DateFin		= Source.m_DateFin;

	// No Ville et station
	m_NrVille		= Source.m_NrVille;
	m_NrStation     = Source.m_NrStation;

	// Tarif base
	m_TarifBase	= Source.m_TarifBase; 

	// Frais d'antenne
	m_FraisAntenne=Source.m_FraisAntenne;
	return(*this);
}

bool CTarifBase::operator<(const CTarifBase &Source)
{
    if(m_NrStation<Source.m_NrStation) return(TRUE);
    if(m_NrVille<Source.m_NrVille) return(TRUE);
    if(m_DateDebut<Source.m_DateDebut) return(TRUE);
    
    return(FALSE);
}
