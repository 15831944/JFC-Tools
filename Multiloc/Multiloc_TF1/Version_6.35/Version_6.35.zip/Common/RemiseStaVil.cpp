// RemiseStaVil.cpp: implementation of the CRemiseStaVil class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "RemiseStaVil.h"

#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRemiseStaVil::CRemiseStaVil()
{
	m_DateDebut=COleDateTime::GetCurrentTime();
	m_Palier.RemoveAll();
}

CRemiseStaVil::~CRemiseStaVil()
{

}

CRemiseStaVil::CRemiseStaVil(const CRemiseStaVil &Source)
{
	*this=Source;
}

CRemiseStaVil & CRemiseStaVil::operator=(const CRemiseStaVil &Source)
{
	m_DateDebut=Source.m_DateDebut;
	m_Palier.Copy(Source.m_Palier);
	return(*this);
}

CRemiseStaVil & CRemiseStaVil::operator=(const CTblRemiseStaVils &Source)
{
	m_DateDebut=Source.m_DateDebut;
	m_Palier.RemoveAll();
	int *pPtr=(int *)Source.m_Data.GetData();
	int Count=*pPtr; pPtr++;

	float *pFloat=(float*)pPtr;
	for(int x=0;x<Count;x++)
	{
		CPalier Palier;
		Palier.m_Palier=*pFloat;
		pFloat++;
		Palier.m_Coef=*pFloat;
		pFloat++;
		m_Palier.Add(Palier);
	}

	CPalier *pPalier=m_Palier.GetData();
	if(pPalier) std::sort(pPalier,(pPalier+m_Palier.GetSize()));
	return(*this);
}

bool CRemiseStaVil::operator<(const CRemiseStaVil &Source)
{
	if(m_DateDebut<Source.m_DateDebut) return(TRUE);
	else return(FALSE);
}

