// DataTarifBase.cpp: implementation of the CDataTarifBase class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DataTarifBase.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataTarifBase::CDataTarifBase()
{
	// Init Datas
	m_TarifBase = 0.0;
	m_FraisAntenne = 0.0;
	m_DateFin.GetCurrentTime(); 
}

CDataTarifBase::~CDataTarifBase()
{

}

////////////////////////////////////////////////////////////////////////////////////////////
//   Fonction constructeur copy
CDataTarifBase::CDataTarifBase(const CDataTarifBase &Source)
{
	*this=Source;
}

////////////////////////////////////////////////////////////////////////////////////////////
//   Fonction d'affectation
CDataTarifBase & CDataTarifBase::operator=(const CDataTarifBase &Source)
{
	m_TarifBase		= Source.m_TarifBase;  
	m_FraisAntenne	= Source.m_FraisAntenne;  
	m_DateFin		= Source.m_DateFin; 
	return(*this);
}