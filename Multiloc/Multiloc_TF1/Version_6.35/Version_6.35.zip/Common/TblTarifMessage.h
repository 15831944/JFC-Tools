#if !defined(AFX_TBLTARIFMESSAGE_H__1DD175D2_BE7D_45AA_9801_9A5A62B7548F__INCLUDED_)
#define AFX_TBLTARIFMESSAGE_H__1DD175D2_BE7D_45AA_9801_9A5A62B7548F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TblTarifMessage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTblTarifMessage DAO recordset

class CTarifMessage;

class CTblTarifMessage : public CDaoRecordset
{
public:
	CTblTarifMessage(CDaoDatabase* pDatabase = NULL);
	CTblTarifMessage & operator=(const CTarifMessage &Source);	// Copy operator
	DECLARE_DYNAMIC(CTblTarifMessage)

// Field/Param Data
	//{{AFX_FIELD(CTblTarifMessage, CDaoRecordset)
	long	m_NrStation;
	long	m_NrVille;
	short	m_NrJour;
	short	m_NrTrh;
	COleDateTime	m_DateDebut;
	COleDateTime	m_DateFin;
	short	m_CoeffTranche;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTblTarifMessage)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TBLTARIFMESSAGE_H__1DD175D2_BE7D_45AA_9801_9A5A62B7548F__INCLUDED_)
