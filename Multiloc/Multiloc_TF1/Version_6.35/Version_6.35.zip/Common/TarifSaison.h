// TarifSaison.h: interface for the CTarifSaison class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TARIFSAISON_H__A4799F3E_2580_4CCA_A727_DB727744C4F9__INCLUDED_)
#define AFX_TARIFSAISON_H__A4799F3E_2580_4CCA_A727_DB727744C4F9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>		// MFC template library
#include "TblTarifSaison.h"

class CTarifSaison  
{
public:
	CTarifSaison();
	virtual ~CTarifSaison();

	CTarifSaison(const CTarifSaison &Source);					// Copy constructor
	CTarifSaison & operator=(const CTarifSaison &Source);		// Copy operator
	CTarifSaison & operator=(const CTblTarifSaison &Source);	// Copy operator
	bool operator<(const CTarifSaison &Source);				// Operator <
	
	// N� Ville
	long	m_NrVille;

	// N� Station
	long	m_NrStation;

	// Intervalle validit�
	COleDateTime	m_DateDebut;
	COleDateTime	m_DateFin;

	// Coeffcient saisonnier (x 100)
	short	m_CoeffSaison;
};

typedef CArray <CTarifSaison,CTarifSaison&> CTarifSaisonArray; 

#endif // !defined(AFX_TARIFSAISON_H__A4799F3E_2580_4CCA_A727_DB727744C4F9__INCLUDED_)
