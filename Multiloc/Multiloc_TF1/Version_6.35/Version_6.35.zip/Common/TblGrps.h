#if !defined(AFX_TBLGRPS_H__CF0FDC85_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
#define AFX_TBLGRPS_H__CF0FDC85_7E12_11D2_9B0D_004005327F6C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TblGrps.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTblGrps DAO recordset
//#include "Grp.h"

class CGrp;

class CTblGrps : public CDaoRecordset
{
public:
	CTblGrps(CDaoDatabase* pDatabase = NULL);
	CTblGrps & operator=(const CGrp &Source);
	DECLARE_DYNAMIC(CTblGrps)

// Field/Param Data
	//{{AFX_FIELD(CTblGrps, CDaoRecordset)
	long	m_NrCible;
	long	m_NrVille;
	long	m_NrStation;
	COleDateTime	m_DateDebut;
	CByteArray	m_Binary;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTblGrps)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TBLGRPS_H__CF0FDC85_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
