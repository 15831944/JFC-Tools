// PrimeRegion.h: interface for the CPrimeRegion class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PRIMEREGION_H__D1539604_C4AD_11D5_8A63_0010B5865AAB__INCLUDED_)
#define AFX_PRIMEREGION_H__D1539604_C4AD_11D5_8A63_0010B5865AAB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>		// MFC template library
#include "TblPrimesRegion.h"
#include "Palier.h"	// Added by ClassView

class CPrimeRegion  
{
public:
	CPrimeRegion();
	virtual ~CPrimeRegion();

	CPrimeRegion(const CPrimeRegion &Source); // Copy constructor
	CPrimeRegion & operator=(const CPrimeRegion &Source);// Copy operator
	CPrimeRegion & operator=(const CTblPrimesRegion &Source);// Copy operator
	bool operator<(const CPrimeRegion &Source);// Operator <

	COleDateTime m_DateDebut; // Date debut
	CPalierArray m_Palier; // Liste de Paliers
};

typedef	CArray<CPrimeRegion,CPrimeRegion&> CPrimeRegionArray;

#endif // !defined(AFX_PRIMEREGION_H__D1539604_C4AD_11D5_8A63_0010B5865AAB__INCLUDED_)
