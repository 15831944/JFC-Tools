// TarifMessage.h: interface for the CTarifMessage class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TARIFMESSAGE_H__431F7402_908D_4663_BC09_D2C2B8BC104C__INCLUDED_)
#define AFX_TARIFMESSAGE_H__431F7402_908D_4663_BC09_D2C2B8BC104C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>		// MFC template library
#include "TblTarifMessage.h"
#include "TarifMessage.h"

class CTarifMessage  
{
public:
	CTarifMessage();
	virtual ~CTarifMessage();

	CTarifMessage(const CTarifMessage &Source);					// Copy constructor
	CTarifMessage & operator=(const CTarifMessage &Source);		// Copy operator
	CTarifMessage & operator=(const CTblTarifMessage &Source);	// Copy operator
	bool operator<(const CTarifMessage &Source);				// Operator <

	// N� station
	long m_NrStation;				// Numero unique de la station

	// N� ville
	long m_NrVille;					// Numero unique de la ville

	// Intervalle date validit�
	COleDateTime m_DateDebut;		// Date debut
	COleDateTime m_DateFin;			// Date fin

	// N� du jour (1 � 7 1=Lundi,.....) 
	short	m_NrJour;

	// N� tranche horaire (1 � 48)
	short	m_NrTrh;

	// Coefficient tranche (x 100)
	short	m_CoeffTranche;

};

typedef CArray<CTarifMessage,CTarifMessage&> CTarifMessageArray;

#endif // !defined(AFX_TARIFMESSAGE_H__431F7402_908D_4663_BC09_D2C2B8BC104C__INCLUDED_)
