// Prime.h: interface for the CPrime class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PRIME_H__2D4C09A5_8907_11D2_AAF8_0000E86750A8__INCLUDED_)
#define AFX_PRIME_H__2D4C09A5_8907_11D2_AAF8_0000E86750A8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>		// MFC template library
#include "TblPrimes.h"
#include "Palier.h"	// Added by ClassView
class CPrime  
{
public:
	CPrime();
	virtual ~CPrime();

	CPrime(const CPrime &Source);					// Copy constructor
	CPrime & operator=(const CPrime &Source);		// Copy operator
	CPrime & operator=(const CTblPrimes &Source);	// Copy operator
	bool operator<(const CPrime &Source);			// Operator <

	COleDateTime m_DateDebut;						// Date debut
	CPalierArray m_Palier;							// Liste de Paliers
};

typedef	CArray<CPrime,CPrime&> CPrimeArray;

#endif // !defined(AFX_PRIME_H__2D4C09A5_8907_11D2_AAF8_0000E86750A8__INCLUDED_)
