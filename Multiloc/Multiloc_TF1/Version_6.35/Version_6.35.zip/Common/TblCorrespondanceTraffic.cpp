// TblCorrespondanceTraffic.cpp : implementation file
//

#include "stdafx.h"
#include "TblCorrespondanceTraffic.h"
#include "CorrespondanceTraffic.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTblCorrespondanceTraffic

IMPLEMENT_DYNAMIC(CTblCorrespondanceTraffic, CDaoRecordset)

CTblCorrespondanceTraffic::CTblCorrespondanceTraffic(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CTblCorrespondanceTraffic)
	m_NrStation			= 0;
	m_NrVille			= 0;
	m_TrafficCode		= _T("");
	m_TrafficLibelle	= _T("");
	m_nFields			= 4;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CTblCorrespondanceTraffic::GetDefaultDBName()
{
	return _T("C:\\Projects\\Multiloc\\Multiloc.mdb");
}

CString CTblCorrespondanceTraffic::GetDefaultSQL()
{
	return _T("[CorrespondanceTraffic]");
}

void CTblCorrespondanceTraffic::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CTblCorrespondanceTraffic)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Long(pFX, _T("[NrStation]"), m_NrStation);
	DFX_Long(pFX, _T("[NrVille]"), m_NrVille);
	DFX_Text(pFX, _T("[TRAFFIC code]"), m_TrafficCode);
	DFX_Text(pFX, _T("[TRAFFIC libelle]"), m_TrafficLibelle);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CTblCorrespondanceTraffic diagnostics

#ifdef _DEBUG
void CTblCorrespondanceTraffic::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CTblCorrespondanceTraffic::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG

CTblCorrespondanceTraffic & CTblCorrespondanceTraffic::operator=(const CCorrespondanceTraffic &Source)
{
	// Nr station
	m_NrStation			= Source.m_NrStation;

	// Nr ville
	m_NrVille			= Source.m_NrVille;

	// Traffic Code
	m_TrafficCode		= Source.m_TrafficCode;

	// Traffic Libelle
	m_TrafficLibelle	= Source.m_TrafficLibelle;

	return(*this);
}

