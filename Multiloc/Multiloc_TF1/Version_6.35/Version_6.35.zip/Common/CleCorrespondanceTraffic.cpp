// CleCorrespondanceTraffic.cpp: implementation of the CCleCorrespondanceTraffic class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CleCorrespondanceTraffic.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCleCorrespondanceTraffic::CCleCorrespondanceTraffic()
{
	// Init Cle
	m_NrStation = 0;
	m_NrVille	= 0;
}

CCleCorrespondanceTraffic::~CCleCorrespondanceTraffic()
{

}

////////////////////////////////////////////////////////////////////////////////////////////
//   Fonction constructeur copy
CCleCorrespondanceTraffic::CCleCorrespondanceTraffic(const CCleCorrespondanceTraffic &Source)
{
	*this=Source;
}

////////////////////////////////////////////////////////////////////////////////////////////
//   Fonction d'affectation
CCleCorrespondanceTraffic & CCleCorrespondanceTraffic::operator=(const CCleCorrespondanceTraffic &Source)
{
	m_NrStation	= Source.m_NrStation;
	m_NrVille   = Source.m_NrVille;

	return(*this);
}

////////////////////////////////////////////////////////////////////////////////////////////
//   Fonction de comparaison <
bool CCleCorrespondanceTraffic::operator < (const CCleCorrespondanceTraffic &Source)const
{
	if (m_NrStation < Source.m_NrStation)	return (true);
	if (m_NrStation > Source.m_NrStation)	return (false);

	if (m_NrVille < Source.m_NrVille)	return (true);
	return (false);
}

////////////////////////////////////////////////////////////////////////////////////////////
//   Fonction de comparaison >
bool CCleCorrespondanceTraffic::operator > (const CCleCorrespondanceTraffic &Source)const
{
	if (m_NrStation > Source.m_NrStation)	return (true);
	if (m_NrStation < Source.m_NrStation)	return (false);
	
	if (m_NrVille   > Source.m_NrVille)		return (true);
	
	return (false);
}

