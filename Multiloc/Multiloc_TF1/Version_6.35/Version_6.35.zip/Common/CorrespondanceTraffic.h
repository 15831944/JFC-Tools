// CorrespondanceTraffic.h: interface for the CCorrespondanceTraffic class.
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_CORRESPONDANCETRAFFIC_H__431F7402_908D_4663_BC09_D2C2B8BC104C__INCLUDED_)
#define AFX_CORRESPONDANCETRAFFIC_H__431F7402_908D_4663_BC09_D2C2B8BC104C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>		// MFC template library
#include "TblCorrespondanceTraffic.h"
#include "CorrespondanceTraffic.h"

class CCorrespondanceTraffic  
{
public:
	CCorrespondanceTraffic();
	virtual ~CCorrespondanceTraffic();

	CCorrespondanceTraffic(const CCorrespondanceTraffic &Source);					// Copy constructor
	CCorrespondanceTraffic & operator=(const CCorrespondanceTraffic &Source);		// Copy operator
	CCorrespondanceTraffic & operator=(const CTblCorrespondanceTraffic &Source);	// Copy operator
	bool operator<(const CCorrespondanceTraffic &Source);							// Operator <

	// N� station
	long m_NrStation;				// Numero unique de la station

	// N� ville
	long m_NrVille;					// Numero unique de la ville

	// Traffic Code
	CString m_TrafficCode;			// Code traffic associ�

	// Traffic Libell�
	CString m_TrafficLibelle;		// Libell� du traffic associ�	

};

typedef CArray<CCorrespondanceTraffic,CCorrespondanceTraffic&> CCorrespondanceTrafficArray;

#endif // !defined(AFX_CORESPONDANCETRAFFIC_H__431F7402_908D_4663_BC09_D2C2B8BC104C__INCLUDED_)