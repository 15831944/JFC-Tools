// VolumeRegion.h: interface for the CVolumeRegion class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VOLUMEREGION_H__D1539603_C4AD_11D5_8A63_0010B5865AAB__INCLUDED_)
#define AFX_VOLUMEREGION_H__D1539603_C4AD_11D5_8A63_0010B5865AAB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>		// MFC template library
#include "TblVolumesRegion.h"
#include "Palier.h"	// Added by ClassView

class CVolumeRegion  
{
public:
	CVolumeRegion();
	virtual ~CVolumeRegion();

	CVolumeRegion(const CVolumeRegion &Source); // Copy constructor
	CVolumeRegion & operator=(const CVolumeRegion &Source);// Copy operator
	CVolumeRegion & operator=(const CTblVolumesRegion &Source);// Copy operator
	bool operator<(const CVolumeRegion &Source);// Operator <

	COleDateTime m_DateDebut; // Date debut
	CPalierArray m_Palier; // Liste de Paliers
};

typedef	CArray<CVolumeRegion,CVolumeRegion&> CVolumeRegionArray;

#endif // !defined(AFX_VOLUMEREGION_H__D1539603_C4AD_11D5_8A63_0010B5865AAB__INCLUDED_)
