// TblTarifMessage.cpp : implementation file
//

#include "stdafx.h"
#include "TblTarifMessage.h"
#include "TarifMessage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTblTarifMessage

IMPLEMENT_DYNAMIC(CTblTarifMessage, CDaoRecordset)

CTblTarifMessage::CTblTarifMessage(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CTblTarifMessage)
	m_NrStation		= 0;
	m_NrVille		= 0;
	m_NrJour		= 0;
	m_NrTrh			= 0;
	m_DateDebut		= (DATE)0;
	m_DateFin		= (DATE)0;
	m_CoeffTranche	= 0;
	m_nFields		= 7;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CTblTarifMessage::GetDefaultDBName()
{
	return _T("C:\\Projects\\Multiloc\\Multiloc.mdb");
}

CString CTblTarifMessage::GetDefaultSQL()
{
	return _T("[TarifMessage]");
}

void CTblTarifMessage::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CTblTarifMessage)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Long(pFX, _T("[NrStation]"), m_NrStation);
	DFX_Long(pFX, _T("[NrVille]"), m_NrVille);
	DFX_Short(pFX, _T("[NrJour]"), m_NrJour);
	DFX_Short(pFX, _T("[NrTrh]"), m_NrTrh);
	DFX_DateTime(pFX, _T("[DateDebut]"), m_DateDebut);
	DFX_DateTime(pFX, _T("[DateFin]"), m_DateFin);
	DFX_Short(pFX, _T("[CoeffTranche]"), m_CoeffTranche);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CTblTarifMessage diagnostics

#ifdef _DEBUG
void CTblTarifMessage::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CTblTarifMessage::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG

CTblTarifMessage & CTblTarifMessage::operator=(const CTarifMessage &Source)
{
	// Date d�but/date fin p�riode tarif
	m_DateDebut.SetDate(Source.m_DateDebut.GetYear(),Source.m_DateDebut.GetMonth(),Source.m_DateDebut.GetDay());
	m_DateFin.SetDate(Source.m_DateFin.GetYear(),Source.m_DateFin.GetMonth(),Source.m_DateFin.GetDay());

	// Nr station
	m_NrStation		= Source.m_NrStation;

	// Nr ville
	m_NrVille		= Source.m_NrVille;

	// No Jour (1 � 7)
	m_NrJour		= Source.m_NrJour;

	// No Tranche horaire
	m_NrTrh			= Source.m_NrTrh;

	// Coeff Tranche
	m_CoeffTranche	= Source.m_CoeffTranche;

	return(*this);
}
