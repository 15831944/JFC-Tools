#if !defined(AFX_TBLREMISESTAVILS_H__2D4C09A1_8907_11D2_AAF8_0000E86750A8__INCLUDED_)
#define AFX_TBLREMISESTAVILS_H__2D4C09A1_8907_11D2_AAF8_0000E86750A8__INCLUDED_

// TblRemiseStaVils.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTblRemiseStaVils DAO recordset

class CRemiseStaVil;

class CTblRemiseStaVils : public CDaoRecordset
{
public:
	CTblRemiseStaVils(CDaoDatabase* pDatabase = NULL);
	CTblRemiseStaVils & operator=(const CRemiseStaVil &Source);
	DECLARE_DYNAMIC(CTblRemiseStaVils)

// Field/Param Data
	//{{AFX_FIELD(CTblRemiseStaVils, CDaoRecordset)
	COleDateTime	m_DateDebut;
	CByteArray	m_Data;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTblRemiseStaVils)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
#endif 