// Station.h: interface for the CStation class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STATION_H__CF0FDC87_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
#define AFX_STATION_H__CF0FDC87_7E12_11D2_9B0D_004005327F6C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>		// MFC template library
#include "TblStations.h"

class CStation  
{
public:
	CStation();
	virtual ~CStation();

	CStation(const CStation &Source); // Copy constructor
	CStation & operator=(const CStation &Source);// Copy operator
	CStation & operator=(const CTblStations &Source);// Copy operator
	bool operator<(const CStation &Source);// Operator <

	long m_NrUnique; // Numero de la Station
	CString m_Libelle;// Libelle de la Station
};

typedef	CArray<CStation,CStation&> CStationArray;

#endif // !defined(AFX_STATION_H__CF0FDC87_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
