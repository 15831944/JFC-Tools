// TblPrimes.cpp : implementation file
//

#include "stdafx.h"
#include "TblPrimes.h"
#include "Prime.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTblPrimes

IMPLEMENT_DYNAMIC(CTblPrimes, CDaoRecordset)

CTblPrimes::CTblPrimes(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CTblPrimes)
	m_DateDebut = (DATE)0;
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CTblPrimes::GetDefaultDBName()
{
	return _T("C:\\multiloc\\multiloc.mdb");
}

CString CTblPrimes::GetDefaultSQL()
{
	return _T("[RemiseSpot]");
}

void CTblPrimes::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CTblPrimes)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_DateTime(pFX, _T("[DateDebut]"), m_DateDebut);
	DFX_Binary(pFX, _T("[Data]"), m_Data,100,AFX_DAO_ENABLE_FIELD_CACHE);
	//}}AFX_FIELD_MAP
//	DFX_LongBinary(pFX, _T("[Data]"), m_Data);
}

/////////////////////////////////////////////////////////////////////////////
// CTblPrimes diagnostics

#ifdef _DEBUG
void CTblPrimes::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CTblPrimes::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG

CTblPrimes & CTblPrimes::operator=(const CPrime &Source)
{
	m_DateDebut.SetDate(Source.m_DateDebut.GetYear(),Source.m_DateDebut.GetMonth(),Source.m_DateDebut.GetDay());
	m_Data.RemoveAll();
	int Size=Source.m_Palier.GetSize();
	BYTE *pByte=(BYTE *)&Size;
	for(int x=0;x<sizeof(int);x++) m_Data.Add(pByte[x]);
	for(int x=0;x<Source.m_Palier.GetSize();x++)
	{
		int y=0;
		CPalier Palier=Source.m_Palier[x];
		for(y=0,pByte=(BYTE *)&Palier.m_Palier;y<sizeof(Palier.m_Palier);y++) m_Data.Add(pByte[y]);
		for(y=0,pByte=(BYTE *)&Palier.m_Coef;y<sizeof(Palier.m_Coef);y++) m_Data.Add(pByte[y]);
	}
	return(*this);
}
