// TblCibles.cpp : implementation file
//

#include "stdafx.h"
#include "TblCibles.h"
#include "Cible.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTblCibles

IMPLEMENT_DYNAMIC(CTblCibles, CDaoRecordset)

CTblCibles::CTblCibles(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CTblCibles)
	m_NrUnique = 0;
	m_Libelle = _T("");
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CTblCibles::GetDefaultDBName()
{
	return _T("multiloc.mdb");
}

CString CTblCibles::GetDefaultSQL()
{
	return _T("[Cibles]");
}

void CTblCibles::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CTblCibles)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Long(pFX, _T("[NrUnique]"), m_NrUnique);
	DFX_Text(pFX, _T("[Libelle]"), m_Libelle);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CTblCibles diagnostics

#ifdef _DEBUG
void CTblCibles::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CTblCibles::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG

CTblCibles & CTblCibles::operator=(const CCible &Source)
{
//	m_NrUnique=Source.m_NrUnique;
	m_Libelle=Source.m_Libelle;
	return(*this);
}
