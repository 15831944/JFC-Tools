// TblTarifSaison.cpp : implementation file
//

#include "stdafx.h"
#include "TblTarifSaison.h"
#include "TarifSaison.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTblTarifSaison

IMPLEMENT_DYNAMIC(CTblTarifSaison, CDaoRecordset)

CTblTarifSaison::CTblTarifSaison(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CTblTarifSaison)
	m_NrVille = 0;
	m_NrStation = 0;
	m_DateDebut = (DATE)0;
	m_DateFin = (DATE)0;
	m_CoeffSaison = 0;
	m_nFields = 5;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CTblTarifSaison::GetDefaultDBName()
{
	return _T("C:\\Projects\\Multiloc\\Multiloc.mdb");
}

CString CTblTarifSaison::GetDefaultSQL()
{
	return _T("[TarifSaison]");
}

void CTblTarifSaison::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CTblTarifSaison)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Long(pFX, _T("[NrVille]"), m_NrVille);
	DFX_Long(pFX, _T("[NrStation]"), m_NrStation);
	DFX_DateTime(pFX, _T("[DateDebut]"), m_DateDebut);
	DFX_DateTime(pFX, _T("[DateFin]"), m_DateFin);
	DFX_Short(pFX, _T("[CoeffSaison]"), m_CoeffSaison);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CTblTarifSaison diagnostics

#ifdef _DEBUG
void CTblTarifSaison::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CTblTarifSaison::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG

CTblTarifSaison & CTblTarifSaison::operator=(const CTarifSaison &Source)
{
	// Date d�but/date fin p�riode tarif
	m_DateDebut.SetDate(Source.m_DateDebut.GetYear(),Source.m_DateDebut.GetMonth(),Source.m_DateDebut.GetDay());
	m_DateFin.SetDate(Source.m_DateFin.GetYear(),Source.m_DateFin.GetMonth(),Source.m_DateFin.GetDay());

	// Nr station
	m_NrStation		= Source.m_NrStation;

	// Nr ville
	m_NrVille		= Source.m_NrVille;

	// Coeff Tranche
	m_CoeffSaison	= Source.m_CoeffSaison;

	return(*this);
}
