// Ville.cpp: implementation of the CVille class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Ville.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CVille::CVille()
{
	m_Libelle=_T("");
	m_NrUnique=0;
	m_NrIndex=0;
	m_Commune=0;
	m_NbHabitantsInsee=0;
}

CVille::~CVille()
{

}

CVille::CVille(const CVille &Source)
{
	*this=Source;
}

CVille & CVille::operator=(const CVille &Source)
{
	m_NrUnique=Source.m_NrUnique;
	m_Libelle=Source.m_Libelle;
	m_NrIndex=Source.m_NrIndex;
	m_Commune=Source.m_Commune;
	m_NbHabitantsInsee=Source.m_NbHabitantsInsee;
	
	return(*this);
}

CVille & CVille::operator=(const CTblVilles &Source)
{
	m_NrUnique=Source.m_NrUnique;
	m_Libelle=Source.m_Libelle;
	m_Commune=Source.m_Commune;
	m_NbHabitantsInsee=Source.m_NbHabitantsInsee;
	m_NrIndex=0;
	return(*this);
}

bool CVille::operator<(const CVille &Source)
{
	if(m_Libelle<Source.m_Libelle) return(TRUE);
	else return(FALSE);
}
