#if !defined(AFX_TBLCORRESPONDANCETRAFFIC_H__1DD175D2_BE7D_45AA_9801_9A5A62B7548F__INCLUDED_)
#define AFX_TBLCORRESPONDANCETRAFFIC_H__1DD175D2_BE7D_45AA_9801_9A5A62B7548F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTblCorrespondanceTraffic DAO recordset

class CCorrespondanceTraffic;

class CTblCorrespondanceTraffic : public CDaoRecordset
{
public:
	CTblCorrespondanceTraffic(CDaoDatabase* pDatabase = NULL);
	CTblCorrespondanceTraffic & operator=(const CCorrespondanceTraffic &Source);	// Copy operator
	DECLARE_DYNAMIC(CTblCorrespondanceTraffic)

// Field/Param Data
	//{{AFX_FIELD(CTblCorrespondanceTraffic, CDaoRecordset)
	long	m_NrStation;
	long	m_NrVille;
	CString m_TrafficCode;
	CString m_TrafficLibelle;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTblCorrespondanceTraffic)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TBLCORRESPONDANCETRAFFIC_H__1DD175D2_BE7D_45AA_9801_9A5A62B7548F__INCLUDED_)