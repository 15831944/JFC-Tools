#if !defined(AFX_TBLTARIFS_H__CF0FDC83_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
#define AFX_TBLTARIFS_H__CF0FDC83_7E12_11D2_9B0D_004005327F6C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TblTarifs.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTblTarifs DAO recordset
class CTarif;

class CTblTarifs : public CDaoRecordset
{
public:
	CTblTarifs(CDaoDatabase* pDatabase = NULL);
	CTblTarifs & operator=(const CTarif &Source);// Copy operator

	DECLARE_DYNAMIC(CTblTarifs)

// Field/Param Data
	//{{AFX_FIELD(CTblTarifs, CDaoRecordset)
	CByteArray	m_Binary;
	short m_FraisAntenne;
	CLongBinary	m_Binary2;
	COleDateTime	m_DateDebut;
	COleDateTime	m_DateFin;
	long			m_TarifDeBase;
//	short	m_FraisMiseAntenne;
	long	m_NrStation;
	long	m_NrVille;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTblTarifs)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TBLTARIFS_H__CF0FDC83_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
