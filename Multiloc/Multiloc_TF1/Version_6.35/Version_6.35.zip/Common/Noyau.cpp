// Noyau.cpp: implementation of the CNoyau class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Noyau.h"

#include "TblVilles.h"
#include "TblStations.h"
#include "TblCibles.h"
#include "TblGrps.h"
#include "TblTarifs.h"

#include "TblTarifBase.h"
#include "TblTarifMessage.h"
#include "TblTarifSaison.h"

#include <algorithm>
#include "math.h"


#ifndef COMPILING_MULTIADM
	#include "..\multiloc\multiloc.h"
#endif


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif



//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CNoyau::CNoyau(CString Database)
{
	// Path Data --  theApp.m_DataBasePath;
	m_Path				= Database;
	m_fInit				= false;

	// Init des flags pour chargement tarifs
	m_fTarifBase_Init	= false;
	m_fTarifMessage_Init= false;
	m_fTarifSaison_Init	= false;

	// Init de toutes les instances
	m_fGrp_Init			= false;
	m_Cible				= -1;
	m_pTblTarif			= NULL;
	m_pTblGrp			= NULL;
	m_pTblFormat		= NULL;
	m_pMapTblFormat		= NULL;
	m_pTblVille			= NULL;
	m_fInit				= LoadTables();
	m_fSpots_Init		= false;
	m_fFinanciere_Init	= false;
	m_fFormat_Init		= false;
}

CNoyau::~CNoyau()
{
	// Destruction du tableau des tarifs
	if(m_pTblTarif)
	{
		for(int x=0;x<m_TblStation.GetSize();x++)
		{
			if(m_pTblTarif && m_pTblTarif[x]) delete [] m_pTblTarif[x];
		}
		delete [] m_pTblTarif;
	}

	// Destruction tableau des grps
	if(m_pTblGrp)
	{
		for(int x=0;x<m_TblStation.GetSize();x++)
		{
			if(m_pTblGrp && m_pTblGrp[x]) delete [] m_pTblGrp[x];
		}
		delete [] m_pTblGrp;
		m_pTblGrp=NULL;
	}

	// Destruction tableau des formats
	if(m_pTblFormat) delete [] m_pTblFormat;
	if(m_pMapTblFormat) delete [] m_pMapTblFormat;

	// Destruction tableau des villes
	if(m_pTblVille) delete [] m_pTblVille;
}

bool CNoyau::ChargerTable(COleDateTime Debut, COleDateTime Fin, int ModeTarif)
{
	int BclTarif=0;

	if(!m_fInit) return(false);

	m_Debut.SetDate(Debut.GetYear(),Debut.GetMonth(),Debut.GetDay());
	m_Fin.SetDate(Fin.GetYear(),Fin.GetMonth(),Fin.GetDay());
	CDaoDatabase Db;
	try
	{
		// Ouverture de la base Multiloc.mdb
		Db.Open(m_Path,FALSE,TRUE);

		// Charge les 3 tables tarifs (de base, coeff messages, coeff p�riodes)
		m_fTarifBase_Init		= LoadTarifBase(Db); 
		m_fTarifMessage_Init	= LoadTarifMessage(Db); 
		m_fTarifSaison_Init		= LoadTarifSaison(Db); 

		// Test des maps
		int NbTarifBase    = m_MapTarifBase.GetCount();
		int NbTarifMessage = m_MapTarifMessage.GetCount();
		int NbTarifSaison  = m_MapTarifSaison.GetCount();

		// Chargement des formats
		m_fFormat_Init=LoadFormats(Db,ModeTarif);

		// Chargement les remises financi�res r�gions
		m_fFinanciere_Init=LoadRemiseFinanciere(Db);

		// Chargement les primes
		m_fSpots_Init=LoadRemiseSpots(Db);

		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("ChargerTable, %s, %s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}

	// Retourne validit� du chargement
	return (m_fTarifBase_Init && m_fTarifMessage_Init && m_fTarifSaison_Init);
}


///////////////////////////////////////////////////////////////////////////////////////////
// Renvoie le coeff format du spot
float CNoyau::DonneCoeffFormat(long NrStation, long NrVille, long NrFormat, int Jour, int InxLigne,int ModeTarif,int ContratFidelite)
{

	// InxLigne		>> en mode tranche horaire  >> Horaire   (0 � 47)
	//				>> en mode floating			>> N� format 

	// attention � l'indice ici n� dans tab
	int NumStation = NrStation-1;

	// **** En attente de gestion des "VIDES STATIONS" (probl�me si index stations non cons�cutifs pour la table des formats) 
	// Mettre en commentaire en version admin
	if (theApp.m_TypeMultiloc == "TF1")
		NumStation = 35;
	else if (theApp.m_TypeMultiloc == "NRJ") 
		NumStation = 1;
	
	// Mettre en version Admin uniquement
	// NumStation = 1;
	
	if (ModeTarif == 0)
	{
		// Format uniquement en mode tranche horaire
		COleDateTime Date = m_Debut + COleDateTimeSpan(Jour,0,0,0);
		bool Key;

		int Taille = m_pMapTblFormat->GetCount();

		if(!m_pMapTblFormat[NumStation].Lookup(m_TblFormat[NrFormat],Key)) return -1;

		// Calage sur date format � prendre
		int y=0;
		for(;y<m_pTblFormat[NumStation].GetSize();y++)
		{
			if(m_pTblFormat[NumStation][y].m_DateDebut<=Date) continue;
			break;
		}
		y--;
		if(y<0) return -1;

		// Renvoi le tableau des formats
		for(int z=0;z<m_pTblFormat[NumStation][y].m_Format.GetSize();z++)
		{
			if(m_pTblFormat[NumStation][y].m_Format[z].m_Libelle==m_TblFormat[NrFormat])
			{
				return (float)(m_pTblFormat[NumStation][y].m_Format[z].m_Coef/100.0);
			}
		}

		return 1.0f;
	}

	else
	{
		// Format uniquement en mode float
		COleDateTime Date = m_Debut + COleDateTimeSpan(Jour,0,0,0);
		bool Key;
		if(!m_pMapTblFormat[NumStation].Lookup(m_TblFormat[NrFormat],Key)) return -1;

		int y=0;
		for(;y<m_pTblFormat[NumStation].GetSize();y++)
		{
			if(m_pTblFormat[NumStation][y].m_DateDebut<=Date) continue;
			break;
		}
		y--;
		if(y<0) return -1;

		// Recherche du format de la station
		for(int z=0;z<m_pTblFormat[NumStation][y].m_Format.GetSize();z++)
		{
			CString TxtFormat = m_TblFormat[NrFormat];
			CString TxtF      = m_pTblFormat[NumStation][y].m_Format[z].m_Libelle; 
			CString VraiF     = m_TblFormat[InxLigne];

			if(m_pTblFormat[NumStation][y].m_Format[z].m_Libelle == m_TblFormat[InxLigne])
			{
				return (float)(m_pTblFormat[NumStation][y].m_Format[z].m_Coef/100.0);
			}
		}

		return 1.0f;
	}
}

///////////////////////////////////////////////////////////////////////////////////////////
// Renvoie le coeff format du spot en long
long CNoyau::DonneCoeffFormatLongx100(long NrStation, long NrVille, long NrFormat, int Jour, int InxLigne,int ModeTarif,int ContratFidelite)
{
	Jour = 6;

	// InxLigne		>> en mode tranche horaire  >> Horaire   (0 � 47)
	//				>> en mode floating			>> N� format 

	// attention � l'indice ici n� dans tab
	int NumStation = NrStation-1;

	// En attente car sinon certains formats ne seront pas d�finis  // A REVOIR !!!!!!!
	// **** En attente de gestion des "VIDES STATIONS" (probl�me si index stations non cons�cutifs pour la table des formats) 
	// A REMETTRE
	// Mettre en commentaire en version admin
	if (theApp.m_TypeMultiloc == "TF1")
		NumStation = 35;
	else if (theApp.m_TypeMultiloc == "NRJ")
		NumStation = 1;
		
	// A remettre en version admin uniquement
	// NumStation=1;

	if (ModeTarif == 0)
	{
		// Format uniquement en mode tranche horaire
		COleDateTime Date = m_Debut + COleDateTimeSpan(Jour,0,0,0);
		bool Key;

		int Taille = m_pMapTblFormat->GetCount();

		if(!m_pMapTblFormat[NumStation].Lookup(m_TblFormat[NrFormat],Key)) return -1;

		// Calage sur date format � prendre
		int y=0;
		for(;y<m_pTblFormat[NumStation].GetSize();y++)
		{
			if(m_pTblFormat[NumStation][y].m_DateDebut<=Date) continue;
			break;
		}
		y--;
		if(y<0) return -1;

		// Renvoi le tableau des formats
		for(int z=0;z<m_pTblFormat[NumStation][y].m_Format.GetSize();z++)
		{
			if(m_pTblFormat[NumStation][y].m_Format[z].m_Libelle==m_TblFormat[NrFormat])
			{
				long ValCoeff = m_pTblFormat[NumStation][y].m_Format[z].m_Coef;
				return (m_pTblFormat[NumStation][y].m_Format[z].m_Coef);
			}
		}

		return 100;
	}

	else
	{
		// Format uniquement en mode float
		COleDateTime Date = m_Debut + COleDateTimeSpan(Jour,0,0,0);
		bool Key;
		if(!m_pMapTblFormat[NumStation].Lookup(m_TblFormat[NrFormat],Key)) return -1;

		int y=0;
		for(;y<m_pTblFormat[NumStation].GetSize();y++)
		{
			if(m_pTblFormat[NumStation][y].m_DateDebut<=Date) continue;
			break;
		}
		y--;
		if(y<0) return -1;

		// Recherche du format de la station
		for(int z=0;z<m_pTblFormat[NumStation][y].m_Format.GetSize();z++)
		{
			CString TxtFormat = m_TblFormat[NrFormat];
			CString TxtF      = m_pTblFormat[NumStation][y].m_Format[z].m_Libelle; 
			CString VraiF     = m_TblFormat[InxLigne];

			if(m_pTblFormat[NumStation][y].m_Format[z].m_Libelle == m_TblFormat[InxLigne])
			{
				return (m_pTblFormat[NumStation][y].m_Format[z].m_Coef);
			}
		}

		return 100;
	}
}

#ifndef COMPILING_MULTIADM

///////////////////////////////////////////////////////////////////////////////////////////
// V�rifie que la tranche horaire sur jour es tdisponible pour ce couple station/ville
bool CNoyau::TrhDisponible(long NrStation, long NrVille, COleDateTime Date , int Horaire)
{
	/*
	// Positionnement cl� de recherche
	CCleTrhNonDispo		CleTrhNonDispo;
	CleTrhNonDispo.m_NrStation	= NrStation;	// m_Station[NrStation].m_NrUnique;
	CleTrhNonDispo.m_NrVille	= NrVille;		// m_Ville[NrVille].m_NrUnique;
	CleTrhNonDispo.m_Date		= Date;			// Jour de la semaine
	CleTrhNonDispo.m_Trh		= Horaire;		// Tranche horaire

	// Placement sur 1er �lmt trh non dispo
	m_MapTrhNonDispo.MoveTo(CleTrhNonDispo,-1);
			
	// V�rifie que la tranche horaire n'est pas interdite
	if (m_MapTrhNonDispo.IsValid())
	{	
		return false;
	}
	*/

	// Sinon pas de soucis, interdiction non d�tect�e
	return true;

}		

///////////////////////////////////////////////////////////////////////////////////////////
//   Renvoie le tarif final d'un spot
long CNoyau::DonneTarif(long NrStation, long NrVille, long NrFormat, int Jour, int Horaire,int ModeTarif,int ContratFidelite)
{
	// Date effective
	COleDateTime Date = m_Debut + COleDateTimeSpan(Jour,0,0,0);

	// Pour France Bleu - tenir compte des interdictions trh par station/ville (voir table TrhNonDispo)
	if (TrhDisponible(NrStation, NrVille, Date, Horaire))
	{
		// Coeff format
		// float CoeffFormat = DonneCoeffFormat(NrStation,NrVille,NrFormat,Jour,Horaire,ModeTarif,ContratFidelite);

		/*if (Jour == 6 && Horaire==30)
			bool stop = true;*/

		long CoeffFormat = DonneCoeffFormatLongx100(NrStation,NrVille,NrFormat,Jour,Horaire,ModeTarif,ContratFidelite);
		
		// Recherche le tarif de base
		float TarifBase = DonneTarifBase(NrStation,NrVille,Date);
		
		if (TarifBase > 0)
		{
			// Recherche le coefficient p�riode
			float CoeffPeriode = DonneCoeffPeriode(NrStation,NrVille,Date,ContratFidelite);

			if (CoeffPeriode > 0)
			{
				// Recherche le coefficient message
				float CoeffMessage = DonneCoeffMessage(NrStation,NrVille,Date,Horaire,ModeTarif);

				// Si contrat fid�lit� alors � voir mais d'office CoeffMessage = 1 (pour tarif final = tarif de base * Coeff Contrat Fid�lit�)
				//if (ContratFidelite == true) CoeffMessage = 1.0;

				if (CoeffMessage > 0)
				{
					// A REMETTRE
					// Mettre en commentaire en version admin
					if (theApp.m_TypeMultiloc == "NRJ")
					{
						// Calcul du tarif final (sans notion d'arrondi)
						return (long)(TarifBase*CoeffPeriode*CoeffMessage*CoeffFormat+0.5);
					}
					else if (theApp.m_TypeMultiloc == "TF1")
					{
						// Calcul arrondi message � 30'  (arrondi automatique � l'entier sup�rieur / par exc�s)
						long Tarif30s = (long)(ceil(TarifBase*CoeffPeriode*CoeffMessage - 0.0001));
						long TarifFinal = (long)(Tarif30s * CoeffFormat + 50) / 100;
						
						return (TarifFinal * 100.0);
					}
										
					// Remettre en version admin uniquement
					// return (long)(TarifBase*CoeffPeriode*CoeffMessage*CoeffFormat+0.5);

					
				}
				return -1;
				
			}
			return -1;
		}
	}

	// Calcul du tarif final
	return -1;
}
#endif


///////////////////////////////////////////////////////////////////////////////////////////
//   Renvoie le tarif de base du spot
 float CNoyau::DonneTarifBase(long NrStation, long NrVille,COleDateTime DateSpot)
{

	if(!m_fTarifBase_Init) return -1;

	// Positionnement cl� de recherche
	CCleTarifBaseSaison		CleTarifBase;
	CleTarifBase.m_NrStation = NrStation;   // m_Station[NrStation].m_NrUnique;
	CleTarifBase.m_NrVille   = NrVille;     // m_Ville[NrVille].m_NrUnique;
	CleTarifBase.m_DateDeb   = DateSpot;

	// Placement sur 1er �lmt tarif base pour ce couple <station,ville>
	m_MapTarifBase.MoveTo(CleTarifBase,-1);
			
	// V�rifie qu'il y a bien un tarif
	if (m_MapTarifBase.IsValid())
	{	
		CCleTarifBaseSaison		CleTarifBaseTrouve;

		// Positionne sur la date la plus proche
		CleTarifBaseTrouve = m_MapTarifBase.GetKey();

		// MODIF 12/12/2009 sinon probl�me acces si 1 seul elmt par couple station/ville (seule le 1er enrgt renvoy� -1 si non trouv�,
		// sinon on prenait l'enrgt pr�c�dent avec ville et station diff , ce qui �tait compl�tement faux)
		// Attention bien v�rifi� que l'on est toujours sur meme station, meme ville
		if (CleTarifBaseTrouve.m_NrStation == CleTarifBase.m_NrStation && CleTarifBaseTrouve.m_NrVille == CleTarifBase.m_NrVille)
		{
			// Datas tarif
			CDataTarifBase DataTarifBase;
			DataTarifBase = m_MapTarifBase.GetItem();

			return (DataTarifBase.m_TarifBase); 
		}
		else
			// pas de tarif trouv�
			return -1;
	}

	// pas de tarif trouv�
	return -1;
}

// Les coefficients pour les modes de tarification sp�cifiques
const float CoeffPeriodeContratFidelite = 1.1;

// const float CoeffMessageFloating        = 1.0;
// const float CoeffMessageFloatingPlus    = 1.1;
const float CoeffMessageFloatJour          = 1.1;

// const float CoeffMessageFloatSemaine	   = 0.95;
const float CoeffMessageFloatSemaine	   = 0.8;		// A partir de janvier 2009

///////////////////////////////////////////////////////////////////////////////////////////
//   Renvoie le coefficient p�riode du spot
float CNoyau::DonneCoeffPeriode(long NrStation, long NrVille,COleDateTime DateSpot,int ContratFidelite)
{
	// type de tarif saisonnier
	const float TarifBlanc = 1.0f;
	const float TarifRouge = 1.2f;
	const float TarifBleu  = 0.7f;

	// Si probl�me initialisation coeff p�riode, on arr�te
	if(!m_fTarifSaison_Init) return -1;

	// Si type contrat fid�lit� d'office tarif Orange
	if (ContratFidelite != 0) return CoeffPeriodeContratFidelite;

	// Positionnement cl� de recherche
	CCleTarifBaseSaison		CleTarifSaison;
	CleTarifSaison.m_NrStation = NrStation;  //m_Station[NrStation].m_NrUnique;
	CleTarifSaison.m_NrVille   = NrVille;    // m_Ville[NrVille].m_NrUnique;
	CleTarifSaison.m_DateDeb   = DateSpot;

	// Attention aux dates sp�cifiques pour les Dimanches
	int JourSemaine = DateSpot.GetDayOfWeek();
	
	// D�clarations des constantes sp�cifiques pour particularit�s tarifs
	const int Dimanche  = 1;
	const int Decembre  = 12;
	const int Juillet   = 7;

	// pour les CGV 2004 pas de diff�rence pour les dimanches
	int annee   = DateSpot.GetYear();

	if (JourSemaine == Dimanche && annee < 2004)
	{
		// N� jour, N� Mois et ann�e
		int NoJour	= DateSpot.GetDay(); 
		int Mois    = DateSpot.GetMonth();
		int annee   = DateSpot.GetYear();
		
		// Test si mois de d�cembre
		if (Mois < Decembre)
		{
			// tous les dimanche hormis en d�cembre tarif bleu
			// et hormis les cas sp�cifique en Juillet (du 1 au 26 pour 2003) >> rouge
			//                              en Juillet (du 1 au 24 pour 2004) >> rouge
			if (Mois != Juillet)
				// Tous les dimanche hormis en Juillet et D�cembre >> tarif bleu
				return TarifBleu;

			if ((Mois == Juillet && NoJour >=1 && NoJour <= 26 && annee == 2003) ||
				(Mois == Juillet && NoJour >=1 && NoJour <= 24 && annee == 2004))
			{
				if (NrVille == 12 ||		//"Biarritz" 
					NrVille == 44 ||		//"Menton"
					NrVille == 54 ||		//"Nice"
					NrVille == 176||		//"Nyons"
					NrVille == 59 ||		//"Perpignan"
					NrVille == 70)			//"St Nazaire"

					// Tarif rouge pour ces villes au mois de juillet m�me les dimanches
					return TarifRouge;
				else
					// pour tous les autres cas
					return TarifBleu;
			}
			else
				// pour tous les autres cas
				return TarifBleu;
		}

		else
		{
			// cas sp�cifique du mois de d�cembre
			if (annee == 2003)
				// ici on est en D�cembre 2003
				if (NoJour < 28)
					return TarifRouge;
				else
					return TarifBlanc;

			else if (annee == 2004)
				// ici on est en D�cembre 2004
				if (NoJour < 26)
					return TarifRouge;
				else
					return TarifBlanc;
			else
				// pour tous les autres cas les Dimanches en tarif Bleu
				return TarifBleu;

		}
	}

	else
	{
		// Ce n'est pas un Dimanche
		// Placement sur 1er �lmt tarif base pour ce couple <station,ville>
		m_MapTarifSaison.MoveTo(CleTarifSaison,-1);
				
		// V�rifie qu'il y a bien un coefficient
		if (m_MapTarifSaison.IsValid())
		{	
			// Positionne sur la date la plus proche
			CleTarifSaison = m_MapTarifSaison.GetKey();

			// Datas coeff p�riode
			CDataTarifSaison DataTarifSaison;
			DataTarifSaison = m_MapTarifSaison.GetItem();

			return (DataTarifSaison.m_CoeffSaison); 
		}
	}

	// pas de cofficient trouv�
	return -1;
}

///////////////////////////////////////////////////////////////////////////////////////////
//   Renvoie le coefficient message du spot
float CNoyau::DonneCoeffMessage(long NrStation, long NrVille, COleDateTime DateSpot, int Horaire,int ModeTarif)
{
	// si probl�me chargement coeff messages, on arr�te
	if(!m_fTarifMessage_Init) return -1;

	// si mode Floating, coeff fixe
	if (ModeTarif == 1) return CoeffMessageFloatJour;

	// si mode Floating +, coeff fixe
	// Attention maintenant coefficient selon ville et station
	if (ModeTarif == 2) 
	{
		float NewCoeffFloatingSemaine = CoeffFloationgSemaineChange(NrStation,NrVille, CoeffMessageFloatSemaine);
		//return CoeffMessageFloatSemaine;
		return NewCoeffFloatingSemaine;
	}


	// Attention en Attente A REVOIR pour NRJ Coeff Message par station  ==> positionner Ville � 0
	// A REMETTRE
	// Mettre en commentaire en version admin
	if (theApp.m_TypeMultiloc == "NRJ")
	{
		NrVille = 0; 
	}		
	else if (theApp.m_TypeMultiloc == "TF1")
	{
		// Special 1 seule matrice
		NrStation = 999;
		NrVille   = 999; 
	}
		
	// Mettre uniquement en version admin
	// NrVille=0;

	// Positionnement cl� de recherche
	CCleTarifMessage		CleTarifMessage;
	CleTarifMessage.m_NrStation = NrStation;   //m_Station[NrStation].m_NrUnique;

	CleTarifMessage.m_NrVille  = NrVille;
	
	// Date r�elle
	CleTarifMessage.m_DateDeb   = DateSpot;

	// N� jour semaine
	int Day = DateSpot.GetDayOfWeek();
	if(Day==1) Day=6;
	else Day-=2;
	CleTarifMessage.m_NrJour = Day;

	// No tranche horaire
	CleTarifMessage.m_NrTrh = Horaire;

	// Placement sur 1er �lmt tarif base pour ce couple <station,ville>
	m_MapTarifMessage.MoveTo(CleTarifMessage,-1);

	// V�rifie qu'il y a bien un coefficient message
	if (m_MapTarifMessage.IsValid())
	{	
		// Positionne sur la date la plus proche
		CleTarifMessage = m_MapTarifMessage.GetKey();

		// Datas coeff message
		CDataTarifMessage DataTarifMessage;
		DataTarifMessage = m_MapTarifMessage.GetItem();

		return (DataTarifMessage.m_CoeffMessage); 
	}

	// pas de cofficient trouv�
	return -1;
}

////////////////////////////////////////////////////////////////////////////////////////////////
// Modification Coeff Floating Semaine de base pour certaines villes ou couples stations/ville
float CNoyau::CoeffFloationgSemaineChange(long NrStation, long NrVille, float CoeffMessageFloatSemaine)
{
	/* Avant 2009
	if (VilleAouVilleMaster(NrStation,NrVille))
	{
		// Remise de 30% sur les villes class�es A ou villes Master
		return 0.7;
	}
	else if (VilleBouVilleC(NrVille))
	{
		// Remise de 20% sur les villes class�es  B ou C
		return 0.8;
	}
	else
	{
		// pour tous les autres cas , appliquer coeff floating semaine de base
		return CoeffMessageFloatSemaine;
	}
	*/

	if (VilleAouVilleMaster(NrStation,NrVille))
	{
		// Remise de 30% sur les villes class�es A ou villes Master
		return 0.7;
	}
	else
	{
		// pour tous les autres cas , appliquer coeff floating semaine de base
		return CoeffMessageFloatSemaine;
	}

}

////////////////////////////////////////////////////////////////////////////////////
// D�termine si ville est du groupe B ou C  (cod� 2 ou 3)
bool CNoyau::VilleBouVilleC(long NrVille)
{
	if (m_CodeTarifVille[NrVille] == 2 || m_CodeTarifVille[NrVille] == 3)
		return true;
	else
		return false;
}

////////////////////////////////////////////////////////////////////////////////////
// D�termine si ville est du groupe A ou station Master cod� 1 ou dans le map master
bool CNoyau::VilleAouVilleMaster(long NrStation, long NrVille)
{
	if (m_CodeTarifVille[NrVille] == 1)
	{
		// Villes du groupe A
		return true;
	}	
	else
	{
		// Calcul code ville station
		long CodeStaVil = NrStation * 1000 + NrVille;
		bool Master = false;

		if (m_MapMasterStationVille.Lookup(CodeStaVil,Master))
		{
			return Master;
		}
		else
			return false;
	}

	// Dans tous les autres cas
	return false;
}

////////////////////////////////////////////////////////////////////////////////////
// Chargement des infos code tarifs ville / station
void CNoyau::LoadCodeTarifVille()
{

	// Les villes tarif A, B, C
	m_CodeTarifVille.SetSize(300);

	// Les villes tarif A ou 1
	m_CodeTarifVille[13]  = 1;
	m_CodeTarifVille[26]  = 1;
	m_CodeTarifVille[35]  = 1;
	m_CodeTarifVille[41]  = 1;
	m_CodeTarifVille[42]  = 1;
	m_CodeTarifVille[43]  = 1;
	m_CodeTarifVille[48]  = 1;
	m_CodeTarifVille[52]  = 1;
	m_CodeTarifVille[54]  = 1;
	m_CodeTarifVille[63]  = 1;
	m_CodeTarifVille[65]  = 1;
	m_CodeTarifVille[72]  = 1;
	m_CodeTarifVille[76]  = 1;

	// Les villes tarif B ou 2
	m_CodeTarifVille[3]   = 2;
	m_CodeTarifVille[4]   = 2;
	m_CodeTarifVille[5]   = 2;
	m_CodeTarifVille[6]   = 2;
	m_CodeTarifVille[8]   = 2;
	m_CodeTarifVille[12]  = 2;
	m_CodeTarifVille[15]  = 2;
	m_CodeTarifVille[18]  = 2;
	m_CodeTarifVille[20]  = 2;
	m_CodeTarifVille[27]  = 2;
	m_CodeTarifVille[45]  = 2;
	m_CodeTarifVille[49]  = 2;
	m_CodeTarifVille[93]  = 2;
	m_CodeTarifVille[121] = 2;
	m_CodeTarifVille[96]  = 2;
	m_CodeTarifVille[97]  = 2;
	m_CodeTarifVille[51]  = 2;
	m_CodeTarifVille[57]  = 2;
	m_CodeTarifVille[59]  = 2;
	m_CodeTarifVille[69]  = 2;
	m_CodeTarifVille[110] = 2;
	m_CodeTarifVille[77]  = 2;
	m_CodeTarifVille[78]  = 2;
	m_CodeTarifVille[114] = 2;
	m_CodeTarifVille[270] = 2;
	m_CodeTarifVille[255] = 2;  // Valenciennes

		
	// Les villes tarif C ou 3
	m_CodeTarifVille[1]   = 3;
	m_CodeTarifVille[115] = 3;
	m_CodeTarifVille[82]  = 3;
	m_CodeTarifVille[117] = 3;
	m_CodeTarifVille[10]  = 3;
	m_CodeTarifVille[85]  = 3;
	m_CodeTarifVille[11]  = 3;
	m_CodeTarifVille[14]  = 3;
	m_CodeTarifVille[86]  = 3;
	m_CodeTarifVille[89]  = 3;
	m_CodeTarifVille[21]  = 3;
	m_CodeTarifVille[23]  = 3;
	m_CodeTarifVille[91]  = 3;
	m_CodeTarifVille[24]  = 3;
	m_CodeTarifVille[92]  = 3;
	m_CodeTarifVille[25]  = 3;
	m_CodeTarifVille[28]  = 3;
	m_CodeTarifVille[30]  = 3;
	m_CodeTarifVille[33]  = 3;
	m_CodeTarifVille[37]  = 3;
	m_CodeTarifVille[98]  = 3;
	m_CodeTarifVille[99]  = 3;
	// m_CodeTarifVille[229] = 3;   // Lorient
	m_CodeTarifVille[44]  = 3;
	m_CodeTarifVille[102] = 3;
	m_CodeTarifVille[46]  = 3;
	m_CodeTarifVille[53]  = 3;
	m_CodeTarifVille[55]  = 3;
	m_CodeTarifVille[56]  = 3;
	m_CodeTarifVille[231] = 3;
	m_CodeTarifVille[209] = 3;
	m_CodeTarifVille[173] = 3;
	m_CodeTarifVille[104] = 3;
	m_CodeTarifVille[61]  = 3;
	m_CodeTarifVille[64]  = 3;
	m_CodeTarifVille[105] = 3;
	m_CodeTarifVille[107] = 3;
	m_CodeTarifVille[70]  = 3;
	m_CodeTarifVille[74]  = 3;
	m_CodeTarifVille[75]  = 3;
	m_CodeTarifVille[80]  = 3;
	m_CodeTarifVille[111] = 3;
	m_CodeTarifVille[112] = 3;
	m_CodeTarifVille[113] = 3;
	m_CodeTarifVille[94]  = 3;
	m_CodeTarifVille[122] = 3;
	m_CodeTarifVille[268] = 3;


	/*
	int nr=m_pDoc->m_pNoyau->m_pTblVille[m_pDoc->m_idxStation[i]][m_pDoc->m_idxVille[i]].m_NrUnique;
	SelVille.SetAt(nr,true);
	*/
	// Les masters (tarification comme Tarif A) - Couple station/ville
	long CodeStationVille;		// Station * 1000 + Ville

	/* A VIRER Decembre 2006
	// Les masters Nrj, Station cod� 1 * 1000
	m_MapMasterStationVille.SetAt(1000 + 8,		true);
	m_MapMasterStationVille.SetAt(1000 + 13,	true);
	m_MapMasterStationVille.SetAt(1000 + 41,	true);
	m_MapMasterStationVille.SetAt(1000 + 43,	true);
	m_MapMasterStationVille.SetAt(1000 + 65,	true);
	m_MapMasterStationVille.SetAt(1000 + 72,	true);
	m_MapMasterStationVille.SetAt(1000 + 76,	true);
	m_MapMasterStationVille.SetAt(1000 + 79,	true);
	m_MapMasterStationVille.SetAt(1000 + 47,	true);
	m_MapMasterStationVille.SetAt(1000 + 176,	true);
	m_MapMasterStationVille.SetAt(1000 + 12,	true);
	m_MapMasterStationVille.SetAt(1000 + 54,	true);
	m_MapMasterStationVille.SetAt(1000 + 59,	true);
	m_MapMasterStationVille.SetAt(1000 + 70,	true);

	
	// Les masters Cherie Fm, Station cod� 2 * 1000
	m_MapMasterStationVille.SetAt(2000 + 13,	true);
	m_MapMasterStationVille.SetAt(2000 + 26,	true);
	m_MapMasterStationVille.SetAt(2000 + 41,	true);
	m_MapMasterStationVille.SetAt(2000 + 42,	true);
	m_MapMasterStationVille.SetAt(2000 + 43,	true);
	m_MapMasterStationVille.SetAt(2000 + 110,	true);
	m_MapMasterStationVille.SetAt(2000 + 76,	true);
	m_MapMasterStationVille.SetAt(2000 + 84,	true);

	// Les masters Nostalgie, Station cod� 3 * 1000
	m_MapMasterStationVille.SetAt(3000 + 8,		true);
	m_MapMasterStationVille.SetAt(3000 + 42,	true);
	m_MapMasterStationVille.SetAt(3000 + 43,	true);
	m_MapMasterStationVille.SetAt(3000 + 65,	true);
	m_MapMasterStationVille.SetAt(3000 + 76,	true);
	m_MapMasterStationVille.SetAt(3000 + 79,	true);
	m_MapMasterStationVille.SetAt(3000 + 47,	true);
	m_MapMasterStationVille.SetAt(3000 + 176,	true);

	// Les masters Nostalgie, Station cod� 4 * 1000
	m_MapMasterStationVille.SetAt(4000 + 54,	true);
	*/

}

/*
//////////////////////////////////////////////////////////////////////////////////////
// Chercher frais annonce Station/Ville (MULTILOC3)
float CNoyau::OLD_DonneFraisAnnonceSpot(long NrStation, long NrVille,int Jour)
{
	
	
	if(!m_fTarifBase_Init || !m_fTarifMessage_Init || !m_fTarifSaison_Init) return -1;

	if(!m_pTblTarif[NrStation][NrVille].GetSize()) return -1;
	COleDateTime Date=m_Debut + COleDateTimeSpan(Jour,0,0,0);

	for(int x=0;x<m_pTblTarif[NrStation][NrVille].GetSize();x++)
	{
		if(m_pTblTarif[NrStation][NrVille][x].m_DateDebut<=Date) continue;
		break;
	}
	x--;
	if(x>=0)
		return ((float)m_pTblTarif[NrStation][NrVille][x].m_FraisAntenne);
	else
		return -1;

}
*/

//////////////////////////////////////////////////////////////////////////////////////
// Chercher frais annonce Station/Ville (MULTILOC3)
float CNoyau::DonneFraisAnnonceSpot(long NrStation, long NrVille,int Jour)
{
	if(!m_fTarifBase_Init) return -1;

	// Date r�elle 
	COleDateTime Date=m_Debut + COleDateTimeSpan(Jour,0,0,0);

	// Positionnement cl� de recherche
	CCleTarifBaseSaison		CleTarifBase;
	CleTarifBase.m_NrStation = m_Station[NrStation].m_NrUnique;
	CleTarifBase.m_NrVille   = m_Ville[NrVille].m_NrUnique;
	CleTarifBase.m_DateDeb   = Date;

	// Placement sur 1er �lmt tarif base pour ce couple <station,ville>
	m_MapTarifBase.MoveTo(CleTarifBase,-1);
			
	// V�rifie qu'il y a bien un tarif
	if (m_MapTarifBase.IsValid())
	{	
		// Positionne sur la date la plus proche
		CleTarifBase = m_MapTarifBase.GetKey();

		// Datas tarif
		CDataTarifBase DataTarifBase;
		DataTarifBase = m_MapTarifBase.GetItem();

		return (DataTarifBase.m_FraisAntenne); 
	}

	// pas de tarif trouv�
	return -1;
}

//////////////////////////////////////////////////////////////////////////////////////
// Chercher GRP
float CNoyau::DonneGrp(long NrStation, long NrVille, int Jour, int Horaire)
{

	if(!m_fGrp_Init) return 0;
	if(!m_pTblGrp) return 0;
	if(!m_pTblGrp[NrStation]) return 0;
	if(!m_pTblGrp[NrStation][NrVille].GetSize()) return 0;
	COleDateTime Date=m_Debut + COleDateTimeSpan(Jour,0,0,0);
	int x=0;
	for(x=0;x<m_pTblGrp[NrStation][NrVille].GetSize();x++)
	{
		if(m_pTblGrp[NrStation][NrVille][x].m_DateDebut<=Date) continue;
		break;
	}
	x--;
	if(x<0) return 0;
	int Day=Date.GetDayOfWeek();
	if(Day==1) Day=6;
	else Day-=2;
	return ((float)m_pTblGrp[NrStation][NrVille][x].m_Grp[Day][Horaire]/100.0);
}

CString CNoyau::DonneAdrMailStationVille(long NrStation, long NrVille)
{
	CString AdrMail = "";

	for (int i= 0;i< m_TblInfoStaVil.GetSize();i++)
	{
		if ((m_TblInfoStaVil[i].m_NrStation == NrStation) && (m_TblInfoStaVil[i].m_NrVille == NrVille))
		{
			AdrMail = m_TblInfoStaVil[i].m_AdrMail;
			break;
		}
	}
	return AdrMail;
}


CString CNoyau::DonneFaxStationVille(long NrStation, long NrVille)
{
	CString Fax = "";

	for (int i= 0;i< m_TblInfoStaVil.GetSize();i++)
	{
		if ((m_TblInfoStaVil[i].m_NrStation == NrStation) && (m_TblInfoStaVil[i].m_NrVille == NrVille))
		{
			Fax = m_TblInfoStaVil[i].m_Fax;
			break;
		}
	}
	return Fax;
}


bool CNoyau::LoadVilles(CDaoDatabase &Db)
{
	m_Ville.RemoveAll();
	CTblVilles Table(&Db);
	Table.Open();
	while(!Table.IsEOF()) 
	{
		CVille Ville;
		Ville=Table;
		m_Ville.Add(Ville);
		Table.MoveNext();
	}
	Table.Close();
	CVille *pVille=m_Ville.GetData();
	if(pVille) std::sort(pVille,(pVille+m_Ville.GetSize()));
	else return false;
	for(int x=0;x<m_Ville.GetSize();x++) m_Ville[x].m_NrIndex=x;
	return true;
}

bool CNoyau::LoadStations(CDaoDatabase &Db)
{
	m_Station.RemoveAll();
	CTblStations Table(&Db);
	Table.Open();
	while(!Table.IsEOF()) 
	{
		CStation Station;
		Station=Table;
		m_Station.Add(Station);
		Table.MoveNext();
	}
	Table.Close();
	CStation *pStation=m_Station.GetData();
//	std::sort(pStation,(pStation+m_Station.GetSize()));
	if(pStation) return true;
	else return false;
}

// MULTILOC3 : chargement des infos sp�cifiques li�es aux sttions/villes (email,fax)
bool CNoyau::LoadInfoStaVil(CDaoDatabase &Db)
{

	m_TblInfoStaVil.RemoveAll();
	CTblInfoStaVil Table(&Db);
	Table.Open();
	while(!Table.IsEOF()) 
	{
		CInfoStaVil InfoStaVil;
		InfoStaVil=Table;
		m_TblInfoStaVil.Add(InfoStaVil);
		Table.MoveNext();
	}
	Table.Close();

	return true;

}

bool CNoyau :: AjouterMailFax(long NrStation,long NrVille,CString AdrMail,CString Fax)
{
	CInfoStaVil InfoStaVil;
	bool Return = false;

	InfoStaVil.m_NrStation =NrStation;
	InfoStaVil.m_NrVille =NrVille;
	InfoStaVil.m_AdrMail =AdrMail;
	InfoStaVil.m_Fax =Fax;


	CDaoDatabase Db;
	try
	{
		Db.Open(m_Path,TRUE,FALSE);
		CTblInfoStaVil Table(&Db);
		Table.Open();
		Table.AddNew();
		Table=InfoStaVil;
		Table.Update();
		Table.Close();
		Db.Close();
	
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}

	// puis on recharge tableau infos stations/villes
	Db.Open(m_Path,FALSE,TRUE);
	if(LoadInfoStaVil(Db)) Return=true;
	Db.Close();

	return Return;
}

// Mise � jour ou ajout Info Mail Faxs
bool CNoyau :: MajMailFax(long NrStation,long NrVille,CString AdrMail,CString Fax)
{
	
	bool InxStaVilTrouve = false;

	for (int i= 0;i< m_TblInfoStaVil.GetSize();i++)
	{
		if ((m_TblInfoStaVil[i].m_NrStation == NrStation) && (m_TblInfoStaVil[i].m_NrVille == NrVille))
		{
			// Ici station/ville info pr�sent on modifie
			m_TblInfoStaVil[i].m_AdrMail = AdrMail;
			m_TblInfoStaVil[i].m_Fax = Fax;
			InxStaVilTrouve = true;
			return ModifierMailFax(i);				;
			break;
		}
	}

	if (!InxStaVilTrouve)
	{
		// Nouvelle station/ville pour info
		return AjouterMailFax(NrStation,NrVille,AdrMail,Fax);
	}

	return false;

	
}

// Modification d'un enregistrement Info Mail/Fax Station/Ville
bool CNoyau :: ModifierMailFax(short InxStaVil)
{
	CDaoDatabase Db;	
	bool ModifOk = false;

	try
	{

		CTblInfoStaVil Table(&Db);
		Table.Open();
		while(!Table.IsEOF() && !ModifOk) 
		{
			CInfoStaVil InfoStaVil;
			InfoStaVil=Table;

	
			if ((InfoStaVil.m_NrStation == m_TblInfoStaVil[InxStaVil].m_NrStation) && (InfoStaVil.m_NrVille == m_TblInfoStaVil[InxStaVil].m_NrVille))
			{
				InfoStaVil = m_TblInfoStaVil[InxStaVil];
				Table.Edit();
				Table = InfoStaVil;
				Table.Update();
				ModifOk = true;
			}
			Table.MoveNext();
		}
		Table.Close();

		return true;

	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

bool CNoyau::LoadCibles(CDaoDatabase &Db)
{
	m_TblCible.RemoveAll();
	CTblCibles Table(&Db);
	Table.Open();
	while(!Table.IsEOF()) 
	{
		CCible Cible;
		Cible=Table;
		m_TblCible.Add(Cible);
		Table.MoveNext();
	}
	Table.Close();
	CCible *pCible=m_TblCible.GetData();

	/*
	if(pCible) std::sort(pCible,(pCible+m_TblCible.GetSize()));
	else return false;
	*/

	return true;
}

bool CNoyau::LoadTables()
{
	bool Return=true;
	CDaoDatabase Db;
	try
	{
		Db.Open(m_Path,FALSE,TRUE);
		if(!LoadStations(Db))
			Return=false;
		if(!LoadVilles(Db))
			Return=false;
		if(!LoadCibles(Db))
			Return=false;
		// MULTILOC3
		if(!LoadInfoStaVil(Db))
			Return=false;
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("LoadTables, %s, %s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return Return;
}

bool CNoyau::ChargerCible(int Index)
{
	//if(!m_fTarif_Init) return false;
	if(!m_fTarifBase_Init || !m_fTarifMessage_Init || !m_fTarifSaison_Init) return false;

	if(Index>=m_TblCible.GetSize()) return false;
	if(m_Cible!=Index || !m_fGrp_Init)
	{
		m_Cible=Index;
		m_fGrp_Init=LoadGrps();
	}
	return true;
}

//////////////////////////////////////////////////////////////////////////////////////
//								Chargement des tarifs
bool CNoyau::LoadTarifs(CDaoDatabase &Db)
{
	bool ChargeOptim = true;
	
	if(m_pTblTarif)
	{
		for(int x=0;x<m_TblStation.GetSize();x++)
		{
			if(m_pTblTarif && m_pTblTarif[x]) delete [] m_pTblTarif[x];
		}
		delete [] m_pTblTarif;
	}
	m_pTblTarif=NULL;
	if(m_pTblGrp)
	{
		for(int x=0;x<m_TblStation.GetSize();x++)
		{
			if(m_pTblGrp && m_pTblGrp[x]) delete [] m_pTblGrp[x];
		}
		delete [] m_pTblGrp;
	}
	m_pTblGrp=NULL;
	m_fGrp_Init=false;
	m_TblStation.RemoveAll();

	if(m_pTblVille) delete [] m_pTblVille;
	m_pTblVille=NULL;
	try
	{
		CTblTarifs Table(&Db);
		Table.Open();

		if(!Table.IsEOF())
		{
			CString Search;
			CTarifArray ** pTblTarif = new	CTarifArray*[m_Station.GetSize()];
			CDWordArray *  pStaVille = new	CDWordArray[m_Station.GetSize()];

			CMap<long,long,long,long> MapSta;
			CMap<long,long,long,long> MapVil;
			long Sta=0;
			long Vil=0;
			for(;Sta<m_Station.GetSize();Sta++)
			{
				MapSta.SetAt(m_Station[Sta].m_NrUnique,Sta);
				pTblTarif[Sta]= new CTarifArray[m_Ville.GetSize()];
			}
			for(;Vil<m_Ville.GetSize();Vil++)
			{
				MapVil.SetAt(m_Ville[Vil].m_NrUnique,Vil);
			}
			while(!Table.IsEOF()) 
			{
				CTarif Tarif;
				Tarif=Table;
				MapSta.Lookup(Tarif.m_NrStation,Sta);
				MapVil.Lookup(Tarif.m_NrVille,Vil);
				pTblTarif[Sta][Vil].Add(Tarif);
				Table.MoveNext();
			}

			for(Sta=0;Sta<m_Station.GetSize();Sta++)
			{
				for(Vil=0;Vil<m_Ville.GetSize();Vil++)
				{
					CTarif *pTarif=pTblTarif[Sta][Vil].GetData();

					if(pTarif)
					{

						std::sort(pTarif,(pTarif+pTblTarif[Sta][Vil].GetSize()));
						int Count=0;
						for(int	x=1;x<pTblTarif[Sta][Vil].GetSize();x++)
						{
							if(pTblTarif[Sta][Vil][x].m_DateDebut>=m_Debut) break;
							Count++;
						}
						if(Count)pTblTarif[Sta][Vil].RemoveAt(0,Count);
	
						if(pTblTarif[Sta][Vil].GetSize()) pStaVille[Sta].Add(Vil);
					}
				}
				if(pStaVille[Sta].GetSize()) m_TblStation.Add(m_Station[Sta]);
			}
			m_pTblVille= new CVilleArray[m_TblStation.GetSize()];
			m_pTblTarif = new CTarifArray*[m_TblStation.GetSize()];
			int s=0;
			for(int x=0,y=0;x<m_Station.GetSize();x++)
			{
				if(!pStaVille[x].GetSize()) continue;
				m_pTblTarif[s]= new CTarifArray[pStaVille[x].GetSize()];
				for(int v=0;v<pStaVille[x].GetSize();v++)
				{	
					m_pTblVille[s].Add(m_Ville[pStaVille[x][v]]);
					for(int t=0;t<pTblTarif[x][pStaVille[x][v]].GetSize();t++)
					{
						m_pTblTarif[s][v].Add(pTblTarif[x][pStaVille[x][v]][t]);
					}
				}
				s++;
				
			}
			if(pTblTarif)
			{
				for(int x=0;x<m_Station.GetSize();x++)
				{
					if(pTblTarif && pTblTarif[x]) delete [] pTblTarif[x];
				}
				delete [] pTblTarif;
			}
			if(pStaVille) delete [] pStaVille;
		}

		Table.Close();
		

	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("LoadTarifs, %s, %s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}

	return true;
}

//////////////////////////////////////////////////////////////////////////////////////
// Chargement des tarifs de  base
bool CNoyau::LoadTarifBase				(CDaoDatabase &Db)
{
	int Sta,Vil;


	// Vide tous les tarifs de base
	m_MapTarifBase.Reset();

	// ??? Qu'est ce que �a fout l� les GRP
	if(m_pTblGrp)
	{
		for(int x=0;x<m_TblStation.GetSize();x++)
		{
			if(m_pTblGrp && m_pTblGrp[x]) delete [] m_pTblGrp[x];
		}
		delete [] m_pTblGrp;
	}
	m_pTblGrp=NULL;
	m_fGrp_Init=false;

	// Vide l atable des stations
	m_TblStation.RemoveAll();

	// Vide la table des villes
	if(m_pTblVille) delete [] m_pTblVille;
	m_pTblVille=NULL;

	// Remplissage Map tarif de base
	try
	{
		// Ouverture de la table tarif de base
		CTblTarifBase Table(&Db);

		Table.Open();
		
		// Si table non vide
		if(!Table.IsEOF())
		{
			
			// Boucle sur tous les �l�ments de la table
			while(!Table.IsEOF()) 
			{


				// R�cup �lmt tarif base
				CTarifBase TarifBase;

				TarifBase = Table;

				// Insertion dans map g�n�ral tarif base
				CDataTarifBase			DataTarifBase;
				CCleTarifBaseSaison		CleTarifBase;

				// D�finition de la cl�
				CleTarifBase.m_NrStation		= TarifBase.m_NrStation;
				CleTarifBase.m_NrVille			= TarifBase.m_NrVille; 
				CleTarifBase.m_DateDeb			= TarifBase.m_DateDebut;								

				// Informations tarif base
				DataTarifBase.m_TarifBase		= float(TarifBase.m_TarifBase)/100.0;
				DataTarifBase.m_FraisAntenne	= float(TarifBase.m_FraisAntenne)/100.0; 
				DataTarifBase.m_DateFin			= TarifBase.m_DateFin;

				// Ajout dans le map
				m_MapTarifBase.MoveTo(CleTarifBase);
				if (!m_MapTarifBase.IsValid())
					m_MapTarifBase.Add(CleTarifBase) = DataTarifBase;
						
				// Passe � l'�lmt table tarif de base suivant
				Table.MoveNext();
			}

			// Date d�but base tarifaire
			COleDateTime DateButtoir(2003,1,1,0,0,0);


			// Dimensionnement m_TblStation
			for(Sta=0;Sta<m_Station.GetSize();Sta++)
			{
				// Positionne flag au moins 1 ville tarif�e pour cette station
				bool AuMoins1Ville = false;

				for(Vil=0;Vil<m_Ville.GetSize();Vil++)
				{
					// No ville et station
					int NoVille   = m_Ville[Vil].m_NrUnique;
					int NoStation = m_Station[Sta].m_NrUnique;

					// Recherche des tarifs correpondants � ces stations villes
					CCleTarifBaseSaison		CleTarifBase;
					CleTarifBase.m_NrStation = long(m_Station[Sta].m_NrUnique);
					CleTarifBase.m_NrVille   = long(m_Ville[Vil].m_NrUnique);
					CleTarifBase.m_DateDeb   = m_Debut;

					// Placement sur 1er �lmt tarif base pour ce couple <station,ville>
					m_MapTarifBase.MoveTo(CleTarifBase,-1);
			
					// V�rifie qu'il y a bien un tarif
					int NbCount = m_MapTarifBase.GetCount();
					if (m_MapTarifBase.IsValid())
					{	
						CleTarifBase = m_MapTarifBase.GetKey();

						if (CleTarifBase.m_NrStation  == m_Station[Sta].m_NrUnique 
						    && CleTarifBase.m_NrVille    == m_Ville[Vil].m_NrUnique)
						{
							// R�cup�re tarif �lmt
							CDataTarifBase DataTarifBase = m_MapTarifBase.GetItem();
							
							// Si <> 0 on valide la station
							if (DataTarifBase.m_TarifBase > 0)
							{
								
								AuMoins1Ville = true;
							}
						}
					}
					
				}

				// Si au moins 1 ville tarif�e on valide la station
				//if (AuMoins1Ville == true)
				//{
					// Ajoute la station
					m_TblStation.Add(m_Station[Sta]);
				//}
			}			

			// Dimensionnement tableau villes/stations
			int NbSta = m_TblStation.GetSize();

			int tailleSta = m_TblStation.GetSize();
			int tailleVil = m_Ville.GetCount();

			m_pTblVille = new CVilleArray[m_TblStation.GetSize()];

			// Voir les stations et villes dispo
			int InxSta = 0;
			for(Sta=0;Sta<m_Station.GetSize();Sta++)
			{
				// Positionne flag au moins 1 ville tarif�e pour cette station
				bool AuMoins1Ville = false;

				CString Libelle = m_Station[Sta].m_Libelle;

				for(Vil=0;Vil<m_Ville.GetSize();Vil++)
				{

					// Flag si ville tarif�e pour cette station
					bool StationVilleTarifee = false;

					// No ville et station
					int NoVille   = m_Ville[Vil].m_NrUnique;
					int NoStation = m_Station[Sta].m_NrUnique;

					//if (NoStation == 12 && NoVille == 224)
					//	NoStation = NoStation;


					// Grosse bidouille avec Date deb et date fin
					int InxDate = 0;
					for (InxDate = 0; InxDate <= 1; InxDate++)
					{
						// Recherche des tarifs correpondants � ces stations villes
						CCleTarifBaseSaison		CleTarifBase;
						CleTarifBase.m_NrStation = long(m_Station[Sta].m_NrUnique);
						CleTarifBase.m_NrVille   = long(m_Ville[Vil].m_NrUnique);

						if (InxDate == 0)
							// Test avec date de d�but p�riode
							CleTarifBase.m_DateDeb   = m_Debut;

						else if (StationVilleTarifee == false)
						{
							// on prend la date de l'ann�e d'apr�s
							CleTarifBase.m_DateDeb   = m_Fin;
						}

						// Placement sur 1er �lmt tarif base pour ce couple <station,ville>
						m_MapTarifBase.MoveTo(CleTarifBase,-1);
				
						// V�rifie qu'il y a bien un tarif
						int NbCount = m_MapTarifBase.GetCount();
						if (m_MapTarifBase.IsValid())
						{	
							CleTarifBase = m_MapTarifBase.GetKey();

							if (CleTarifBase.m_NrStation  == m_Station[Sta].m_NrUnique 
								&& CleTarifBase.m_NrVille    == m_Ville[Vil].m_NrUnique)
							{
								// R�cup�re tarif �lmt
								CDataTarifBase DataTarifBase = m_MapTarifBase.GetItem();
								
								// Si <> 0 on valide la station
								if (DataTarifBase.m_TarifBase > 0)
								{
									// Ajout de la ville
									CVille Ville = m_Ville[Vil];
									int Index = m_pTblVille[InxSta].Add(m_Ville[Vil]);
									AuMoins1Ville = true;
									StationVilleTarifee = true;
								}
							}
						}
					}
				}

				// Si au moins 1 ville tarif�e on valide la station
				//if (AuMoins1Ville == true) InxSta++;
				InxSta++;

			}
		}

		// Fermeture table des tarifs de base
		Table.Close();

	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("LoadTarifs, %s, %s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;

}

//////////////////////////////////////////////////////////////////////////////////////
// Chargement des tarifs message
bool CNoyau::LoadTarifMessage			(CDaoDatabase &Db)
{
	// Vide tous les tarifs de base
	m_MapTarifMessage.Reset();

	// Remplissage Map tarif messages
	try
	{
		// Ouverture de la table tarif messages
		CTblTarifMessage Table(&Db);
		Table.Open();

		// Si table non vide
		if(!Table.IsEOF())
		{
			// Boucle sur tous les �l�ments de la table
			while(!Table.IsEOF()) 
			{
				// R�cup �lmt tarif message
				CTarifMessage TarifMessage;
				TarifMessage = Table;

				// Insertion dans map g�n�ral tarif Message
				CDataTarifMessage		DataTarifMessage;
				CCleTarifMessage		CleTarifMessage;

				// D�finition de la cl�
				CleTarifMessage.m_NrStation		= TarifMessage.m_NrStation;
				CleTarifMessage.m_NrVille		= TarifMessage.m_NrVille;
				CleTarifMessage.m_NrJour		= TarifMessage.m_NrJour; 
				CleTarifMessage.m_NrTrh		    = TarifMessage.m_NrTrh;								
				CleTarifMessage.m_DateDeb 	    = TarifMessage.m_DateDebut;

				// Informations tarif message
				DataTarifMessage.m_CoeffMessage = float(TarifMessage.m_CoeffTranche)/100.0;
				DataTarifMessage.m_DateFin   	= TarifMessage.m_DateFin;

				// Ajout dans le map
				m_MapTarifMessage.MoveTo(CleTarifMessage);
				if (!m_MapTarifMessage.IsValid())
				{
					m_MapTarifMessage.Add(CleTarifMessage) = DataTarifMessage;
				}
						
				// Passe � l'�lmt table tarif de base suivant
				Table.MoveNext();
			}
		}

		// Fermeture table des coefficients message
		Table.Close();
		

	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("LoadTarifs, %s, %s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

//////////////////////////////////////////////////////////////////////////////////////
// Chargement des tarifs message (idem LoadTarifMessage mais avec clef station/ville)
/*
// A FAIRE TF1
bool CNoyau::LoadTarifMessageStationVille	(CDaoDatabase &Db)
{
	// Vide tous les tarifs de base
	m_MapTarifMessage.Reset();

	// Remplissage Map tarif messages
	try
	{
		// Ouverture de la table tarif messages
		CTblTarifMessage Table(&Db);
		Table.Open();

		// Si table non vide
		if(!Table.IsEOF())
		{
			// Boucle sur tous les �l�ments de la table
			while(!Table.IsEOF()) 
			{
				// R�cup �lmt tarif message
				CTarifMessage TarifMessage;
				TarifMessage = Table;

				// Insertion dans map g�n�ral tarif Message
				CDataTarifMessage				DataTarifMessage;
				CCleTarifMessage				CleTarifMessage;

				// D�finition de la cl�
				CleTarifMessage.m_NrStation		= TarifMessage.m_NrStation;
				CleTarifMessage.m_NrJour		= TarifMessage.m_NrJour; 
				CleTarifMessage.m_NrTrh		    = TarifMessage.m_NrTrh;								
				CleTarifMessage.m_DateDeb 	    = TarifMessage.m_DateDebut;

				// Informations tarif message
				DataTarifMessage.m_CoeffMessage = float(TarifMessage.m_CoeffTranche)/100.0;
				DataTarifMessage.m_DateFin   	= TarifMessage.m_DateFin;

				// Ajout dans le map
				m_MapTarifMessage.MoveTo(CleTarifMessage);
				if (!m_MapTarifMessage.IsValid())
				{
					m_MapTarifMessage.Add(CleTarifMessage) = DataTarifMessage;
				}

				// Passe � l'�lmt table tarif de base suivant
				Table.MoveNext();
			}
		}

		// Fermeture table des coefficients message
		Table.Close();


	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("LoadTarifs, %s, %s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}
*/

//////////////////////////////////////////////////////////////////////////////////////
// Chargement des tarifs p�riode
bool CNoyau::LoadTarifSaison			(CDaoDatabase &Db)
{
	// Vide tous les tarifs p�riodes
	m_MapTarifSaison.Reset();

	// Remplissage Map tarif p�riodes
	try
	{
		// Ouverture de la table tarif p�riodes
		CTblTarifSaison Table(&Db);
		Table.Open();

		// Si table non vide
		if(!Table.IsEOF())
		{
	
			// Boucle sur tous les �l�ments de la table
			while(!Table.IsEOF()) 
			{
				// R�cup �lmt tarif saison
				CTarifSaison TarifSaison;
				TarifSaison = Table;

				// Insertion dans map g�n�ral tarif p�riodes
				CDataTarifSaison		DataTarifSaison;
				CCleTarifBaseSaison		CleTarifSaison;

				// D�finition de la cl�
				CleTarifSaison.m_NrStation		= TarifSaison.m_NrStation;
				CleTarifSaison.m_NrVille		= TarifSaison.m_NrVille; 
				CleTarifSaison.m_DateDeb		= TarifSaison.m_DateDebut;								

				// Informations tarif saison
				DataTarifSaison.m_CoeffSaison 	= float(TarifSaison.m_CoeffSaison)/100.0;
				DataTarifSaison.m_DateFin   	= float(TarifSaison.m_DateFin);

				// Ajout dans le map
				m_MapTarifSaison.MoveTo(CleTarifSaison);
				if (!m_MapTarifSaison.IsValid())
					m_MapTarifSaison.Add(CleTarifSaison) = DataTarifSaison;
						
				// Passe � l'�lmt table tarif de base suivant
				Table.MoveNext();
			}
		}

		// Fermeture table des coefficients p�riode
		Table.Close();
		

	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("LoadTarifs, %s, %s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

bool CNoyau::LoadGrps()
{

	int NrSta,NrVil;

	if(m_pTblGrp)
	{
		for(int x=0;x<m_TblStation.GetSize();x++)
		{
			if(m_pTblGrp && m_pTblGrp[x]) delete [] m_pTblGrp[x];
		}
		delete [] m_pTblGrp;
		m_pTblGrp=NULL;
	}
	CDaoDatabase Db;
	try
	{
		Db.Open(m_Path,FALSE,TRUE);
		CTblGrps Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			int Size  = m_TblStation.GetSize();
			int Sta=0;
			m_pTblGrp = new CGrpArray*[m_TblStation.GetSize()];
			for(;Sta<m_TblStation.GetSize();Sta++)
				m_pTblGrp[Sta] = NULL;

			int NbSta = m_TblStation.GetSize();	
			for(Sta=0;Sta<m_TblStation.GetSize();Sta++)
			{
				if (m_pTblVille[Sta].GetSize() > 0)
					// Alloue si au moins 1 ville
					m_pTblGrp[Sta]= new CGrpArray[m_pTblVille[Sta].GetSize()];

				for(int Vil=0;Vil<m_pTblVille[Sta].GetSize();Vil++)
				{
					NrSta = m_TblStation[Sta].m_NrUnique;
					NrVil = m_pTblVille[Sta][Vil].m_NrUnique;

					Search.Format("NrStation = %d AND NrVille = %d AND NrCible = %d AND DateDebut <= %s",
						m_TblStation[Sta].m_NrUnique,m_pTblVille[Sta][Vil].m_NrUnique,m_TblCible[m_Cible].m_NrUnique,m_Fin.Format("#%m/%d/%y#"));//,m_Debut.Format("#%m/%d/%y#"));
					if(Table.FindFirst(Search))
					{
						do
						{
							CGrp Grp;
							Grp=Table;
							m_pTblGrp[Sta][Vil].Add(Grp);
						}
						while(Table.FindNext(Search));
						CGrp *pGrp=m_pTblGrp[Sta][Vil].GetData();
						if(pGrp)
						{
							std::sort(pGrp,(pGrp+m_pTblGrp[Sta][Vil].GetSize()));
							int Count=0;
							for(int x=1;x<m_pTblGrp[Sta][Vil].GetSize();x++)
							{
								if(m_pTblGrp[Sta][Vil][x].m_DateDebut>=m_Debut) break;
								Count++;
							}
							if(Count) m_pTblGrp[Sta][Vil].RemoveAt(0,Count);
						}
					}
				}
			}
		}
		Table.Close();
		Db.Close();

	}

	

	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("LoadGrps, %s, %s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	if(!m_pTblGrp) return(false);
	return true;
}

bool CNoyau::LoadFormats(CDaoDatabase &Db, int ModeTarif)
{
	CFormatMap FormatMap;

	m_TblFormat.RemoveAll();
	if(m_pTblFormat) delete [] m_pTblFormat;
	m_pTblFormat=NULL;
	if(m_pMapTblFormat) delete [] m_pMapTblFormat;
	m_pMapTblFormat=NULL;

	try
	{
		CTblFormats Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			m_pTblFormat	= new CFormatArray[m_TblStation.GetSize()];
			m_pMapTblFormat = new CFormatMap[m_TblStation.GetSize()];


			int Taille = m_TblStation.GetSize();

			for(int Sta=0;Sta<m_TblStation.GetSize();Sta++)
			{
				int NoSta = m_TblStation[Sta].m_NrUnique;

				Search.Format("NrStation = %d AND DateDebut <= %s",
					m_TblStation[Sta].m_NrUnique,m_Fin.Format("#%m/%d/%y#"));
				if(Table.FindFirst(Search))
				{
					bool Key;
					do
					{
						CFormat Format;
						CFormat FormatAvecGratos;
						Format=Table;
						
						// Voir pour les formats en mode floating !!!!!! les gratos !!!!!
						if (ModeTarif != 0)
						{
							// Refabrique les formats avec les gratos (pour les modes floating)
							FormatAvecGratos = Format;
							FormatAvecGratos.m_Format.RemoveAll();
							FormatAvecGratos.m_Format.SetSize(Format.m_Format.GetSize() * 2); 

							for (int ff = 0; ff < Format.m_Format.GetSize(); ff++)
							{						
								// Le payant
								CFormatD FormatD;
								FormatD = Format.m_Format[ff];
								FormatAvecGratos.m_Format[ff * 2] = FormatD;  

								// Le gratos
								// FormatD.m_Libelle = "g-" + FormatD.m_Libelle;
								FormatD.m_Libelle += "/g";
								FormatD.m_Coef     = 0; 
								FormatAvecGratos.m_Format[ff * 2 +1] = FormatD;  
							}

							// Ajoute les formats par stations
							m_pTblFormat[Sta].Add(FormatAvecGratos);

						}
						else

							// Ajoute format en mode normal
							m_pTblFormat[Sta].Add(Format);
					}

					while(Table.FindNext(Search));
					CFormat *pFormat=m_pTblFormat[Sta].GetData();
					if(pFormat)
					{
						std::sort(pFormat,(pFormat+m_pTblFormat[Sta].GetSize()));
						int Count=0;
						int x=1;
						for(;x<m_pTblFormat[Sta].GetSize();x++)
						{
							if(m_pTblFormat[Sta][x].m_DateDebut>=m_Debut) break;
							Count++;
						}

						if(Count) m_pTblFormat[Sta].RemoveAt(0,Count);

						int Nb = m_pTblFormat[Sta].GetSize();

						for(x=0;x<m_pTblFormat[Sta].GetSize();x++)
						{
							int NbF =  m_pTblFormat[Sta][x].m_Format.GetSize();
							for(int y=0;y<m_pTblFormat[Sta][x].m_Format.GetSize();y++)
							{
								if(!m_pMapTblFormat[Sta].Lookup(m_pTblFormat[Sta][x].m_Format[y].m_Libelle,Key))
								{
									m_pMapTblFormat[Sta].SetAt(m_pTblFormat[Sta][x].m_Format[y].m_Libelle,true);
									FormatMap.SetAt(m_pTblFormat[Sta][x].m_Format[y].m_Libelle,true);
								}
							}
						}

					}
				}
			}
		}
		Table.Close();


		int NbF = m_pMapTblFormat->GetCount();
		NbF = 0;

	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("LoadFormats, %s, %s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	POSITION Pos=FormatMap.GetStartPosition();
	while(Pos)
	{
		CString String;
		bool Key;
		FormatMap.GetNextAssoc(Pos,String,Key);
		m_TblFormat.Add(String);
	}
	CString *pFormat=m_TblFormat.GetData();
	if(pFormat) std::sort(pFormat,(pFormat+m_TblFormat.GetSize()));
	return true;
}

bool CNoyau::LoadRemiseFinanciere(CDaoDatabase &Db)
{
	m_TblRemiseFinanciere.RemoveAll();
	try
	{
		CTblVolumes Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("DateDebut <= %s",m_Fin.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				do
				{
					CVolume Volume;
					Volume=Table;
					m_TblRemiseFinanciere.Add(Volume);
				}
				while(Table.FindNext(Search));
				CVolume *pVolume=m_TblRemiseFinanciere.GetData();
				if(pVolume)
				{
					std::sort(pVolume,(pVolume+m_TblRemiseFinanciere.GetSize()));
					int Count=0;
					for(int x=1;x<m_TblRemiseFinanciere.GetSize();x++)
					{
						if(m_TblRemiseFinanciere[x].m_DateDebut>=m_Debut) break;
						Count++;
					}
					if(Count) m_TblRemiseFinanciere.RemoveAt(0,Count);
				}
			}
		}
		Table.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("LoadRemiseFinanciere, %s, %s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

bool CNoyau::LoadRemiseSpots(CDaoDatabase &Db)
{
	m_TblRemiseSpot.RemoveAll();
	try
	{
		CTblPrimes Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("DateDebut <= %s",m_Fin.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				do
				{
					CPrime Prime;
					Prime=Table;
					m_TblRemiseSpot.Add(Prime);
				}
				while(Table.FindNext(Search));
				CPrime *pPrime=m_TblRemiseSpot.GetData();
				if(pPrime)
				{
					std::sort(pPrime,(pPrime+m_TblRemiseSpot.GetSize()));
					int Count=0;
					for(int x=1;x<m_TblRemiseSpot.GetSize();x++)
					{
						if(m_TblRemiseSpot[x].m_DateDebut>=m_Debut) break;
						Count++;
					}
					if(Count) m_TblRemiseSpot.RemoveAt(0,Count);
				}
			}
		}
		Table.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("LoadRemiseSpots, %s, %s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

/////////////////////////////////////////////////////////////////////////
// Chargement table remise nb stations/villes
bool CNoyau::LoadRemiseStaVil(CDaoDatabase &Db)
{
	m_TblRemiseStaVil.RemoveAll();
	try
	{
		CTblRemiseStaVils Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("DateDebut <= %s",m_Fin.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				do
				{
					CRemiseStaVil RemiseStaVil;
					RemiseStaVil = Table;
					m_TblRemiseStaVil.Add(RemiseStaVil);
				}
				while(Table.FindNext(Search));

				CRemiseStaVil * pRemiseStaVil = m_TblRemiseStaVil.GetData();

				if(pRemiseStaVil)
				{
					std::sort(pRemiseStaVil,(pRemiseStaVil + m_TblRemiseStaVil.GetSize()));
					int Count=0;
					for(int x=1;x<m_TblRemiseStaVil.GetSize();x++)
					{
						if(m_TblRemiseStaVil[x].m_DateDebut>=m_Debut) break;
						Count++;
					}
					if(Count) m_TblRemiseStaVil.RemoveAt(0,Count);
				}
			}
		}
		Table.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("LoadRemiseStaVil, %s, %s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

bool CNoyau::LoadRemiseFinanciereRegion(CDaoDatabase &Db)
{
	m_TblRemiseFinanciereRegion.RemoveAll();
	try
	{
		CTblVolumesRegion Table(&Db);
		Table.Open();

		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("DateDebut <= %s",m_Fin.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				do
				{
					CVolumeRegion VolumeRegion;
					VolumeRegion=Table;
					m_TblRemiseFinanciereRegion.Add(VolumeRegion);
				}
				while(Table.FindNext(Search));
				CVolumeRegion *pVolumeRegion=m_TblRemiseFinanciereRegion.GetData();
				if(pVolumeRegion)
				{
					std::sort(pVolumeRegion,(pVolumeRegion+m_TblRemiseFinanciereRegion.GetSize()));
					int Count=0;
					for(int x=1;x<m_TblRemiseFinanciereRegion.GetSize();x++)
					{
						if(m_TblRemiseFinanciereRegion[x].m_DateDebut>=m_Debut) break;
						Count++;
					}
					if(Count) m_TblRemiseFinanciereRegion.RemoveAt(0,Count);
				}
			}
		}
		Table.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("LoadRemiseFinanciereRegion, %s, %s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

bool CNoyau::LoadRemiseSpotsRegion(CDaoDatabase &Db)
{
	m_TblRemiseSpotRegion.RemoveAll();
	try
	{
		CTblPrimesRegion Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("DateDebut <= %s",m_Fin.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				do
				{
					CPrimeRegion PrimeRegion;
					PrimeRegion=Table;
					m_TblRemiseSpotRegion.Add(PrimeRegion);
				}
				while(Table.FindNext(Search));
				CPrimeRegion *pPrimeRegion=m_TblRemiseSpotRegion.GetData();
				if(pPrimeRegion)
				{
					std::sort(pPrimeRegion,(pPrimeRegion+m_TblRemiseSpotRegion.GetSize()));
					int Count=0;
					for(int x=1;x<m_TblRemiseSpotRegion.GetSize();x++)
					{
						if(m_TblRemiseSpotRegion[x].m_DateDebut>=m_Debut) break;
						Count++;
					}
					if(Count) m_TblRemiseSpotRegion.RemoveAt(0,Count);
				}
			}
		}
		Table.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("LoadRemiseSpotsRegion, %s, %s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

float CNoyau::DonneRemiseFinanciere(int Jour, long Budget,bool PrixEnEuro,float TauxEuroFranc)
{
//	AfxMessageBox("Enter DonneRemiseFinanciere");
	COleDateTime theDate;
	theDate=m_Debut + COleDateTimeSpan(0,0,0,0);
	int x=0;
	for(;x<m_TblRemiseFinanciere.GetSize();x++)
	{
		if(m_TblRemiseFinanciere[x].m_DateDebut<=theDate) continue;
		break;
	}
	x--;
	if(x<0) return 0.0;
	if (PrixEnEuro)
	{

		for(int y=m_TblRemiseFinanciere[x].m_Palier.GetSize()-1;y>=0;y--)
		{
			if(Budget>=m_TblRemiseFinanciere[x].m_Palier[y].m_Palier)
				return m_TblRemiseFinanciere[x].m_Palier[y].m_Coef;
		}


	}
	else
	{
		// Attention les paliers sont en euros !!!
		for(int y=m_TblRemiseFinanciere[x].m_Palier.GetSize()-1;y>=0;y--)
		{
			if(Budget>=(m_TblRemiseFinanciere[x].m_Palier[y].m_Palier*TauxEuroFranc))
				return m_TblRemiseFinanciere[x].m_Palier[y].m_Coef;
		}
	}

	return 0.0;
}

///////////////////////////////////////////////////////////////////////////////////////////
// Calcul Remise Volume de messages (par nb spots moyen)
float CNoyau::DonneRemiseSpot(int Jour, long NbSpots, int &BorneInf, int &BorneSup, CString TypeMultiloc)
{
	// Pour TF1, il faudra cr�er la table Remise Spot Sp�ciale TF1, comme pour NRJ
	// Pour le moment en dur
	if (TypeMultiloc == "TF1")
	{
		// Init indice palier
		if (NbSpots < 25)
		{	
			BorneInf = 0;
			BorneSup = 24;
			return 0.0;
		}
		else if (NbSpots <= 50)
		{
			BorneInf = 25;
			BorneSup = 50;
			return 10.0;
		}
		else if (NbSpots <= 100)
		{
			BorneInf = 51;
			BorneSup = 100;
			return 15.0;
		}
		else if (NbSpots <= 200)
		{
			BorneInf = 101;
			BorneSup = 200;
			return 20.0;
		}
		else
		{
			BorneInf = 200;
			BorneSup = 999;
			return 25.0;
		}
	}
	else
	{
		COleDateTime Date=m_Debut + COleDateTimeSpan(Jour,0,0,0);
		int x=0;
		for(;x<m_TblRemiseSpot.GetSize();x++)
		{
			if(m_TblRemiseSpot[x].m_DateDebut<=Date) continue;
			break;
		}
		x--;
		if(x<0) return 0.0;
		for(int y=m_TblRemiseSpot[x].m_Palier.GetSize()-1;y>=0;y--)
		{
			if(NbSpots>=m_TblRemiseSpot[x].m_Palier[y].m_Palier)
				return m_TblRemiseSpot[x].m_Palier[y].m_Coef;
		}
	}

	return 0.0;
	
}

///////////////////////////////////////////////////////////////////////////////////////////
// Calcul Remise Station/Villes 
float CNoyau::DonneRemiseStationVille(int Jour, long NbStaVil, int &BorneInf, int &BorneSup, CString TypeMultiloc)
{
	// Pour TF1, il faudra cr�er la table Remise Station Ville Sp�ciale TF1
	// Pour le moment en dur
	if (TypeMultiloc == "TF1")
	{
		// Init indice palier
		if (NbStaVil < 2)
		{
			BorneInf = 0;
			BorneSup = 1;
			return 0.0;
		}
		else if (NbStaVil <= 5)
		{
			BorneInf = 2;
			BorneSup = 5;
			return 5.0;
		}
		else if (NbStaVil <= 10)
		{
			BorneInf = 6;
			BorneSup = 10;
			return 10.0;
		}
		else if (NbStaVil <= 15)
		{
			BorneInf = 11;
			BorneSup = 15;
			return 15.0;
		}
		else
		{
			BorneInf = 15;
			BorneSup = 999;
			return 20.0;
		}
	}
	else
	{
		COleDateTime Date=m_Debut + COleDateTimeSpan(Jour,0,0,0);
		int x=0;
		for(;x < m_TblRemiseStaVil.GetSize(); x++)
		{
			if(m_TblRemiseStaVil[x].m_DateDebut <= Date) continue;
			break;
		}
		x--;

		if(x<0) return 0.0;
		for(int y = m_TblRemiseStaVil[x].m_Palier.GetSize()-1; y>=0; y--)
		{
			if(NbStaVil >= m_TblRemiseStaVil[x].m_Palier[y].m_Palier)
				return m_TblRemiseStaVil[x].m_Palier[y].m_Coef;
		}
	}

	return 0.0;
}

float CNoyau::DonneRemiseFinanciereRegion(int Jour, long Budget,bool PrixEnEuro,float TauxEuroFranc)
{
	COleDateTime theDate;
	theDate=m_Debut + COleDateTimeSpan(0,0,0,0);
	int x=0;
	for(;x<m_TblRemiseFinanciereRegion.GetSize();x++)
	{
		if(m_TblRemiseFinanciereRegion[x].m_DateDebut<=theDate) continue;
		break;
	}
	x--;
	if(x<0) return 0.0;
	if (PrixEnEuro)
	{
		for(int y=m_TblRemiseFinanciereRegion[x].m_Palier.GetSize()-1;y>=0;y--)
		{
			float ValRemise = m_TblRemiseFinanciereRegion[x].m_Palier[y].m_Palier;
			if(Budget>=m_TblRemiseFinanciereRegion[x].m_Palier[y].m_Palier)
				return m_TblRemiseFinanciereRegion[x].m_Palier[y].m_Coef;
		}
	}
	else
	{
		// Attention les paliers sont en euros !!!
		for(int y=m_TblRemiseFinanciereRegion[x].m_Palier.GetSize()-1;y>=0;y--)
		{
			if(Budget>=(m_TblRemiseFinanciereRegion[x].m_Palier[y].m_Palier*TauxEuroFranc))
				return m_TblRemiseFinanciereRegion[x].m_Palier[y].m_Coef;
		}
	}

	return 0.0;
}

float CNoyau::DonneRemiseSpotRegion(int Jour, long NbSpots)
{
	COleDateTime Date=m_Debut + COleDateTimeSpan(Jour,0,0,0);
	int x=0;
	for(;x<m_TblRemiseSpotRegion.GetSize();x++)
	{
		if(m_TblRemiseSpotRegion[x].m_DateDebut<=Date) continue;
		break;
	}
	x--;
	if(x<0) return 0.0;
	for(int y=m_TblRemiseSpotRegion[x].m_Palier.GetSize()-1;y>=0;y--)
	{
		//float FSpot = m_TblRemiseSpotRegion[x].m_Palier[y].m_Palier;
		if(NbSpots>=m_TblRemiseSpotRegion[x].m_Palier[y].m_Palier)
			return m_TblRemiseSpotRegion[x].m_Palier[y].m_Coef;
	}
	return 0.0;
	
}

bool CNoyau::ChargerTabMois()
{
	COleDateTime DateCour;
	int MoisCour = 0;
	int NbMois;

	CMois InfoMois;

	// Calcul des mois en cours sur la p�riode
	m_TblMois.RemoveAll();
	
	MoisCour = m_Debut.GetMonth();
	InfoMois.NoAnnee = m_Debut.GetYear();
	InfoMois.NoMois = m_Debut.GetMonth();
	InfoMois.NoJour = m_Debut.GetDay();
	InfoMois.IndexJourPeriode = 0;

	if (m_Fin >= m_Debut)
	{
		// Bug / ALAIN 28/03/2003 calcul nb mois si mois cpomplet + 1 jour
		//for (DateCour = m_Debut;DateCour < m_Fin;DateCour +=1)
		for (DateCour = m_Debut;DateCour <= m_Fin;DateCour +=1)
		{
			if (DateCour.GetMonth() != MoisCour)
			{
				// stocke info mois pr�c�dent
				m_TblMois.Add(InfoMois);

				// pr�pare info mois suivant
				InfoMois.NoAnnee =  DateCour.GetYear();
				InfoMois.NoMois = DateCour.GetMonth();
				InfoMois.NoJour = DateCour.GetDay();
				InfoMois.NbJour = 1;

				// avant
				// InfoMois.NbJour = 0;
				InfoMois.IndexJourPeriode = (DateCour - m_Debut).GetDays();
				MoisCour = DateCour.GetMonth();
			}	
			else
				InfoMois.NbJour +=1;

		}

		// puis stocke dernier mois s'il y a lieu
		if (InfoMois.NbJour == 0) InfoMois.NbJour +=1;
		m_TblMois.Add(InfoMois);

	}

	/* bon mais probl�me si 1er juin 1 seul spot
	if (m_Fin >= m_Debut)
	{
		// Bug / ALAIN 28/03/2003 calcul nb mois si mois cpomplet + 1 jour
		for (DateCour = m_Debut;DateCour < m_Fin;DateCour +=1)
		{
			if (DateCour.GetMonth() != MoisCour)
			{
				// stocke info mois pr�c�dent
				m_TblMois.Add(InfoMois);

				// pr�pare info mois suivant
				InfoMois.NoAnnee =  DateCour.GetYear();
				InfoMois.NoMois = DateCour.GetMonth();
				InfoMois.NoJour = DateCour.GetDay();
				InfoMois.NbJour = 1;
				InfoMois.IndexJourPeriode = (DateCour - m_Debut).GetDays();
				MoisCour = DateCour.GetMonth();
			}	
			else
				InfoMois.NbJour +=1;

		}

		// puis stocke dernier mois s'il y a lieu
		if (InfoMois.NbJour == 0) InfoMois.NbJour +=1;
		m_TblMois.Add(InfoMois);

	}
	*/
	
	NbMois = m_TblMois.GetSize();
	return true;

}


