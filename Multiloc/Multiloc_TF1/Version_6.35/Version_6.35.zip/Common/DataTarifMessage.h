// DataTarifMessage.h: interface for the CDataTarifMessage class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATATARIFMESSAGE_H__BA2C2120_8DBD_4EC2_94B4_89BA84F1E1D1__INCLUDED_)
#define AFX_DATATARIFMESSAGE_H__BA2C2120_8DBD_4EC2_94B4_89BA84F1E1D1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataTarifMessage  
{
public:
	CDataTarifMessage();
	virtual ~CDataTarifMessage();

	CDataTarifMessage(const CDataTarifMessage &Source);				// Copy constructor
	CDataTarifMessage & operator=(const CDataTarifMessage &Source);	// Affectation operator

public:
	// datas
	float m_CoeffMessage;			// Coefficient message
	COleDateTime m_DateFin;			// date fin prise en compte tarif
};

#endif // !defined(AFX_DATATARIFMESSAGE_H__BA2C2120_8DBD_4EC2_94B4_89BA84F1E1D1__INCLUDED_)
