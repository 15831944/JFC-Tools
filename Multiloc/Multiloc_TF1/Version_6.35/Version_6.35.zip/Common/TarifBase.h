// TarifBase.h: interface for the CTarifBase class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TARIFBASE_H__C1A07F30_B797_4AFC_BBB4_C08B3E931275__INCLUDED_)
#define AFX_TARIFBASE_H__C1A07F30_B797_4AFC_BBB4_C08B3E931275__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>		// MFC template library
#include "TblTarifBase.h"

class CTarifBase  
{
public:
	CTarifBase();
	virtual ~CTarifBase();

	CTarifBase(const CTarifBase &Source);					// Copy constructor
	CTarifBase & operator=(const CTarifBase &Source);		// Copy operator
	CTarifBase & operator=(const CTblTarifBase &Source);	// Copy operator
	bool operator<(const CTarifBase &Source);				// Operator <

	long m_NrVille;					// Numero unique de la ville
	long m_NrStation;				// Numero unique de la station
	COleDateTime m_DateDebut;		// Date debut
	COleDateTime m_DateFin;			// Date fin

	// Tarif de base 
	long m_TarifBase;				// Tarif de base *100
	
    // Frais d'antenne
	int m_FraisAntenne;				// Frais de mise � l'antenne
	
};

typedef	CArray<CTarifBase,CTarifBase&> CTarifBaseArray;


#endif // !defined(AFX_TARIFBASE_H__C1A07F30_B797_4AFC_BBB4_C08B3E931275__INCLUDED_)
