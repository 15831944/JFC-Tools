// TblGrps.cpp : implementation file
//

#include "stdafx.h"
#include "TblGrps.h"
#include "Grp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTblGrps

IMPLEMENT_DYNAMIC(CTblGrps, CDaoRecordset)

CTblGrps::CTblGrps(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CTblGrps)
	m_NrCible = 0;
	m_NrVille = 0;
	m_NrStation = 0;
	m_DateDebut = (DATE)0;
	m_nFields = 5;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CTblGrps::GetDefaultDBName()
{
	return _T("multiloc.mdb");
}

CString CTblGrps::GetDefaultSQL()
{
	return _T("[Grp]");
}

void CTblGrps::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CTblGrps)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Long(pFX, _T("[NrCible]"), m_NrCible);
	DFX_Long(pFX, _T("[NrVille]"), m_NrVille);
	DFX_Long(pFX, _T("[NrStation]"), m_NrStation);
	DFX_DateTime(pFX, _T("[DateDebut]"), m_DateDebut);
	DFX_Binary(pFX, _T("[Binary]"), m_Binary,1350,AFX_DAO_ENABLE_FIELD_CACHE);
	//}}AFX_FIELD_MAP
//	DFX_Binary(pFX, _T("[Binary]"), m_Binary);
}

/////////////////////////////////////////////////////////////////////////////
// CTblGrps diagnostics

#ifdef _DEBUG
void CTblGrps::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CTblGrps::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG

CTblGrps & CTblGrps::operator=(const CGrp &Source)
{
	m_DateDebut.SetDate(Source.m_DateDebut.GetYear(),Source.m_DateDebut.GetMonth(),Source.m_DateDebut.GetDay());
	m_NrVille=Source.m_NrVille;
	m_NrStation=Source.m_NrStation;
	m_NrCible=Source.m_NrCible;

	m_Binary.RemoveAll();
	for(int x=0;x<NB_JOURS;x++)
	{
		BYTE *pByte=(BYTE *)Source.m_Grp[x].GetData();
		for(int y=0;y<(NB_DEMIHEURE*sizeof(WORD));y++)
		{
			m_Binary.Add(*pByte);
			pByte++;
		}
	}
	return(*this);
}
