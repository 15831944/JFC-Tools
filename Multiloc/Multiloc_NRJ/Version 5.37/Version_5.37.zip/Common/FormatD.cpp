// FormatD.cpp: implementation of the CFormatD class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FormatD.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFormatD::CFormatD()
{
	m_Coef=0.0;
	m_Libelle=_T("");
}

CFormatD::~CFormatD()
{

}

CFormatD::CFormatD(const CFormatD &Source)
{
	*this=Source;
}

CFormatD & CFormatD::operator=(const CFormatD &Source)
{
	m_Libelle=Source.m_Libelle;
	m_Coef=Source.m_Coef;
	return(*this);
}

bool CFormatD::operator<(const CFormatD &Source)
{
	if(m_Libelle<Source.m_Libelle) return(TRUE);
	else return(FALSE);
}
