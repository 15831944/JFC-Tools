// Station.cpp: implementation of the CStation class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Station.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CStation::CStation()
{
	m_Libelle=_T("");
	m_NrUnique=0;
}

CStation::~CStation()
{

}

CStation::CStation(const CStation &Source)
{
	*this=Source;
}

CStation & CStation::operator=(const CStation &Source)
{
	m_NrUnique=Source.m_NrUnique;
	m_Libelle=Source.m_Libelle;
	return(*this);
}

CStation & CStation::operator=(const CTblStations &Source)
{
	m_NrUnique=Source.m_NrUnique;
	m_Libelle=Source.m_Libelle;
	return(*this);
}

bool CStation::operator<(const CStation &Source)
{
	if(m_Libelle<Source.m_Libelle) return(TRUE);
	else return(FALSE);
}
