// TblVolumes.cpp : implementation file
//

#include "stdafx.h"
#include "TblVolumes.h"
#include "Volume.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTblVolumes

IMPLEMENT_DYNAMIC(CTblVolumes, CDaoRecordset)

CTblVolumes::CTblVolumes(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CTblVolumes)
	m_DateDebut = (DATE)0;
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CTblVolumes::GetDefaultDBName()
{
	return _T("C:\\multiloc\\multiloc.mdb");
}

CString CTblVolumes::GetDefaultSQL()
{
	return _T("[RemiseFinanciere]");
}

void CTblVolumes::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CTblVolumes)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_DateTime(pFX, _T("[DateDebut]"), m_DateDebut);
	DFX_Binary(pFX, _T("[Data]"), m_Data,100,AFX_DAO_ENABLE_FIELD_CACHE);
	//}}AFX_FIELD_MAP
//	DFX_LongBinary(pFX, _T("[Data]"), m_Data);
}

/////////////////////////////////////////////////////////////////////////////
// CTblVolumes diagnostics

#ifdef _DEBUG
void CTblVolumes::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CTblVolumes::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG

CTblVolumes & CTblVolumes::operator=(const CVolume &Source)
{
	m_DateDebut.SetDate(Source.m_DateDebut.GetYear(),Source.m_DateDebut.GetMonth(),Source.m_DateDebut.GetDay());
	m_Data.RemoveAll();
	int Size=Source.m_Palier.GetSize();
	BYTE *pByte=(BYTE *)&Size;
	for(int x=0;x<sizeof(int);x++) m_Data.Add(pByte[x]);
	for(x=0;x<Source.m_Palier.GetSize();x++)
	{
		int y=0;
		CPalier Palier=Source.m_Palier[x];
		for(y=0,pByte=(BYTE *)&Palier.m_Palier;y<sizeof(Palier.m_Palier);y++) m_Data.Add(pByte[y]);
		for(y=0,pByte=(BYTE *)&Palier.m_Coef;y<sizeof(Palier.m_Coef);y++) m_Data.Add(pByte[y]);
	}
	return(*this);
}
