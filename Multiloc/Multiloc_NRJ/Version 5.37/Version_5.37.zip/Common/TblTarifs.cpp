// TblTarifs.cpp : implementation file
//
#include "stdafx.h"
#include "TblTarifs.h"
#include "Tarif.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTblTarifs

IMPLEMENT_DYNAMIC(CTblTarifs, CDaoRecordset)

CTblTarifs::CTblTarifs(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CTblTarifs)
	m_DateDebut		= (DATE)0;
	m_DateFin		= (DATE)0;
	m_FraisAntenne	= 0;
	m_TarifDeBase	= 0;
	m_NrStation		= 0;
	m_NrVille		= 0;
	m_nFields		= 7;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CTblTarifs::GetDefaultDBName()
{
	return _T("multiloc.mdb");
}

CString CTblTarifs::GetDefaultSQL()
{
	return _T("[Tarifs]");
}

void CTblTarifs::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CTblTarifs)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	//DFX_LongBinary(pFX, _T("[Binary]"), m_Binary);
	DFX_Binary(pFX, _T("[Binary]"), m_Binary, 1350,AFX_DAO_ENABLE_FIELD_CACHE);
	DFX_DateTime(pFX, _T("[DateDebut]"), m_DateDebut);
	DFX_DateTime(pFX, _T("[DateFin]"), m_DateFin);
	DFX_Short(pFX, _T("[FraisAntenne]"), m_FraisAntenne);
	DFX_Long(pFX, _T("[NrStation]"), m_NrStation);
	DFX_Long(pFX, _T("[NrVille]"), m_NrVille);
	DFX_Long(pFX, _T("[TarifBase]"), m_TarifDeBase);
	//}}AFX_FIELD_MAP
//	DFX_Binary(pFX, _T("[Binary]"), m_Binary);
}

/////////////////////////////////////////////////////////////////////////////
// CTblTarifs diagnostics

#ifdef _DEBUG
void CTblTarifs::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CTblTarifs::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG

CTblTarifs & CTblTarifs::operator=(const CTarif &Source)
{
	// Date d�but/date fin p�riode tarif
	m_DateDebut.SetDate(Source.m_DateDebut.GetYear(),Source.m_DateDebut.GetMonth(),Source.m_DateDebut.GetDay());
	m_DateFin.SetDate(Source.m_DateFin.GetYear(),Source.m_DateFin.GetMonth(),Source.m_DateFin.GetDay());

	// N� ville et station
	m_NrVille		= Source.m_NrVille;
	m_NrStation		= Source.m_NrStation;

	// Tarif de base
	m_TarifDeBase	= Source.m_TarifDeBase;  

	// Grille tarifaire
	m_Binary.RemoveAll();
	for(int x=0;x<NB_JOURS;x++)
	{
		BYTE *pByte=(BYTE *)Source.m_Tarif[x].GetData();
		for(int y=0;y<(NB_DEMIHEURE*sizeof(DWORD));y++)
		{
			m_Binary.Add(*pByte);
			pByte++;
		}
	}

	// Frais mise � l'antenne
	m_FraisAntenne = Source.m_FraisAntenne;

	return(*this);
}
