// Prime.cpp: implementation of the CPrime class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Prime.h"

#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPrime::CPrime()
{
	m_DateDebut=COleDateTime::GetCurrentTime();
	m_Palier.RemoveAll();
}

CPrime::~CPrime()
{

}

CPrime::CPrime(const CPrime &Source)
{
	*this=Source;
}

CPrime & CPrime::operator=(const CPrime &Source)
{
	m_DateDebut=Source.m_DateDebut;
	m_Palier.Copy(Source.m_Palier);
	return(*this);
}

CPrime & CPrime::operator=(const CTblPrimes &Source)
{
	m_DateDebut=Source.m_DateDebut;
	m_Palier.RemoveAll();
	int *pPtr=(int *)Source.m_Data.GetData();
	int Count=*pPtr; pPtr++;

	// Modif CGV 2002
	/*
	for(int x=0;x<Count;x++)
	{
		CPalier Palier;
		Palier.m_Palier=*pPtr;
		pPtr++;
		float *pFloat=(float*)pPtr;
		Palier.m_Coef=*pFloat;
		pFloat++;
		pPtr=(int *)pFloat;
		m_Palier.Add(Palier);
	}
	*/

	float *pFloat=(float*)pPtr;
	for(int x=0;x<Count;x++)
	{
		CPalier Palier;
		Palier.m_Palier=*pFloat;
		pFloat++;
		Palier.m_Coef=*pFloat;
		pFloat++;
		m_Palier.Add(Palier);
	}

	CPalier *pPalier=m_Palier.GetData();
	if(pPalier) std::sort(pPalier,(pPalier+m_Palier.GetSize()));
	return(*this);
}

bool CPrime::operator<(const CPrime &Source)
{
	if(m_DateDebut<Source.m_DateDebut) return(TRUE);
	else return(FALSE);
}
