#if !defined(AFX_TBLTARIFBASE_H__69DF45F3_11CC_4094_8A5A_BBCB0091EB55__INCLUDED_)
#define AFX_TBLTARIFBASE_H__69DF45F3_11CC_4094_8A5A_BBCB0091EB55__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TblTarifBase.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTblTarifBase DAO recordset
class CTarifBase;

class CTblTarifBase : public CDaoRecordset
{
public:
	CTblTarifBase(CDaoDatabase* pDatabase = NULL);
	CTblTarifBase & operator=(const CTarifBase &Source);// Copy operator
	DECLARE_DYNAMIC(CTblTarifBase)

// Field/Param Data
	//{{AFX_FIELD(CTblTarifBase, CDaoRecordset)
	long	m_NrStation;
	long	m_NrVille;
	COleDateTime	m_DateDebut;
	COleDateTime	m_DateFin;
	long	m_TarifBase;
	short	m_FraisAntenne;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTblTarifBase)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TBLTARIFBASE_H__69DF45F3_11CC_4094_8A5A_BBCB0091EB55__INCLUDED_)
