// TblVilles.cpp : implementation file
//

#include "stdafx.h"
#include "TblVilles.h"
#include "Ville.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTblVilles

IMPLEMENT_DYNAMIC(CTblVilles, CDaoRecordset)

CTblVilles::CTblVilles(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CTblVilles)
	m_NrUnique = 0;
	m_Libelle = _T("");
	m_Commune = 0;
	m_NbHabitantsInsee = 0;
	m_nFields = 4;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CTblVilles::GetDefaultDBName()
{
	return _T("multiloc.mdb");
}

CString CTblVilles::GetDefaultSQL()
{
	return _T("[Villes]");
}

void CTblVilles::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CTblVilles)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Long(pFX, _T("[NrUnique]"), m_NrUnique);
	DFX_Text(pFX, _T("[Libelle]"), m_Libelle);
	DFX_Long(pFX, _T("[Commune]"), m_Commune);
	DFX_Long(pFX, _T("[NbHabitantsInsee]"), m_NbHabitantsInsee);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CTblVilles diagnostics

#ifdef _DEBUG
void CTblVilles::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CTblVilles::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG

CTblVilles & CTblVilles::operator=(const CVille &Source)
{
//	m_NrUnique=Source.m_NrUnique;
	m_Libelle=Source.m_Libelle;
	m_Commune=Source.m_Commune;
	m_NbHabitantsInsee=Source.m_NbHabitantsInsee;
	return(*this);
}
