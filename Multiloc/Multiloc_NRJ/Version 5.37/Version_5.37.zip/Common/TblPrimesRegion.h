#if !defined(AFX_TBLPRIMESREGION_H__C76DA7A3_D2BA_11D5_8A64_0010B5865AAB__INCLUDED_)
#define AFX_TBLPRIMESREGION_H__C76DA7A3_D2BA_11D5_8A64_0010B5865AAB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TblPrimesRegion.h : header file
//

class CPrimeRegion;

/////////////////////////////////////////////////////////////////////////////
// CTblPrimesRegion DAO recordset

class CTblPrimesRegion : public CDaoRecordset
{
public:
	CTblPrimesRegion(CDaoDatabase* pDatabase = NULL);
	CTblPrimesRegion & operator=(const CPrimeRegion &Source);
	DECLARE_DYNAMIC(CTblPrimesRegion)

// Field/Param Data
	//{{AFX_FIELD(CTblPrimesRegion, CDaoRecordset)
	CByteArray	m_Data;
	COleDateTime	m_DateDebut;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTblPrimesRegion)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TBLPRIMESREGION_H__C76DA7A3_D2BA_11D5_8A64_0010B5865AAB__INCLUDED_)
