// DataTarifBase.h: interface for the CDataTarifBase class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATATARIFBASE_H__3E692887_03E3_4087_8D85_E8C2173FBFEB__INCLUDED_)
#define AFX_DATATARIFBASE_H__3E692887_03E3_4087_8D85_E8C2173FBFEB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataTarifBase  
{
public:
	CDataTarifBase();
	virtual ~CDataTarifBase();

	CDataTarifBase(const CDataTarifBase &Source);				// Copy constructor
	CDataTarifBase & operator=(const CDataTarifBase &Source);	// Affectation operator

public:
	// datas
	float m_TarifBase;			// Tarif de base
	float m_FraisAntenne;		// Frais d'antenne	
	COleDateTime m_DateFin;		// Date fin prise en compte tarif

};

#endif // !defined(AFX_DATATARIFBASE_H__3E692887_03E3_4087_8D85_E8C2173FBFEB__INCLUDED_)
