// DataTarifSaison.h: interface for the CDataTarifSaison class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATATARIFSAISON_H__0B7CD7DE_472C_4E03_9B94_82F0935976A4__INCLUDED_)
#define AFX_DATATARIFSAISON_H__0B7CD7DE_472C_4E03_9B94_82F0935976A4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataTarifSaison  
{
public:
	CDataTarifSaison();
	virtual ~CDataTarifSaison();

	CDataTarifSaison(const CDataTarifSaison &Source);				// Copy constructor
	CDataTarifSaison & operator=(const CDataTarifSaison &Source);	// Affectation operator

public:
	// datas
	float m_CoeffSaison;		// Coefficeint p�riode
	COleDateTime m_DateFin;		// Date fin prise en compte tarif

};

#endif // !defined(AFX_DATATARIFSAISON_H__0B7CD7DE_472C_4E03_9B94_82F0935976A4__INCLUDED_)
