// TblInfoStaVil.cpp : implementation file
//

#include "stdafx.h"
#include "TblInfoStaVil.h"
#include "InfoStaVil.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTblInfoStaVil

IMPLEMENT_DYNAMIC(CTblInfoStaVil, CDaoRecordset)

CTblInfoStaVil::CTblInfoStaVil(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CTblInfoStaVil)
	m_NrStation = 0;
	m_NrVille = 0;
	m_AdrMail = _T("");
	m_Fax = _T("");
	m_nFields = 4;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenTable;
}

CTblInfoStaVil & CTblInfoStaVil:: operator=(const CInfoStaVil &Source)
{
	m_NrStation = Source.m_NrStation;
	m_NrVille = Source.m_NrVille;
	m_AdrMail = Source.m_AdrMail;
	m_Fax = Source.m_Fax;
	return (*this);
}


CString CTblInfoStaVil::GetDefaultDBName()
{
	return _T("C:\\Projects\\Multiloc\\multiloc.mdb");
}

CString CTblInfoStaVil::GetDefaultSQL()
{
	return _T("[StationVilleInfo]");
}

void CTblInfoStaVil::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CTblInfoStaVil)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Long(pFX, _T("[NrStation]"), m_NrStation);
	DFX_Long(pFX, _T("[NrVille]"), m_NrVille);
	DFX_Text(pFX, _T("[AdrMail]"), m_AdrMail);
	DFX_Text(pFX, _T("[Fax]"), m_Fax);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CTblInfoStaVil diagnostics

#ifdef _DEBUG
void CTblInfoStaVil::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CTblInfoStaVil::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
