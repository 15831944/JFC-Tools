#if !defined(AFX_TBLVOLUMES_H__2D4C09A2_8907_11D2_AAF8_0000E86750A8__INCLUDED_)
#define AFX_TBLVOLUMES_H__2D4C09A2_8907_11D2_AAF8_0000E86750A8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TblVolumes.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTblVolumes DAO recordset

class CVolume;

class CTblVolumes : public CDaoRecordset
{
public:
	CTblVolumes(CDaoDatabase* pDatabase = NULL);
	CTblVolumes & operator=(const CVolume &Source);
	DECLARE_DYNAMIC(CTblVolumes)

// Field/Param Data
	//{{AFX_FIELD(CTblVolumes, CDaoRecordset)
	COleDateTime	m_DateDebut;
	CByteArray	m_Data;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTblVolumes)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TBLVOLUMES_H__2D4C09A2_8907_11D2_AAF8_0000E86750A8__INCLUDED_)
