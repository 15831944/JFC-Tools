// Format.h: interface for the CFormat class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FORMAT_H__2D4C09A3_8907_11D2_AAF8_0000E86750A8__INCLUDED_)
#define AFX_FORMAT_H__2D4C09A3_8907_11D2_AAF8_0000E86750A8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>		// MFC template library
#include "TblFormats.h"
#include "FormatD.h"	// Added by ClassView
class CFormat  
{
public:
	CFormat();
	virtual ~CFormat();

	CFormat(const CFormat &Source); // Copy constructor
	CFormat & operator=(const CFormat &Source);// Copy operator
	CFormat & operator=(const CTblFormats &Source);// Copy operator
	bool operator<(const CFormat &Source);// Operator <

	long m_NrStation; // Numero unique de la station
	COleDateTime m_DateDebut; // Date debut
	CFormatDArray m_Format;
};

typedef	CArray<CFormat,CFormat&> CFormatArray;

#endif // !defined(AFX_FORMAT_H__2D4C09A3_8907_11D2_AAF8_0000E86750A8__INCLUDED_)
