// CleTarifMessage.cpp: implementation of the CCleTarifMessage class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CleTarifMessage.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCleTarifMessage::CCleTarifMessage()
{
	// Init Cle
	m_NrStation = 0;
	m_NrJour    = 0;
	m_NrTrh     = 0;
	m_DateDeb.GetCurrentTime();
}

CCleTarifMessage::~CCleTarifMessage()
{

}

////////////////////////////////////////////////////////////////////////////////////////////
//   Fonction constructeur copy
CCleTarifMessage::CCleTarifMessage(const CCleTarifMessage &Source)
{
	*this=Source;
}

////////////////////////////////////////////////////////////////////////////////////////////
//   Fonction d'affectation
CCleTarifMessage & CCleTarifMessage::operator=(const CCleTarifMessage &Source)
{
	m_NrStation	= Source.m_NrStation;
	m_NrJour    = Source.m_NrJour; 
	m_NrTrh     = Source.m_NrTrh; 
	m_DateDeb	= Source.m_DateDeb; 
	
	return(*this);
}

////////////////////////////////////////////////////////////////////////////////////////////
//   Fonction de comparaison <
bool CCleTarifMessage::operator < (const CCleTarifMessage &Source)const
{
	if (m_NrStation < Source.m_NrStation)	return (true);
	if (m_NrStation > Source.m_NrStation)	return (false);

	if (m_NrJour	< Source.m_NrJour)		return (true);
	if (m_NrJour	> Source.m_NrJour)		return (false);

	if (m_NrTrh		< Source.m_NrTrh)		return (true);
	if (m_NrTrh		> Source.m_NrTrh)		return (false);

	if (m_DateDeb	< Source.m_DateDeb)		return (true);
	
	return (false);
}

////////////////////////////////////////////////////////////////////////////////////////////
//   Fonction de comparaison >
bool CCleTarifMessage::operator > (const CCleTarifMessage &Source)const
{
	if (m_NrStation > Source.m_NrStation)	return (true);
	if (m_NrStation < Source.m_NrStation)	return (false);

	if (m_NrJour	> Source.m_NrJour)		return (true);
	if (m_NrJour	< Source.m_NrJour)		return (false);

	if (m_NrTrh		> Source.m_NrTrh)		return (true);
	if (m_NrTrh		< Source.m_NrTrh)		return (false);

	if (m_DateDeb	> Source.m_DateDeb)		return (true);
	
	return (false);
}
