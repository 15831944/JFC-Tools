#if !defined(AFX_TBLFORMATS_H__2D4C09A0_8907_11D2_AAF8_0000E86750A8__INCLUDED_)
#define AFX_TBLFORMATS_H__2D4C09A0_8907_11D2_AAF8_0000E86750A8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TblFormats.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTblFormats DAO recordset

class CFormat;

class CTblFormats : public CDaoRecordset
{
public:
	CTblFormats(CDaoDatabase* pDatabase = NULL);
	CTblFormats & operator=(const CFormat &Source);
	DECLARE_DYNAMIC(CTblFormats)

// Field/Param Data
	//{{AFX_FIELD(CTblFormats, CDaoRecordset)
	long	m_NrStation;
	COleDateTime	m_DateDebut;
	CByteArray	m_Data;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTblFormats)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TBLFORMATS_H__2D4C09A0_8907_11D2_AAF8_0000E86750A8__INCLUDED_)
