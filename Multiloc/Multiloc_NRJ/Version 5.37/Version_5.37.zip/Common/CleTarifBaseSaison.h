// CleTarifBaseSaison.h: interface for the CCleTarifBaseSaison class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CLETARIFBASESAISON_H__57BDADA6_AEF9_40F0_A9AD_24806F17776D__INCLUDED_)
#define AFX_CLETARIFBASESAISON_H__57BDADA6_AEF9_40F0_A9AD_24806F17776D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCleTarifBaseSaison  
{
public:
	CCleTarifBaseSaison();
	virtual ~CCleTarifBaseSaison();

	CCleTarifBaseSaison(const CCleTarifBaseSaison &Source);				// Copy constructor
	CCleTarifBaseSaison & operator=(const CCleTarifBaseSaison &Source); // Affectation operator
	bool operator<(const CCleTarifBaseSaison &Source)const;				// Operator <
	bool operator>(const CCleTarifBaseSaison &Source)const;				// Operator <

public:
	// �lmts de la cl�
	long m_NrVille;					// Code ville
	long m_NrStation;				// Code station radio
	COleDateTime m_DateDeb;			// date d�but prise en compte tarif

};

#endif // !defined(AFX_CLETARIFBASESAISON_H__57BDADA6_AEF9_40F0_A9AD_24806F17776D__INCLUDED_)
