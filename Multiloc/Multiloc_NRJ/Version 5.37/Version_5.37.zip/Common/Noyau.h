// Noyau.h: interface for the CNoyau class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NOYAU_H__CF0FDC8C_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
#define AFX_NOYAU_H__CF0FDC8C_7E12_11D2_9B0D_004005327F6C__INCLUDED_

#include "InfoStaVil.h"			
#include "Station.h"			
#include "Cible.h"			
#include "Ville.h"			
#include "Tarif.h"			
#include "TarifBase.h"			
#include "TarifMessage.h"			
#include "TarifSaison.h"			
#include "Grp.h"			
#include "Format.h"			
#include "Volume.h"			
#include "Prime.h"			
#include "VolumeRegion.h"	
#include "PrimeRegion.h"	
#include "Mois.h"			

#include "CleTarifBaseSaison.h"
#include "DataTarifBase.h"
#include "DataTarifSaison.h"
#include "CleTarifMessage.h"
#include "DataTarifMessage.h"
#include "JLib.h"


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

typedef CMap<CString,LPCSTR,bool,bool> CFormatMap;	// Map des formats

class CNoyau  
{
public:
	CInfoStaVilArray m_TblInfoStaVil;
	bool ChargerTabMois();

	float DonneRemiseSpot(int Jour,long NbSpots);
	float DonneRemiseFinanciere(int Jour,long Budget,bool PrixEnEuro,float TauxEuroFranc);
	float DonneRemiseSpotRegion(int Jour,long NbSpots);
	float DonneRemiseFinanciereRegion(int Jour,long Budget,bool PrixEnEuro,float TauxEuroFranc);

	// Donne l'index liste des villes valide pour la station
	// Input : index de la station
	// Return : CDWordArray * sur l'index liste
	// CDWordArray * DonneVilles(int Station);
	// Charger Toutes les Grps du cible
	// Input : index de la cible
	// Return : true si OK else false
	bool ChargerCible(int Index);
	CNoyau(CString Database);
	virtual ~CNoyau();

	// Charger Toutes les tables entre dates (Date Debut et Fin) // Return : true si OK else false
	bool ChargerTable(COleDateTime Debut, COleDateTime Fin, int ModeTarif = 0);

	// Renvoie le tarif final d'un spot
	long DonneTarif(long NrStation, long NrVille, long NrFormat, int Jour, int Horaire,int ModeTarif,int ContratFidelite);

	// Renvoie le coefficient format
	float DonneCoeffFormat(long NrStation, long NrVille, long NrFormat, int Jour, int Horaire,int ModeTarif,int ContratFidelite);

	// Renvoie le tarif de base du spot
	float DonneTarifBase(long NrStation, long NrVille,COleDateTime DateSpot);

	// Renvoie le coefficient p�riode du spot
	float DonneCoeffPeriode(long NrStation, long NrVille,COleDateTime DateSpot,int ContratFidelite);

	// Renvoie le coefficient message du spot
	float DonneCoeffMessage(long NrStation, long NrVille, COleDateTime DateSpot, int Horaire,int ModeTarif);

	// Modification Coeff Floating Semaine de base pour certaines villes ou couples stations/ville
	float CoeffFloationgSemaineChange(long NrStation, long NrVille, float CoeffMessageFloatSemaine);

	// D�termine si ville est du groupe B ou C
	bool VilleBouVilleC(long NrVille);

	// D�termine si ville est du groupe A ou station Master
	bool VilleAouVilleMaster(long NrStation, long NrVille);

	// Chargement des infos code tarifs ville / station
	void LoadCodeTarifVille();

	// Chercher frais annonce Station/Ville
	float DonneFraisAnnonceSpot(long NrStation, long NrVille,int jour);

	// Cherche Info Stations/Ville
	CString DonneAdrMailStationVille(long NrStation, long NrVille);
	CString DonneFaxStationVille(long NrStation, long NrVille);

	// Mise � jour nouvelle adresse mail et fax
	bool MajMailFax(long NrStation,long NrVille,CString AdrMail,CString Fax);

	// Mise � jour dans database
	bool ModifierMailFax(short InxStationVille);
	bool AjouterMailFax(long NrStation,long NrVille,CString AdrMail,CString Fax);

	// Chercher un Grp
	// Return : Grp ou 0 si error
	float DonneGrp(long NrStation, long NrVille, int Jour, int Horaire);

	CStationArray	m_TblStation;	// Table des Stations 
	CVilleArray		*m_pTblVille;	// Table des Villes[Station]
	
	// MULTILOC3 / table des infos villes
	CCibleArray		m_TblCible;		// Table des Cibles
	CStringArray	m_TblFormat;	// Table des formats unique
	CVilleArray		m_Ville;		// Table des Villes
	CMoisArray		m_TblMois;		// Table des mois

	// Table Code Tarif Ville
	CArray <int,int&> m_CodeTarifVille;	

	// Table des masters (code radio * 1000 + code ville)
	CMap <long, long, bool, bool> m_MapMasterStationVille;
	

	// Chercher un tarif (Return : Tarif ou -1 si error)
	// long DonneTarif(long NrStation, long NrVille, long NrFormat, int Jour, int Horaire);
	// bool ChargerTableRegion(COleDateTime Debut, COleDateTime Fin);

protected:
	CString m_Path;
	bool LoadRemiseSpots			(CDaoDatabase &Db);
	bool LoadRemiseFinanciere		(CDaoDatabase &Db);
	bool LoadRemiseSpotsRegion		(CDaoDatabase &Db);
	bool LoadRemiseFinanciereRegion	(CDaoDatabase &Db);
	bool LoadFormats				(CDaoDatabase &Db, int ModeTarif);
	bool LoadTables();
	bool LoadVilles					(CDaoDatabase &Db);
	bool LoadStations				(CDaoDatabase &Db);
	bool LoadCibles					(CDaoDatabase &Db);

	// Chargement tarif (ancien format)
	bool LoadTarifs					(CDaoDatabase &Db);

	// Chargement des nouvelles bases tarifaires
	bool LoadTarifBase				(CDaoDatabase &Db);
	bool LoadTarifMessage			(CDaoDatabase &Db);
	bool LoadTarifSaison			(CDaoDatabase &Db);

	// Maps des bases tarifaires
	JMap <CCleTarifBaseSaison,CDataTarifBase>	m_MapTarifBase;
	JMap <CCleTarifMessage,CDataTarifMessage>	m_MapTarifMessage;
	JMap <CCleTarifBaseSaison,CDataTarifSaison> m_MapTarifSaison;

	bool LoadGrps();
	bool LoadInfoStaVil				(CDaoDatabase &Db);

	COleDateTime	m_Fin;
	COleDateTime	m_Debut;
	int				m_Cible;
	bool			m_fInit;							// Flag d'initialisation 

	bool			m_fTarifBase_Init;					// Flag d'initialisation Tarif de Base
	bool			m_fTarifMessage_Init;				// Flag d'initialisation Tarif Messages
	bool			m_fTarifSaison_Init;				// Flag d'initialisation Tarif P�riode

	bool			m_fSpots_Init;						// Flag d'initialisation Prime
	bool			m_fFinanciere_Init;					// Flag d'initialisation Volume
	bool			m_fFormat_Init;						// Flag d'initialisation Format
	bool			m_fGrp_Init;						// Flag d'initialisation Grp

	CTarifArray **	m_pTblTarif;						// Table des Tarifs

	CGrpArray **		m_pTblGrp;						// Table des Grps
	CFormatArray *		m_pTblFormat;					// Table des Formats * Stations
	CVolumeArray		m_TblRemiseFinanciere;			// Table des remises financiere
	CPrimeArray			m_TblRemiseSpot;				// Table des remise spots
	CVolumeRegionArray	m_TblRemiseFinanciereRegion;	// Table des remises financiere
	CPrimeRegionArray	m_TblRemiseSpotRegion;			// Table des remise spots
	CStationArray		m_Station;						// Table des Stations 
	CFormatMap *		m_pMapTblFormat;				// Map des formats * Stations
};

#endif // !defined(AFX_NOYAU_H__CF0FDC8C_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
