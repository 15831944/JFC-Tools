// FormatD.h: interface for the CFormatD class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FORMATD_H__2D4C09A8_8907_11D2_AAF8_0000E86750A8__INCLUDED_)
#define AFX_FORMATD_H__2D4C09A8_8907_11D2_AAF8_0000E86750A8__INCLUDED_

#include <afxtempl.h>		// MFC template library

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFormatD  
{
public:
	CFormatD();
	virtual ~CFormatD();

	CFormatD(const CFormatD &Source); // Copy constructor
	CFormatD & operator=(const CFormatD &Source);// Copy operator
	bool operator<(const CFormatD &Source);// Operator <
	CString m_Libelle;
	float m_Coef;
};

typedef	CArray<CFormatD,CFormatD&> CFormatDArray;

#endif // !defined(AFX_FORMATD_H__2D4C09A8_8907_11D2_AAF8_0000E86750A8__INCLUDED_)
