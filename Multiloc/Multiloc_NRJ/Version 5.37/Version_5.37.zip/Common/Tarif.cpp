// Tarif.cpp: implementation of the CTarif class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Tarif.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTarif::CTarif()
{
	m_NrStation=0;
	m_NrVille=0;
	COleDateTime Date=COleDateTime::GetCurrentTime();
	m_DateDebut.SetDate(Date.GetYear(),Date.GetMonth(),Date.GetDay());
	m_DateFin.SetDate(Date.GetYear(),Date.GetMonth(),Date.GetDay());
	m_TarifDeBase = 0;
	for(int x=0;x<NB_JOURS;x++)
	{
		m_Tarif[x].SetSize(NB_DEMIHEURE);
		for(int y=0;y<NB_DEMIHEURE;y++)
		{
			m_Tarif[x][y]=0;
		}
	}
	m_FraisAntenne = 0;
}

CTarif::~CTarif()
{

}

CTarif::CTarif(const CTarif &Source)
{
	*this=Source;
}

CTarif & CTarif::operator=(const CTarif &Source)
{
	m_DateDebut		= Source.m_DateDebut;
	m_DateFin		= Source.m_DateFin;
	m_NrVille		= Source.m_NrVille;
	m_NrStation		= Source.m_NrStation;

	// Le tarif de base
	m_TarifDeBase	= Source.m_TarifDeBase; 

	// la grille tarifaire par tranche horaire (49 1/2 heures)
	for(int x=0;x<NB_JOURS;x++)
	{
		m_Tarif[x].Copy(Source.m_Tarif[x]);
	}

	// Les frais d'antenne
	m_FraisAntenne	= Source.m_FraisAntenne;

	return(*this);
}

CTarif & CTarif::operator=(const CTblTarifs &Source)
{
	m_DateDebut		= Source.m_DateDebut;
	m_DateFin		= Source.m_DateFin;
	m_NrVille		= Source.m_NrVille;
	m_NrStation     = Source.m_NrStation;

	// Tarif de base
	m_TarifDeBase	= Source.m_TarifDeBase; 

	// Grille tarifaire
	DWORD *pDWord=(DWORD *)Source.m_Binary.GetData();
	for(int x=0;x<NB_JOURS;x++)
	{
		for(int y=0;y<NB_DEMIHEURE;y++)
		{
			m_Tarif[x][y]=*pDWord;
			pDWord++;
		}
	}
	m_FraisAntenne=Source.m_FraisAntenne;
	return(*this);
}

/*
bool CTarif::operator<(const CTarif &Source)
{
	if(m_NrStation<Source.m_NrStation) return(TRUE);
	if(m_NrVille<Source.m_NrVille) return(TRUE);
	if(m_DateDebut<Source.m_DateDebut) return(TRUE);
	if(m_DateFin<Source.m_DateFin) return(TRUE);
	else return(FALSE);
}
*/

bool CTarif::operator<(const CTarif &Source)
{
    if(m_NrStation<Source.m_NrStation) return(TRUE);
    if(m_NrVille<Source.m_NrVille) return(TRUE);
    if(m_DateDebut<Source.m_DateDebut) return(TRUE);
    // if(m_DateFin<Source.m_DateFin) return(TRUE);
    return(FALSE);
}