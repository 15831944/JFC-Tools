#if !defined(AFX_TBLPRIMES_H__2D4C09A1_8907_11D2_AAF8_0000E86750A8__INCLUDED_)
#define AFX_TBLPRIMES_H__2D4C09A1_8907_11D2_AAF8_0000E86750A8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TblPrimes.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTblPrimes DAO recordset

class CPrime;

class CTblPrimes : public CDaoRecordset
{
public:
	CTblPrimes(CDaoDatabase* pDatabase = NULL);
	CTblPrimes & operator=(const CPrime &Source);
	DECLARE_DYNAMIC(CTblPrimes)

// Field/Param Data
	//{{AFX_FIELD(CTblPrimes, CDaoRecordset)
	COleDateTime	m_DateDebut;
	CByteArray	m_Data;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTblPrimes)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TBLPRIMES_H__2D4C09A1_8907_11D2_AAF8_0000E86750A8__INCLUDED_)
