// Tarif.h: interface for the CTarif class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TARIF_H__CF0FDC8A_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
#define AFX_TARIF_H__CF0FDC8A_7E12_11D2_9B0D_004005327F6C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>		// MFC template library
#include "TblTarifs.h"

class CTarif  
{
	#define NB_JOURS 7
	#define NB_DEMIHEURE 48
public:
	CTarif();
	virtual ~CTarif();

	CTarif(const CTarif &Source); // Copy constructor
	CTarif & operator=(const CTarif &Source);// Copy operator
	CTarif & operator=(const CTblTarifs &Source);// Copy operator
	bool operator<(const CTarif &Source);// Operator <

	long m_NrVille;					// Numero unique de la ville
	long m_NrStation;				// Numero unique de la station
	COleDateTime m_DateDebut;		// Date debut
	COleDateTime m_DateFin;			// Date fin

	// Ajout Tarif de base (servira pour les remises sp�ciales)
	long m_TarifDeBase;				// Tarif de base *100
	CDWordArray m_Tarif[NB_JOURS];	// Tarifs en francs NB_JOURS * NB_QHEURES
   
	int m_FraisAntenne;				// Frais de mise � l'antenne


};

typedef	CArray<CTarif,CTarif&> CTarifArray;

#endif // !defined(AFX_TARIF_H__CF0FDC8A_7E12_11D2_9B0D_004005327F6C__INCLUDED_)
