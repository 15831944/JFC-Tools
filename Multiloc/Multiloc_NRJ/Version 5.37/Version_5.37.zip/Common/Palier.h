// Palier.h: interface for the CPalier class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PALIER_H__2D4C09A7_8907_11D2_AAF8_0000E86750A8__INCLUDED_)
#define AFX_PALIER_H__2D4C09A7_8907_11D2_AAF8_0000E86750A8__INCLUDED_

#include <afxtempl.h>		// MFC template library

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPalier  
{
public:
	CPalier();
	virtual ~CPalier();

	CPalier(const CPalier &Source); // Copy constructor
	CPalier & operator=(const CPalier &Source);// Copy operator
	bool operator<(const CPalier &Source);// Operator <
	float m_Coef;
	float m_Palier;
	//int m_Palier;
};

typedef	CArray<CPalier,CPalier&> CPalierArray;

#endif // !defined(AFX_PALIER_H__2D4C09A7_8907_11D2_AAF8_0000E86750A8__INCLUDED_)
