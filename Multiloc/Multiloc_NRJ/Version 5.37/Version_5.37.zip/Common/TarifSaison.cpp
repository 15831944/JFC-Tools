// TarifSaison.cpp: implementation of the CTarifSaison class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TarifSaison.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTarifSaison::CTarifSaison()
{

}

CTarifSaison::~CTarifSaison()
{

}

CTarifSaison::CTarifSaison(const CTarifSaison &Source)
{
	*this=Source;
}

CTarifSaison & CTarifSaison::operator=(const CTarifSaison &Source)
{
	// Date d�but et fin 
	m_DateDebut		= Source.m_DateDebut;
	m_DateFin		= Source.m_DateFin;

	// N� station
	m_NrStation		= Source.m_NrStation;

	// N� Ville
	m_NrVille		= Source.m_NrVille;
	
	// Coeff Saisonnier
	m_CoeffSaison   = Source.m_CoeffSaison;  

	return(*this);
}

CTarifSaison & CTarifSaison::operator=(const CTblTarifSaison &Source)
{
	// Date d�but et fin p�riode
	m_DateDebut		= Source.m_DateDebut;
	m_DateFin		= Source.m_DateFin;

	// N� station
	m_NrStation		= Source.m_NrStation;

	// N� Ville
	m_NrVille		= Source.m_NrVille;
	
	// Coeff Saisonnier
	m_CoeffSaison   = Source.m_CoeffSaison;  

	return(*this);
}

bool CTarifSaison::operator<(const CTarifSaison &Source)
{
    if(m_NrStation<Source.m_NrStation) return(TRUE);
    if(m_NrVille<Source.m_NrVille) return(TRUE);
    if(m_DateDebut<Source.m_DateDebut) return(TRUE);
    
    return(FALSE);
}

