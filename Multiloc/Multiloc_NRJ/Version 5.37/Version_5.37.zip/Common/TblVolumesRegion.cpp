// TblVolumesRegion.cpp : implementation file
//

#include "stdafx.h"
#include "TblVolumesRegion.h"
#include "VolumeRegion.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTblVolumesRegion

IMPLEMENT_DYNAMIC(CTblVolumesRegion, CDaoRecordset)

CTblVolumesRegion::CTblVolumesRegion(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CTblVolumesRegion)
	m_DateDebut = (DATE)0;
	m_nFields = 2;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}

CString CTblVolumesRegion::GetDefaultDBName()
{
	return _T("D:\\Projects\\Multiloc\\Multiloc.mdb");
}

CString CTblVolumesRegion::GetDefaultSQL()
{
	return _T("[RemiseFinanciereRegion]");
}

void CTblVolumesRegion::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CTblVolumesRegion)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_DateTime(pFX, _T("[DateDebut]"), m_DateDebut);
	DFX_Binary(pFX, _T("[Data]"), m_Data,100,AFX_DAO_ENABLE_FIELD_CACHE);
	//}}AFX_FIELD_MAP
}

CTblVolumesRegion & CTblVolumesRegion::operator=(const CVolumeRegion &Source)
{
	m_DateDebut.SetDate(Source.m_DateDebut.GetYear(),Source.m_DateDebut.GetMonth(),Source.m_DateDebut.GetDay());
	m_Data.RemoveAll();
	int Size=Source.m_Palier.GetSize();
	BYTE *pByte=(BYTE *)&Size;
	for(int x=0;x<sizeof(int);x++) m_Data.Add(pByte[x]);
	for(x=0;x<Source.m_Palier.GetSize();x++)
	{
		int y=0;
		CPalier Palier=Source.m_Palier[x];
		for(y=0,pByte=(BYTE *)&Palier.m_Palier;y<sizeof(Palier.m_Palier);y++) m_Data.Add(pByte[y]);
		for(y=0,pByte=(BYTE *)&Palier.m_Coef;y<sizeof(Palier.m_Coef);y++) m_Data.Add(pByte[y]);
	}
	return(*this);
}


/////////////////////////////////////////////////////////////////////////////
// CTblVolumesRegion diagnostics

#ifdef _DEBUG
void CTblVolumesRegion::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CTblVolumesRegion::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
