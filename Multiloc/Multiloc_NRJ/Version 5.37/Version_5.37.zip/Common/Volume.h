// Volume.h: interface for the CVolume class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VOLUME_H__2D4C09A4_8907_11D2_AAF8_0000E86750A8__INCLUDED_)
#define AFX_VOLUME_H__2D4C09A4_8907_11D2_AAF8_0000E86750A8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>		// MFC template library
#include "TblVolumes.h"
#include "Palier.h"	// Added by ClassView

class CVolume  
{
public:
	CVolume();
	virtual ~CVolume();

	CVolume(const CVolume &Source); // Copy constructor
	CVolume & operator=(const CVolume &Source);// Copy operator
	CVolume & operator=(const CTblVolumes &Source);// Copy operator
	bool operator<(const CVolume &Source);// Operator <

	COleDateTime m_DateDebut; // Date debut
	CPalierArray m_Palier; // Liste de Paliers
};

typedef	CArray<CVolume,CVolume&> CVolumeArray;

#endif // !defined(AFX_VOLUME_H__2D4C09A4_8907_11D2_AAF8_0000E86750A8__INCLUDED_)
