#if !defined(AFX_TBLINFOSTAVIL_H__08584F77_BF18_425D_B105_EDD14F374816__INCLUDED_)
#define AFX_TBLINFOSTAVIL_H__08584F77_BF18_425D_B105_EDD14F374816__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TblInfoStaVil.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTblInfoStaVil DAO recordset

class CInfoStaVil;

class CTblInfoStaVil : public CDaoRecordset
{
public:
	CTblInfoStaVil(CDaoDatabase* pDatabase = NULL);
	CTblInfoStaVil & operator=(const CInfoStaVil &Source);// Copy operator
	DECLARE_DYNAMIC(CTblInfoStaVil)

// Field/Param Data
	//{{AFX_FIELD(CTblInfoStaVil, CDaoRecordset)
	long	m_NrStation;
	long	m_NrVille;
	CString	m_AdrMail;
	CString	m_Fax;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTblInfoStaVil)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TBLINFOSTAVIL_H__08584F77_BF18_425D_B105_EDD14F374816__INCLUDED_)
