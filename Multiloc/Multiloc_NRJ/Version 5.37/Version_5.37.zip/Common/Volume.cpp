// Volume.cpp: implementation of the CVolume class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Volume.h"

#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CVolume::CVolume()
{
	m_DateDebut=COleDateTime::GetCurrentTime();
	m_Palier.RemoveAll();
}

CVolume::~CVolume()
{

}

CVolume::CVolume(const CVolume &Source)
{
	*this=Source;
}

CVolume & CVolume::operator=(const CVolume &Source)
{
	m_DateDebut=Source.m_DateDebut;
	m_Palier.Copy(Source.m_Palier);
	return(*this);
}

CVolume & CVolume::operator=(const CTblVolumes &Source)
{
	m_DateDebut=Source.m_DateDebut;
	m_Palier.RemoveAll();
	int *pPtr=(int *)Source.m_Data.GetData();
	int Count=*pPtr; pPtr++;

	/* Modif suite � conversion palier en float (27/12/2001)
	for(int x=0;x<Count;x++)
	{
		CPalier Palier;
		Palier.m_Palier=*pPtr;
		pPtr++;
		float *pFloat=(float*)pPtr;
		Palier.m_Coef=*pFloat;
		pFloat++;
		pPtr=(int *)pFloat;
		m_Palier.Add(Palier);
	}
	*/

	float *pFloat=(float*)pPtr;

	for(int x=0;x<Count;x++)
	{
		CPalier Palier;
		Palier.m_Palier=*pFloat;
		pFloat++;
		Palier.m_Coef=*pFloat;
		pFloat++;
		m_Palier.Add(Palier);
	}

	CPalier *pPalier=m_Palier.GetData();
	if(pPalier) std::sort(pPalier,(pPalier+m_Palier.GetSize()));
	return(*this);
}

bool CVolume::operator<(const CVolume &Source)
{
	if(m_DateDebut<Source.m_DateDebut) return(TRUE);
	else return(FALSE);
}
