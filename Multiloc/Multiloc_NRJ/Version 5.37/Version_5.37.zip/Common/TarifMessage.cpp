// TarifMessage.cpp: implementation of the CTarifMessage class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TarifMessage.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTarifMessage::CTarifMessage()
{

}

CTarifMessage::~CTarifMessage()
{

}

CTarifMessage::CTarifMessage(const CTarifMessage &Source)
{
	*this=Source;
}

CTarifMessage & CTarifMessage::operator=(const CTarifMessage &Source)
{
	// Date d�but et fin 
	m_DateDebut		= Source.m_DateDebut;
	m_DateFin		= Source.m_DateFin;

	// N� station
	m_NrStation		= Source.m_NrStation;

	// N� Jour
	m_NrJour		= Source.m_NrJour;
	
	// N� Trh
	m_NrTrh			= Source.m_NrTrh;
	
	// Coeff Tranche
	m_CoeffTranche  = Source.m_CoeffTranche;  

	return(*this);
}

CTarifMessage & CTarifMessage::operator=(const CTblTarifMessage &Source)
{
	// Date d�but et fin p�riode
	m_DateDebut		= Source.m_DateDebut;
	m_DateFin		= Source.m_DateFin;

	// No station
	m_NrStation     = Source.m_NrStation;

	// N� Jour
	m_NrJour		= Source.m_NrJour;
	
	// N� Trh
	m_NrTrh			= Source.m_NrTrh;
	
	// Coeff Tranche
	m_CoeffTranche  = Source.m_CoeffTranche;  

	return(*this);
}

bool CTarifMessage::operator<(const CTarifMessage &Source)
{
    if(m_NrStation	<	Source.m_NrStation)	return(TRUE);
    if(m_NrJour		<	Source.m_NrJour)	return(TRUE);
    if(m_NrTrh		<	Source.m_NrTrh)		return(TRUE);
    
    return(FALSE);
}
