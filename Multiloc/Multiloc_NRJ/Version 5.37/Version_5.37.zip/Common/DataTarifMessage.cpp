// DataTarifMessage.cpp: implementation of the CDataTarifMessage class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DataTarifMessage.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataTarifMessage::CDataTarifMessage()
{
	// Init Datas
	m_CoeffMessage = 0.0;
	m_DateFin.GetCurrentTime(); 

}

CDataTarifMessage::~CDataTarifMessage()
{

}

////////////////////////////////////////////////////////////////////////////////////////////
//   Fonction constructeur copy
CDataTarifMessage::CDataTarifMessage(const CDataTarifMessage &Source)
{
	*this=Source;
}

////////////////////////////////////////////////////////////////////////////////////////////
//   Fonction d'affectation
CDataTarifMessage & CDataTarifMessage::operator=(const CDataTarifMessage &Source)
{
	m_CoeffMessage  = Source.m_CoeffMessage;
	m_DateFin		= Source.m_DateFin; 
	return(*this);
}
