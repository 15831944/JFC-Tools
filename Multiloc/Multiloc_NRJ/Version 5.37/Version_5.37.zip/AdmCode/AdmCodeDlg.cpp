// AdmCodeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "AdmCode.h"
#include "AdmCodeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAdmCodeDlg dialog

CAdmCodeDlg::CAdmCodeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAdmCodeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAdmCodeDlg)
	m_NomUtil = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CAdmCodeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAdmCodeDlg)
	DDX_Control(pDX, IDC_CADRE1, m_Cadre1);
	DDX_Control(pDX, IDC_LISTDISPOVILLES, m_ListDisposVilles);
	DDX_Control(pDX, IDC_BTN_CODEUTIL, m_BtnCreerCodeUtil);
	DDX_Control(pDX, IDC_CODEUTIL, m_CodeUtil);
	DDX_Control(pDX, IDC_SPIN1, m_ExchangeList);
	DDX_Control(pDX, IDC_LISTSELVILLES, m_ListSelVilles);
	DDX_Text(pDX, ID_EDIT_NOMUTIL, m_NomUtil);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAdmCodeDlg, CDialog)
	//{{AFX_MSG_MAP(CAdmCodeDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN1, OnDeltaposSpin1)
	ON_BN_CLICKED(IDC_BTN_CODEUTIL, OnBtnCodeutil)
	ON_EN_CHANGE(ID_EDIT_NOMUTIL, OnChangeEditNomutil)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAdmCodeDlg message handlers

BOOL CAdmCodeDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// Chargement des listes
	SetupData();
	UpdateData(false);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CAdmCodeDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CAdmCodeDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CRect rect;
	GetClientRect(&rect);

	if (IsIconic())
	{
		
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);

		// Couleur de fond bleu JFC
		CBrush fond(RGB_BleuJFC);
		dc.FillRect(rect,&fond);
	}
	else
	{
		// Couleur de fond bleu JFC
		CBrush fond(RGB_BleuJFC);
		dc.FillRect(rect,&fond);

		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CAdmCodeDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CAdmCodeDlg::SetupData()
{
	m_Data.Load();
	m_ListDisposVilles.ResetContent();
	if(m_Data.m_Villes.GetSize())
	{
		for(int x=0;x<m_Data.m_Villes.GetSize();x++)
		{
			CString String;
			int toto = m_Data.m_Villes[x].m_NrUnique;
			
			String.Format("%4d %s",m_Data.m_Villes[x].m_NrUnique,m_Data.m_Villes[x].m_Libelle);
			m_ListDisposVilles.AddString(String);
		}
		m_ListDisposVilles.SetCurSel(0);
		m_DataCopy=m_Data.m_Villes[0];
		m_CurData=0;

	}
	else
	{
		m_DataCopy.m_NrUnique=0;
		m_DataCopy.m_Libelle="";
		m_DataCopy.m_Commune=0;
		m_DataCopy.m_NbHabitantsInsee=0;
		m_CurData=-1;

	}
	UpdateData(false);
}


void CAdmCodeDlg::OnDeltaposSpin1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	int i;
	CString StrVille;
	CString StrVilleDeselect;

	// R�cup�ration �tat spin (up/down)
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;

	if (pNMUpDown->iDelta <= 0) 
	{
		// Insertion des villes dispos s�lectionn�es
		m_ListSelVilles.ResetContent();
		for (i= 0;i< m_ListDisposVilles.GetCount();i++)
		{
			if (m_ListDisposVilles.GetSel(i) > 0)
			{
				// R�cup�re nom de la ville
				m_ListDisposVilles.GetText(i,StrVille);

				// Ajout libell� dans la liste Utilisateur
				m_ListSelVilles.AddString(StrVille.Mid(4));
				int CVille = atoi(StrVille.Left(4));
				m_ListSelVilles.SetItemData(m_ListSelVilles.GetCount()-1,CVille); 
			}	
			
			m_CodeUtil.SetWindowText("");
		}

	}
	else
	{
		// Suppression des villes en cours // s�lectionn�es
		for (i= m_ListSelVilles.GetCount()-1;i>=0;i--)
		{
			if (m_ListSelVilles.GetSel(i) > 0)
			{
				m_ListSelVilles.GetText(i,StrVilleDeselect);
				m_ListSelVilles.DeleteString(i);

				// Recherche de cette ville dans liste dispo pour la d�valider
				for (int j= 0;j<m_ListDisposVilles.GetCount();j++)
				{
					if (m_ListDisposVilles.GetSel(j) > 0)
					{
						m_ListDisposVilles.GetText(j,StrVille);
						if (StrVille.Mid(4) == StrVilleDeselect)
							m_ListDisposVilles.SetSel(j,FALSE);
					}
				}
			}
			m_CodeUtil.SetWindowText("");
		}
	}

	*pResult = 0;
}



void CAdmCodeDlg::OnBtnCodeutil() 
{
	CString CodeUtil = "";
	int AsciiNom = 0;
	int AlphaNom = 0;
	int CodeNomVille = 0;
	int CodeVille;
	CString StrVille;
	CString StrCodeGlobal;
	int i;

	// Cr�ation du code Utilsateur d'acc�s aux x villes s�lectionn�es
	UpdateData(TRUE);
	if (m_NomUtil.GetLength() > 0)
	{

		if (m_ListSelVilles.GetCount() > 0)
		{
			// Somme code ascii nom utilisateur
			for (i=0;i<m_NomUtil.GetLength();i++)
			{
				CodeUtil.Format("%d",m_NomUtil.GetAt(i));
				AsciiNom = AsciiNom + atoi(CodeUtil);
			}
			CodeUtil.Format("%d",AsciiNom);

			// Somme code ascii nom utilisateur
			for (i=0;i<m_NomUtil.GetLength();i++)
			{
				CodeUtil.Format("%d",m_NomUtil.GetAt(i)-64);
				AlphaNom = AlphaNom + atoi(CodeUtil);
			}

			StrCodeGlobal = "";
			for (i=0;i<m_ListSelVilles.GetCount();i++)
			{
				// Code Nom = ((AsciiNom * N� Ville + AlphaNom * 5) mod 255)
				CodeNomVille = (AsciiNom * (i+1) + AlphaNom * 5) % 255;
				CodeVille = m_ListSelVilles.GetItemData(i);

				// Code Final ville = CodeNomVille + CodeVille
				CodeUtil.Format("%3x",CodeNomVille + CodeVille);
				CodeUtil.MakeUpper();
				StrCodeGlobal = StrCodeGlobal + CodeUtil;
			}
			StrCodeGlobal.Replace(" ","0");
			m_CodeUtil.SetWindowText(StrCodeGlobal);
			UpdateData(FALSE);
		}

		else
		{
			AfxMessageBox("Attention vous devez au moins s�lectionner 1 ville");
			m_CodeUtil.SetWindowText("");
		}

	}

	else
	{
		AfxMessageBox("Attention vous devez entrer un nom d'utilisateur");
		m_CodeUtil.SetWindowText("");
	}

	
}

void CAdmCodeDlg::OnChangeEditNomutil() 
{
	m_CodeUtil.SetWindowText("");
}
