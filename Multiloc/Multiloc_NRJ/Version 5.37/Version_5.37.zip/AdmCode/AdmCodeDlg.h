// AdmCodeDlg.h : header file
//

#if !defined(AFX_ADMCODEDLG_H__F8A0DCA2_E900_47CF_9C9A_7C7F1C5BA11F__INCLUDED_)
#define AFX_ADMCODEDLG_H__F8A0DCA2_E900_47CF_9C9A_7C7F1C5BA11F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DataVille.h"
#include "Obj_Gray.h"

/////////////////////////////////////////////////////////////////////////////
// CAdmCodeDlg dialog

class CAdmCodeDlg : public CDialog
{
// Construction
public:
	CAdmCodeDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CAdmCodeDlg)
	enum { IDD = IDD_ADMCODE_DIALOG };
	CObj_Gray	m_Cadre1;
	CListBox	m_ListDisposVilles;
	CButton	m_BtnCreerCodeUtil;
	CButton	m_CodeUtil;
	CSpinButtonCtrl	m_ExchangeList;
	CListBox	m_ListSelVilles;
	CString	m_NomUtil;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAdmCodeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CAdmCodeDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDeltaposSpin1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBtnCodeutil();
	afx_msg void OnChangeEditNomutil();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	void GetData();
	void SetupData();

	CVille m_DataCopy;
	int m_CurData;
	bool m_Mode_New;
	CDataVille m_Data;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADMCODEDLG_H__F8A0DCA2_E900_47CF_9C9A_7C7F1C5BA11F__INCLUDED_)
