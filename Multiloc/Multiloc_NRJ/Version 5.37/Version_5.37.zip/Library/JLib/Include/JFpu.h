//
// Fichier: JFpu.h
// Auteur:  Sylvain SAMMURI
// Date:    04/06/2002
//

// on inclut les d�finitions n�cessaires
#include "JLib.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_FPU_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_FPU_H

class JFpu
{
public:
	// le constructeur
	JFpu();

	// la fonction pour configurer le Fpu
	JVoid Configure(JBool Truncate = false);

	// la fonction pour mettre � jour les indicateurs
	JVoid UpdateFlags();

	// les fonctions pour r�cup�rer l'�tat des indicateurs
	JBool GetInvalidOperationFlag(JBool Update = false);
	JBool GetOutOfRangeFlag(JBool Update = false);
	JBool GetPrecisionFlag(JBool Update = false);	

	// la fonction pour r�initialiser les indicateurs
	JVoid ResetFlags();

	// la fonction pour r�tablir le Fpu
	JVoid Restore();

	// le destructeur
	~JFpu();

private:
	// les fonctions pour manipuler l'�tat du Fpu
	JUnt16 OnSetControlWord(JUnt16 Control);
	JUnt16 OnGetStatusWord(JBool Reset);

private:
	// l'op�rateur d'affectation
	JFpu & operator =(const JFpu & Source);

	// le constructeur copie
	JFpu(const JFpu & Source);

private:
	JUnt16 m_Control; // le mot de contr�le
	JUnt16 m_Status;  // le mot d'�tat
};

// fin de l'inclusion conditionnelle
#endif
