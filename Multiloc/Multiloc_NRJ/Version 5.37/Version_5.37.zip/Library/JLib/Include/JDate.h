//
// Fichier: JDate.h
// Auteur:  Sylvain SAMMURI
// Date:    04/06/2002
//

// on inclut les d�finitions n�cessaires
#include "JLib.h"
#include "JStream.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_DATE_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_DATE_H

class JDate
{
public:
	// les constructeurs
	JDate();
	JDate(const JDate & Source);

	// la fonction pour v�rifier la validit� de la date
	JBool IsValid() const;

	// les fonctions pour s�rialiser la date
	JVoid Send(JStream & Stream) const;
	JVoid Recv(JStream & Stream);

	// les fonctions pour manipuler la date
	JVoid SetDate(JInt32   Day, JInt32   Month, JInt32   Year);
	JVoid GetDate(JInt32 & Day, JInt32 & Month, JInt32 & Year) const;

	// la fonction pour r�cup�rer le jour de la semaine
	JInt32 GetDayOfWeek() const;

	// les fonctions pour r�cup�rer les dates particuli�res
	JDate GetDateOfWeek() const;
	JDate GetDateOfMonth() const;
	JDate GetDateOfYear() const;

	// l'op�rateur d'affectation
	JDate & operator =(const JDate & Source);

	// les op�rateurs arithm�tiques
	JDate operator +(JInt32 NbDays) const;
	JDate operator -(JInt32 NbDays) const;

	// l'op�rateur de soustraction de deux dates
	JInt32 operator -(const JDate & Reference) const;

	// les op�rateurs d'incr�mentation et de d�cr�mentation
	JVoid   operator +=(JInt32 NbDays);
	JVoid   operator -=(JInt32 NbDays);
	JDate & operator ++();
	JDate & operator --();
	JDate & operator ++(int);
	JDate & operator --(int);

	// les op�rateurs de comparaison
	JBool operator ==(const JDate & Reference) const;
	JBool operator !=(const JDate & Reference) const;
	JBool operator < (const JDate & Reference) const;
	JBool operator <=(const JDate & Reference) const;
	JBool operator > (const JDate & Reference) const;
	JBool operator >=(const JDate & Reference) const;
	
	// la fonction pour r�initialiser la date
	JVoid Reset();

	// le destructeur
	~JDate();

private:
	// la fonction pour v�rifier les dates
	JBool OnCheckDate(JInt32 Day, JInt32 Month, JInt32 Year) const;

private:
	// les fonctions pour manipuler les indices
	JVoid OnComputeDateToIndex(JInt32 Day, JInt32 Month, JInt32 Year, JInt32 & Index) const;
	JVoid OnComputeIndexToDate(JInt32 Index, JInt32 & Day, JInt32 & Month, JInt32 & Year) const;

private:
	// les fonctions pour ajouter des jours
	JBool OnAddDay(JInt32 & Index, JInt32 NbDays) const;
	JBool OnSubDay(JInt32 & Index, JInt32 NbDays) const;

private:
	// la fonction pour v�rifier les jours
	JBool OnCheckDeltaDay(JInt32 NbDays) const;

private:
	JInt32 m_Index; // l'indice de la date
};

// fin de l'inclusion conditionnelle
#endif
