//
// Fichier: JConnection.h
// Auteur:  Sylvain SAMMURI
// Date:    26/06/2002
//

// on inclut les d�finitions n�cessaires
#include "JStream.h"
#include "JSerialize.h"
#include "JCompress.h"
#include "JEncrypt.h"
#include "JDecrypt.h"
#include "JExpand.h"
#include "JPipe.h"
#include "JPath.h"
#include "JHost.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_CONNECTION_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_CONNECTION_H

class JConnection : public JStream
{
private:
	// le constructeur
	JConnection(JSerialize* pPrev, JSerialize* pNext);

public:
	// la fonction pour cr�er une instance
	static JConnection* Create(const JHost & Host, const JPath & Path);

	// le destructeur
	virtual ~JConnection();

private:
	// l'op�rateur d'affectation
	JConnection & operator =(const JConnection & Source);

	// le constructeur copie
	JConnection(const JConnection & Source);

private:
	JCompress* m_pCompress; // la compression des donn�es
	JEncrypt*  m_pEncrypt;  // l'encryptage des donn�es
	JDecrypt*  m_pDecrypt;  // le d�cryptage des donn�es
	JExpand*   m_pExpand;   // la d�compression des donn�es
	JPipe*     m_pPipe;     // le tube
};

// fin de l'inclusion conditionnelle
#endif
