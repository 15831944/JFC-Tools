//
// Fichier: JMemento.h
// Auteur:  Sylvain SAMMURI
// Date:    26/06/2002
//

// on inclut les d�finitions n�cessaires
#include "JStream.h"
#include "JSerialize.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_MEMENTO_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_MEMENTO_H

class JMemento : public JStream
{
private:
	// le constructeur
	JMemento(JSerialize* pPrev, JSerialize* pNext);

public:
	// la fonction pour cr�er une instance
	static JMemento* Create();

	// le destructeur
	virtual ~JMemento();

private:
	// l'op�rateur d'affectation
	JMemento & operator =(const JMemento & Source);

	// le constructeur copie
	JMemento(const JMemento & Source);

private:
	JMemory* m_pMemory; // la m�moire
};

// fin de l'inclusion conditionnelle
#endif
