//
// Fichier: JMemoryFull.h
// Auteur:  Sylvain SAMMURI
// Date:    04/06/2002
//

// on inclut les d�finitions n�cessaires
#include "JException.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_MEMORY_FULL_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_MEMORY_FULL_H

class JMemoryFull : public JException
{
private:
	// le constructeur
	JMemoryFull();

private:
	// l'unique instance de l'exception
	static JMemoryFull m_Instance;

public:
	// la fonction pour r�cup�rer l'instance de l'exception
	static JMemoryFull* GetInstance();

public:
	// la fonction pour r�cup�rer le message
	virtual const JChar* GetMessage() const;

	// le destructeur
	virtual ~JMemoryFull();

private:
	// l'op�rateur d'affectation
	JMemoryFull & operator =(const JMemoryFull & Source);

	// le constructeur copie
	JMemoryFull(const JMemoryFull & Source);
};

// fin de l'inclusion conditionnelle
#endif
