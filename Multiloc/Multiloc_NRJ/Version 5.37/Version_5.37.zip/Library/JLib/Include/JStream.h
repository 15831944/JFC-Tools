//
// Fichier: JStream.h
// Auteur:  Sylvain SAMMURI
// Date:    17/06/2002
//

// on inclut les d�finitions n�cessaires
#include "JLib.h"
#include "JSerialize.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_STREAM_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_STREAM_H

class JStream
{
protected:
	// le constructeur
	JStream(JSerialize* pPrev, JSerialize* pNext);

public:
	// la fonction pour tester le tampon
	virtual JBool IsEmpty();

	// les fonctions pour transf�rer les bool�ens
	virtual JVoid Send(JBool   Value);
	virtual JVoid Recv(JBool & Value);

	// les fonctions pour transf�rer les caract�res
	virtual JVoid Send(JChar   Value);
	virtual JVoid Recv(JChar & Value);

	// les fonctions pour transf�rer les entiers 8 bits
	virtual JVoid Send(JInt08   Value);
	virtual JVoid Send(JUnt08   Value);
	virtual JVoid Recv(JInt08 & Value);
	virtual JVoid Recv(JUnt08 & Value);

	// les fonctions pour transf�rer les entiers 16 bits
	virtual JVoid Send(JInt16   Value);
	virtual JVoid Send(JUnt16   Value);
	virtual JVoid Recv(JInt16 & Value);
	virtual JVoid Recv(JUnt16 & Value);

	// les fonctions pour transf�rer les entiers 32 bits
	virtual JVoid Send(JInt32   Value);
	virtual JVoid Send(JUnt32   Value);
	virtual JVoid Recv(JInt32 & Value);
	virtual JVoid Recv(JUnt32 & Value);

	// les fonctions pour transf�rer les flottants 32 bits
	virtual JVoid Send(JFlt32   Value);
	virtual JVoid Recv(JFlt32 & Value);

	// les fonctions pour transf�rer les flottants 64 bits
	virtual JVoid Send(JFlt64   Value);
	virtual JVoid Recv(JFlt64 & Value);

	// la fonction pour vider le tampon
	virtual JVoid Flush();

	// le destructeur
	virtual ~JStream();

private:
	// l'op�rateur d'affectation
	JStream & operator =(const JStream & Source);

	// le constructeur copie
	JStream(const JStream & Source);

private:
	JSerialize* m_pPrev; // le pr�c�dent
	JSerialize* m_pNext; // le suivant
};

// fin de l'inclusion conditionnelle
#endif
