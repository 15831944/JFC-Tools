//
// Fichier: JEncrypt.h
// Auteur:  Sylvain SAMMURI
// Date:    26/06/2002
//

// on inclut les d�finitions n�cessaires
#include "JSerialize.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_ENCRYPT_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_ENCRYPT_H

class JEncrypt : public JSerialize
{
private:
	// le constructeur
	JEncrypt(JSerialize* pNext);

public:
	// la fonction pour cr�er une instance
	static JEncrypt* Create(JSerialize* pNext);

public:
	// la fonction pour tester le tampon
	virtual JBool IsEmpty();

	// les fonctions pour transf�rer les donn�es
	virtual JVoid  Send(JUnt08 Data);
	virtual JUnt08 Recv();

	// la fonction pour vider le tampon
	virtual JVoid Flush();

	// le destructeur
	virtual ~JEncrypt();

private:
	// l'op�rateur d'affectation
	JEncrypt & operator =(const JEncrypt & Source);

	// le constructeur copie
	JEncrypt(const JEncrypt & Source);

private:
	JSerialize* m_pNext; // le suivant
};

// fin de l'inclusion conditionnelle
#endif
