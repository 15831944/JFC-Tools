//
// Fichier: JTime.h
// Auteur:  Sylvain SAMMURI
// Date:    04/06/2002
//

// on inclut les d�finitions n�cessaires
#include "JLib.h"
#include "JStream.h"

// on v�rifie que le fichier n'a pas d�j� �t� inclus
#ifndef JLIB_TIME_H

// on d�finit la macro pour �viter les inclusions multiples
#define JLIB_TIME_H

class JTime
{
public:
	// les constructeurs
	JTime();
	JTime(const JTime & Source);

	// la fonction pour v�rifier la validit� de l'heure
	JBool IsValid() const;

	// les fonctions pour s�rialiser l'heure
	JVoid Send(JStream & Stream) const;
	JVoid Recv(JStream & Stream);

	// les fonctions pour manipuler l'heure
	JVoid SetTime(JInt32   Hour, JInt32   Minute, JInt32   Second);
	JVoid GetTime(JInt32 & Hour, JInt32 & Minute, JInt32 & Second) const;

	// les fonctions pour r�cup�rer les heures particuli�res
	JTime GetTimeOfHour() const;
	JTime GetTimeOfMinute() const;

	// l'op�rateur d'affectation
	JTime & operator =(const JTime & Source);

	// les op�rateurs arithm�tiques
	JTime operator +(JInt32 NbSeconds) const;
	JTime operator -(JInt32 NbSeconds) const;

	// l'op�rateur de soustraction de deux heures
	JInt32 operator -(const JTime & Reference) const;

	// les op�rateurs d'incr�mentation et de d�cr�mentation
	JVoid   operator +=(JInt32 NbSeconds);
	JVoid   operator -=(JInt32 NbSeconds);
	JTime & operator ++();
	JTime & operator --();
	JTime & operator ++(int);
	JTime & operator --(int);

	// les op�rateurs de comparaison
	JBool operator ==(const JTime & Reference) const;
	JBool operator !=(const JTime & Reference) const;
	JBool operator < (const JTime & Reference) const;
	JBool operator <=(const JTime & Reference) const;
	JBool operator > (const JTime & Reference) const;
	JBool operator >=(const JTime & Reference) const;

	// la fonction pour r�initialiser l'heure
	JVoid Reset();

	// le destructeur
	~JTime();

private:
	// la fonction pour v�rifier les heures
	JBool OnCheckTime(JInt32 Hour, JInt32 Minute, JInt32 Second) const;

private:
	// les fonctions pour manipuler les indices
	JVoid OnComputeTimeToIndex(JInt32 Hour, JInt32 Minute, JInt32 Second, JInt32 & Index) const;
	JVoid OnComputeIndexToTime(JInt32 Index, JInt32 & Hour, JInt32 & Minute, JInt32 & Second) const;

private:
	// les fonctions pour ajouter des secondes
	JBool OnAddSeconde(JInt32 & Index, JInt32 NbSeconds) const;
	JBool OnSubSeconde(JInt32 & Index, JInt32 NbSeconds) const;

private:
	// la fonction pour v�rifier les secondes
	JBool OnCheckDeltaSeconde(JInt32 NbSeconds) const;

private:
	JInt32 m_Index; // l'indice de l'heure
};

// fin de l'inclusion conditionnelle
#endif
