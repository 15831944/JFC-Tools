// DataGrp.h: interface for the CDataGrp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATAGRP_H__E88DE141_7F96_11D2_9B0D_004005327F6C__INCLUDED_)
#define AFX_DATAGRP_H__E88DE141_7F96_11D2_9B0D_004005327F6C__INCLUDED_

#include "Grp.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataGrp  
{
public:
	int Delete(int Index);
	int Add(CGrp &Grp);
	int Modify(CGrp &Grp, int Index);
	bool Load(long NrStation, long NrVille, long NrCible);
	CGrpArray m_Grps;
	CDataGrp();
	virtual ~CDataGrp();

};

#endif // !defined(AFX_DATAGRP_H__E88DE141_7F96_11D2_9B0D_004005327F6C__INCLUDED_)
