#if !defined(AFX_MAILFAXDLG_H__EB844327_802B_4142_A4A9_44ADBFCB73F6__INCLUDED_)
#define AFX_MAILFAXDLG_H__EB844327_802B_4142_A4A9_44ADBFCB73F6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MailFaxDlg.h : header file
//

#include "DataMailFax.h"
#include "DataVille.h"
#include "DataStation.h"

/////////////////////////////////////////////////////////////////////////////
// CMailFaxDlg dialog

class CMailFaxDlg : public CDialog
{
// Construction
public:

	void SetupMailFax();
	void UpdateMailFax(bool Load);
	
	bool m_Mode_Modify;
	bool m_Mode_New;
	int m_CurMailFax;


	int m_CurStation;
	int m_CurVille;
	CDataMailFax m_MailFaxs;
	CDataVille m_Villes;
	CDataStation m_Stations;

	



	CMailFaxDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMailFaxDlg)
	enum { IDD = IDD_MAILFAX_DIALOG };
	CComboBox	m_ChoixStation;
	CComboBox	m_ChoixVille;
	CString	m_Fax;
	CString	m_AdrMail;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMailFaxDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	void UpdateButtons();
	CMailFax m_MailFaxCopy;
	void ClearMailFax();

	// Generated message map functions
	//{{AFX_MSG(CMailFaxDlg)
	afx_msg void OnSelchangeComboStation();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnSelchangeComboVille();
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnAjouter();
	afx_msg void OnBtnModifier();
	afx_msg void OnBtnSupprimer();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAILFAXDLG_H__EB844327_802B_4142_A4A9_44ADBFCB73F6__INCLUDED_)
