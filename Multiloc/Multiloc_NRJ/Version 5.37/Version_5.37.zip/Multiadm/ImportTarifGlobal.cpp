// ImportTarifGlobal.cpp : implementation file
//

#include "stdafx.h"
#include "multiadm.h"
#include "ImportTarifGlobal.h"
#include "ImportTarif.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CImportTarifGlobal dialog


CImportTarifGlobal::CImportTarifGlobal(CWnd* pParent /*=NULL*/)
	: CDialog(CImportTarifGlobal::IDD, pParent)
{
	//{{AFX_DATA_INIT(CImportTarifGlobal)
	m_ProgSave = _T("");
	//}}AFX_DATA_INIT
}


void CImportTarifGlobal::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CImportTarifGlobal)
	DDX_Control(pDX, IDC_PROGRESS_IMPORT, m_ProgressImport);
	DDX_Text(pDX, IDC_PROGSAVE, m_ProgSave);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CImportTarifGlobal, CDialog)
	//{{AFX_MSG_MAP(CImportTarifGlobal)
	ON_BN_CLICKED(IDC_IMPORT, OnImport)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CImportTarifGlobal message handlers

void CImportTarifGlobal::OnImport() 
{

	CStdioFile File;
	CImportTarif Import;
	CString FileTarif;

	/*
	// Fabrication du fichier Import Standard (comme avant) � partir du fichier g�n�rale
	if (Import.CreerFicImport(FileTarif,&m_ProgressImport))
	{
		// Import des tarifs
		Import.ImportGeneEuro(FileTarif,&m_ProgressImport);
	}
	else
		// Attention vraisemblablement un probl�me dans fichier g�n�rale des tarifs
		AfxMessageBox("Probl�me de cr�ation fichier transfert tarif, v�rifier votre fichier");
	*/

	CFileDialog Dialog(true,NULL,NULL,OFN_NOCHANGEDIR|OFN_ALLOWMULTISELECT,NULL,NULL);
	char *Buffer=new char[5050];
	Buffer[0]=0;
	Dialog.m_ofn.lpstrFile=Buffer;
	Dialog.m_ofn.nMaxFile=5000;
	
	if(Dialog.DoModal()==IDOK)
	{
		CWaitCursor Wait;
		POSITION Pos=Dialog.GetStartPosition();
		while(Pos)
		{
			
			FileTarif=Dialog.GetNextPathName(Pos);
		}

		// Verification si c'est bien un fichier englobant tous les tarifs
		if (FileTarif.Right(3) != "csv")
		{
			AfxMessageBox("Fichier non csv !!!");
			return;
		}
		else
		{
			if(!File.Open(FileTarif,CFile::modeRead|CFile::typeText))
			{
				AfxMessageBox("Ouverture du fichier impossible!");
				return;
			}

			File.Close();
		}

		// Import des tarifs (table tarif messages, tarif saisons, tarifs de base)
		Import.ImportGeneEuro(FileTarif,&m_ProgressImport,m_ProgSave);

	}
	
}

BOOL CImportTarifGlobal::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_ProgressImport.SetRange(0,100);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
