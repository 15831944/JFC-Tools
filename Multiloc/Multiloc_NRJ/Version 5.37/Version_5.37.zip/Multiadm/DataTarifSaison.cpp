// DataTarifSaison.cpp: implementation of the CDataTarifSaison class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiadm.h"
#include "DataTarifSaison.h"

#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataTarifSaison::CDataTarifSaison()
{

}

CDataTarifSaison::~CDataTarifSaison()
{

}

bool CDataTarifSaison::Load(long NrStation, long NrVille)
{
	m_TarifSaison.RemoveAll();
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",FALSE,TRUE);
		CTblTarifSaison Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation = %d AND NrVille = %d",NrStation,NrVille);
			if(Table.FindFirst(Search))
			{
				do
				{
					CTarifSaison TarifSaison;
					TarifSaison = Table;
					m_TarifSaison.Add(TarifSaison);
				}
				while(Table.FindNext(Search));
			}
		}
		Table.Close();
		Db.Close();
		CTarifSaison *pTarifSaison = m_TarifSaison.GetData();
		if(pTarifSaison) std::sort(pTarifSaison,(pTarifSaison + m_TarifSaison.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataTarifSaison::Modify(CTarifSaison &TarifSaison, int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifSaison Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation = %d AND NrVille = %d AND DateDebut = %s",
				m_TarifSaison[Index].m_NrStation,
				m_TarifSaison[Index].m_NrVille,
				m_TarifSaison[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table = TarifSaison;
				Table.Update();
				m_TarifSaison[Index] = TarifSaison;
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataTarifSaison::Add(CTarifSaison &TarifSaison)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifSaison Table(&Db);
		Table.Open();
		Table.AddNew();
		Table = TarifSaison;
		Table.Update();
		Table.Close();
		Db.Close();
		m_TarifSaison.Add(TarifSaison);
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataTarifSaison::Delete(int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifSaison Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation= %d AND NrVille = %d AND DateDebut = %s",
				           m_TarifSaison[Index].m_NrStation,
						   m_TarifSaison[Index].m_NrVille,
				           m_TarifSaison[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Delete();
				m_TarifSaison.RemoveAt(Index);
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}
