// DataVolumeRegion.cpp: implementation of the CDataVolumeRegion class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiadm.h"
#include "DataVolumeRegion.h"
#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataVolumeRegion::CDataVolumeRegion()
{

}

CDataVolumeRegion::~CDataVolumeRegion()
{

}

bool CDataVolumeRegion::Load()
{
	m_VolumesRegion.RemoveAll();
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",FALSE,TRUE);
		CTblVolumesRegion Table(&Db);
		Table.Open();
		while(!Table.IsEOF()) 
		{
			CVolumeRegion VolumeRegion;
			VolumeRegion=Table;
			m_VolumesRegion.Add(VolumeRegion);
			Table.MoveNext();
		}
		while(!Table.IsEOF())
		Table.Close();
		Db.Close();
		CVolumeRegion *pVolumeRegion=m_VolumesRegion.GetData();
		if(pVolumeRegion) std::sort(pVolumeRegion,(pVolumeRegion+m_VolumesRegion.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataVolumeRegion::Modify(CVolumeRegion &VolumeRegion, int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblVolumesRegion Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("DateDebut = %s",m_VolumesRegion[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table=VolumeRegion;
				Table.Update();
				m_VolumesRegion[Index]=VolumeRegion;
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataVolumeRegion::Add(CVolumeRegion &VolumeRegion)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblVolumesRegion Table(&Db);
		Table.Open();
		Table.AddNew();
		Table=VolumeRegion;
		Table.Update();
		Table.Close();
		Db.Close();
		m_VolumesRegion.Add(VolumeRegion);
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataVolumeRegion::Delete(int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblVolumesRegion Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("DateDebut = %s",m_VolumesRegion[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Delete();
				m_VolumesRegion.RemoveAt(Index);
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}