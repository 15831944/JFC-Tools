#if !defined(AFX_FORMATDLG_H__E3234543_8A97_11D2_AAF8_0000E86750A8__INCLUDED_)
#define AFX_FORMATDLG_H__E3234543_8A97_11D2_AAF8_0000E86750A8__INCLUDED_

#include "DataFormat.h"	// Added by ClassView
#include "DataStation.h"	// Added by ClassView
#include "Format.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FormatDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFormatDlg dialog

class CFormatDlg : public CDialog
{
// Construction
public:
	int m_CurStation;
	bool m_Mode_Modify;
	bool m_Mode_New;
	int m_CurData;
	int m_CurFormat;
	CDataFormat m_Data;
	CFormatDlg(CWnd* pParent = NULL);   // standard constructor
	CDataStation m_Stations;

// Dialog Data
	//{{AFX_DATA(CFormatDlg)
	enum { IDD = IDD_FORMAT_DIALOG };
	CComboBox	m_CtrlStation;
	CListBox	m_CtrlFormats;
	CString		m_Format;
	float	m_Coef;
	COleDateTime	m_DateDebut;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFormatDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void GetData();
	void UpdateFormat();
	void UpdateList();
	void UpdateButtons();
	CFormat m_DataCopy;
	CFormatD m_FormatCopy;
	// Generated message map functions
	//{{AFX_MSG(CFormatDlg)
	afx_msg void OnBnAjouter();
	afx_msg void OnBnAjouterFormat();
	afx_msg void OnBnModifier();
	afx_msg void OnBnModifierFormat();
	afx_msg void OnBnSupprimerFormat();
	afx_msg void OnBnSupprimer1();
	afx_msg void OnRecBack();
	afx_msg void OnRecBegin();
	afx_msg void OnRecEnd();
	afx_msg void OnRecNext();
	virtual void OnCancel();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeList1();
	afx_msg void OnSelchangeCombo2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FORMATDLG_H__E3234543_8A97_11D2_AAF8_0000E86750A8__INCLUDED_)
