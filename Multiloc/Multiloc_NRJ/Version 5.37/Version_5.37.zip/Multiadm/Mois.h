// Mois.h: interface for the CMois class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MOIS_H__0AA9FBBC_B039_465D_B7A5_54F9486559F8__INCLUDED_)
#define AFX_MOIS_H__0AA9FBBC_B039_465D_B7A5_54F9486559F8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMois  
{
public:
	CMois();
	virtual ~CMois();

	int NoMois;				// de 1 � 12
	int NoAnnee;			// format yyyy
	int NoJour;				// de 0 � 31
	int NbJour;				// nombre jours valides
	int IndexJourPeriode;	// Index jour sur la p�riode s�lectionn�e
};

typedef	CArray<CMois,CMois&> CMoisArray;

#endif // !defined(AFX_MOIS_H__0AA9FBBC_B039_465D_B7A5_54F9486559F8__INCLUDED_)
