// TblMailFax.cpp : implementation file
//

#include "stdafx.h"
#include "multiadm.h"
#include "TblMailFax.h"
#include "MailFax.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTblMailFax

IMPLEMENT_DYNAMIC(CTblMailFax, CDaoRecordset)

CTblMailFax::CTblMailFax(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CTblMailFax)
	m_NrStation = 0;
	m_NrVille = 0;
	m_AdrMail = _T("");
	m_Fax = _T("");
	m_nFields = 4;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenTable;
}

CTblMailFax &CTblMailFax :: operator=(const CMailFax &Source)
{
	m_NrStation = Source.m_NrStation;
	m_NrVille = Source.m_NrVille;
	m_AdrMail = Source.m_AdrMail;
	m_Fax = Source.m_Fax;
	return(*this);
}

CString CTblMailFax::GetDefaultDBName()
{
	return _T("C:\\Projects\\Multiloc\\multiloc.mdb");
}

CString CTblMailFax::GetDefaultSQL()
{
	return _T("[StationVilleInfo]");
}

void CTblMailFax::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CTblMailFax)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Long(pFX, _T("[NrStation]"), m_NrStation);
	DFX_Long(pFX, _T("[NrVille]"), m_NrVille);
	DFX_Text(pFX, _T("[AdrMail]"), m_AdrMail);
	DFX_Text(pFX, _T("[Fax]"), m_Fax);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CTblMailFax diagnostics

#ifdef _DEBUG
void CTblMailFax::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CTblMailFax::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
