// DataPrime.h: interface for the CDataPrime class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATAPRIME_H__F3536061_89D6_11D2_AAF8_0000E86750A8__INCLUDED_)
#define AFX_DATAPRIME_H__F3536061_89D6_11D2_AAF8_0000E86750A8__INCLUDED_

#include "prime.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataPrime  
{
public:
	int Delete(int Index);
	int Add(CPrime &Prime);
	int Modify(CPrime &Prime, int Index);
	bool Load();
	CPrimeArray m_Primes;

	CDataPrime();
	virtual ~CDataPrime();

};

#endif // !defined(AFX_DATAPRIME_H__F3536061_89D6_11D2_AAF8_0000E86750A8__INCLUDED_)
