// ImportTarif.h: interface for the CImportTarif class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IMPORTTARIF_H__92276D00_8E9E_11D2_AAF8_0000E86750A8__INCLUDED_)
#define AFX_IMPORTTARIF_H__92276D00_8E9E_11D2_AAF8_0000E86750A8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DataTarif.h"
/*
#include "DataTarifBase.h"
#include "DataTarifMessage.h"
#include "DataTarifSaison.h"
*/

#include "TarifBase.h"
#include "TarifMessage.h"
#include "TarifSaison.h"


class CImportTarif : public CDataTarif  
{
public:
	
	// Import du fichier tarif
	bool ImportFile();
	bool Import(CString FileName);

	// Cr�ation fichier import � partir du fichier g�n�rale
	bool CreerFicImport(CString &FileTarif,CProgressCtrl *ProgressBar);
	bool ImportGeneEuro(CString FileName,CProgressCtrl *ProgressBar,CString &m_ProgSave);


	CImportTarif();
	
	virtual ~CImportTarif();

	// Infos tarification
	struct TarifVilleReg{
		int Code;
		CString Libelle;
		int CodeVille;
		float TarifReg[11];   // Nb stations Multiloc
	};

	// Info coefficient tarif
	struct PeriodeTarif{
		CString DateDeb;
		float CoeffPeriode;
	};		
	
	// Type de tarification message et coeff associ�
	struct InfoTarifMessage{
		CString TypeMessage;
		int		CoeffMessage;
	};
	
	// Type de p�riode tarification et coeff associ�
	struct InfoTarifPeriode{
		CString LibPeriode;
		int CoeffPeriode;
	};

	// struct tableau villes valides par stations
	struct StationTarifee{
		int CodeVille;
		CArray <int,int&> TabCodeStation;
	};

protected:
	
	bool AddReplace(CTarif &Tarif);

	// Ajout/Replace d�tails tarif
	bool AddReplaceTarifBase		(CTarifBase &TarifBase);
	bool AddReplaceTarifMessage		(CTarifMessage &TarifMessage);
	bool AddReplaceTarifSaison		(CTarifSaison &TarifSaison);

	// Ajout/Replace via tableau des tarifs (Tarif Message,Saison,de Base)
	bool AddReplaceAllTarifBase		(CTarifBaseArray    &TarifBaseArray);
	bool AddReplaceAllTarifMessage	(CTarifMessageArray &TarifMessageArray);
	bool AddReplaceAllTarifSaison	(CTarifSaisonArray  &TarifSaisonArray,CProgressCtrl *ProgressBar,CString &ProgSave);

	// Lecture fichier tarif g�n�ral (pour passer les commentaires)
	bool LireLigne(CStdioFile &File, CString &Data);

};

#endif // !defined(AFX_IMPORTTARIF_H__92276D00_8E9E_11D2_AAF8_0000E86750A8__INCLUDED_)
