// GrpDlg.cpp : implementation file
//

#include "stdafx.h"
#include "multiadm.h"
#include "GrpDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGrpDlg dialog
CGrpDlg::CGrpDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGrpDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGrpDlg)
	m_DateDebut = COleDateTime::GetCurrentTime();
	m_Edit1 = 0;
	m_Edit2 = 0;
	m_Edit3 = 0;
	m_Edit4 = 0;
	m_Edit5 = 0;
	m_Edit6 = 0;
	m_Edit7 = 0;
	m_Edit8 = 0;
	m_Edit9 = 0;
	m_Edit10 = 0;
	m_Edit11 = 0;
	m_Edit12 = 0;
	m_Edit13 = 0;
	m_Edit14 = 0;
	m_Edit15 = 0;
	m_Edit16 = 0;
	m_Edit17 = 0;
	m_Edit18 = 0;
	m_Edit19 = 0;
	m_Edit20 = 0;
	m_Edit21 = 0;
	m_Edit22 = 0;
	m_Edit23 = 0;
	m_Edit24 = 0;
	m_Edit25 = 0;
	m_Edit26 = 0;
	m_Edit27 = 0;
	m_Edit28 = 0;
	m_Edit29 = 0;
	m_Edit30 = 0;
	m_Edit31 = 0;
	m_Edit32 = 0;
	m_Edit33 = 0;
	m_Edit34 = 0;
	m_Edit35 = 0;
	m_Edit36 = 0;
	m_Edit37 = 0;
	m_Edit38 = 0;
	m_Edit39 = 0;
	m_Edit40 = 0;
	m_Edit41 = 0;
	m_Edit42 = 0;
	m_Edit43 = 0;
	m_Edit44 = 0;
	m_Edit45 = 0;
	m_Edit46 = 0;
	m_Edit47 = 0;
	m_Edit48 = 0;
	//}}AFX_DATA_INIT
	m_Mode_Modify=false;
	m_Mode_New=false;
}


void CGrpDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGrpDlg)
	DDX_Control(pDX, IDC_CB_VILLE, m_Ctrl_Ville);
	DDX_Control(pDX, IDC_CB_STATION, m_Ctrl_Station);
	DDX_Control(pDX, IDC_CB_CIBLE, m_Ctrl_Cible);
	DDX_DateTimeCtrl(pDX, IDC_DATE_DEBUT, m_DateDebut);
	DDX_Text(pDX, IDC_EDIT1, m_Edit1);
	DDV_MinMaxDWord(pDX, m_Edit1, 0, 32768);
	DDX_Text(pDX, IDC_EDIT2, m_Edit2);
	DDV_MinMaxDWord(pDX, m_Edit2, 0, 32768);
	DDX_Text(pDX, IDC_EDIT3, m_Edit3);
	DDV_MinMaxDWord(pDX, m_Edit3, 0, 32768);
	DDX_Text(pDX, IDC_EDIT4, m_Edit4);
	DDV_MinMaxDWord(pDX, m_Edit4, 0, 32768);
	DDX_Text(pDX, IDC_EDIT5, m_Edit5);
	DDV_MinMaxDWord(pDX, m_Edit5, 0, 32768);
	DDX_Text(pDX, IDC_EDIT6, m_Edit6);
	DDV_MinMaxDWord(pDX, m_Edit6, 0, 32768);
	DDX_Text(pDX, IDC_EDIT7, m_Edit7);
	DDV_MinMaxDWord(pDX, m_Edit7, 0, 32768);
	DDX_Text(pDX, IDC_EDIT8, m_Edit8);
	DDV_MinMaxDWord(pDX, m_Edit8, 0, 32768);
	DDX_Text(pDX, IDC_EDIT9, m_Edit9);
	DDV_MinMaxDWord(pDX, m_Edit9, 0, 32768);
	DDX_Text(pDX, IDC_EDIT10, m_Edit10);
	DDV_MinMaxDWord(pDX, m_Edit10, 0, 32768);
	DDX_Text(pDX, IDC_EDIT11, m_Edit11);
	DDV_MinMaxDWord(pDX, m_Edit11, 0, 32768);
	DDX_Text(pDX, IDC_EDIT12, m_Edit12);
	DDV_MinMaxDWord(pDX, m_Edit12, 0, 32768);
	DDX_Text(pDX, IDC_EDIT13, m_Edit13);
	DDV_MinMaxDWord(pDX, m_Edit13, 0, 32768);
	DDX_Text(pDX, IDC_EDIT14, m_Edit14);
	DDV_MinMaxDWord(pDX, m_Edit14, 0, 32768);
	DDX_Text(pDX, IDC_EDIT15, m_Edit15);
	DDV_MinMaxDWord(pDX, m_Edit15, 0, 32768);
	DDX_Text(pDX, IDC_EDIT16, m_Edit16);
	DDV_MinMaxDWord(pDX, m_Edit16, 0, 32768);
	DDX_Text(pDX, IDC_EDIT17, m_Edit17);
	DDV_MinMaxDWord(pDX, m_Edit17, 0, 32768);
	DDX_Text(pDX, IDC_EDIT18, m_Edit18);
	DDV_MinMaxDWord(pDX, m_Edit18, 0, 32768);
	DDX_Text(pDX, IDC_EDIT19, m_Edit19);
	DDV_MinMaxDWord(pDX, m_Edit19, 0, 32768);
	DDX_Text(pDX, IDC_EDIT20, m_Edit20);
	DDV_MinMaxDWord(pDX, m_Edit20, 0, 32768);
	DDX_Text(pDX, IDC_EDIT21, m_Edit21);
	DDV_MinMaxDWord(pDX, m_Edit21, 0, 32768);
	DDX_Text(pDX, IDC_EDIT22, m_Edit22);
	DDV_MinMaxDWord(pDX, m_Edit22, 0, 32768);
	DDX_Text(pDX, IDC_EDIT23, m_Edit23);
	DDV_MinMaxDWord(pDX, m_Edit23, 0, 32768);
	DDX_Text(pDX, IDC_EDIT24, m_Edit24);
	DDV_MinMaxDWord(pDX, m_Edit24, 0, 32768);
	DDX_Text(pDX, IDC_EDIT25, m_Edit25);
	DDV_MinMaxDWord(pDX, m_Edit25, 0, 32768);
	DDX_Text(pDX, IDC_EDIT26, m_Edit26);
	DDV_MinMaxDWord(pDX, m_Edit26, 0, 32768);
	DDX_Text(pDX, IDC_EDIT27, m_Edit27);
	DDV_MinMaxDWord(pDX, m_Edit27, 0, 32768);
	DDX_Text(pDX, IDC_EDIT28, m_Edit28);
	DDV_MinMaxDWord(pDX, m_Edit28, 0, 32768);
	DDX_Text(pDX, IDC_EDIT29, m_Edit29);
	DDV_MinMaxDWord(pDX, m_Edit29, 0, 32768);
	DDX_Text(pDX, IDC_EDIT30, m_Edit30);
	DDV_MinMaxDWord(pDX, m_Edit30, 0, 32768);
	DDX_Text(pDX, IDC_EDIT31, m_Edit31);
	DDV_MinMaxDWord(pDX, m_Edit31, 0, 32768);
	DDX_Text(pDX, IDC_EDIT32, m_Edit32);
	DDV_MinMaxDWord(pDX, m_Edit32, 0, 32768);
	DDX_Text(pDX, IDC_EDIT33, m_Edit33);
	DDV_MinMaxDWord(pDX, m_Edit33, 0, 32768);
	DDX_Text(pDX, IDC_EDIT34, m_Edit34);
	DDV_MinMaxDWord(pDX, m_Edit34, 0, 32768);
	DDX_Text(pDX, IDC_EDIT35, m_Edit35);
	DDV_MinMaxDWord(pDX, m_Edit35, 0, 32768);
	DDX_Text(pDX, IDC_EDIT36, m_Edit36);
	DDV_MinMaxDWord(pDX, m_Edit36, 0, 32768);
	DDX_Text(pDX, IDC_EDIT37, m_Edit37);
	DDV_MinMaxDWord(pDX, m_Edit37, 0, 32768);
	DDX_Text(pDX, IDC_EDIT38, m_Edit38);
	DDV_MinMaxDWord(pDX, m_Edit38, 0, 32768);
	DDX_Text(pDX, IDC_EDIT39, m_Edit39);
	DDV_MinMaxDWord(pDX, m_Edit39, 0, 32768);
	DDX_Text(pDX, IDC_EDIT40, m_Edit40);
	DDV_MinMaxDWord(pDX, m_Edit40, 0, 32768);
	DDX_Text(pDX, IDC_EDIT41, m_Edit41);
	DDV_MinMaxDWord(pDX, m_Edit41, 0, 32768);
	DDX_Text(pDX, IDC_EDIT42, m_Edit42);
	DDV_MinMaxDWord(pDX, m_Edit42, 0, 32768);
	DDX_Text(pDX, IDC_EDIT43, m_Edit43);
	DDV_MinMaxDWord(pDX, m_Edit43, 0, 32768);
	DDX_Text(pDX, IDC_EDIT44, m_Edit44);
	DDV_MinMaxDWord(pDX, m_Edit44, 0, 32768);
	DDX_Text(pDX, IDC_EDIT45, m_Edit45);
	DDV_MinMaxDWord(pDX, m_Edit45, 0, 32768);
	DDX_Text(pDX, IDC_EDIT46, m_Edit46);
	DDV_MinMaxDWord(pDX, m_Edit46, 0, 32768);
	DDX_Text(pDX, IDC_EDIT47, m_Edit47);
	DDV_MinMaxDWord(pDX, m_Edit47, 0, 32768);
	DDX_Text(pDX, IDC_EDIT48, m_Edit48);
	DDV_MinMaxDWord(pDX, m_Edit48, 0, 32768);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGrpDlg, CDialog)
	//{{AFX_MSG_MAP(CGrpDlg)
	ON_BN_CLICKED(IDC_BN_DUPLIQUER, OnBnDupliquer)
	ON_BN_CLICKED(IDC_BN_MEMORISER, OnBnMemoriser)
	ON_BN_CLICKED(IDC_BN_MODIFIER, OnBnModifier)
	ON_BN_CLICKED(IDC_BN_SUPPRIMER, OnBnSupprimer)
	ON_BN_CLICKED(IDC_BN_SUPPRIMER_ALL, OnBnSupprimerAll)
	ON_CBN_SELCHANGE(IDC_CB_STATION, OnSelchangeCbStation)
	ON_CBN_SELCHANGE(IDC_CB_VILLE, OnSelchangeCbVille)
	ON_CBN_SELCHANGE(IDC_CB_CIBLE, OnSelchangeCbCible)
	ON_BN_CLICKED(IDC_RAD_DIMANCHE, OnRadDimanche)
	ON_BN_CLICKED(IDC_RAD_JEUDI, OnRadJeudi)
	ON_BN_CLICKED(IDC_RAD_LUNDI, OnRadLundi)
	ON_BN_CLICKED(IDC_RAD_MARDI, OnRadMardi)
	ON_BN_CLICKED(IDC_RAD_MERCREDI, OnRadMercredi)
	ON_BN_CLICKED(IDC_RAD_SAMEDI, OnRadSamedi)
	ON_BN_CLICKED(IDC_RAD_VENDREDI, OnRadVendredi)
	ON_BN_CLICKED(IDC_REC_BACK, OnRecBack)
	ON_BN_CLICKED(IDC_REC_BEGIN, OnRecBegin)
	ON_BN_CLICKED(IDC_REC_END, OnRecEnd)
	ON_BN_CLICKED(IDC_REC_NEW, OnRecNew)
	ON_BN_CLICKED(IDC_REC_NEXT, OnRecNext)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGrpDlg message handlers

BOOL CGrpDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	if(!m_Stations.Load())
	{
		AfxMessageBox("Il faut cr�er au moins une Station");
		EndDialog(false);
	}
	if(!m_Villes.Load())
	{
		AfxMessageBox("Il faut cr�er au moins une Ville");
		EndDialog(false);
	}
	if(!m_Cibles.Load())
	{
		AfxMessageBox("Il faut cr�er au moins une Cible");
		EndDialog(false);
	}
	for(int x=0;x<m_Stations.m_Stations.GetSize();x++)
	{
		m_Ctrl_Station.AddString(m_Stations.m_Stations[x].m_Libelle);
	}
	for(x=0;x<m_Villes.m_Villes.GetSize();x++)
	{
		m_Ctrl_Ville.AddString(m_Villes.m_Villes[x].m_Libelle);
	}
	for(x=0;x<m_Cibles.m_Cibles.GetSize();x++)
	{
		m_Ctrl_Cible.AddString(m_Cibles.m_Cibles[x].m_Libelle);
	}
	m_CurCible=m_Cibles.m_Cibles[0].m_NrUnique;;
	m_Ctrl_Cible.SetCurSel(0);
	m_CurStation=m_Stations.m_Stations[0].m_NrUnique;
	m_Ctrl_Station.SetCurSel(0);
	m_CurVille=m_Villes.m_Villes[0].m_NrUnique;;
	m_Ctrl_Ville.SetCurSel(0);
	UpdateGrps(true);
	UpdateButtons();
	UpdateData(false);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CGrpDlg::OnBnDupliquer() 
{
	if(m_Mode_Modify || m_Mode_New)
	{
		if(m_CurDay < 6)
		{
			GetGrpData();
			m_GrpCopy.m_Grp[m_CurDay+1].Copy(m_GrpCopy.m_Grp[m_CurDay]);
			m_CurDay++;
		}
		else
		{
			GetGrpData();
			m_GrpCopy.m_Grp[0].Copy(m_GrpCopy.m_Grp[m_CurDay]);
			m_CurDay=0;
		}
		SetDay();
		SetupGrps();
	}
}

void CGrpDlg::OnBnMemoriser() 
{
	if(m_Mode_Modify)
	{
		GetGrpData();
		if(m_Grps.Modify(m_GrpCopy,m_CurGrp))
		{
			m_Grps.m_Grps[m_CurGrp]=m_GrpCopy;
			m_Mode_Modify=false;
		}
		UpdateButtons();
		return;
	}
	if(m_Mode_New)
	{
		GetGrpData();
		if(m_Grps.Add(m_GrpCopy))
		{
			m_CurGrp++;
			m_Mode_New=false;
		}
		UpdateButtons();
		return;
	}
}

void CGrpDlg::OnBnModifier() 
{
	if(m_CurGrp>=0)
	{
		m_Mode_Modify=TRUE;
		m_GrpCopy=m_Grps.m_Grps[m_CurGrp];
		SetupGrps();
		UpdateButtons();
	}
}

void CGrpDlg::OnBnSupprimer() 
{
	if(m_Mode_Modify || m_Mode_New)
	{
		for(int x=0;x<m_GrpCopy.m_Grp[m_CurDay].GetSize();x++)
		{
			m_GrpCopy.m_Grp[m_CurDay][x]=0;
		}
		SetupGrps();
	}
}

void CGrpDlg::OnBnSupprimerAll() 
{
	if(m_CurGrp<0) return;
	if(m_Mode_Modify || m_Mode_New) return;
	if(m_Grps.Delete(m_CurGrp))
	{
		if(m_CurGrp>0) m_CurGrp--;
		else
		{
			if(!m_Grps.m_Grps.GetSize()) m_CurGrp=-1;
		}
		m_CurDay=0;
		SetDay();
		SetupGrps();
		UpdateButtons();
	}
}

void CGrpDlg::OnSelchangeCbStation() 
{
	m_CurStation=m_Stations.m_Stations[m_Ctrl_Station.GetCurSel()].m_NrUnique;
	m_Mode_New=false;
	m_Mode_Modify=false;
	UpdateGrps(true);
	UpdateButtons();
}

void CGrpDlg::OnSelchangeCbVille() 
{
	m_CurVille=m_Villes.m_Villes[m_Ctrl_Ville.GetCurSel()].m_NrUnique;
	m_Mode_New=false;
	m_Mode_Modify=false;
	UpdateGrps(true);
	UpdateButtons();
}

void CGrpDlg::OnSelchangeCbCible() 
{
	m_CurCible=m_Cibles.m_Cibles[m_Ctrl_Cible.GetCurSel()].m_NrUnique;
	m_Mode_New=false;
	m_Mode_Modify=false;
	UpdateGrps(true);
	UpdateButtons();
}

void CGrpDlg::OnRadDimanche() 
{
	if(m_Mode_Modify || m_Mode_New)	GetGrpData();
	m_CurDay=6;
	SetupGrps();
}

void CGrpDlg::OnRadJeudi() 
{
	if(m_Mode_Modify || m_Mode_New)	GetGrpData();
	m_CurDay=3;
	SetupGrps();
}

void CGrpDlg::OnRadLundi() 
{
	if(m_Mode_Modify || m_Mode_New)	GetGrpData();
	m_CurDay=0;
	SetupGrps();
}

void CGrpDlg::OnRadMardi() 
{
	if(m_Mode_Modify || m_Mode_New)	GetGrpData();
	m_CurDay=1;
	SetupGrps();
}

void CGrpDlg::OnRadMercredi() 
{
	if(m_Mode_Modify || m_Mode_New)	GetGrpData();
	m_CurDay=2;
	SetupGrps();
}

void CGrpDlg::OnRadSamedi() 
{
	if(m_Mode_Modify || m_Mode_New)	GetGrpData();
	m_CurDay=5;
	SetupGrps();
}

void CGrpDlg::OnRadVendredi() 
{
	if(m_Mode_Modify || m_Mode_New)	GetGrpData();
	m_CurDay=4;
	SetupGrps();
}

void CGrpDlg::OnRecBack() 
{
	if(m_CurGrp>0) m_CurGrp--;
	SetupGrps();
	UpdateButtons();
}

void CGrpDlg::OnRecBegin() 
{
	if(m_CurGrp>0) m_CurGrp=0;
	SetupGrps();
	UpdateButtons();
}

void CGrpDlg::OnRecEnd() 
{
	m_CurGrp=m_Grps.m_Grps.GetSize()-1;
	SetupGrps();
	UpdateButtons();
}

void CGrpDlg::OnRecNew() 
{
	m_Mode_New=TRUE;
	m_CurDay=0;
	m_GrpCopy.m_DateDebut=COleDateTime::GetCurrentTime();
	m_GrpCopy.m_NrCible=m_CurCible;
	m_GrpCopy.m_NrVille=m_CurVille;
	m_GrpCopy.m_NrStation=m_CurStation;
	SetDay();
	SetupGrps();
	UpdateButtons();
}

void CGrpDlg::OnRecNext() 
{
	if(m_CurGrp<m_Grps.m_Grps.GetSize()-1) m_CurGrp++;
	SetupGrps();
	UpdateButtons();
}

void CGrpDlg::OnCancel() 
{
	if(m_Mode_New || m_Mode_Modify)
	{
		m_Mode_New=false;
		m_Mode_Modify=false;
		SetupGrps();
		UpdateButtons();
	}
	else CDialog::OnCancel();
}

void CGrpDlg::OnOK() 
{
	if(!m_Mode_New && !m_Mode_Modify) CDialog::OnOK();
}

void CGrpDlg::UpdateGrps(bool Load)
{
	if(Load)
	{
		m_Grps.Load(m_CurStation,m_CurVille,m_CurCible);
		if(m_Grps.m_Grps.GetSize())
		{
			m_CurGrp=0;
		}
		else m_CurGrp=-1;
	}
	m_CurDay=0;
	SetDay();
	SetupGrps();
	UpdateButtons();
}

void CGrpDlg::SetupGrps()
{
	CGrp *Grp=NULL;
	if(m_Mode_Modify || m_Mode_New) Grp=&m_GrpCopy;
	else
	{
		if(m_CurGrp<0)
		{
			ClearGrps();
			return;
		}
		else Grp=&m_Grps.m_Grps[m_CurGrp];
	}
	m_DateDebut=Grp->m_DateDebut;
	int x=0;
	m_Edit1 =  Grp->m_Grp[m_CurDay][x++];
	m_Edit2 =  Grp->m_Grp[m_CurDay][x++];	
	m_Edit3 =  Grp->m_Grp[m_CurDay][x++];
	m_Edit4 =  Grp->m_Grp[m_CurDay][x++];
	m_Edit5 =  Grp->m_Grp[m_CurDay][x++];
	m_Edit6 =  Grp->m_Grp[m_CurDay][x++];
	m_Edit7 =  Grp->m_Grp[m_CurDay][x++];
	m_Edit8 =  Grp->m_Grp[m_CurDay][x++];
	m_Edit9 =  Grp->m_Grp[m_CurDay][x++];
	m_Edit10 = Grp->m_Grp[m_CurDay][x++];
	m_Edit11 = Grp->m_Grp[m_CurDay][x++];
	m_Edit12 = Grp->m_Grp[m_CurDay][x++];
	m_Edit13 = Grp->m_Grp[m_CurDay][x++];
	m_Edit14 = Grp->m_Grp[m_CurDay][x++];
	m_Edit15 = Grp->m_Grp[m_CurDay][x++];
	m_Edit16 = Grp->m_Grp[m_CurDay][x++];
	m_Edit17 = Grp->m_Grp[m_CurDay][x++];
	m_Edit18 = Grp->m_Grp[m_CurDay][x++];
	m_Edit19 = Grp->m_Grp[m_CurDay][x++];
	m_Edit20 = Grp->m_Grp[m_CurDay][x++];
	m_Edit21 = Grp->m_Grp[m_CurDay][x++];
	m_Edit22 = Grp->m_Grp[m_CurDay][x++];
	m_Edit23 = Grp->m_Grp[m_CurDay][x++];
	m_Edit24 = Grp->m_Grp[m_CurDay][x++];
	m_Edit25 = Grp->m_Grp[m_CurDay][x++];
	m_Edit26 = Grp->m_Grp[m_CurDay][x++];
	m_Edit27 = Grp->m_Grp[m_CurDay][x++];
	m_Edit28 = Grp->m_Grp[m_CurDay][x++];
	m_Edit29 = Grp->m_Grp[m_CurDay][x++];
	m_Edit30 = Grp->m_Grp[m_CurDay][x++];
	m_Edit31 = Grp->m_Grp[m_CurDay][x++];
	m_Edit32 = Grp->m_Grp[m_CurDay][x++];
	m_Edit33 = Grp->m_Grp[m_CurDay][x++];
	m_Edit34 = Grp->m_Grp[m_CurDay][x++];
	m_Edit35 = Grp->m_Grp[m_CurDay][x++];
	m_Edit36 = Grp->m_Grp[m_CurDay][x++];
	m_Edit37 = Grp->m_Grp[m_CurDay][x++];
	m_Edit38 = Grp->m_Grp[m_CurDay][x++];
	m_Edit39 = Grp->m_Grp[m_CurDay][x++];
	m_Edit40 = Grp->m_Grp[m_CurDay][x++];
	m_Edit41 = Grp->m_Grp[m_CurDay][x++];
	m_Edit42 = Grp->m_Grp[m_CurDay][x++];
	m_Edit43 = Grp->m_Grp[m_CurDay][x++];
	m_Edit44 = Grp->m_Grp[m_CurDay][x++];
	m_Edit45 = Grp->m_Grp[m_CurDay][x++];
	m_Edit46 = Grp->m_Grp[m_CurDay][x++];
	m_Edit47 = Grp->m_Grp[m_CurDay][x++];
	m_Edit48 = Grp->m_Grp[m_CurDay][x++];
	UpdateData(false);
}

void CGrpDlg::SetDay()
{
	switch(m_CurDay)
	{
		case 0: CheckRadioButton(IDC_RAD_LUNDI,IDC_RAD_DIMANCHE,IDC_RAD_LUNDI); break;
		case 1: CheckRadioButton(IDC_RAD_LUNDI,IDC_RAD_DIMANCHE,IDC_RAD_MARDI); break;
		case 2: CheckRadioButton(IDC_RAD_LUNDI,IDC_RAD_DIMANCHE,IDC_RAD_MERCREDI); break;
		case 3: CheckRadioButton(IDC_RAD_LUNDI,IDC_RAD_DIMANCHE,IDC_RAD_JEUDI); break;
		case 4: CheckRadioButton(IDC_RAD_LUNDI,IDC_RAD_DIMANCHE,IDC_RAD_VENDREDI); break;
		case 5: CheckRadioButton(IDC_RAD_LUNDI,IDC_RAD_DIMANCHE,IDC_RAD_SAMEDI); break;
		case 6: CheckRadioButton(IDC_RAD_LUNDI,IDC_RAD_DIMANCHE,IDC_RAD_DIMANCHE); break;
	}
}

void CGrpDlg::GetGrpData()
{
	if(!m_Mode_Modify && !m_Mode_New) return;
	UpdateData(true);
	CGrp *Grp=&m_GrpCopy;
	Grp->m_DateDebut=m_DateDebut;
	int x=0;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit1 ;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit2 ;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit3 ;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit4 ;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit5 ;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit6 ;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit7 ;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit8 ;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit9 ;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit10;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit11;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit12;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit13;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit14;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit15;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit16;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit17;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit18;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit19;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit20;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit21;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit22;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit23;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit24;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit25;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit26;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit27;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit28;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit29;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit30;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit31;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit32;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit33;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit34;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit35;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit36;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit37;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit38;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit39;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit40;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit41;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit42;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit43;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit44;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit45;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit46;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit47;
	Grp->m_Grp[m_CurDay][x++] = (short) m_Edit48;
}

void CGrpDlg::UpdateButtons()
{
	if(m_Mode_Modify || m_Mode_New)
	{
		if(m_Mode_Modify)
		{
			GetDlgItem(IDC_BN_SUPPRIMER_ALL)->EnableWindow(true); 
		}
		else
		{
			GetDlgItem(IDC_BN_SUPPRIMER_ALL)->EnableWindow(false); 
		}

		GetDlgItem(IDC_DATE_DEBUT)->EnableWindow(true); 
		GetDlgItem(IDC_RAD_DIMANCHE)->EnableWindow(true); 
		GetDlgItem(IDC_RAD_JEUDI)->EnableWindow(true); 
		GetDlgItem(IDC_RAD_LUNDI)->EnableWindow(true); 
		GetDlgItem(IDC_RAD_MARDI)->EnableWindow(true); 
		GetDlgItem(IDC_RAD_MERCREDI)->EnableWindow(true); 
		GetDlgItem(IDC_RAD_SAMEDI)->EnableWindow(true); 
		GetDlgItem(IDC_RAD_VENDREDI)->EnableWindow(true); 
		
		GetDlgItem(IDC_REC_BACK)->EnableWindow(false); 
		GetDlgItem(IDC_REC_BEGIN)->EnableWindow(false); 
		GetDlgItem(IDC_REC_END)->EnableWindow(false); 
		GetDlgItem(IDC_REC_NEW)->EnableWindow(false); 
		GetDlgItem(IDC_REC_NEXT)->EnableWindow(false); 

		GetDlgItem(IDC_BN_DUPLIQUER)->EnableWindow(true); 
		GetDlgItem(IDC_BN_MEMORISER)->EnableWindow(true); 
		GetDlgItem(IDC_BN_MODIFIER)->EnableWindow(false); 
		GetDlgItem(IDC_BN_SUPPRIMER)->EnableWindow(true); 

		GetDlgItem(IDCANCEL)->EnableWindow(true); 
		GetDlgItem(IDOK)->EnableWindow(false); 

		GetDlgItem(IDC_EDIT1)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT2)->EnableWindow(true);  
		GetDlgItem(IDC_EDIT3)->EnableWindow(true);  
		GetDlgItem(IDC_EDIT4)->EnableWindow(true);  
		GetDlgItem(IDC_EDIT5)->EnableWindow(true);  
		GetDlgItem(IDC_EDIT6)->EnableWindow(true);  
		GetDlgItem(IDC_EDIT7)->EnableWindow(true);  
		GetDlgItem(IDC_EDIT8)->EnableWindow(true);  
		GetDlgItem(IDC_EDIT9)->EnableWindow(true);  
		GetDlgItem(IDC_EDIT10)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT11)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT12)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT13)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT14)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT15)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT16)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT17)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT18)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT19)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT20)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT21)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT22)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT23)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT24)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT25)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT26)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT27)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT28)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT29)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT30)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT31)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT32)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT33)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT34)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT35)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT36)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT37)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT38)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT39)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT40)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT41)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT42)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT43)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT44)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT45)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT46)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT47)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT48)->EnableWindow(true); 
	}
	else
	{
		GetDlgItem(IDCANCEL)->EnableWindow(false); 
		GetDlgItem(IDC_DATE_DEBUT)->EnableWindow(false); 

		if(m_CurGrp<0)
		{
			GetDlgItem(IDC_RAD_DIMANCHE)->EnableWindow(false); 
			GetDlgItem(IDC_RAD_JEUDI)->EnableWindow(false); 
			GetDlgItem(IDC_RAD_LUNDI)->EnableWindow(false); 
			GetDlgItem(IDC_RAD_MARDI)->EnableWindow(false); 
			GetDlgItem(IDC_RAD_MERCREDI)->EnableWindow(false); 
			GetDlgItem(IDC_RAD_SAMEDI)->EnableWindow(false); 
			GetDlgItem(IDC_RAD_VENDREDI)->EnableWindow(false); 

			GetDlgItem(IDC_BN_SUPPRIMER_ALL)->EnableWindow(false); 
			GetDlgItem(IDC_BN_MODIFIER)->EnableWindow(false); 
			GetDlgItem(IDC_REC_BACK)->EnableWindow(false); 
			GetDlgItem(IDC_REC_BEGIN)->EnableWindow(false); 
			GetDlgItem(IDC_REC_END)->EnableWindow(false); 
			GetDlgItem(IDC_REC_NEXT)->EnableWindow(false); 
		}
		else
		{
			GetDlgItem(IDC_RAD_DIMANCHE)->EnableWindow(true); 
			GetDlgItem(IDC_RAD_JEUDI)->EnableWindow(true); 
			GetDlgItem(IDC_RAD_LUNDI)->EnableWindow(true); 
			GetDlgItem(IDC_RAD_MARDI)->EnableWindow(true); 
			GetDlgItem(IDC_RAD_MERCREDI)->EnableWindow(true); 
			GetDlgItem(IDC_RAD_SAMEDI)->EnableWindow(true); 
			GetDlgItem(IDC_RAD_VENDREDI)->EnableWindow(true); 

			GetDlgItem(IDC_BN_SUPPRIMER_ALL)->EnableWindow(true); 
			GetDlgItem(IDC_BN_MODIFIER)->EnableWindow(true); 
			if(m_CurGrp==0)
			{
				GetDlgItem(IDC_REC_BACK)->EnableWindow(false); 
				GetDlgItem(IDC_REC_BEGIN)->EnableWindow(false);
			}
			else
			{
				GetDlgItem(IDC_REC_BACK)->EnableWindow(true); 
				GetDlgItem(IDC_REC_BEGIN)->EnableWindow(true);
			}
			if(m_CurGrp==m_Grps.m_Grps.GetSize()-1)
			{
				GetDlgItem(IDC_REC_END)->EnableWindow(false); 
				GetDlgItem(IDC_REC_NEXT)->EnableWindow(false);
			}
			else 
			{
				GetDlgItem(IDC_REC_END)->EnableWindow(true); 
				GetDlgItem(IDC_REC_NEXT)->EnableWindow(true);
			}
		}
		GetDlgItem(IDC_REC_NEW)->EnableWindow(true); 

		GetDlgItem(IDC_BN_DUPLIQUER)->EnableWindow(false); 
		GetDlgItem(IDC_BN_MEMORISER)->EnableWindow(false); 
		GetDlgItem(IDC_BN_SUPPRIMER)->EnableWindow(false); 

		GetDlgItem(IDOK)->EnableWindow(true); 

		GetDlgItem(IDC_EDIT1)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT2)->EnableWindow(false);  
		GetDlgItem(IDC_EDIT3)->EnableWindow(false);  
		GetDlgItem(IDC_EDIT4)->EnableWindow(false);  
		GetDlgItem(IDC_EDIT5)->EnableWindow(false);  
		GetDlgItem(IDC_EDIT6)->EnableWindow(false);  
		GetDlgItem(IDC_EDIT7)->EnableWindow(false);  
		GetDlgItem(IDC_EDIT8)->EnableWindow(false);  
		GetDlgItem(IDC_EDIT9)->EnableWindow(false);  
		GetDlgItem(IDC_EDIT10)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT11)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT12)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT13)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT14)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT15)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT16)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT17)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT18)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT19)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT20)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT21)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT22)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT23)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT24)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT25)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT26)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT27)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT28)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT29)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT30)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT31)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT32)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT33)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT34)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT35)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT36)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT37)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT38)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT39)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT40)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT41)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT42)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT43)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT44)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT45)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT46)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT47)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT48)->EnableWindow(false); 
	}
}

void CGrpDlg::ClearGrps()
{
	m_DateDebut = COleDateTime::GetCurrentTime();
	m_Edit1 = 0;
	m_Edit2 = 0;
	m_Edit3 = 0;
	m_Edit4 = 0;
	m_Edit5 = 0;
	m_Edit6 = 0;
	m_Edit7 = 0;
	m_Edit8 = 0;
	m_Edit9 = 0;
	m_Edit10 = 0;
	m_Edit11 = 0;
	m_Edit12 = 0;
	m_Edit13 = 0;
	m_Edit14 = 0;
	m_Edit15 = 0;
	m_Edit16 = 0;
	m_Edit17 = 0;
	m_Edit18 = 0;
	m_Edit19 = 0;
	m_Edit20 = 0;
	m_Edit21 = 0;
	m_Edit22 = 0;
	m_Edit23 = 0;
	m_Edit24 = 0;
	m_Edit25 = 0;
	m_Edit26 = 0;
	m_Edit27 = 0;
	m_Edit28 = 0;
	m_Edit29 = 0;
	m_Edit30 = 0;
	m_Edit31 = 0;
	m_Edit32 = 0;
	m_Edit33 = 0;
	m_Edit34 = 0;
	m_Edit35 = 0;
	m_Edit36 = 0;
	m_Edit37 = 0;
	m_Edit38 = 0;
	m_Edit39 = 0;
	m_Edit40 = 0;
	m_Edit41 = 0;
	m_Edit42 = 0;
	m_Edit43 = 0;
	m_Edit44 = 0;
	m_Edit45 = 0;
	m_Edit46 = 0;
	m_Edit47 = 0;
	m_Edit48 = 0;
	UpdateData(false);
}
