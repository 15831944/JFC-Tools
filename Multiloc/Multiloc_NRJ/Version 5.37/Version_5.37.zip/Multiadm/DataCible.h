// DataCible.h: interface for the CDataCible class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATACIBLE_H__E88DE140_7F96_11D2_9B0D_004005327F6C__INCLUDED_)
#define AFX_DATACIBLE_H__E88DE140_7F96_11D2_9B0D_004005327F6C__INCLUDED_

#include "Cible.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataCible  
{
public:
	int Delete(int Index);
	int Add(CCible &Cible);
	int Modify(CCible &Cible, int Index);
	CCibleArray m_Cibles;
	bool Load();
	CDataCible();
	virtual ~CDataCible();

protected:
};

#endif // !defined(AFX_DATACIBLE_H__E88DE140_7F96_11D2_9B0D_004005327F6C__INCLUDED_)
