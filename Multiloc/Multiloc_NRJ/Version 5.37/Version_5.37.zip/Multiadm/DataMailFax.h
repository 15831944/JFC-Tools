// DataMailFax.h: interface for the CDataMailFax class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATAMAILFAX_H__11B1692D_A04B_487C_BA24_13F202491CB3__INCLUDED_)
#define AFX_DATAMAILFAX_H__11B1692D_A04B_487C_BA24_13F202491CB3__INCLUDED_

#include "MailFax.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataMailFax  
{
public:
	CDataMailFax();
	virtual ~CDataMailFax();

	int Delete(int Index);
	int Add(CMailFax &MailFax);
	int Modify(CMailFax &MailFax, int Index);
	bool Load();
	int GetMailFax(long NrStation,long NrVille);
	bool MailFaxExist(long NrStation,long NrVille,int &InxMailFax);
	CMailFaxArray m_MailFaxs;

};

#endif // !defined(AFX_DATAMAILFAX_H__11B1692D_A04B_487C_BA24_13F202491CB3__INCLUDED_)
