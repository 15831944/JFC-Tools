// DataStation.cpp: implementation of the CDataStation class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiadm.h"
#include "DataStation.h"
#include "TblStations.h"
#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataStation::CDataStation()
{
}

CDataStation::~CDataStation()
{

}

bool CDataStation::Load()
{
	m_Stations.RemoveAll();
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",FALSE,TRUE);
		CTblStations Table(&Db);
		Table.Open();
		while(!Table.IsEOF()) 
		{
			CStation Station;
			Station=Table;
			m_Stations.Add(Station);
			Table.MoveNext();
		}
		Table.Close();
		Db.Close();
//		CStation *pStation=m_Stations.GetData();
//		if(pStation) std::sort(pStation,(pStation+m_Stations.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataStation::Modify(CStation &Station, int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblStations Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrUnique = %d",m_Stations[Index].m_NrUnique);
			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table=Station;
				Table.Update();
				m_Stations[Index]=Station;
//				CStation *pStation=m_Stations.GetData();
//				if(pStation) std::sort(pStation,(pStation+m_Stations.GetSize()));
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataStation::Add(CStation &Station)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblStations Table(&Db);
		Table.Open();
		Table.AddNew();
		Table=Station;
		Table.Update();
		Station=Table;
		Table.Close();
		Db.Close();
		m_Stations.Add(Station);
//		CStation *pStation=m_Stations.GetData();
//		if(pStation) std::sort(pStation,(pStation+m_Stations.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataStation::Delete(int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblStations Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrUnique = %d",m_Stations[Index].m_NrUnique);
			if(Table.FindFirst(Search))
			{
				Table.Delete();
				m_Stations.RemoveAt(Index);
//				CStation *pStation=m_Stations.GetData();
//				if(pStation) std::sort(pStation,(pStation+m_Stations.GetSize()));
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}
