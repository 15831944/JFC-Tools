// MailFaxDlg.cpp : implementation file
//

#include "stdafx.h"
#include "multiadm.h"
#include "MailFaxDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMailFaxDlg dialog


CMailFaxDlg::CMailFaxDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMailFaxDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMailFaxDlg)
	m_Fax = _T("");
	m_AdrMail = _T("");
	//}}AFX_DATA_INIT
	m_Mode_New=false;
	m_Mode_Modify=false;
}


void CMailFaxDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMailFaxDlg)
	DDX_Control(pDX, IDC_COMBO_STATION, m_ChoixStation);
	DDX_Control(pDX, IDC_COMBO_VILLE, m_ChoixVille);
	DDX_Text(pDX, IDC_EDIT_FAX, m_Fax);
	DDX_Text(pDX, IDC_EDIT_MAIL, m_AdrMail);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMailFaxDlg, CDialog)
	//{{AFX_MSG_MAP(CMailFaxDlg)
	ON_CBN_SELCHANGE(IDC_COMBO_STATION, OnSelchangeComboStation)
	ON_CBN_SELCHANGE(IDC_COMBO_VILLE, OnSelchangeComboVille)
	ON_BN_CLICKED(IDC_BTN_AJOUTER, OnBtnAjouter)
	ON_BN_CLICKED(IDC_BTN_MODIFIER, OnBtnModifier)
	ON_BN_CLICKED(IDC_BTN_SUPPRIMER, OnBtnSupprimer)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMailFaxDlg message handlers

void CMailFaxDlg :: ClearMailFax()
{
	m_AdrMail = "";
	m_Fax = "";
}

void CMailFaxDlg::OnSelchangeComboStation() 
{
	int Pos;

	m_Mode_New=false;
	m_Mode_Modify=false;

	// Index station s�lectionn�e
	Pos=m_ChoixStation.GetCurSel();
	if(Pos!=CB_ERR)
	{
		m_CurStation=m_Stations.m_Stations[Pos].m_NrUnique;
	}

	m_MailFaxs.Load();

	// recherche n� enrgt mail fax dans tanb enrgt mail fax
	m_CurMailFax = m_MailFaxs.GetMailFax(m_CurStation,m_CurVille);
	if(m_CurMailFax >= 0)
	{
		m_MailFaxCopy=m_MailFaxs.m_MailFaxs[m_CurMailFax];
	}
	else
	{
		m_CurMailFax=-1;
		m_MailFaxCopy.m_AdrMail = "";
		m_MailFaxCopy.m_Fax = "";
		m_MailFaxCopy.m_NrStation = m_CurStation;
		m_MailFaxCopy.m_NrVille = m_CurVille;

	}
	SetupMailFax();
	UpdateButtons();
	UpdateData(false);


}

void CMailFaxDlg::OnOK() 
{
	UpdateData(true);
	if(m_Mode_Modify)
	{
		if(m_MailFaxs.Modify(m_MailFaxCopy,m_CurMailFax))
		{
			m_Mode_Modify=false;
		}
		UpdateButtons();
		return;
	}
	if(m_Mode_New)
	{
		m_MailFaxCopy.m_NrStation=m_CurStation;
		m_MailFaxCopy.m_NrVille=m_CurVille;
		m_MailFaxCopy.m_AdrMail = m_AdrMail;
		m_MailFaxCopy.m_Fax = m_Fax;

		if(m_MailFaxs.Add(m_MailFaxCopy))
		{
			m_CurMailFax++;
			m_Mode_New=false;
		}
		else
		{
			CString Message="Une liste de Formats avec le m�me date existe d�j�";
			AfxMessageBox(Message);
		}
		UpdateButtons();
		return;
	}
	CDialog::OnOK();
}

void CMailFaxDlg::OnCancel() 
{
	if(m_Mode_New || m_Mode_Modify)
	{
		m_Mode_New=false;
		m_Mode_Modify=false;
		SetupMailFax();
		UpdateButtons();
	}
	else CDialog::OnCancel();
	

}

void CMailFaxDlg::OnSelchangeComboVille() 
{
	int Pos;

	m_Mode_New=false;
	m_Mode_Modify=false;

	// Index ville s�lectionn�e
	Pos=m_ChoixVille.GetCurSel();
	if(Pos!=CB_ERR)
	{
		m_CurVille=m_Villes.m_Villes[Pos].m_NrUnique;
	}
	m_MailFaxs.Load();

	// recherche n� enrgt mail fax dans tanb enrgt mail fax
	m_CurMailFax = m_MailFaxs.GetMailFax(m_CurStation,m_CurVille);
	if(m_CurMailFax >= 0)
	{
		m_MailFaxCopy=m_MailFaxs.m_MailFaxs[m_CurMailFax];
	}
	else
	{
		m_CurMailFax=-1;
		m_MailFaxCopy.m_AdrMail = "";
		m_MailFaxCopy.m_Fax = "";
		m_MailFaxCopy.m_NrStation = m_CurStation;
		m_MailFaxCopy.m_NrVille = m_CurVille;

	}
	SetupMailFax();
	UpdateButtons();
	UpdateData(false);
}

void CMailFaxDlg::UpdateMailFax(bool Load)
{
	int NbMailFax;	

	if(Load)
	{
		m_MailFaxs.Load();
		NbMailFax = m_MailFaxs.m_MailFaxs.GetSize();

		if(m_MailFaxs.m_MailFaxs.GetSize())
		{
			m_CurMailFax=0;
		}
		else m_CurMailFax=-1;
	}
	SetupMailFax();
	UpdateButtons();	
}

void CMailFaxDlg::SetupMailFax()
{
	int InxMailFax;

	CMailFax *MailFax=NULL;
	if(m_Mode_Modify || m_Mode_New)
		MailFax=&m_MailFaxCopy;
	else
	{
		if(m_CurMailFax<0)
		{
			ClearMailFax();
			return;
		}
		else
			MailFax=&m_MailFaxs.m_MailFaxs[m_CurMailFax];
	}

	m_Fax =  MailFax->m_Fax;
	m_AdrMail=  MailFax->m_AdrMail;	

	if (m_MailFaxs.MailFaxExist(MailFax->m_NrStation,MailFax->m_NrVille,InxMailFax))
	{
		if (m_Mode_Modify)
			m_MailFaxs.Modify(*MailFax,InxMailFax);
	}
	else
	{
		// on l'ajoute dans la table
		m_MailFaxs.Add(*MailFax);
	}

	UpdateData(false);	
}


BOOL CMailFaxDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if(!m_Stations.Load())
	{
		AfxMessageBox("Il faut cr�er au moins une Station");
		EndDialog(false);
	}
	if(!m_Villes.Load())
	{
		AfxMessageBox("Il faut cr�er au moins une Ville");
		EndDialog(false);
	}
	for(int x=0;x<m_Stations.m_Stations.GetSize();x++)
	{
		m_ChoixStation.AddString(m_Stations.m_Stations[x].m_Libelle);
	}
	for(x=0;x<m_Villes.m_Villes.GetSize();x++)
	{
		m_ChoixVille.AddString(m_Villes.m_Villes[x].m_Libelle);
	}
	m_CurStation=m_Stations.m_Stations[0].m_NrUnique;
	m_ChoixStation.SetCurSel(0);
	m_CurVille=m_Villes.m_Villes[0].m_NrUnique;
	m_ChoixVille.SetCurSel(0);

	UpdateMailFax(true);
	UpdateButtons();
	UpdateData(false);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE

}

void CMailFaxDlg::OnBtnAjouter() 
{
	UpdateData(true);
	m_Mode_New=TRUE;
	m_MailFaxCopy.m_AdrMail =m_AdrMail ;
	m_MailFaxCopy.m_Fax=m_Fax;
	m_MailFaxCopy.m_NrStation =m_CurStation;
	m_MailFaxCopy.m_NrVille =m_CurVille;
	SetupMailFax();
	UpdateButtons();
}

void CMailFaxDlg::OnBtnModifier() 
{
	UpdateData(true);
	if(m_CurMailFax>=0)
	{
		m_Mode_Modify=TRUE;
		m_MailFaxCopy=m_MailFaxs.m_MailFaxs[m_CurMailFax];
		SetupMailFax();
		UpdateButtons();
	}
}

void CMailFaxDlg::OnBtnSupprimer() 
{
	if(m_CurMailFax>=0)
	{

		if(m_MailFaxs.Delete(m_CurMailFax))
		{
			SetupMailFax();
			UpdateButtons();
			UpdateData(false);
		}
	}
	
}

void CMailFaxDlg::UpdateButtons()
{
	if(m_Mode_Modify || m_Mode_New)
	{
		if(m_Mode_Modify)
			GetDlgItem(IDC_BTN_SUPPRIMER)->EnableWindow(true); 
		else
			GetDlgItem(IDC_BTN_SUPPRIMER)->EnableWindow(false); 

		GetDlgItem(IDC_BTN_AJOUTER)->EnableWindow(false); 
		GetDlgItem(IDC_BTN_MODIFIER)->EnableWindow(false); 
		GetDlgItem(IDCANCEL)->EnableWindow(true); 
		GetDlgItem(IDOK)->EnableWindow(true); 
	}
	else
	{
		if(m_CurMailFax<0)
		{
			GetDlgItem(IDC_BTN_SUPPRIMER)->EnableWindow(false); 
			GetDlgItem(IDC_BTN_MODIFIER)->EnableWindow(false); 
			GetDlgItem(IDC_BTN_AJOUTER)->EnableWindow(true); 
		}
		else
		{
			GetDlgItem(IDC_BTN_SUPPRIMER)->EnableWindow(true); 
			GetDlgItem(IDC_BTN_MODIFIER)->EnableWindow(true); 
			GetDlgItem(IDC_BTN_AJOUTER)->EnableWindow(false); 
		}
		
		GetDlgItem(IDOK)->EnableWindow(true); 
		GetDlgItem(IDCANCEL)->EnableWindow(false); 
	}
}
