// DataTarif.h: interface for the CDataTarif class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATATARIF_H__A3EB53E3_7EFD_11D2_9B0D_004005327F6C__INCLUDED_)
#define AFX_DATATARIF_H__A3EB53E3_7EFD_11D2_9B0D_004005327F6C__INCLUDED_

#include "Tarif.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataTarif  
{
public:
	int Delete(int Index);
	int Add(CTarif &Tarif);
	int Modify(CTarif &Tarif, int Index);
	bool Load(long NrStation, long NrVille);
	CDataTarif();
	virtual ~CDataTarif();
	CTarifArray m_Tarifs;

};

#endif // !defined(AFX_DATATARIF_H__A3EB53E3_7EFD_11D2_9B0D_004005327F6C__INCLUDED_)
