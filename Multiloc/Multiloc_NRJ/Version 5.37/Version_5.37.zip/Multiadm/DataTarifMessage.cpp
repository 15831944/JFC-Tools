// DataTarifMessage.cpp: implementation of the CDataTarifMessage class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiadm.h"
#include "DataTarifMessage.h"

#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataTarifMessage::CDataTarifMessage()
{

}

CDataTarifMessage::~CDataTarifMessage()
{

}

bool CDataTarifMessage::Load(long NrStation, long NrVille)
{
	m_TarifMessage.RemoveAll();
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",FALSE,TRUE);
		CTblTarifMessage Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation = %d",NrStation);
			if(Table.FindFirst(Search))
			{
				do
				{
					CTarifMessage TarifMessage;
					TarifMessage = Table;
					m_TarifMessage.Add(TarifMessage);
				}
				while(Table.FindNext(Search));
			}
		}
		Table.Close();
		Db.Close();
		CTarifMessage *pTarifMessage = m_TarifMessage.GetData();
		if(pTarifMessage) std::sort(pTarifMessage,(pTarifMessage + m_TarifMessage.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataTarifMessage::Modify(CTarifMessage &TarifMessage, int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifMessage Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation = %d AND DateDebut = %s",m_TarifMessage[Index].m_NrStation,m_TarifMessage[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table = TarifMessage;
				Table.Update();
				m_TarifMessage[Index] = TarifMessage;
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataTarifMessage::Add(CTarifMessage &TarifMessage)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifMessage Table(&Db);
		Table.Open();
		Table.AddNew();
		Table = TarifMessage;
		Table.Update();
		Table.Close();
		Db.Close();
		m_TarifMessage.Add(TarifMessage);
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataTarifMessage::Delete(int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifMessage Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation= %d AND DateDebut = %s",m_TarifMessage[Index].m_NrStation,	m_TarifMessage[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Delete();
				m_TarifMessage.RemoveAt(Index);
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}
