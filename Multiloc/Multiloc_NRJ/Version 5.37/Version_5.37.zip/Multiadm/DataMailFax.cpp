// DataMailFax.cpp: implementation of the CDataMailFax class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiadm.h"
#include "DataMailFax.h"
#include "TblMailFax.h"

#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataMailFax::CDataMailFax()
{

}

CDataMailFax::~CDataMailFax()
{

}

int CDataMailFax ::Delete(int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblMailFax Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation= %d AND NrVille = %d",m_MailFaxs[Index].m_NrStation,m_MailFaxs[Index].m_NrVille);
			if(Table.FindFirst(Search))
			{
				Table.Delete();
				m_MailFaxs.RemoveAt(Index);
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataMailFax ::Add(CMailFax &MailFax)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblMailFax Table(&Db);
		Table.Open();
		Table.AddNew();
		Table=MailFax;
		Table.Update();
		Table.Close();
		Db.Close();
		m_MailFaxs.Add(MailFax);

	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataMailFax ::Modify(CMailFax &MailFax, int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblMailFax Table(&Db);
		
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation = %d AND NrVille = %d",m_MailFaxs[Index].m_NrStation,m_MailFaxs[Index].m_NrVille);
			//Search.Format("NrStation = %d AND NrVille = %d AND AdrMail =  %s AND Fax = %s",m_MailFaxs[Index].m_NrStation,m_MailFaxs[Index].m_NrVille,m_MailFaxs[Index].m_AdrMail,m_MailFaxs[Index].m_Fax);
			

//			Table.MoveFirst();
//			MailFax = Table;

//			Table.MoveNext();
//			MailFax = Table;

			//Search = "AdrMail = 222222222";

			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table=MailFax;
				Table.Update();
				m_MailFaxs[Index]=MailFax;
				CMailFax *pMailFax=m_MailFaxs.GetData();
				if(pMailFax) std::sort(pMailFax,(pMailFax+m_MailFaxs.GetSize()));
			}
		}
		Table.Close();
		Db.Close();
	}


	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;

/*
CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblVilles Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrUnique = %d",m_Villes[Index].m_NrUnique);

			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table=Ville;
				Table.Update();
				m_Villes[Index]=Ville;
				CVille *pVille=m_Villes.GetData();
				if(pVille) std::sort(pVille,(pVille+m_Villes.GetSize()));
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
*/
}

bool CDataMailFax ::Load()
{
	m_MailFaxs.RemoveAll();
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",FALSE,TRUE);
		CTblMailFax Table(&Db);
		Table.Open();
		while(!Table.IsEOF()) 
		{
			CMailFax MailFax;
			MailFax=Table;
			m_MailFaxs.Add(MailFax);
			Table.MoveNext();
		}
		Table.Close();
		Db.Close();
		CMailFax *pMailFax=m_MailFaxs.GetData();
		if(pMailFax) std::sort(pMailFax,(pMailFax+m_MailFaxs.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
	
}

// Renvoie n� enrgt mail fax
int CDataMailFax :: GetMailFax(long NrStation,long NrVille)
{
	int NSta,NVil;

	if (m_MailFaxs.GetSize() > 0 )
	{
		// recherche dans tableau d�j� charg�
		for (int i = 0;i<m_MailFaxs.GetSize();i++)
		{
			NSta =  m_MailFaxs[i].m_NrStation;
			NVil =  m_MailFaxs[i].m_NrVille;

			if (m_MailFaxs[i].m_NrStation== NrStation && m_MailFaxs[i].m_NrVille == NrVille)
				return i;			
		}
		return -1;
	}
	else
		return -1;

}

bool CDataMailFax :: MailFaxExist(long NrStation,long NrVille,int &InxMailFax)
{
	int NSta,NVil;

	if (m_MailFaxs.GetSize() > 0 )
	{
		// recherche dans tableau d�j� charg�
		for (int i = 0;i<m_MailFaxs.GetSize();i++)
		{
			NSta =  m_MailFaxs[i].m_NrStation;
			NVil =  m_MailFaxs[i].m_NrVille;

			if (m_MailFaxs[i].m_NrStation== NrStation && m_MailFaxs[i].m_NrVille == NrVille)
			{
				InxMailFax = i;
				return true;
			}				
		}
		return false;
	}
	else
		return false;			
}	