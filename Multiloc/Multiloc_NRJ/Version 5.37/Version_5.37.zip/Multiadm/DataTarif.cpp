// DataTarif.cpp: implementation of the CDataTarif class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiadm.h"
#include "DataTarif.h"

#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataTarif::CDataTarif()
{

}

CDataTarif::~CDataTarif()
{

}

bool CDataTarif::Load(long NrStation, long NrVille)
{
	m_Tarifs.RemoveAll();
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",FALSE,TRUE);
		CTblTarifs Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation = %d AND NrVille = %d",NrStation,NrVille);
			if(Table.FindFirst(Search))
			{
				do
				{
					CTarif Tarif;
					Tarif=Table;
					m_Tarifs.Add(Tarif);
				}
				while(Table.FindNext(Search));
			}
		}
		Table.Close();
		Db.Close();
		CTarif *pTarif=m_Tarifs.GetData();
		if(pTarif) std::sort(pTarif,(pTarif+m_Tarifs.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataTarif::Modify(CTarif &Tarif, int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifs Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation = %d AND NrVille = %d AND DateDebut = %s",m_Tarifs[Index].m_NrStation,m_Tarifs[Index].m_NrVille,
				m_Tarifs[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table=Tarif;
				Table.Update();
				m_Tarifs[Index]=Tarif;
//				CTarif *pTarif=m_Tarifs.GetData();
//				if(pTarif) std::sort(pTarif,(pTarif+m_Tarifs.GetSize()));
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataTarif::Add(CTarif &Tarif)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifs Table(&Db);
		Table.Open();
		Table.AddNew();
		Table=Tarif;
		Table.Update();
		Table.Close();
		Db.Close();
		m_Tarifs.Add(Tarif);
//		CTarif *pTarif=m_Tarifs.GetData();
//		if(pTarif) std::sort(pTarif,(pTarif+m_Tarifs.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataTarif::Delete(int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifs Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation= %d AND NrVille = %d AND DateDebut = %s",m_Tarifs[Index].m_NrStation,m_Tarifs[Index].m_NrVille,
				m_Tarifs[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Delete();
				m_Tarifs.RemoveAt(Index);
//				CTarif *pTarif=m_Tarifs.GetData();
//				if(pTarif) std::sort(pTarif,(pTarif+m_Tarifs.GetSize()));
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}
