// DataVille.h: interface for the CDataVille class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATAVILLE_H__A3EB53E1_7EFD_11D2_9B0D_004005327F6C__INCLUDED_)
#define AFX_DATAVILLE_H__A3EB53E1_7EFD_11D2_9B0D_004005327F6C__INCLUDED_

#include "Ville.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataVille  
{
public:
	int Delete(int Index);
	int Add(CVille &Ville);
	int Modify(CVille &Ville, int Index);
	bool Load();
	int CodeVille(CString LibelleVille);
	int CodeVilleExist(int CodeVille);
	CDataVille();
	virtual ~CDataVille();
	CVilleArray m_Villes;

protected:
};

#endif // !defined(AFX_DATAVILLE_H__A3EB53E1_7EFD_11D2_9B0D_004005327F6C__INCLUDED_)
