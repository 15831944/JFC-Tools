// DlgImportGrpGlobal.cpp : implementation file
//

#include "stdafx.h"
#include "multiadm.h"
#include "DlgImportGrpGlobal.h"
#include "ImportGrp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgImportGrpGlobal dialog


CDlgImportGrpGlobal::CDlgImportGrpGlobal(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgImportGrpGlobal::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgImportGrpGlobal)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlgImportGrpGlobal::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgImportGrpGlobal)
	DDX_Control(pDX, IDC_PROGRESS_IMPORT, m_ProgressImportGrp);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgImportGrpGlobal, CDialog)
	//{{AFX_MSG_MAP(CDlgImportGrpGlobal)
	ON_BN_CLICKED(IDC_IMPORTGRP, OnImportgrp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgImportGrpGlobal message handlers

void CDlgImportGrpGlobal::OnImportgrp() 
{
	CImportGrp Import;
	CString FileGrp;

	// Choix du fichier globale GRP � importer
	if (!Import.ChoixFicGeneGRP(FileGrp,&m_ProgressImportGrp))
	{
		// Attention vraisemblablement un probl�me dans fichier g�n�rale des tarifs
		AfxMessageBox("Probl�me de cr�ation fichier transfert GRP, v�rifier votre fichier");	
	}
	m_ProgressImportGrp.SetRange(0,100);
}

BOOL CDlgImportGrpGlobal::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_ProgressImportGrp.SetRange(0,100);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
