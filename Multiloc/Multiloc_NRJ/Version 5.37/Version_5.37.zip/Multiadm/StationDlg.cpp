// StationDlg.cpp : implementation file
//

#include "stdafx.h"
#include "multiadm.h"
#include "StationDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStationDlg dialog


CStationDlg::CStationDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CStationDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CStationDlg)
	m_String = _T("");
	//}}AFX_DATA_INIT
	m_Mode_Modify=false;
	m_Mode_New=false;
	m_CurData=-1;
}


void CStationDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStationDlg)
	DDX_Control(pDX, IDC_LIST, m_ListBox);
	DDX_Text(pDX, IDC_EDIT, m_String);
	DDV_MaxChars(pDX, m_String, 18);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CStationDlg, CDialog)
	//{{AFX_MSG_MAP(CStationDlg)
	ON_BN_CLICKED(IDC_BN_AJOUTER, OnBnAjouter)
	ON_BN_CLICKED(IDC_BN_SUPPRIMER, OnBnSupprimer)
	ON_LBN_SELCHANGE(IDC_LIST, OnSelchangeList)
	ON_BN_CLICKED(IDC_BN_MODIFIER, OnBnModifier)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStationDlg message handlers
void CStationDlg::OnBnModifier() 
{
	m_Mode_Modify=true;
	UpdateButtons();
	UpdateData(false);
}

void CStationDlg::OnBnAjouter() 
{
	m_Mode_New=true;
	m_DataCopy.m_NrUnique=-1;
	m_DataCopy.m_Libelle="Nouvelle Station";
	SetData();
	UpdateButtons();
	UpdateData(false);
}

void CStationDlg::OnBnSupprimer() 
{
	if(m_CurData<0) return;
	if(m_Mode_Modify || m_Mode_New) return;
	if(m_Data.Delete(m_CurData))
	{
		SetupData(false);
		UpdateButtons();
		UpdateData(false);
	}
}

void CStationDlg::OnCancel() 
{
	if(m_Mode_New || m_Mode_Modify)
	{
		m_Mode_New=false;
		m_Mode_Modify=false;
		SetupData(false);
		UpdateButtons();
		UpdateData(false);
	}
	else CDialog::OnCancel();
}

void CStationDlg::OnOK() 
{
	if(m_Mode_Modify)
	{
		GetData();
		if(m_Data.Modify(m_DataCopy,m_CurData))
		{
			m_Mode_Modify=false;
			m_DataCopy=m_Data.m_Stations[m_CurData];
			SetupData(false);
		}
		UpdateButtons();
		return;
	}
	if(m_Mode_New)
	{
		GetData();
		m_DataCopy.m_NrUnique=0;
		if(m_Data.Add(m_DataCopy))
		{
			m_Mode_New=false;
			SetupData(true);
		}
		UpdateButtons();
		return;
	}
	CDialog::OnOK();
}

BOOL CStationDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	SetupData(true);
	UpdateButtons();
	UpdateData(false);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CStationDlg::OnSelchangeList() 
{
	m_Mode_New=false;
	m_Mode_Modify=false;
	m_CurData=m_ListBox.GetCurSel();
	m_DataCopy=m_Data.m_Stations[m_ListBox.GetCurSel()];
	SetData();
	UpdateButtons();
	UpdateData(false);
}

void CStationDlg::SetupData(bool Load)
{
	if(Load) m_Data.Load();
	m_ListBox.ResetContent();
	if(m_Data.m_Stations.GetSize())
	{
		for(int x=0;x<m_Data.m_Stations.GetSize();x++)
		{
			CString String;
			String.Format("%4d\t%s",m_Data.m_Stations[x].m_NrUnique,m_Data.m_Stations[x].m_Libelle);
			m_ListBox.AddString(String);
		}
		m_ListBox.SetCurSel(0);
		m_DataCopy=m_Data.m_Stations[0];
		m_CurData=0;
	}
	else
	{
		m_DataCopy.m_NrUnique=0;
		m_DataCopy.m_Libelle="";
		m_CurData=-1;

	}
	SetData();
	UpdateData(false);
}

void CStationDlg::UpdateButtons()
{
	if(m_Mode_Modify || m_Mode_New)
	{
		if(m_Mode_Modify) GetDlgItem(IDC_BN_SUPPRIMER)->EnableWindow(true); 
		else GetDlgItem(IDC_BN_SUPPRIMER)->EnableWindow(false); 
		GetDlgItem(IDC_BN_AJOUTER)->EnableWindow(false); 
		GetDlgItem(IDC_BN_MODIFIER)->EnableWindow(false); 
		GetDlgItem(IDC_EDIT)->EnableWindow(true); 
		GetDlgItem(IDC_LIST)->EnableWindow(false); 
		GetDlgItem(IDCANCEL)->EnableWindow(true); 
		GetDlgItem(IDOK)->EnableWindow(true); 
	}
	else
	{
		if(m_CurData<0)
		{
			GetDlgItem(IDC_BN_SUPPRIMER)->EnableWindow(false); 
			GetDlgItem(IDC_BN_MODIFIER)->EnableWindow(false); 
		}
		else
		{
			GetDlgItem(IDC_BN_SUPPRIMER)->EnableWindow(true); 
			GetDlgItem(IDC_BN_MODIFIER)->EnableWindow(true); 
		}
		GetDlgItem(IDC_BN_AJOUTER)->EnableWindow(true); 
		GetDlgItem(IDC_EDIT)->EnableWindow(true); 
		GetDlgItem(IDC_LIST)->EnableWindow(true); 

		GetDlgItem(IDOK)->EnableWindow(true); 
		GetDlgItem(IDCANCEL)->EnableWindow(false); 
	}
}

void CStationDlg::SetData()
{
	m_String=m_DataCopy.m_Libelle;
	UpdateData(false);
}

void CStationDlg::GetData()
{
	UpdateData(true);
	m_String.TrimLeft();
	m_String.TrimRight();
	m_DataCopy.m_Libelle=m_String;
}

