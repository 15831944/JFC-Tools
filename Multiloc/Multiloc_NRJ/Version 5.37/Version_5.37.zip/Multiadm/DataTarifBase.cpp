// DataTarifBase.cpp: implementation of the CDataTarifBase class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiadm.h"
#include "DataTarifBase.h"

#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataTarifBase::CDataTarifBase()
{

}

CDataTarifBase::~CDataTarifBase()
{

}

bool CDataTarifBase::Load(long NrStation, long NrVille)
{
	m_TarifBase.RemoveAll();
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",FALSE,TRUE);
		CTblTarifBase Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation = %d AND NrVille = %d",NrStation,NrVille);
			if(Table.FindFirst(Search))
			{
				do
				{
					CTarifBase TarifBase;
					TarifBase=Table;
					m_TarifBase.Add(TarifBase);
				}
				while(Table.FindNext(Search));
			}
		}
		Table.Close();
		Db.Close();
		CTarifBase *pTarifBase=m_TarifBase.GetData();
		if(pTarifBase) std::sort(pTarifBase,(pTarifBase + m_TarifBase.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataTarifBase::Modify(CTarifBase &TarifBase, int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifBase Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation = %d AND NrVille = %d AND DateDebut = %s",
				           m_TarifBase[Index].m_NrStation,
						   m_TarifBase[Index].m_NrVille,
				           m_TarifBase[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table=TarifBase;
				Table.Update();
				m_TarifBase[Index] = TarifBase;
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataTarifBase::Add(CTarifBase &TarifBase)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifBase Table(&Db);
		Table.Open();
		Table.AddNew();
		Table = TarifBase;
		Table.Update();
		Table.Close();
		Db.Close();
		m_TarifBase.Add(TarifBase);
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataTarifBase::Delete(int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblTarifBase Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrStation= %d AND NrVille = %d AND DateDebut = %s",m_TarifBase[Index].m_NrStation,m_TarifBase[Index].m_NrVille,
				m_TarifBase[Index].m_DateDebut.Format("#%m/%d/%y#"));
			if(Table.FindFirst(Search))
			{
				Table.Delete();
				m_TarifBase.RemoveAt(Index);
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}
