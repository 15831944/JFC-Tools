// multiadm.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "multiadm.h"
#include "multiadmDlg.h"
#include "noyau.h"
#include "TarifDlg.h"
#include "GrpDlg.h"
#include "StationDlg.h"
#include "CibleDlg.h"
#include "VilleDlg.h"
#include "PrimeDlg.h"
#include "VolumeDlg.h"
#include "FormatDlg.h"
#include "MailFaxDlg.h"
#include "ImportTarif.h"
#include "ImportGrp.h"
#include "ImportTarifGlobal.h"
#include "DlgImportGrpGlobal.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMultiadmApp

BEGIN_MESSAGE_MAP(CMultiadmApp, CWinApp)
	//{{AFX_MSG_MAP(CMultiadmApp)
	ON_COMMAND(ID_STATIONS, OnStations)
	ON_COMMAND(ID_TARIFS, OnTarifs)
	ON_COMMAND(ID_VILLES, OnVilles)
	ON_COMMAND(ID_GRPS, OnGrps)
	ON_COMMAND(ID_CIBLES, OnCibles)
	ON_COMMAND(ID_FORMAT, OnFormat)
	ON_COMMAND(ID_PRIME, OnPrime)
	ON_COMMAND(ID_VOLUMES, OnVolumes)
	ON_COMMAND(ID_TARIFS_IMPORT, OnTarifsImport)
	ON_COMMAND(ID_GRPS_IMPORT, OnGrpsImport)
	ON_COMMAND(IDFAXMAIL, OnFaxmail)
	ON_COMMAND(ID_TARIFSEURO_IMPORT, OnTarifseuroImport)
	ON_COMMAND(ID_PRIMEREGION, OnPrimeregion)
	ON_COMMAND(ID_VOLUMESREGION, OnVolumesregion)
	ON_COMMAND(ID_GRPS_IMPORTGLOBAL, OnGrpsImportglobal)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMultiadmApp construction

CMultiadmApp::CMultiadmApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CMultiadmApp object

CMultiadmApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CMultiadmApp initialization

BOOL CMultiadmApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Modif de Sylvain
//	COleDateTime date = COleDateTime::GetCurrentTime();
//	COleDateTime ref(2000,1,12,0,0,0);
//	if(date>=ref)
//	{
//		AfxMessageBox("Cette version du logiciel n'est plus valide. Contactez JFC...");
//		return FALSE;
//	}
	// Modif de Sylvain

	CMultiadmDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

void CMultiadmApp::OnStations() 
{
/*
	CNoyau Noyau;
	COleDateTime Debut(1998,6,1,0,0,0);
	COleDateTime Fin(1999,12,1,0,0,0);
	Noyau.ChargerTable(Debut,Fin);
	Noyau.ChargerCible(0);
	*/
	CStationDlg Dialog;
	Dialog.DoModal();
}

void CMultiadmApp::OnTarifs() 
{
	CTarifDlg Dialog;
	Dialog.DoModal();
}

void CMultiadmApp::OnVilles() 
{
	CVilleDlg Dialog;
	Dialog.DoModal();
}

void CMultiadmApp::OnGrps() 
{
	CGrpDlg Dialog;
	Dialog.DoModal();
}

void CMultiadmApp::OnCibles() 
{
	CCibleDlg Dialog;
	Dialog.DoModal();
}

void CMultiadmApp::OnFormat() 
{
	CFormatDlg Dialog;
	Dialog.DoModal();
}

void CMultiadmApp::OnPrime() 
{
	CPrimeDlg Dialog;

	// Gestion des remises financi�res nationales
	Dialog.m_TypePrime = 0;
	Dialog.DoModal();
}

void CMultiadmApp::OnVolumes() 
{
	CVolumeDlg Dialog;

	// Gestion des volumes en national
	Dialog.m_TypeVolume = 0;
	Dialog.DoModal();
}

void CMultiadmApp::OnTarifsImport() 
{
	CImportTarif Import;
	Import.ImportFile();
}

// Import des tarifs via fichier global d�fini comme ci-dessous

void CMultiadmApp::OnTarifseuroImport() 
{

	//CImportTarif Import;
	//CString FileTarif;

	CImportTarifGlobal DlgTarifGlobal;

	DlgTarifGlobal.DoModal();
	
}

void CMultiadmApp::OnGrpsImport() 
{
	CImportGrp Import;
	Import.ImportFile();
}

void CMultiadmApp::OnFaxmail() 
{
	CMailFaxDlg Dialog;
	Dialog.DoModal();
}

void CMultiadmApp::OnConvEuro() 
{
	AfxMessageBox("Attention les tarifs vont �tre convertis en Euro, arrondi � l'euro sup�rieur !!!");
}



void CMultiadmApp::OnPrimeregion() 
{
	CPrimeDlg Dialog;

	// Gestion des remises financi�res r�gionales
	Dialog.m_TypePrime = 1;
	Dialog.DoModal();
	
}

void CMultiadmApp::OnVolumesregion() 
{
	CVolumeDlg Dialog;

	// Gestion des volumes en r�gional
	Dialog.m_TypeVolume = 1;
	Dialog.DoModal();	
}

void CMultiadmApp::OnGrpsImportglobal() 
{
	// Affichage boite de dialogue import tot grps
	CDlgImportGrpGlobal DlgGrpGlobal;
	DlgGrpGlobal.DoModal();
}
