// DataTarifSaison.h: interface for the CDataTarifSaison class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATATARIFSAISON_H__71B821B1_2A92_4DFF_98C2_D84A7B2E0C71__INCLUDED_)
#define AFX_DATATARIFSAISON_H__71B821B1_2A92_4DFF_98C2_D84A7B2E0C71__INCLUDED_

#include "TarifSaison.h"	// Added by ClassView

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataTarifSaison  
{
public:

	CDataTarifSaison();
	virtual ~CDataTarifSaison();

	int Delete(int Index);
	int Add(CTarifSaison &TarifSaison);
	int Modify(CTarifSaison &TarifSaison, int Index);
	bool Load(long NrStation, long NrVille);
	
	CTarifSaisonArray m_TarifSaison;
};

#endif // !defined(AFX_DATATARIFSAISON_H__71B821B1_2A92_4DFF_98C2_D84A7B2E0C71__INCLUDED_)
