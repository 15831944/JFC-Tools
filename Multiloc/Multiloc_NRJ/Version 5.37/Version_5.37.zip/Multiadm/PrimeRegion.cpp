// PrimeRegion.cpp: implementation of the CPrimeRegion class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiadm.h"
#include "PrimeRegion.h"

#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPrimeRegion::CPrimeRegion()
{
	m_DateDebut=COleDateTime::GetCurrentTime();
	m_Palier.RemoveAll();
}

CPrimeRegion::~CPrimeRegion()
{

}

CPrimeRegion::CPrimeRegion(const CPrimeRegion &Source)
{
	*this=Source;
}

CPrimeRegion & CPrimeRegion::operator=(const CPrimeRegion &Source)
{
	m_DateDebut=Source.m_DateDebut;
	m_Palier.Copy(Source.m_Palier);
	return(*this);
}

CPrimeRegion & CPrimeRegion::operator=(const CTblPrimesRegion &Source)
{
	m_DateDebut=Source.m_DateDebut;
	m_Palier.RemoveAll();
	int *pPtr=(int *)Source.m_Data.GetData();
	int Count=*pPtr; pPtr++;

	// Modif CGV 2002
	/*
	for(int x=0;x<Count;x++)
	{
		CPalier Palier;
		Palier.m_Palier=*pPtr;
		pPtr++;
		float *pFloat=(float*)pPtr;
		Palier.m_Coef=*pFloat;
		pFloat++;
		pPtr=(int *)pFloat;
		m_Palier.Add(Palier);
	}
	*/
	float *pFloat=(float*)pPtr;
	for(int x=0;x<Count;x++)
	{
		CPalier Palier;
		Palier.m_Palier=*pFloat;
		pFloat++;
		Palier.m_Coef=*pFloat;
		pFloat++;
		m_Palier.Add(Palier);
	}

	CPalier *pPalier=m_Palier.GetData();
	if(pPalier) std::sort(pPalier,(pPalier+m_Palier.GetSize()));
	return(*this);
}

bool CPrimeRegion::operator<(const CPrimeRegion &Source)
{
	if(m_DateDebut<Source.m_DateDebut) return(TRUE);
	else return(FALSE);
}
