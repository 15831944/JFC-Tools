// DataTarifBase.h: interface for the CDataTarifBase class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATATARIFBASE_H__AF5D38EE_28BC_43F4_AF8D_805C5EE7FDBF__INCLUDED_)
#define AFX_DATATARIFBASE_H__AF5D38EE_28BC_43F4_AF8D_805C5EE7FDBF__INCLUDED_

#include "TarifBase.h"	// Added by ClassView

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataTarifBase  
{
public:
	CDataTarifBase();
	virtual ~CDataTarifBase();

	int Delete(int Index);
	int Add(CTarifBase &TarifBase);
	int Modify(CTarifBase &TarifBase, int Index);
	bool Load(long NrStation, long NrVille);
	
	CTarifBaseArray m_TarifBase;


	//CDataTarifBase(CDataTarifBase const &);
	//CDataTarifBase & operator=(CDataTarifBase const &);

};

#endif // !defined(AFX_DATATARIFBASE_H__AF5D38EE_28BC_43F4_AF8D_805C5EE7FDBF__INCLUDED_)
