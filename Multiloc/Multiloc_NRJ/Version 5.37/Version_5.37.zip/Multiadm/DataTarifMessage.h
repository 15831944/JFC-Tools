// DataTarifMessage.h: interface for the CDataTarifMessage class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATATARIFMESSAGE_H__3AE7A103_F483_499B_97D0_6EFF50C7AF31__INCLUDED_)
#define AFX_DATATARIFMESSAGE_H__3AE7A103_F483_499B_97D0_6EFF50C7AF31__INCLUDED_

#include "TarifMessage.h"	// Added by ClassView

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataTarifMessage  
{
public:
	CDataTarifMessage();
	virtual ~CDataTarifMessage();

	int Delete(int Index);
	int Add(CTarifMessage &TarifMessage);
	int Modify(CTarifMessage &TarifMessage, int Index);
	bool Load(long NrStation, long NrVille);
	
	CTarifMessageArray m_TarifMessage;

};

#endif // !defined(AFX_DATATARIFMESSAGE_H__3AE7A103_F483_499B_97D0_6EFF50C7AF31__INCLUDED_)
