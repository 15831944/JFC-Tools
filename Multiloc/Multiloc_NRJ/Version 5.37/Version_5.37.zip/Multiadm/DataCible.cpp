// DataCible.cpp: implementation of the CDataCible class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiadm.h"
#include "DataCible.h"
#include "TblCibles.h"

#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataCible::CDataCible()
{
}

CDataCible::~CDataCible()
{

}

bool CDataCible::Load()
{
	m_Cibles.RemoveAll();
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",FALSE,TRUE);
		CTblCibles Table(&Db);
		Table.Open();
		while(!Table.IsEOF()) 
		{
			CCible Cible;
			Cible=Table;
			m_Cibles.Add(Cible);
			Table.MoveNext();
		}
		Table.Close();
		Db.Close();
		CCible *pCible=m_Cibles.GetData();
		if(pCible) std::sort(pCible,(pCible+m_Cibles.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataCible::Modify(CCible &Cible, int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblCibles Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrUnique = %d",m_Cibles[Index].m_NrUnique);
			if(Table.FindFirst(Search))
			{
				Table.Edit();
				Table=Cible;
				Table.Update();
				m_Cibles[Index]=Cible;
				CCible *pCible=m_Cibles.GetData();
				if(pCible) std::sort(pCible,(pCible+m_Cibles.GetSize()));
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataCible::Add(CCible &Cible)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblCibles Table(&Db);
		Table.Open();
		Table.AddNew();
		Table=Cible;
		Table.Update();
		Cible=Table;
		Table.Close();
		Db.Close();
		m_Cibles.Add(Cible);
		CCible *pCible=m_Cibles.GetData();
		if(pCible) std::sort(pCible,(pCible+m_Cibles.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}

int CDataCible::Delete(int Index)
{
	CDaoDatabase Db;
	try
	{
		Db.Open("multiloc.mdb",TRUE,FALSE);
		CTblCibles Table(&Db);
		Table.Open();
		if(!Table.IsEOF())
		{
			CString Search;
			Search.Format("NrUnique = %d",m_Cibles[Index].m_NrUnique);
			if(Table.FindFirst(Search))
			{
				Table.Delete();
				m_Cibles.RemoveAt(Index);
				CCible *pCible=m_Cibles.GetData();
				if(pCible) std::sort(pCible,(pCible+m_Cibles.GetSize()));
			}
		}
		Table.Close();
		Db.Close();
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}
