// DataClient.cpp: implementation of the CDataClient class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiloc.h"
#include "DataClient.h"

#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataClient::CDataClient()
{

}

CDataClient::~CDataClient()
{

}

bool CDataClient::Load()
{
	m_TabClients.RemoveAll();
	CDaoDatabase Db;
	try
	{
		//Db.Open("multiccc.mdb",FALSE,TRUE);
		Db.Open("multicom.mdb",FALSE,TRUE);
		CTblClient Table(&Db);
		Table.Open();
		while(!Table.IsEOF()) 
		{
			CClient Client;
			Client=Table;
			m_TabClients.Add(Client);
			Table.MoveNext();
		}
		Table.Close();
		Db.Close();
		CClient *pClient=m_TabClients.GetData();
		if(pClient) std::sort(pClient,(pClient+m_TabClients.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}
