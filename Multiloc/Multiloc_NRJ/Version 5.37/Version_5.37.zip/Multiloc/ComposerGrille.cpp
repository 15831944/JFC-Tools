// ComposerGrille.cpp: implementation of the CComposerGrille class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiloc.h"
#include "ComposerGrille.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CComposerGrille::CComposerGrille()
{
	m_pSpotJH=NULL;
	m_NrSymbolActif=0;
}

CComposerGrille::~CComposerGrille()
{

}


bool CComposerGrille::OnLeftClick(short X, short Y, short PosX, short PosY, CPoint pos)
{

	if (m_pDoc->m_ModeTarif == 0)
	{
		// composition m�lodie en mode classique
		if(m_pSpotJH==NULL){return TRUE;}

		if(m_pSpotJH[X][Y]==0)
			m_pSpotJH[X][Y]=m_NrSymbolActif+1;

		else if
			(m_pSpotJH[X][Y]==m_NrSymbolActif+1)m_pSpotJH[X][Y]=0;

		else 
			m_pSpotJH[X][Y]=m_NrSymbolActif+1;
	}
	else
	{
		// composition m�lodie en mode floating
		short ne=m_pSpotJH[X][Y]/100;
		short nr=m_pSpotJH[X][Y]%100;

		m_pSpotJH[X][Y] = m_pSpotJH[X][Y] + 1;
		m_pSpotJH[X][Y] = m_pSpotJH[X][Y] % 100;

	}		

	// Mise � jour
	UpdateNbSpot();
	InvalidateRect(NULL);
	return TRUE;
}

bool CComposerGrille::OnRightClick(short X, short Y, short PosX, short PosY, CPoint pos)
{
	if (m_pDoc->m_ModeTarif > 0)
	{

		// Suppression des spots en mode Floating
		m_pSpotJH[X][Y] = 0;

		// Mise � jour
		UpdateNbSpot();
		InvalidateRect(NULL);
	}
	return TRUE;
}

void CComposerGrille::DessineCellule(CDC * dc, CRect RectCel, short X, short Y, short PosX, short PosY)
{
	if (m_pDoc->m_ModeTarif == 0)
	{
		// dessin �lmt en mode classique
		short nb;
		if(m_pSpotJH==NULL){
			CBrush b(RGB(192,192,192));
			dc->FillRect(RectCel,&b);
			return;
		}
		if((nb=m_pSpotJH[X][Y])>0){
			dc->DrawIcon(RectCel.left,RectCel.top,(*m_phIcon)[nb-1]);
		}
	}
	else
	{
		// Mode grille Floating (Jour x Format dispo)
		int nr=m_pSpotJH[X][Y]%100;
		if(nr>0)
		{
			CString NbSpots;
			if (m_pSpotJH[X][Y]%100 < 10)
			{
				NbSpots.Format("%2d",m_pSpotJH[X][Y]%100);
			}
			else
			{
				NbSpots.Format("%d",m_pSpotJH[X][Y]%100);
			}

			// Signal des spots gratos couleur fond cellule jaune clair
			if (Y % 2 != 0)
				dc->FillSolidRect(RectCel,RGB(249,242,193));

			dc->DrawText(NbSpots,RectCel,0);
		}
	}
}

void CComposerGrille::UpdateNbSpot()
{
	int j,h,f,nb=0;
	
	if (m_pDoc->m_ModeTarif == 0)
	{
		// maj nb spots en mode classique
		for (j=0;j<7;j++) for (h=0;h<m_pDoc->m_NbHoraire;h++)
		{

			short indCombi  = m_pSpotJH[j][h]-1;
			int Taille		= m_pDoc->m_Combin.GetSize(); 

			if(m_pSpotJH[j][h])
				nb+=m_pDoc->m_Combin[m_pSpotJH[j][h]-1].m_Def.GetSize();
		}
	}
	else
	{
		// maj nb spots en mode floating

		for (j=0;j<7;j++) 
			for (f=0;f<m_pDoc->m_NbFormat;f++)
			{
				// Nb spot pour & jour et 1 ligne format
				int nr=m_pSpotJH[j][f]%100;

				// Total global nb spots
				if(m_pSpotJH[j][f])	nb += nr;
			}
	}
	
	// maj boite affichage nb spots
	CString txt;
	txt.Format("%d",nb);
	m_pEditNbSpot->SetWindowText(txt);
}

void CComposerGrille::SetSymbolActif(int nr)
{
	m_NrSymbolActif=nr;
}

void CComposerGrille::SetTabIcon(void *tab){
	m_phIcon=(CArray<HICON ,HICON>*)tab;
}
