// DlgSelection.cpp : implementation file
//

#include "stdafx.h"
#include "multiloc.h"
#include "DlgSelection.h"
extern CMultilocApp theApp;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgSelection dialog


CDlgSelection::CDlgSelection(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgSelection::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgSelection)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

}


void CDlgSelection::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgSelection)
	DDX_Control(pDX, IDC_COMBOBOXEX, m_Combo);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgSelection, CDialog)
	//{{AFX_MSG_MAP(CDlgSelection)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgSelection message handlers

void CDlgSelection::OnOK() 
{
	m_Sel=m_Combo.GetCurSel();
	if(m_Sel==CB_ERR){
		MessageBox("La s�lection est invalide");
		return;
	}
	if(m_NrLien.GetSize()>m_Sel)m_Sel=m_NrLien[m_Sel];

	CDialog::OnOK();
}

BOOL CDlgSelection::OnInitDialog() 
{
	theApp.JoueMusic(7);
	CDialog::OnInitDialog();
	m_Combo.SetImageList(m_pIL);
	COMBOBOXEXITEM cbi;
	memset(&cbi,0,sizeof(cbi));
	cbi.mask = CBEIF_IMAGE | CBEIF_OVERLAY |CBEIF_SELECTEDIMAGE;//| CBEIF_INDENT ;
	
	int iItem=0;
	m_NrLien.RemoveAll();
	for(short i=0;i<m_pIL->GetImageCount();i++){
		if(m_Use.GetSize()>i && m_Use[i])continue;
		m_NrLien.Add(i);
		cbi.iItem = iItem++;
		cbi.iImage = i;
		cbi.iSelectedImage = i;
		cbi.iOverlay = i;
		m_Combo.InsertItem(&cbi);
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
