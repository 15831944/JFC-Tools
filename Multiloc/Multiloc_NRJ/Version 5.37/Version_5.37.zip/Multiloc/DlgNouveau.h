#if !defined(AFX_DLGNOUVEAU_H__CAB02341_57AF_11D2_AD1C_0080C708A895__INCLUDED_)
#define AFX_DLGNOUVEAU_H__CAB02341_57AF_11D2_AD1C_0080C708A895__INCLUDED_

#include "DataCommercial.h"
#include "DataClient.h"

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DlgNouveau.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgNouveau dialog

#include "noyau.h"
#include "noyaucommande.h"

class CDlgNouveau : public CDialog
{
// Construction
public:

	~CDlgNouveau();

	CDlgNouveau(CWnd* pParent = NULL);   // standard constructor
	

// Dialog Data
	//{{AFX_DATA(CDlgNouveau)
	enum { IDD = IDD_NOUVEAU };
	CComboBox	m_ComboClient;
	CComboBox	m_ComboCommercial;
	CComboBox	m_ComboCible;
	CString	m_CibleSelect;
	int		m_Duree;
	COleDateTime	m_DateDebut;
	COleDateTime	m_DateFin;
	CString	m_ClientSelect;
	CString	m_CommercialSelect;
	CString	m_NomCommercialODP;
	CString	m_Enseigne;
	BOOL	m_ChkClientNRL;
	//}}AFX_DATA


	short m_NrCibleSelect;
	CString m_CodeCommercialSelect;
	CString m_CodeClientSelect;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgNouveau)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	CNoyau *m_pNoyau;
	CNoyauCommande *m_pNoyauCommande;
	// Generated message map functions
	//{{AFX_MSG(CDlgNouveau)
	virtual BOOL OnInitDialog();
	afx_msg void OnCancelMode();
	virtual void OnOK();
	afx_msg void OnChangeEditDuree();
	afx_msg void OnDeltaposSpinDuree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDateDebutChange(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDateFinChange(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGNOUVEAU_H__CAB02341_57AF_11D2_AD1C_0080C708A895__INCLUDED_)
