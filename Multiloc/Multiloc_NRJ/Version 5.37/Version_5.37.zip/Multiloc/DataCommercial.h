// DataCommercial.h: interface for the CDataCommercial class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATACOMMERCIAL_H__919877A8_439A_11D4_8658_0080C708A895__INCLUDED_)
#define AFX_DATACOMMERCIAL_H__919877A8_439A_11D4_8658_0080C708A895__INCLUDED_

#include "Commercial.h"	// Added by ClassView

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataCommercial  
{
public:
	CDataCommercial();
	virtual ~CDataCommercial();

	bool Load();
	CCommercialArray m_TabCommerciaux;
};

#endif // !defined(AFX_DATACOMMERCIAL_H__919877A8_439A_11D4_8658_0080C708A895__INCLUDED_)
