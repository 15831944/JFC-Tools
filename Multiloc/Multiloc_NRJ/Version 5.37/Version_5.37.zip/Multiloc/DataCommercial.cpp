// DataCommercial.cpp: implementation of the CDataCommercial class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiloc.h"
#include "DataCommercial.h"

#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDataCommercial::CDataCommercial()
{

}

CDataCommercial::~CDataCommercial()
{

}

bool CDataCommercial::Load()
{
	m_TabCommerciaux.RemoveAll();
	CDaoDatabase Db;
	try
	{
		//Db.Open("multiccc.mdb",FALSE,TRUE);
		Db.Open("multicom.mdb",FALSE,TRUE);
		CTblCommercial Table(&Db);
		Table.Open();
		while(!Table.IsEOF()) 
		{
			CCommercial Commercial;
			Commercial=Table;
			m_TabCommerciaux.Add(Commercial);
			Table.MoveNext();
		}
		Table.Close();
		Db.Close();
		CCommercial *pCommercial=m_TabCommerciaux.GetData();
		if(pCommercial) std::sort(pCommercial,(pCommercial+m_TabCommerciaux.GetSize()));
	}
	catch(CDaoException *e)
	{
		CString Message;
		Message.Format("%s,%s",e->m_pErrorInfo->m_strSource,e->m_pErrorInfo->m_strDescription);
		AfxMessageBox(Message);
		return(false);
	}
	return true;
}
