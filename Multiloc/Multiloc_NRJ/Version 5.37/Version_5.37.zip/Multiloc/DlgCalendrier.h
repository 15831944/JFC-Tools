//{{AFX_INCLUDES()
#include "calendar.h"
//}}AFX_INCLUDES
#if !defined(AFX_DLGCALENDRIER_H__CAB02342_57AF_11D2_AD1C_0080C708A895__INCLUDED_)
#define AFX_DLGCALENDRIER_H__CAB02342_57AF_11D2_AD1C_0080C708A895__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DlgCalendrier.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgCalendrier dialog

class CDlgCalendrier : public CDialog
{
// Construction
public:
	COleDateTime GetDate();
	COleDateTime m_Date;
	void SetDate(COleDateTime date);
	CDlgCalendrier(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgCalendrier)
	enum { IDD = IDD_CALENDRIER };
	CCalendar	m_ActiveX;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgCalendrier)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgCalendrier)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnButtonMoismoins();
	afx_msg void OnButtonMoisplus();
	afx_msg void OnButtonAnneemoins();
	afx_msg void OnButtonAnneeplus();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCALENDRIER_H__CAB02342_57AF_11D2_AD1C_0080C708A895__INCLUDED_)
