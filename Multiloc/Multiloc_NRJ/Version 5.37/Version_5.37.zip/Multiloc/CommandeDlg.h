#if !defined(AFX_COMMANDEDLG_H__81713A41_4518_11D4_8658_0080C708A895__INCLUDED_)
#define AFX_COMMANDEDLG_H__81713A41_4518_11D4_8658_0080C708A895__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CommandeDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCommandeDlg dialog
class CMultilocDoc;

class CCommandeDlg : public CDialog
{
// Construction
public:
	
	CMultilocDoc * m_pDoc;
	CCommandeDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCommandeDlg();
	bool Activate(CMultilocDoc * pDoc);
	void UpdateCommande();
	// Maj dialoigue commande avec infos campagne en cours
	void UpdateCommandeCampagne(long CodeNoCampagne);

	// Chargement des infos commandes document courant
	void ChargeInfoCommandeDoc();

	// Sauvegarde nouvelles infos commande
	bool CommandeComplete();
	void StockeNvInfoCommande();
	bool CreerNouvelleCampagne(CCampagne &Campagne);
	bool CreerNouvelleCampagneRegion(CCampagne &Campagne);

	// Mise � jour de la campagne avec nvlles infos saisis dans dialogue commande
	bool MajCampagne(CCampagne &Campagne);
	bool MajCampagneRegion(CCampagne &Campagne);

	// Ajout des stations/ville de la campagne courante; ainsi que les spots (dans table access) 
	bool AjoutStationVilleSpotCommande(CCampagne & Campagne);



// Dialog Data
	//{{AFX_DATA(CCommandeDlg)
	enum { IDD = IDD_ENRGTCOMMANDE };
	CComboBox	m_ComboCodeSecodip;
	CComboBox	m_ComboTypeCampagne;
	CComboBox	m_ComboRegion;
	CButton	m_BtnSelectionMail;
	CComboBox	m_ComboCommercial;
	CComboBox	m_ComboMandataire;
	CComboBox	m_ComboAnnonceur;
	CComboBox	m_ComboAgence;
	CComboBox	m_ComboClient;
	CString	m_ClientSelect;
	CString	m_Commentaire;
	BOOL	m_CheckAnnonceurDirect;
	CString	m_NomCampagne;
	long	m_NumRegion;
	long m_NumCodeSecodip;
	CString	m_AgenceSelect;
	CString	m_AnnonceurSelect;
	CString	m_CommercialSelect;
	CString	m_MandataireSelect;
	COleDateTime	m_DateDebCampagne;
	COleDateTime	m_DateCreationCampagne;
	COleDateTime	m_DateDernModifCampagne;
	COleDateTime	m_DateFinCampagne;
	BOOL	m_CheckMailAuto;
	CString	m_RegionSelect;
	CString	m_TypeCampagneSelect;
	CString	m_NoVersion;
	CString	m_BudgetGlobal;
	CString	m_NbModifCamp;
	CString	m_NoCampagne;
	CString	m_NbSpots;
	CString m_CodeSecodipSelect;
	//}}AFX_DATA

	// Les variables � stocker dans campagne (via tables)
	long m_NoCommercial;
	long m_NoClient;
	long m_NoAgence;
	long m_NoAnnonceur;
	long m_NoMandataire;
	int m_NoTypeCampagne;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCommandeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCommandeDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnChkCmdannonceurdirect();
	afx_msg void OnChkMailauto();
	afx_msg void OnSelchangeCmbCmdClient();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMMANDEDLG_H__81713A41_4518_11D4_8658_0080C708A895__INCLUDED_)
