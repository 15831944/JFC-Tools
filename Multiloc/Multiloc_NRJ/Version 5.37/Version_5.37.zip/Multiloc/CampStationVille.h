// CampStationVille.h: interface for the CCampStationVille class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CAMPSTATIONVILLE_H__E807F89B_3935_4D99_91EE_88883A33D041__INCLUDED_)
#define AFX_CAMPSTATIONVILLE_H__E807F89B_3935_4D99_91EE_88883A33D041__INCLUDED_

#include "TblCampStationVille.h"
#include <afxtempl.h>		// MFC template library

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCampStationVille  
{
public:

	long	m_NumStationVille;
	long	m_NumCampagne;
	long	m_NumStation;
	long	m_NumVille;
	float	m_RemCouplage;

	CCampStationVille();
	virtual ~CCampStationVille();

	CCampStationVille   & operator=(const CCampStationVille   &Source);
	CCampStationVille   & operator=(const CTblCampStationVille &Source);

};

#endif // !defined(AFX_CAMPSTATIONVILLE_H__E807F89B_3935_4D99_91EE_88883A33D041__INCLUDED_)
