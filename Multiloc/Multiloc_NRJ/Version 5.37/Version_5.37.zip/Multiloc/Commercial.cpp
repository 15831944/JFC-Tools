// Commercial.cpp: implementation of the CCommercial class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiloc.h"
#include "Commercial.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCommercial::CCommercial()
{
	m_NumCommercial = 0;
	m_Nom=_T("");
	m_Fax=_T("");
	m_Email=_T("");
	m_Code=_T("");
	m_Tel=_T("");
	m_Commentaire=_T("");
}

CCommercial::~CCommercial()
{

}

CCommercial & CCommercial::operator=(const CCommercial &Source)
{
	m_NumCommercial =Source.m_NumCommercial;
	m_Nom=Source.m_Nom;
	m_Fax=Source.m_Fax;
	m_Tel=Source.m_Tel;
	m_Email=Source.m_Email;
	m_Code=Source.m_Code;
	m_Commentaire=Source.m_Commentaire;
	return(*this);
}

CCommercial & CCommercial::operator=(const CTblCommercial &Source)
{
	m_NumCommercial =Source.m_NumCommercial;
	m_Nom=Source.m_Nom;
	m_Fax=Source.m_Fax;
	m_Tel=Source.m_Tel;
	m_Email=Source.m_Email;
	m_Code=Source.m_Code;
	m_Commentaire=Source.m_Commentaire;
	return(*this);
}


bool CCommercial::operator<(const CCommercial &Source)
{
	if(m_Nom<Source.m_Nom) return(TRUE);
	else return(FALSE);
}
