#if !defined(AFX_CASCADEREGION_H__5F0B2AC1_C70C_11D5_8A63_0010B5865AAB__INCLUDED_)
#define AFX_CASCADEREGION_H__5F0B2AC1_C70C_11D5_8A63_0010B5865AAB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CascadeRegion.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCascadeRegion dialog

class CMultilocDoc;

class CCascadeRegion : public CDialog
{
#define TAUXNOUVEAUCLIENTREGION			10.0f
#define TAUXRENOUVELLEMENTREGION		10.0f
#define TAUXANTICIPATIONREGION			10.0f
#define TAUXMULTIVILLESREGION			20.0f
#define TAUXABONNEMENTREGION			 5.0f
#define TAUXPROFESSIONNELREGION			15.0f

// attention aux taux maxi sans abattement abonnement (sinon 25% et 55%)
#define TAUXMAXIABATTREGION				20.0f
#define TAUXMAXIREGION					50.0f

#define TAUXREMISEMANDATSREGION			 2.0f

// Construction
public:
	CCascadeRegion(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCascadeRegion();				// destructeur

	void SetDoc(CMultilocDoc * pDoc);
	void Activate(CMultilocDoc* m_pDoc=NULL,float budget=-1, COleDateTime * date=NULL);

	float UpdateCascade(float budget, COleDateTime * date=NULL);
	float DonneBudgetNet(void);
	void CalculCumulMandat();
	void MajTxtDevise();
	void MajMontantEuroFranc();

	
// Dialog Data
	//{{AFX_DATA(CCascadeRegion)
	enum { IDD = IDD_CASCADEREGION };
	CEdit	m_EditFraisTechniqueRegion;
	CStatic	m_TxtDevise6;
	CEdit	m_EditFraisAnnonceRegion;
	CStatic	m_TxtDevise7;
	CStatic	m_TxtDevise5;
	CStatic	m_TxtDevise4;
	CStatic	m_TxtDevise3;
	CStatic	m_TxtDevise2;
	CStatic	m_TxtDevise1;
	float	m_BrutRegion;
	float	m_BrutHtRegion;
	float	m_CoeffAbattementRegion;
	float	m_CoeffTotalRegion;
	float	m_CoeffDegressifRegion;
	float	m_CoeffNbMessagesRegion;
	float	m_CoeffRenouvellementRegion;
	float	m_CoeffMultiVillesRegion;
	float	m_totalcabrutregion;
	float	m_totalbrutregion;
	float	m_totalnetregion;
	float	m_primeanticipationregion;
	float	m_coeffNouveauClientRegion;
	float	m_primeabonnementregion;
	double	m_TotalFraisAnnonceRegion;
	BOOL	m_checkNouveauClientRegion;
	BOOL	m_checkRenouvellementRegion;
	BOOL	m_checkMultiVilleRegion;
	BOOL	m_checkAnticipationRegion;
	BOOL	m_checkAbonnementRegion;
	COleDateTime	m_DateDiffusionRegion;
	float	m_TauxDeRegieRegion;
	BOOL	m_checkProfessionnel;
	float	m_totalnetnetregion;
	BOOL	m_checknegociationregion;
	float	m_coeffnegociationregion;
	float	m_coeffremiseregion;
	double	m_FraisTechniqueRegion;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCascadeRegion)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	CMultilocDoc * m_pDoc;

	// Generated message map functions
	//{{AFX_MSG(CCascadeRegion)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeBruthtRegion();
	afx_msg void OnCheckprimeanticipationRegion();
	afx_msg void OnCheckprimemultivilleRegion();
	afx_msg void OnCheckprimerenouvellementRegion();
	afx_msg void OnCheckprimeabonnementRegion();
	afx_msg void OnChangeCoeffnegociationRegion();
	afx_msg void OnChangeEditTauxderegieRegion();
	afx_msg void OnChangeFraisannonceRegion();
	afx_msg void OnChecknegociationRegion();
	afx_msg void OnCheckprimeprofessionnelRegion();
	afx_msg void OnCheckprimenouveauclientRegion();
	afx_msg void OnChangePrimeprofessionnelRegion();
	afx_msg void OnChangeFraistechniqueregion();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	bool m_flagMultiVille;
	void UpdateAffichage(bool update);
	float CheckBudgetNet(void);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CASCADEREGION_H__5F0B2AC1_C70C_11D5_8A63_0010B5865AAB__INCLUDED_)
