#if !defined(AFX_DLGEDITER_H__CD5AE0A0_8872_11D2_843A_004005327F70__INCLUDED_)
#define AFX_DLGEDITER_H__CD5AE0A0_8872_11D2_843A_004005327F70__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgEditer.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgEditer dialog

class CMultilocDoc;
class CDlgEditer : public CDialog
{
// Construction
public:
	CDlgEditer(CWnd* pParent = NULL);   // standard constructor


// Dialog Data
	//{{AFX_DATA(CDlgEditer)
	enum { IDD = IDD_EDITER };
	CEdit	m_BtnODP;
	CEdit	m_BtnVilleDepResa;
	CButton	m_BtnInfoRemise;
	CButton	m_BtnNetStation;
	CButton	m_BtnCalendrier;
	CButton	m_BtnSynthese;
	CButton	m_BtnListeVilles;
	CListBox	m_liststation;
	CListBox	m_listvilles;
	int		m_calendrier;
	int		m_listevilles;
	int		m_synthese;
	BOOL	m_edvillenet;
	BOOL	m_edvillecpm;
	BOOL	m_BonPourAccord;
	BOOL	m_checknetsta;
	BOOL	m_RepartitionMois;
	BOOL	m_checkinforemise;
	BOOL	m_CalendCompact;
	CString	m_VilleDepResa;
	CString	m_NoODP;
	BOOL	m_EditGrise;
	BOOL	m_PlanType;
	//}}AFX_DATA

	CMultilocDoc *m_pDoc;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgEditer)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	
	// Generated message map functions
	//{{AFX_MSG(CDlgEditer)
	afx_msg void OnCalendriers();
	afx_msg void OnListevilles();
	afx_msg void OnSynthese();
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnCheckRepartimois();
	afx_msg void OnPdf();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGEDITER_H__CD5AE0A0_8872_11D2_843A_004005327F70__INCLUDED_)
