// DlgFormat.cpp : implementation file
//

#include "stdafx.h"
#include "multiloc.h"
#include "DlgFormat.h"
extern CMultilocApp theApp;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgFormat dialog


CDlgFormat::CDlgFormat(CMultilocDoc *pDoc,CWnd* pParent /*=NULL*/)
	: CDialog(CDlgFormat::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgFormat)
	m_Preferenciel = FALSE;
	m_HorsEcran = FALSE;
	m_Gracieu = FALSE;
	m_GZU = FALSE;
	m_ExigenceEcran = FALSE;
	m_MessageMultiple = FALSE;
	m_AnnonceurMultiple = FALSE;
	//}}AFX_DATA_INIT
	m_pDoc=pDoc;
}


void CDlgFormat::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgFormat)
	DDX_Control(pDX, IDC_LIST_SELECTION, m_ListSelection);
	DDX_Control(pDX, IDC_LIST_DISPO, m_ListDispo);
	DDX_Control(pDX, IDC_COMBOBOXEX_SYMBOL, m_ComboSymbol);
	DDX_Check(pDX, IDC_CHECK1, m_Preferenciel);
	DDX_Check(pDX, IDC_CHECK2, m_HorsEcran);
	DDX_Check(pDX, IDC_CHECK4, m_Gracieu);
	DDX_Check(pDX, IDC_CHECK5, m_GZU);
	DDX_Check(pDX, IDC_CHECK6, m_ExigenceEcran);
	DDX_Check(pDX, IDC_CHECK7, m_MessageMultiple);
	DDX_Check(pDX, IDC_CHECK3, m_AnnonceurMultiple);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgFormat, CDialog)
	//{{AFX_MSG_MAP(CDlgFormat)
	ON_BN_CLICKED(IDC_BUTTON_NOUVEAU, OnButtonNouveau)
	ON_BN_CLICKED(IDC_BUTTON_SUPRESS, OnButtonSupress)
	ON_LBN_SELCHANGE(IDC_LIST_DISPO, OnSelchangeListDispo)
	ON_LBN_SELCHANGE(IDC_LIST_SELECTION, OnSelchangeListSelection)
	ON_CBN_SELCHANGE(IDC_COMBOBOXEX_SYMBOL, OnSelchangeComboboxexSymbol)
	ON_BN_CLICKED(IDC_CHECK1, OnPreferenciel)
	ON_BN_CLICKED(IDC_CHECK2, OnHorsEcran)
	ON_BN_CLICKED(IDC_CHECK4, OnGracieu)
	ON_BN_CLICKED(IDC_CHECK5, OnGZU)
	ON_BN_CLICKED(IDC_CHECK6, OnExigenceEcran)
	ON_BN_CLICKED(IDC_CHECK7, OnMessageMultiple)
	ON_BN_CLICKED(IDC_CHECK3, OnAnnonceurMultiple)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgFormat message handlers

void CDlgFormat::OnOK() 
{
	m_pDoc->m_Combin.Copy(m_Combin);
	
	CDialog::OnOK();
}

void CDlgFormat::OnButtonNouveau() 
{
	CDlgSelection Dlg;
	Dlg.m_pIL=&m_pDoc->m_ImageFormat;
	int i;
	for(i=0;i<Dlg.m_pIL->GetImageCount();i++)Dlg.m_Use.Add(0);
	for(i=0;i<m_Combin.GetSize();i++)Dlg.m_Use[m_Combin[i].m_NrSymbol]++;
	if(Dlg.DoModal()!=IDOK)return;

	SCombinaison s;
	s.m_NrSymbol=Dlg.m_Sel;
	m_NrSymbolActif=m_Combin.Add(s);
	RefreshCombo(1);
}

void CDlgFormat::RefreshCombo(char fTout){
	if(fTout){
		COMBOBOXEXITEM cbi;
		memset(&cbi,0,sizeof(cbi));
		cbi.mask = CBEIF_IMAGE | CBEIF_OVERLAY |CBEIF_SELECTEDIMAGE;//| CBEIF_INDENT ;
		m_ComboSymbol.ResetContent();
		for(int i=0;i<m_Combin.GetSize();i++){
			cbi.iItem = i;
			cbi.iImage = m_Combin[i].m_NrSymbol;
			cbi.iSelectedImage = m_Combin[i].m_NrSymbol;
			cbi.iOverlay = m_Combin[i].m_NrSymbol;
			m_ComboSymbol.InsertItem(&cbi);
		}
		m_ComboSymbol.SetCurSel(m_NrSymbolActif);
	}
	m_ListSelection.ResetContent();
	if(m_NrSymbolActif>=m_Combin.GetSize())return;
	for(int i=0;i<m_Combin[m_NrSymbolActif].m_Def.GetSize();i++){
		int idx=m_Combin[m_NrSymbolActif].m_Def[i];
		m_ListSelection.AddString(m_pDoc->m_pNoyau->m_TblFormat[idx]);
	}

	m_Preferenciel		= m_Combin[m_NrSymbolActif].m_fPreferenciel;
	m_HorsEcran			= m_Combin[m_NrSymbolActif].m_fHorsEcran;
	m_AnnonceurMultiple = m_Combin[m_NrSymbolActif].m_fAnnonceurMultiple;

	//GCV 2001 A FAIRE
	if (theApp.m_CGV > 2000)
		m_GZU=m_Combin[m_NrSymbolActif].m_fGZU;

	if (theApp.m_CGV > 2003)
	{
		// CGV 2004
		m_MessageMultiple   = m_Combin[m_NrSymbolActif].m_fMessageMultiple;
		m_ExigenceEcran     = m_Combin[m_NrSymbolActif].m_fExigenceEcran;
	}

	m_Gracieu=m_Combin[m_NrSymbolActif].m_fGracieu;
	UpdateData(0);
}


void CDlgFormat::RefreshSelection()
{
	if(m_NrSymbolActif>=m_Combin.GetSize())return;
	int nb=m_ListSelection.GetCount();
	m_Combin[m_NrSymbolActif].m_Def.RemoveAll();
	for(int i=0;i<nb;i++){
		CString txt;
		m_ListSelection.GetText(i,txt);
		// on le retrouve dans la liste des formats
		for(int f=0;f<m_pDoc->m_pNoyau->m_TblFormat.GetSize();f++){
			if(m_pDoc->m_pNoyau->m_TblFormat[f]==txt){
				m_Combin[m_NrSymbolActif].m_Def.Add(f);
				break;
			}
		}
	}
}

void CDlgFormat::OnButtonSupress() 
{
	if(m_NrSymbolActif==0){
		MessageBox("Il est interdit de supprimer cette combinaison");
		return;
	}
	m_Combin.RemoveAt(m_NrSymbolActif);
	m_NrSymbolActif=0;
	RefreshCombo(1);
}

BOOL CDlgFormat::OnInitDialog()
{
	theApp.JoueMusic(7);
	CDialog::OnInitDialog();
	m_ComboSymbol.SetImageList(&m_pDoc->m_ImageFormat);
	m_Combin.Copy(m_pDoc->m_Combin);

	for(int i=0;i<m_pDoc->m_pNoyau->m_TblFormat.GetSize();i++)
		m_ListDispo.AddString(m_pDoc->m_pNoyau->m_TblFormat[i]);

	m_NrSymbolActif=0;
	RefreshCombo(1);
	
	return TRUE;  // return TRUE unless you set the focus to a control
             // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgFormat::OnSelchangeListDispo() 
{
	int nb=m_ListSelection.GetCount();
	if(nb>=3){
		MessageBox("Trois formats maximum !");
		return;
	}
	
	int i=m_ListDispo.GetCurSel();
	m_ListSelection.AddString(m_pDoc->m_pNoyau->m_TblFormat[i]);
	RefreshSelection();
}

void CDlgFormat::OnSelchangeListSelection() 
{
	int i=m_ListSelection.GetCurSel();
	m_ListSelection.DeleteString(i);
	RefreshSelection();
}

void CDlgFormat::OnSelchangeComboboxexSymbol() 
{
	m_NrSymbolActif=m_ComboSymbol.GetCurSel();	
	RefreshCombo(0);
}

////////////////////////////////////////////////////////////
// Parrainage Hors Ecran
void CDlgFormat::OnHorsEcran() 
{
	if(m_NrSymbolActif>=m_Combin.GetSize())return;
	UpdateData(1);
	m_Combin[m_NrSymbolActif].m_fHorsEcran = m_HorsEcran;
}


////////////////////////////////////////////////////////////
// Emplacements Pr�f�rentiels
void CDlgFormat::OnPreferenciel() 
{
	if(m_NrSymbolActif>=m_Combin.GetSize())return;
	UpdateData(1);
	m_Combin[m_NrSymbolActif].m_fPreferenciel = m_Preferenciel;
}

////////////////////////////////////////////////////////////
// Exigence d'un �cran
void CDlgFormat::OnExigenceEcran() 
{
	if(m_NrSymbolActif>=m_Combin.GetSize())return;
	UpdateData(1);
	m_Combin[m_NrSymbolActif].m_fExigenceEcran = m_ExigenceEcran;
	
}

////////////////////////////////////////////////////////////
// Plusieurs messages dans le m�me �cran
void CDlgFormat::OnMessageMultiple() 
{
	if(m_NrSymbolActif>=m_Combin.GetSize())return;
	UpdateData(1);
	m_Combin[m_NrSymbolActif].m_fMessageMultiple=m_MessageMultiple;	
}

////////////////////////////////////////////////////////////
// Citation de plusieurs annonceurs dans un m�me message
void CDlgFormat::OnAnnonceurMultiple() 
{
	if(m_NrSymbolActif>=m_Combin.GetSize())return;
	UpdateData(1);
	m_Combin[m_NrSymbolActif].m_fAnnonceurMultiple=m_AnnonceurMultiple;
}

////////////////////////////////////////////////////////////
// Grandes Zones Urbaines
void CDlgFormat::OnGZU() 
{
	if(m_NrSymbolActif>=m_Combin.GetSize())return;
	UpdateData(1);
	m_Combin[m_NrSymbolActif].m_fGZU=m_GZU;	
}

////////////////////////////////////////////////////////////
// Gracieux
void CDlgFormat::OnGracieu() 
{
	if(m_NrSymbolActif>=m_Combin.GetSize())return;
	UpdateData(1);
	m_Combin[m_NrSymbolActif].m_fGracieu=m_Gracieu;
}

