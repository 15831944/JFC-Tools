// Client.cpp: implementation of the CClient class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiloc.h"
#include "Client.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CClient::CClient()
{
	m_NumClient = 0;
	m_Nom=_T("");
	m_Fax=_T("");
	m_Tel=_T("");
	m_Email=_T("");
	m_Contact=_T("");
	m_CodePostal=0;
	m_Code=_T("");
	m_Adresse=_T("");
	m_Ville=_T("");
	m_Commentaire=_T("");
	m_AvoirClient = 0;
}

CClient::~CClient()
{

}

CClient & CClient::operator=(const CClient &Source)
{
	m_NumClient =Source.m_NumClient;
	m_Nom=Source.m_Nom;
	m_Fax=Source.m_Fax;
	m_Tel=Source.m_Tel;
	m_Email=Source.m_Email;
	m_Contact=Source.m_Contact;
	m_CodePostal=Source.m_CodePostal;
	m_Code=Source.m_Code;
	m_Adresse=Source.m_Adresse;
	m_Ville=Source.m_Ville;
	m_Commentaire = Source.m_Commentaire;
	m_AvoirClient = Source.m_AvoirClient;
	return(*this);
}

CClient & CClient::operator=(const CTblClient &Source)
{
	m_NumClient =Source.m_NumClient;
	m_Nom=Source.m_Nom;
	m_Fax=Source.m_Fax;
	m_Tel=Source.m_Tel;
	m_Email=Source.m_Email;
	m_Contact=Source.m_Contact;
	m_CodePostal=Source.m_CodePostal;
	m_Code=Source.m_Code;
	m_Adresse=Source.m_Adresse;
	m_Ville=Source.m_Ville;
	m_Commentaire = Source.m_Commentaire;
	return(*this);
}

bool CClient::operator<(const CClient &Source)
{
	if(m_Nom<Source.m_Nom) return(TRUE);
	else return(FALSE);
}