// CascadeRegion.cpp : implementation file
//

#include "stdafx.h"
#include "multiloc.h"
#include "CascadeRegion.h"
#include "MultilocDoc.h"
#include "Obj_PDF.h"

extern CMultilocApp theApp;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCascadeRegion dialog


CCascadeRegion::CCascadeRegion(CWnd* pParent /*=NULL*/)
	: CDialog(CCascadeRegion::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCascadeRegion)
	m_BrutRegion = 0.0f;
	m_BrutHtRegion = 0.0f;
	m_CoeffAbattementRegion = 0.0f;
	m_CoeffTotalRegion = 0.0f;
	m_CoeffDegressifRegion = 0.0f;
	m_CoeffNbMessagesRegion = 0.0f;
	m_CoeffRenouvellementRegion = TAUXRENOUVELLEMENTREGION;
	m_CoeffMultiVillesRegion = TAUXMULTIVILLESREGION;
	m_totalcabrutregion = 0.0f;
	m_totalbrutregion = 0.0f;
	m_totalnetregion = 0.0f;
	m_primeanticipationregion = TAUXANTICIPATIONREGION;
	m_coeffNouveauClientRegion = TAUXNOUVEAUCLIENTREGION;
	m_primeabonnementregion = TAUXABONNEMENTREGION;
	m_TotalFraisAnnonceRegion = 0.0;
	m_checkNouveauClientRegion = FALSE;
	m_checkRenouvellementRegion = FALSE;
	m_checkMultiVilleRegion = FALSE;
	m_checkAnticipationRegion = FALSE;
	m_checkAbonnementRegion = FALSE;
	m_DateDiffusionRegion = COleDateTime::GetCurrentTime();
	m_TauxDeRegieRegion = 60.0f; //30.0f;
	m_checkProfessionnel = FALSE;
	m_totalnetnetregion = 0.0f;
	m_checknegociationregion = FALSE;
	m_coeffnegociationregion = 0.0f;
	m_coeffremiseregion = TAUXPROFESSIONNELREGION;
	m_FraisTechniqueRegion = 0.0;
	//}}AFX_DATA_INIT

	m_pDoc=NULL;
	if (theApp.m_MultilocRegion == 1)
	{
		Create(IDD_CASCADEREGION);
	}
	
}

CCascadeRegion::~CCascadeRegion()
{
	DestroyWindow();
}

void CCascadeRegion::Activate(CMultilocDoc * pDoc,float budget, COleDateTime * date)
{
	if(pDoc)m_pDoc=pDoc;

	theApp.JoueMusic(4);
	ShowWindow(SW_SHOW);
	UpdateCascade(budget, date);
	return;
}

void CCascadeRegion::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCascadeRegion)
	DDX_Control(pDX, IDC_FRAISTECHNIQUEREGION, m_EditFraisTechniqueRegion);
	DDX_Control(pDX, IDC_TXTDEVISE6, m_TxtDevise6);
	DDX_Control(pDX, IDC_FRAISANNONCE_REGION, m_EditFraisAnnonceRegion);
	DDX_Control(pDX, IDC_TXTDEVISE7, m_TxtDevise7);
	DDX_Control(pDX, IDC_TXTDEVISE5, m_TxtDevise5);
	DDX_Control(pDX, IDC_TXTDEVISE4, m_TxtDevise4);
	DDX_Control(pDX, IDC_TXTDEVISE3, m_TxtDevise3);
	DDX_Control(pDX, IDC_TXTDEVISE2, m_TxtDevise2);
	DDX_Control(pDX, IDC_TXTDEVISE1, m_TxtDevise1);
	DDX_Text(pDX, IDC_BRUT_REGION, m_BrutRegion);
	DDX_Text(pDX, IDC_BRUTHT_REGION, m_BrutHtRegion);
	DDV_MinMaxFloat(pDX, m_BrutHtRegion, 0.f, 1.e+009f);
	DDX_Text(pDX, IDC_COEFFABATTEMENT_REGION, m_CoeffAbattementRegion);
	DDX_Text(pDX, IDC_COEFFTOTAL_REGION, m_CoeffTotalRegion);
	DDX_Text(pDX, IDC_REMISEFINANCIERE_REGION, m_CoeffDegressifRegion);
	DDX_Text(pDX, IDC_REMISEMESSAGE_REGION, m_CoeffNbMessagesRegion);
	DDX_Text(pDX, IDC_PRIMEMULTIVILLE_REGION, m_CoeffMultiVillesRegion);
	DDX_Text(pDX, IDC_TOTALCABRUTREGION, m_totalcabrutregion);
	DDX_Text(pDX, IDC_TOTALBRUT_REGION, m_totalbrutregion);
	DDX_Text(pDX, IDC_TOTALNETREGION, m_totalnetregion);
	DDX_Text(pDX, IDC_PRIMEANTICIPATION_REGION, m_primeanticipationregion);
	DDX_Text(pDX, IDC_REMISENOUVEAUCLIENT_REGION, m_coeffNouveauClientRegion);
	DDX_Text(pDX, IDC_PRIMEABONNEMENT_REGION, m_primeabonnementregion);
	DDX_Text(pDX, IDC_FRAISANNONCE_REGION, m_TotalFraisAnnonceRegion);
	DDX_Check(pDX, IDC_CHECKPRIMENOUVEAUCLIENT_REGION, m_checkNouveauClientRegion);
	DDX_Check(pDX, IDC_CHECKPRIMERENOUVELLEMENT_REGION, m_checkRenouvellementRegion);
	DDX_Check(pDX, IDC_CHECKPRIMEMULTIVILLE_REGION, m_checkMultiVilleRegion);
	DDX_Check(pDX, IDC_CHECKPRIMEANTICIPATION_REGION, m_checkAnticipationRegion);
	DDX_Check(pDX, IDC_CHECKPRIMEABONNEMENT_REGION, m_checkAbonnementRegion);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER_REGION, m_DateDiffusionRegion);
	DDX_Text(pDX, IDC_EDIT_TAUXDEREGIE_REGION, m_TauxDeRegieRegion);
	DDX_Check(pDX, IDC_CHECKPRIMEPROFESSIONNEL_REGION, m_checkProfessionnel);
	DDX_Text(pDX, IDC_TOTALNETNET_REGION, m_totalnetnetregion);
	DDX_Check(pDX, IDC_CHECKNEGOCIATION_REGION, m_checknegociationregion);
	DDX_Text(pDX, IDC_COEFFNEGOCIATION_REGION, m_coeffnegociationregion);
	DDX_Text(pDX, IDC_PRIMEPROFESSIONNEL_REGION, m_coeffremiseregion);
	DDX_Text(pDX, IDC_FRAISTECHNIQUEREGION, m_FraisTechniqueRegion);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCascadeRegion, CDialog)
	//{{AFX_MSG_MAP(CCascadeRegion)
	ON_EN_CHANGE(IDC_BRUTHT_REGION, OnChangeBruthtRegion)
	ON_BN_CLICKED(IDC_CHECKPRIMEANTICIPATION_REGION, OnCheckprimeanticipationRegion)
	ON_BN_CLICKED(IDC_CHECKPRIMEMULTIVILLE_REGION, OnCheckprimemultivilleRegion)
	ON_BN_CLICKED(IDC_CHECKPRIMERENOUVELLEMENT_REGION, OnCheckprimerenouvellementRegion)
	ON_BN_CLICKED(IDC_CHECKPRIMEABONNEMENT_REGION, OnCheckprimeabonnementRegion)
	ON_EN_CHANGE(IDC_COEFFNEGOCIATION_REGION, OnChangeCoeffnegociationRegion)
	ON_EN_CHANGE(IDC_EDIT_TAUXDEREGIE_REGION, OnChangeEditTauxderegieRegion)
	ON_EN_CHANGE(IDC_FRAISANNONCE_REGION, OnChangeFraisannonceRegion)
	ON_BN_CLICKED(IDC_CHECKNEGOCIATION_REGION, OnChecknegociationRegion)
	ON_BN_CLICKED(IDC_CHECKPRIMEPROFESSIONNEL_REGION, OnCheckprimeprofessionnelRegion)
	ON_BN_CLICKED(IDC_CHECKPRIMENOUVEAUCLIENT_REGION, OnCheckprimenouveauclientRegion)
	ON_EN_CHANGE(IDC_PRIMEPROFESSIONNEL_REGION, OnChangePrimeprofessionnelRegion)
	ON_EN_CHANGE(IDC_FRAISTECHNIQUEREGION, OnChangeFraistechniqueregion)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCascadeRegion message handlers

BOOL CCascadeRegion::OnInitDialog() 
{
	CDialog::OnInitDialog();

	UpdateAffichage(true);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
	
}

void CCascadeRegion::SetDoc(CMultilocDoc *pDoc)
{
	m_pDoc=pDoc;
}


void CCascadeRegion::OnChangeBruthtRegion() 
{
	UpdateData(true);
	UpdateCascade(-1,NULL);
	m_pDoc->UpdateAllViews(NULL, 2);
}


void CCascadeRegion::OnCheckprimeanticipationRegion() 
{
	UpdateData(true);
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);
}

void CCascadeRegion::OnCheckprimemultivilleRegion() 
{
	UpdateData(true);
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);	
}

void CCascadeRegion::OnCheckprimerenouvellementRegion() 
{
	UpdateData(true);
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);	
}

void CCascadeRegion::OnCheckprimeabonnementRegion() 
{
	UpdateData(true);
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);
}


float CCascadeRegion::UpdateCascade(float budget, COleDateTime * date)
{
	float m_totalEnEuro;
	float m_totalInter;

	if(!m_pDoc)	return 0;
	if(budget>=0)	m_BrutRegion=m_totalcabrutregion=budget;


	if(date!=NULL)	m_DateDiffusionRegion=*date;
	UpdateAffichage(false);

	// Attention si total d�j� converti en francs
	m_totalEnEuro = m_totalbrutregion;
	//if (m_pDoc->m_PrixEnEuro == false)
	//	m_totalEnEuro = m_totalbrutregion * m_pDoc->m_TauxFrancEuro;

	/* avant 16/12/2001
	// calcul d�gressif via remise financi�re
	m_CoeffDegressifRegion=m_pDoc->m_pNoyau->DonneRemiseFinanciereRegion(0,m_totalEnEuro,m_pDoc->m_PrixEnEuro,m_pDoc->m_TauxEuroFranc);
	
	// remise Nb Spots
	if(m_pDoc->m_NbSpotCascade>0){
		int NbSpotMoyen=m_pDoc->m_NbSpotCascade/m_pDoc->m_NbStationVilleCascade;
		m_CoeffNbMessagesRegion=m_pDoc->m_pNoyau->DonneRemiseSpotRegion(0,NbSpotMoyen);
	}
	else m_CoeffNbMessagesRegion=0.0f;
	*/

	// remise Nb Spots
	if(m_pDoc->m_NbSpotCascade>0){
		int NbSpotMoyen=m_pDoc->m_NbSpotCascade/m_pDoc->m_NbStationVilleCascade;
		m_CoeffNbMessagesRegion=m_pDoc->m_pNoyau->DonneRemiseSpotRegion(0,NbSpotMoyen);
	}
	else m_CoeffNbMessagesRegion=0.0f;

	// en mode r�gion, pour calcul coeff remise financi�re, on applique avant la remise de volume
	m_totalInter = (float)(m_totalEnEuro * (100.0-m_CoeffNbMessagesRegion)/100);
	m_CoeffDegressifRegion=m_pDoc->m_pNoyau->DonneRemiseFinanciereRegion(0,m_totalInter,m_pDoc->m_PrixEnEuro,m_pDoc->m_TauxEuroFranc);


    // remise multivilles pour CGV R�gion
	// calcul du nb de villes de - 50000
	CMap <short, short, bool,bool> SelVille;
	for(short i=0 ; i<m_pDoc->m_NbStationVille ; i++){
		if(m_pDoc->m_pNoyau->m_pTblVille[m_pDoc->m_idxStation[i]][m_pDoc->m_idxVille[i]].m_NbHabitantsInsee>=0)continue;  // avant >= 50000
		int nr=m_pDoc->m_pNoyau->m_pTblVille[m_pDoc->m_idxStation[i]][m_pDoc->m_idxVille[i]].m_NrUnique;
		SelVille.SetAt(nr,true);
	}
	if(SelVille.GetCount()>=2)
		m_flagMultiVille=true;
	else
		m_flagMultiVille=false;

	UpdateAffichage(true);
	return CheckBudgetNet();
}

float CCascadeRegion::CheckBudgetNet(void)
{
	return m_totalnetregion;
}

float CCascadeRegion::DonneBudgetNet(void)
{
	return CheckBudgetNet();
}

void CCascadeRegion::CalculCumulMandat()
{
	// en mode R�gion, il s'agit d'appliquer uniquement la remise "professionnel"
	// pour obtenir le net net
	UpdateAffichage(true);
}

void CCascadeRegion::MajTxtDevise()
{
	if (m_pDoc)
	{
		// Les labels devis budget
		if (m_pDoc->m_PrixEnEuro == true)
		{
			m_TxtDevise1.SetWindowText("Euros");
			m_TxtDevise2.SetWindowText("Euros");
			m_TxtDevise3.SetWindowText("Euros");
			m_TxtDevise4.SetWindowText("Euros");
			m_TxtDevise5.SetWindowText("Euros");
			m_TxtDevise6.SetWindowText("Euros");
			m_TxtDevise7.SetWindowText("Euros");
		}
		else
		{
			m_TxtDevise1.SetWindowText("Frs");
			m_TxtDevise2.SetWindowText("Frs");
			m_TxtDevise3.SetWindowText("Frs");
			m_TxtDevise4.SetWindowText("Frs");
			m_TxtDevise5.SetWindowText("Frs");
			m_TxtDevise6.SetWindowText("Frs");
			m_TxtDevise7.SetWindowText("Frs");
		}
	}

	return;
		
}


void CCascadeRegion :: MajMontantEuroFranc()
{
		// Mise � jour des Frais Annonce non auto et Frais duplication
	if (m_pDoc != NULL)
	{
		if (m_pDoc->m_PrixEnEuro)
		{
			if (!m_pDoc->m_TotalFraisAnnonceEnEuro)
				//m_TotalFraisAnnonce = int(m_TotalFraisAnnonce * m_pDoc->m_TauxFrancEuro + 0.5);
				m_TotalFraisAnnonceRegion = m_TotalFraisAnnonceRegion * m_pDoc->m_TauxFrancEuro;

			if (!m_pDoc->m_TotalFraisAnnonceEnEuro)
				//m_TotalFraisAnnonce = int(m_TotalFraisAnnonce * m_pDoc->m_TauxFrancEuro + 0.5);
				m_FraisTechniqueRegion = m_FraisTechniqueRegion * m_pDoc->m_TauxFrancEuro;

			if (!m_pDoc->m_CAHistoriqueEnEuro)
				m_BrutHtRegion = m_BrutHtRegion * m_pDoc->m_TauxFrancEuro;

			m_pDoc->m_TotalFraisAnnonceEnEuro = TRUE;
			m_pDoc->m_CAHistoriqueEnEuro = TRUE;


		}
		else
		{

			if (m_pDoc->m_TotalFraisAnnonceEnEuro)
				//m_TotalFraisAnnonce = int(m_TotalFraisAnnonce * m_pDoc->m_TauxEuroFranc + 0.5);
				m_TotalFraisAnnonceRegion = m_TotalFraisAnnonceRegion * m_pDoc->m_TauxEuroFranc;

			if (m_pDoc->m_TotalFraisAnnonceEnEuro)
				//m_TotalFraisAnnonce = int(m_TotalFraisAnnonce * m_pDoc->m_TauxEuroFranc + 0.5);
				m_FraisTechniqueRegion = m_FraisTechniqueRegion * m_pDoc->m_TauxEuroFranc;

			if (m_pDoc->m_CAHistoriqueEnEuro)
				m_BrutHtRegion = m_BrutHtRegion * m_pDoc->m_TauxEuroFranc;

			m_pDoc->m_CAHistoriqueEnEuro = FALSE;
			m_pDoc->m_TotalFraisAnnonceEnEuro = FALSE;
		}
	}	

	UpdateAffichage(false);  // A virer par la suite ??????????????

	UpdateData(false);

	return;
}	

void CCascadeRegion::UpdateAffichage(bool update)
{
	COleDateTime DateCampagne;
	CCampagne Campagne;
	CString CodeClient;
	double TotalBrutAnneeClient = 0;
	
	// Mise � jour Devise courante
	MajTxtDevise();

	//calcul du Total abattements
	
	/* Version avant 12/06/2002 pas de cascade sur ces diff�rentes remises
	m_CoeffAbattementRegion=+0.0f;
	if(m_checkNouveauClientRegion)m_CoeffAbattementRegion+=m_coeffNouveauClientRegion;
	if(m_checkRenouvellementRegion)m_CoeffAbattementRegion+=m_CoeffRenouvellementRegion;
	if(m_checkAnticipationRegion)m_CoeffAbattementRegion+=m_primeanticipationregion;
	if(m_checkMultiVilleRegion)m_CoeffAbattementRegion+=m_CoeffMultiVillesRegion;
	if(m_checkAbonnementRegion)m_CoeffAbattementRegion+=m_primeabonnementregion;
	*/

	// Version avec Cascade Remise (multiplication des diff�rents coefficients)
	m_CoeffAbattementRegion = 100.0f;

	// Remise nouveau client
	if(m_checkNouveauClientRegion) 
		m_CoeffAbattementRegion*=(100.0 - m_coeffNouveauClientRegion)/100;

	// Remise Renouvellement Region
	if(m_checkRenouvellementRegion)	
		m_CoeffAbattementRegion*=(100.0 - m_CoeffRenouvellementRegion) / 100;

	// Remise Anticipation Region
	if(m_checkAnticipationRegion)
		m_CoeffAbattementRegion*=(100.0 - m_primeanticipationregion) / 100;

	// Remise Multi-Villes
	if(m_checkMultiVilleRegion)
		m_CoeffAbattementRegion*=(100.0 - m_CoeffMultiVillesRegion) / 100;

	// Remise Prime Abonnement Region
	if(m_checkAbonnementRegion)
		m_CoeffAbattementRegion*=(100.0 - m_primeabonnementregion) / 100;

	m_CoeffAbattementRegion = 100.0 - m_CoeffAbattementRegion;

	// Sp�cifique R�gion tenir compte remise abonnement/engagement
	if (m_checkAbonnementRegion == FALSE)
	{
		if(m_CoeffAbattementRegion>TAUXMAXIABATTREGION)m_CoeffAbattementRegion=TAUXMAXIABATTREGION;
	}
	else
	{
		if(m_CoeffAbattementRegion>(TAUXMAXIABATTREGION+TAUXABONNEMENTREGION))m_CoeffAbattementRegion=TAUXMAXIABATTREGION+TAUXABONNEMENTREGION;
	}

	//calcul du Total prime et remise
	m_CoeffTotalRegion=100.0f;
	m_CoeffTotalRegion-=m_CoeffNbMessagesRegion*m_CoeffTotalRegion*0.01;
	m_CoeffTotalRegion-=m_CoeffDegressifRegion*m_CoeffTotalRegion*0.01;
	m_CoeffTotalRegion-=m_CoeffAbattementRegion*m_CoeffTotalRegion*0.01;
	m_CoeffTotalRegion=100-m_CoeffTotalRegion;

	if (m_checkAbonnementRegion == FALSE)
	{
		if(m_CoeffTotalRegion>TAUXMAXIREGION) m_CoeffTotalRegion=TAUXMAXIREGION;
	}
	else
	{
		if(m_CoeffTotalRegion>TAUXMAXIREGION+TAUXABONNEMENTREGION) m_CoeffTotalRegion=TAUXMAXIREGION+TAUXABONNEMENTREGION;
	}
	
	// arrondir
	m_CoeffTotalRegion=((int)(0.49999999+m_CoeffTotalRegion*100))/100.0;


	// CGV 2001
	if (m_checknegociationregion)
		m_totalnetregion=m_totalcabrutregion-(m_totalcabrutregion*m_coeffnegociationregion/100);
	else
		m_totalnetregion=m_totalcabrutregion-(m_totalcabrutregion*m_CoeffTotalRegion/100);

	m_totalnetregion = int((m_totalnetregion+0.005)*100);
	m_totalnetregion = m_totalnetregion/100;

	//total brut
	m_totalbrutregion=m_BrutHtRegion+m_BrutRegion;

	// Remise professionnelle
	m_coeffremiseregion = TAUXPROFESSIONNELREGION;

	//total net net (avec remise professionnelle)
	if (m_checkProfessionnel == TRUE)
		m_totalnetnetregion=m_totalnetregion-(m_totalnetregion*m_coeffremiseregion/100);
	else
		m_totalnetnetregion=m_totalnetregion;
	
	m_totalnetnetregion = int((m_totalnetnetregion+0.005)*100);
	m_totalnetnetregion = m_totalnetnetregion/100;
	if(update)	UpdateData(false);

}

void CCascadeRegion::OnChangeCoeffnegociationRegion() 
{
	UpdateData(true);
	UpdateAffichage(false);
	m_pDoc->UpdateAllViews(NULL, 2);
}

void CCascadeRegion::OnChangeEditTauxderegieRegion() 
{
	UpdateData(true);
	if(m_pDoc) m_pDoc->UpdateAllViews(NULL, 2);
}

void CCascadeRegion::OnChangeFraisannonceRegion() 
{
	UpdateData(true);
	UpdateAffichage(false);
	m_pDoc->UpdateAllViews(NULL, 2);
	m_pDoc->m_TotalFraisAnnonceEnEuro = m_pDoc->m_PrixEnEuro;
}

void CCascadeRegion::OnChecknegociationRegion() 
{
	UpdateData(true);
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);
}

void CCascadeRegion::OnCheckprimeprofessionnelRegion() 
{
	UpdateData(true);
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);	
}

void CCascadeRegion::OnCheckprimenouveauclientRegion() 
{
	UpdateData(true);
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);	
}

void CCascadeRegion::OnChangePrimeprofessionnelRegion() 
{
	
	UpdateData(true);
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);	
}

void CCascadeRegion::OnChangeFraistechniqueregion() 
{

	UpdateData(true);
	UpdateAffichage(false);
	m_pDoc->UpdateAllViews(NULL, 2);

	//m_pDoc->m_TotalFraisAnnonceEnEuro = m_pDoc->m_PrixEnEuro;	
}

