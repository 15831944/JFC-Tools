// Annonceur.h: interface for the CAnnonceur class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ANNONCEUR_H__E9163723_468C_11D4_8658_0080C708A895__INCLUDED_)
#define AFX_ANNONCEUR_H__E9163723_468C_11D4_8658_0080C708A895__INCLUDED_

#include "TblAnnonceur.h"
#include <afxtempl.h>		// MFC template library

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CAnnonceur  
{
public:

	long	m_NumAnnonceur;
	CString	m_Code;
	CString	m_Nom;
	CString	m_Adresse;
	CString	m_Ville;
	long	m_CodePostal;
	CString	m_Contact;
	CString	m_Tel;
	CString	m_Fax;
	CString	m_Email;
	CString m_Commentaire;

	CAnnonceur();
	virtual ~CAnnonceur();

	CAnnonceur & operator=(const CAnnonceur &Source);
	CAnnonceur & operator=(const CTblAnnonceur &Source);
	bool operator<(const CAnnonceur &Source);

};

typedef CArray<CAnnonceur,CAnnonceur&> CAnnonceurArray;

#endif // !defined(AFX_ANNONCEUR_H__E9163723_468C_11D4_8658_0080C708A895__INCLUDED_)
