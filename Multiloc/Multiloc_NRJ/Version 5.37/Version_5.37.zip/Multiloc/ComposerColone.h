// ComposerColone.h: interface for the CComposerColone class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COMPOSERCOLONE_H__B06DCCC3_805F_11D2_843A_004005327F70__INCLUDED_)
#define AFX_COMPOSERCOLONE_H__B06DCCC3_805F_11D2_843A_004005327F70__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include "..\COMPOSENTS\obj_col.h"

class CComposerColone : public CObj_Col  
{
public:
	CComposerColone();
	virtual ~CComposerColone();
	virtual void DessineFond(CDC * dc, CRect RectObj);
	virtual void DessineCellule(CDC * dc, CRect RectCel, short Y, short PosY);

	// Initialisation des libell�s formats spots
	void InitModeColonne(int ModeTarif,CStringArray &TabFormat);

	CStringArray m_TabFormat; 
	int m_ModeTarif;

private:

	CFont m_MSSansSerif;

};

#endif // !defined(AFX_COMPOSERCOLONE_H__B06DCCC3_805F_11D2_843A_004005327F70__INCLUDED_)
