#if !defined(AFX_DLGCOMPOSER_H__14C23842_7FD5_11D2_843A_004005327F70__INCLUDED_)
#define AFX_DLGCOMPOSER_H__14C23842_7FD5_11D2_843A_004005327F70__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgComposer.h : header file
//

#include "composergrille.h"
#include "composercolone.h"
#include "multilocdoc.h"
/////////////////////////////////////////////////////////////////////////////
// CDlgComposer dialog

class CDlgComposer : public CDialog
{
// Construction
public:
	CDlgComposer(CMultilocDoc *pDoc,CWnd* pParent = NULL);   // standard constructor
	CMultilocDoc *m_pDoc;

// Dialog Data
	//{{AFX_DATA(CDlgComposer)
	enum { IDD = IDD_COMPOSER };
	CComboBoxEx	m_ComboMelodie;
	CComboBoxEx	m_ComboFormat;
	CEdit	m_EditNbSpot;
	CComposerColone	m_ObjColone;
	CScrollBar	m_VScroll;
	CComposerGrille	m_ObjGrille;
	CString	m_txt;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgComposer)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CMelodieArray m_Melodie;
	void RefreshCombo();
	int m_NrSymbolActif;
	// Generated message map functions
	//{{AFX_MSG(CDlgComposer)
	virtual BOOL OnInitDialog();
	afx_msg void OnCancelMode();
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnAddMelodie();
	afx_msg void OnDeleteMelodie();
	afx_msg void OnSelchangeComboboFormat();
	afx_msg void OnComboboxMelodieSelchange();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	bool m_fInit;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCOMPOSER_H__14C23842_7FD5_11D2_843A_004005327F70__INCLUDED_)
