// DlgChangerPeriode.cpp : implementation file
//

#include "stdafx.h"
#include "multiloc.h"
#include "DlgChangerPeriode.h"
extern CMultilocApp theApp;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgChangerPeriode dialog


CDlgChangerPeriode::CDlgChangerPeriode(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgChangerPeriode::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgChangerPeriode)
	m_DateDebut = COleDateTime::GetCurrentTime();
	m_DateFin = COleDateTime::GetCurrentTime();
	m_Duree = 0;
	//}}AFX_DATA_INIT
}


void CDlgChangerPeriode::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgChangerPeriode)
	DDX_DateTimeCtrl(pDX, IDC_DATE_DEBUT, m_DateDebut);
	DDX_DateTimeCtrl(pDX, IDC_DATE_FIN, m_DateFin);
	DDX_Text(pDX, IDC_EDIT_DUREE, m_Duree);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgChangerPeriode, CDialog)
	//{{AFX_MSG_MAP(CDlgChangerPeriode)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_DATE_DEBUT, OnChangeDateDebut)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_DATE_FIN, OnChangeDateFin)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_DUREE, OnDeltaposSpinDuree)
	ON_EN_CHANGE(IDC_EDIT_DUREE, OnChangeEditDuree)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgChangerPeriode message handlers

BOOL CDlgChangerPeriode::OnInitDialog() 
{
	theApp.JoueMusic(7);
	CDialog::OnInitDialog();
	
	m_Duree=1+m_DateFin-m_DateDebut;
	UpdateData(0);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgChangerPeriode::OnChangeDateDebut(NMHDR* pNMHDR, LRESULT* pResult) 
{
	UpdateData(1);
	m_Duree=1+m_DateFin-m_DateDebut;
	UpdateData(0);
	
	*pResult = 0;
}

void CDlgChangerPeriode::OnChangeDateFin(NMHDR* pNMHDR, LRESULT* pResult) 
{
	UpdateData(1);
	m_Duree=1+m_DateFin-m_DateDebut;
	UpdateData(0);
	
	*pResult = 0;
}

void CDlgChangerPeriode::OnDeltaposSpinDuree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN*  pNMUpDown= (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	UpdateData(1);
	m_Duree-=pNMUpDown->iDelta;
	if(m_Duree<1)m_Duree=1;
	if(m_Duree>366)m_Duree=366;
	m_DateFin=m_DateDebut+COleDateTimeSpan(m_Duree-1,0,0,0);

	UpdateData(0);
	
	*pResult = 0;
}

void CDlgChangerPeriode::OnOK() 
{
	// on r�cup�re et on test les valeurs
	UpdateData(1);

	// v�rification de la dur�e
	if(m_Duree<1 || m_Duree>366){
		MessageBox("La dur�e du plan est invalide","Message",MB_ICONWARNING | MB_OK);
		return;
	}

	// v�rification de la date de d�but
	COleDateTime Minimum(2000, 1, 1, 0, 0, 0);
	if (m_DateDebut < Minimum)
	{
		if (IDNO == AfxMessageBox("Attention, cette version du logiciel utilise les CGV 2000.\nVoulez-vous continuer ?", MB_YESNO | MB_ICONQUESTION))
			return;
	}

	// fin de la bo�te
	EndDialog(IDOK);
}

void CDlgChangerPeriode::OnChangeEditDuree() 
{
	UpdateData(1);
	m_DateFin=m_DateDebut+COleDateTimeSpan(m_Duree-1,0,0,0);
	UpdateData(0);
}
