// ComposerGrille.h: interface for the CComposerGrille class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COMPOSERGRILLE_H__14C23843_7FD5_11D2_843A_004005327F70__INCLUDED_)
#define AFX_COMPOSERGRILLE_H__14C23843_7FD5_11D2_843A_004005327F70__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "multilocdoc.h"

class CComposerGrille : public CObj_Gril
{
public:
	CComposerGrille();
	virtual ~CComposerGrille();
	short ** m_pSpotJH;
	CEdit *m_pEditNbSpot;
	void SetSymbolActif(int nr);
	void SetTabIcon(void * tab);
	void UpdateNbSpot();
	CMultilocDoc *m_pDoc;
	
private:
	void DessineCellule(CDC * dc, CRect RectCel, short X, short Y, short PosX, short PosY);
	bool OnLeftClick(short X, short Y, short PosX, short PosY, CPoint pos);
	bool OnRightClick(short X, short Y, short PosX, short PosY, CPoint pos);

	CArray<HICON ,HICON >*m_phIcon;
	int m_NrSymbolActif;
};

#endif // !defined(AFX_COMPOSERGRILLE_H__14C23843_7FD5_11D2_843A_004005327F70__INCLUDED_)
