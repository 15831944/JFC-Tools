// CodeSECODIP.cpp: implementation of the CCodeSECODIP class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiloc.h"
#include "CodeSECODIP.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCodeSECODIP::CCodeSECODIP()
{
	m_NumCode = 0;
	m_NomProduit = _T("");
	m_CodeSecodip = _T("");
	m_SecteurActiv = _T("");
}

CCodeSECODIP::~CCodeSECODIP()
{

}

CCodeSECODIP & CCodeSECODIP::operator=(const CCodeSECODIP &Source)
{
	m_NumCode = Source.	m_NumCode;
	m_NomProduit = Source.m_NomProduit;
	m_CodeSecodip = Source.	m_CodeSecodip;
	m_SecteurActiv = Source.m_SecteurActiv;
	return(*this);
}

CCodeSECODIP & CCodeSECODIP::operator=(const CTblCodeSecodip &Source)
{
	m_NumCode = Source.	m_NumCode;
	m_NomProduit = Source.m_NomProduit;
	m_CodeSecodip = Source.	m_CodeSecodip;
	m_SecteurActiv = Source.m_SecteurActiv;
	return(*this);
}

bool CCodeSECODIP::operator<(const CCodeSECODIP &Source)
{
	if(m_CodeSecodip<Source.m_CodeSecodip) return(TRUE);
	else return(FALSE);
}
