// DlgCalendrier.cpp : implementation file
//

#include "stdafx.h"
#include "multiloc.h"
#include "DlgCalendrier.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgCalendrier dialog


CDlgCalendrier::CDlgCalendrier(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgCalendrier::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgCalendrier)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlgCalendrier::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgCalendrier)
	DDX_Control(pDX, IDC_CALENDAR1, m_ActiveX);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgCalendrier, CDialog)
	//{{AFX_MSG_MAP(CDlgCalendrier)
	ON_BN_CLICKED(IDC_BUTTON_MOISMOINS, OnButtonMoismoins)
	ON_BN_CLICKED(IDC_BUTTON_MOISPLUS, OnButtonMoisplus)
	ON_BN_CLICKED(IDC_BUTTON_ANNEEMOINS, OnButtonAnneemoins)
	ON_BN_CLICKED(IDC_BUTTON_ANNEEPLUS, OnButtonAnneeplus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgCalendrier message handlers

void CDlgCalendrier::OnOK() 
{
	m_Date.SetDate(m_ActiveX.GetYear(),m_ActiveX.GetMonth(),m_ActiveX.GetDay());
	EndDialog(IDOK);
}

void CDlgCalendrier::SetDate(COleDateTime Date)
{
	m_Date=Date;
}

BOOL CDlgCalendrier::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_ActiveX.SetYear(m_Date.GetYear());
	m_ActiveX.SetMonth(m_Date.GetMonth());
	m_ActiveX.SetDay(m_Date.GetDay());
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

COleDateTime CDlgCalendrier::GetDate()
{
	return(m_Date);

}

void CDlgCalendrier::OnButtonMoismoins() 
{
	m_ActiveX.PreviousMonth();	
}

void CDlgCalendrier::OnButtonMoisplus() 
{
	m_ActiveX.NextMonth();	
}

void CDlgCalendrier::OnButtonAnneemoins() 
{
	m_ActiveX.PreviousYear();	
}

void CDlgCalendrier::OnButtonAnneeplus() 
{
	m_ActiveX.NextYear();	
	
}
