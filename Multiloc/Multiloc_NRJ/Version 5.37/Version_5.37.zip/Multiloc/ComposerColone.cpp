// ComposerColone.cpp: implementation of the CComposerColone class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiloc.h"
#include "ComposerColone.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CComposerColone::CComposerColone()
{
	m_MSSansSerif.CreateFont(-8, 0, 0, 0,FW_NORMAL,0, 0, 0, 0, 0, 0, 0,(BYTE)(VARIABLE_PITCH | FF_SWISS),"MS Sans Serif");         /* and face name only */
}

CComposerColone::~CComposerColone()
{

}

void CComposerColone::DessineCellule(CDC * dc, CRect RectCel, short Y, short PosY)
{
	CString txt;

	if (m_ModeTarif == 0)
	{
		// en mode tranche horaire
		short nbmin;
		nbmin=5*60+Y*30;


		// txt.Format("%dH%02d",nbmin/60,nbmin%60);
		if (nbmin <= 24 * 60)
		{
			// format avant minuit
			txt.Format("%dH%02d",nbmin/60,nbmin%60);
		}
		else
		{
			// format apr�s minuit
			nbmin -= 1440;
			txt.Format("%dH%02d",nbmin/60,nbmin%60);
		}

	}
	else
	{
		// en mode type de format (5s,10s,etc....) 
		if (Y < m_TabFormat.GetSize())
		{
			// Libell� du format
			txt = m_TabFormat[Y] + "s";

			// Entete colonne format gratos en jaune clair
			if (Y % 2 != 0)
				dc->FillSolidRect(RectCel,RGB(249,242,193));
		}
		else
		{
			txt = "xxx";
		}
	}

	dc->SelectObject(m_MSSansSerif);
	dc->DrawText(txt,-1,RectCel,DT_NOPREFIX|DT_CENTER|DT_VCENTER);
}

void CComposerColone::DessineFond(CDC * dc, CRect RectObj)
{
	dc->FillSolidRect(RectObj,RGB(192,192,192));
}


// Initialisation des libell�s formats spots
void CComposerColone:: InitModeColonne(int ModeTarif,CStringArray &TabFormat)
{
	// R�cup mode de saisie spot (pour affichage libell� en colonne)
	m_ModeTarif = ModeTarif;

	if (TabFormat.GetSize() > 0 && ModeTarif > 0)
	{
		// Init taille tableau des formats
		m_TabFormat.SetSize(TabFormat.GetSize());
		for (int i=0;i<TabFormat.GetSize();i++)
		{
			m_TabFormat[i] = TabFormat[i];
		}
	}
}