#if !defined(AFX_DLGSELECTION_H__03469041_886B_11D2_AC40_0080C708A895__INCLUDED_)
#define AFX_DLGSELECTION_H__03469041_886B_11D2_AC40_0080C708A895__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgSelection.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgSelection dialog

class CDlgSelection : public CDialog
{
// Construction
public:
	CDlgSelection(CWnd* pParent = NULL);   // standard constructor
	CImageList *m_pIL; // Images List (a mettre � jour avant)
	CWordArray m_Use; // ceux d�j� utilis� (a mettre � jour avant)
	int m_Sel; // la selection apr�s le IDOK

// Dialog Data
	//{{AFX_DATA(CDlgSelection)
	enum { IDD = IDD_SELECTSYMBOL };
	CComboBoxEx	m_Combo;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgSelection)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CWordArray m_NrLien; 

	// Generated message map functions
	//{{AFX_MSG(CDlgSelection)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGSELECTION_H__03469041_886B_11D2_AC40_0080C708A895__INCLUDED_)
