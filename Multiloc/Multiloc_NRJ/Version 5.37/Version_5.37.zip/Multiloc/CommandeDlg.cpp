// CommandeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "multiloc.h"
#include "multilocdoc.h"
#include "CommandeDlg.h"
#include "NoyauCommande.h" 
#include "SelMailDlg.h"


extern CMultilocApp theApp;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CMultilocApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CCommandeDlg dialog


CCommandeDlg::CCommandeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCommandeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCommandeDlg)
	m_ClientSelect = _T("");
	m_Commentaire = _T("");
	m_CheckAnnonceurDirect = TRUE;
	m_NomCampagne = _T("");
	m_NumRegion = 1;
	m_NumCodeSecodip=1;
	m_AgenceSelect = _T("");
	m_AnnonceurSelect = _T("");
	m_CommercialSelect = _T("");
	m_MandataireSelect = _T("");
	m_DateDebCampagne = COleDateTime::GetCurrentTime();
	m_DateCreationCampagne = COleDateTime::GetCurrentTime();
	m_DateDernModifCampagne = COleDateTime::GetCurrentTime();
	m_DateFinCampagne = COleDateTime::GetCurrentTime();
	m_CheckMailAuto = FALSE;
	m_RegionSelect = _T("");
	m_TypeCampagneSelect = _T("");
	m_NoVersion = _T("0");
	m_BudgetGlobal = _T("0");
	m_NbModifCamp = _T("0");
	m_NoCampagne = _T("");
	m_NbSpots = _T("");
	m_CodeSecodipSelect = _T("");
	//}}AFX_DATA_INIT

	Create(IDD_ENRGTCOMMANDE);
	m_pDoc=NULL;
}

CCommandeDlg::~CCommandeDlg()
{
	DestroyWindow();
}

bool CCommandeDlg::Activate(CMultilocDoc * pDoc)
{
	if(pDoc)m_pDoc=pDoc;

	theApp.JoueMusic(5);

  	ShowWindow(SW_SHOW);
	UpdateCommande();
	return true;
}


// Chargement des infos commandes document courant
void CCommandeDlg::ChargeInfoCommandeDoc()
{

	short InxTab;
	CString AdrMail; 
	CString Txt;
	long NrStation;
	long NrVille;

	// Info no de version et nb modifs campagne
	m_NoVersion.Format("%d",m_pDoc->m_NoVersionCommande + 1);
	m_NbModifCamp.Format("%d",atoi(m_NoVersion)-1); // correspond au nb version -1 (1ere version =1)

	// Les dates
	m_DateDebCampagne =m_pDoc->m_DateDebut;
	m_DateFinCampagne =m_pDoc->m_DateFin;
	m_DateDernModifCampagne =m_pDoc->m_DateCommande;
	m_DateCreationCampagne =m_pDoc->m_DateCreationCommande;

	// Les infos plans
	m_NbSpots.Format("%d",m_pDoc->m_NbSpot);
	m_BudgetGlobal.Format("%7.2f",m_pDoc->m_BBrut);

	// Si annonceur direct >> pas d'agence ni mandataire
	m_CheckAnnonceurDirect = m_pDoc->m_pNoyauCommande->m_AnnonceurDirect;
	if (m_CheckAnnonceurDirect)
	{
		m_ComboAgence.EnableWindow(FALSE);
		m_ComboMandataire.EnableWindow(FALSE);
	}
	else
	{
		m_ComboAgence.EnableWindow(TRUE);
		m_ComboMandataire.EnableWindow(TRUE);
	}

    // Si d�j� dossier command�, update avec infos campagne
	if (m_pDoc->m_CodeNoCampagne != 0)
	{
		// Recup no campagne stock� dans dossier
		m_NoCampagne.Format("%d",m_pDoc->m_CodeNoCampagne);

		UpdateCommandeCampagne(m_pDoc->m_CodeNoCampagne);

		// Texte commentaire commande
		m_Commentaire = m_pDoc->m_pNoyauCommande->m_TxtCommande;

	}
	else
	{
		// voir si Client et Commercial d�j� choisi
		if (m_pDoc->m_pNoyauCommande->m_CodeCommandeClient !="")
		{
			if (m_pDoc->m_pNoyauCommande->SelectionClient(m_pDoc->m_pNoyauCommande->m_CodeCommandeClient,InxTab) == true)
				if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblClient.GetSize())
					m_ClientSelect = m_pDoc->m_pNoyauCommande->m_TblClient[InxTab].m_Nom;
		}

		if (m_pDoc->m_pNoyauCommande->m_CodeCommandeCommercial !="")
		{
			if (m_pDoc->m_pNoyauCommande->SelectionCommercial(m_pDoc->m_pNoyauCommande->m_CodeCommandeCommercial,InxTab) == true)
				if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblCommercial.GetSize())
					m_CommercialSelect = m_pDoc->m_pNoyauCommande->m_TblCommercial[InxTab].m_Nom;
		}

		// Tout d'abord dans le cas d'une 1ere commande, recherche no campagne valide
		m_NoCampagne.Format("%d",m_pDoc->m_pNoyauCommande->NoUniqueDispoCampagne());

		// Affichage Type campagne
		if (m_NoTypeCampagne == CNoyauCommande::m_AchatClassique)
		{
			m_TypeCampagneSelect = G_TxtAchatClassique; //"Achat classique";
		}
		else
		{
			m_TypeCampagneSelect = G_TxtContrat; //"Contrat";
		}

		// Affichage Region Campagne
		if (m_pDoc->m_pNoyauCommande->GetNomRegion(Txt,m_NumRegion))
			m_RegionSelect = Txt;

		// Affichage Nom Produit Secodip
		if (m_pDoc->m_pNoyauCommande->GetNomProduitSecodip(Txt,m_NumCodeSecodip))
			m_CodeSecodipSelect = Txt;


	
		// Mode Mail/Fax
		m_CheckMailAuto = m_pDoc->m_pNoyauCommande->m_MailAuto;
		if (m_CheckMailAuto)
		{
			m_BtnSelectionMail.EnableWindow(FALSE);
		}

		UpdateData(0);

	}

	// Recup toutes les dernieres adresses email
	for (short i=0 ; i<m_pDoc->m_NbStationVille ; i++)
	{
		NrStation = m_pDoc->m_pNoyau->m_TblStation[m_pDoc->m_idxStation[i]].m_NrUnique;
		NrVille = m_pDoc->m_pNoyau->m_pTblVille[m_pDoc->m_idxStation[i]][m_pDoc->m_idxVille[i]].m_NrUnique;
		AdrMail = m_pDoc->m_pNoyau->DonneAdrMailStationVille(NrStation,NrVille);
		m_pDoc->m_Juke[m_pDoc->m_idxStation[i]][m_pDoc->m_idxVille[i]].m_AdrMailStationVille = AdrMail;
	}	



}

void CCommandeDlg::UpdateCommande()
{
	short nr;

	// Initilalise tous les combo
	m_ComboClient.ResetContent();
	m_ComboCommercial.ResetContent();
	m_ComboAnnonceur.ResetContent();
	m_ComboAgence.ResetContent();
	m_ComboMandataire.ResetContent();
	m_ComboRegion.ResetContent();
	m_ComboTypeCampagne.ResetContent();
	UpdateData(true);

	// Ainsi que les autres elmts
	m_Commentaire="";
	m_NomCampagne="";
	UpdateData(false);
	

	// Charge les combo-box
	// Les interlocuteurs "client"
	for (nr=0;nr<m_pDoc->m_pNoyauCommande->m_TblClient.GetSize();nr++)
		m_ComboClient.AddString(m_pDoc->m_pNoyauCommande->m_TblClient[nr].m_Nom);

	// Les interlocuteurs "commercial"
	for (nr=0;nr<m_pDoc->m_pNoyauCommande->m_TblCommercial.GetSize();nr++)
		m_ComboCommercial.AddString(m_pDoc->m_pNoyauCommande->m_TblCommercial[nr].m_Nom);

	// Les interlocuteurs "agence"
	for (nr=0;nr<m_pDoc->m_pNoyauCommande->m_TblAgence.GetSize();nr++)
		m_ComboAgence.AddString(m_pDoc->m_pNoyauCommande->m_TblAgence[nr].m_Nom);
	
	// Les interlocuteurs "annonceur"
	for (nr=0;nr<m_pDoc->m_pNoyauCommande->m_TblAnnonceur.GetSize();nr++)
		m_ComboAnnonceur.AddString(m_pDoc->m_pNoyauCommande->m_TblAnnonceur[nr].m_Nom);

	// Les interlocuteurs "mandataire"
	for (nr=0;nr<m_pDoc->m_pNoyauCommande->m_TblMandataire.GetSize();nr++)
		m_ComboMandataire.AddString(m_pDoc->m_pNoyauCommande->m_TblMandataire[nr].m_Nom);

	// Les type de campagne (classique ou contrat)
	m_ComboTypeCampagne.AddString(G_TxtAchatClassique);
	m_ComboTypeCampagne.AddString(G_TxtContrat);

	// Les r�gions
	for (nr=0;nr<m_pDoc->m_pNoyauCommande->m_TblRegion.GetSize();nr++)
		m_ComboRegion.AddString(m_pDoc->m_pNoyauCommande->m_TblRegion[nr].m_Region);

	// Les codes secodip
	for (nr=0;nr<m_pDoc->m_pNoyauCommande->m_TblCodeSecodip.GetSize();nr++)
		m_ComboCodeSecodip.AddString(m_pDoc->m_pNoyauCommande->m_TblCodeSecodip[nr].m_NomProduit);	

	// Init Infos g�n�rales (no version/region,periode....) via document
	ChargeInfoCommandeDoc();

	UpdateData(false);	// mise � jour des controles via "variables value"
}

// Mise � jour boite dialogue Commande 
void CCommandeDlg::UpdateCommandeCampagne(long CodeNoCampagne)
{
	short nr;
	short InxTab;
	long Code;
	CString CodeCommande;
	CString Txt;
	CRegion Region;
	bool Ok;

	for (nr=0;nr<m_pDoc->m_pNoyauCommande->m_TblCampagne.GetSize();nr++)
	{
		if (m_pDoc->m_pNoyauCommande->m_TblCampagne[nr].m_NumCampagne == CodeNoCampagne)
		{
			m_NomCampagne=m_pDoc->m_pNoyauCommande->m_TblCampagne[nr].m_Nom;

			// A FAIRE (voir stockage code achat)
			//m_NoTypeCampagne=m_pDoc->m_pNoyauCommande->m_TblCampagne[nr].m_CodeAchat;

			m_DateCreationCampagne=m_pDoc->m_pNoyauCommande->m_TblCampagne[nr].m_DateCreation;
			// A FAIRE
			m_DateDernModifCampagne=m_DateCreationCampagne;

			
			Code = m_pDoc->m_pNoyauCommande->m_TblCampagne[nr].m_NumClient;
			Ok= m_pDoc->m_pNoyauCommande->SelectionClient(Code,InxTab);
			if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblClient.GetSize())
				m_ClientSelect =m_pDoc->m_pNoyauCommande->m_TblClient[InxTab].m_Nom;

			Code=m_pDoc->m_pNoyauCommande->m_TblCampagne[nr].m_NumCommercial;
			Ok = m_pDoc->m_pNoyauCommande->SelectionCommercial(Code,InxTab);
			if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblCommercial.GetSize())
				m_CommercialSelect = m_pDoc->m_pNoyauCommande->m_TblCommercial[InxTab].m_Nom;

			CodeCommande = m_pDoc->m_pNoyauCommande->m_CodeCommandeAnnonceur;
			Ok = m_pDoc->m_pNoyauCommande->SelectionAnnonceur(CodeCommande,InxTab);
			if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblAnnonceur.GetSize())
				m_AnnonceurSelect =m_pDoc->m_pNoyauCommande->m_TblAnnonceur[InxTab].m_Nom;

			CodeCommande = m_pDoc->m_pNoyauCommande->m_CodeCommandeAgence;
			Ok =m_pDoc->m_pNoyauCommande->SelectionAgence(CodeCommande,InxTab);
			if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblAgence.GetSize())
				m_AgenceSelect = m_pDoc->m_pNoyauCommande->m_TblAgence[InxTab].m_Nom;

			CodeCommande = m_pDoc->m_pNoyauCommande->m_CodeCommandeMandataire;
			Ok = m_pDoc->m_pNoyauCommande->SelectionMandataire(CodeCommande,InxTab);
			if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblMandataire.GetSize())
				m_MandataireSelect = m_pDoc->m_pNoyauCommande->m_TblMandataire[InxTab].m_Nom;

			
			// Affichage Region campagne courante
			m_NumRegion = m_pDoc->m_pNoyauCommande->m_TblCampagne[nr].m_NumRegion;
			if (m_pDoc->m_pNoyauCommande->GetNomRegion(Txt,m_NumRegion))
				m_RegionSelect = Txt;

			// Affichage Produit Secodip Selectionn�e
			m_NumCodeSecodip = m_pDoc->m_pNoyauCommande->m_TblCampagne[nr].m_NumCodeSecodip;
			if (m_pDoc->m_pNoyauCommande->GetNomProduitSecodip(Txt,m_NumCodeSecodip))	
				m_CodeSecodipSelect = Txt;

			break;
		}	
	}

	// Affichage Type campagne
	if (m_NoTypeCampagne == CNoyauCommande :: m_AchatClassique)
	{
		m_TypeCampagneSelect = G_TxtAchatClassique; //"Achat classique";
	}
	else
	{
		m_TypeCampagneSelect = G_TxtContrat; //"Contrat";
	}
	UpdateData(0);

}

bool CCommandeDlg::CommandeComplete()
{

	bool OkInterlocuteur = false;

	if (m_ClientSelect != "" &&
		m_CommercialSelect != "" &&
		m_CheckAnnonceurDirect == TRUE &&
		m_AnnonceurSelect != "")
		OkInterlocuteur = true;

	else if (m_ClientSelect != "" &&
			 m_CommercialSelect != "" &&
		     m_CheckAnnonceurDirect == FALSE &&
		     m_AnnonceurSelect != "" &&
			 m_AgenceSelect != "" &&
			 m_MandataireSelect != "")
		OkInterlocuteur = true;

	// Test info campagne
	if (OkInterlocuteur == true &&
		m_NomCampagne != "" &&
		m_TypeCampagneSelect != "")
		return true;
	else
		return false;


}

void CCommandeDlg::StockeNvInfoCommande()
{
	CCampagne Campagne;
	CString FicCourant,ExtSave,SaveFic;
	CString PathFicDoc;
	BOOL FileExist=FALSE;
	
	if (m_pDoc->m_pNoyauCommande->m_EtatCommande == CNoyauCommande::m_AucuneCommande)
	{
		// Cas 1er enrgt commande (aucune commande > dossier command�)
		m_pDoc->m_pNoyauCommande->m_EtatCommande = CNoyauCommande::m_CommandeEnCours;
		m_pDoc->m_NoVersionCommande = atoi(m_NoVersion);

		// Enregistrement dans dossier mlc
		m_pDoc->m_DateCreationCommande=COleDateTime::GetCurrentTime();
		m_pDoc->m_DateCommande=COleDateTime::GetCurrentTime();
		
		// Enregistrement dans Noyau Commande du dossier
		
		m_pDoc->m_pNoyauCommande->m_CodeCommandeCommercial=m_pDoc->m_pNoyauCommande->GetCodeCommandeCommercial(m_CommercialSelect);
		m_pDoc->m_pNoyauCommande->m_CodeCommandeClient=m_pDoc->m_pNoyauCommande->GetCodeCommandeClient(m_ClientSelect);
		m_pDoc->m_pNoyauCommande->m_CodeCommandeAnnonceur=m_pDoc->m_pNoyauCommande->GetCodeCommandeAnnonceur(m_AnnonceurSelect);
		m_pDoc->m_pNoyauCommande->m_AnnonceurDirect=m_CheckAnnonceurDirect;
		m_pDoc->m_pNoyauCommande->m_CodeCommandeAgence=m_pDoc->m_pNoyauCommande->GetCodeCommandeAgence(m_AgenceSelect);
		m_pDoc->m_pNoyauCommande->m_CodeCommandeMandataire=m_pDoc->m_pNoyauCommande->GetCodeCommandeMandataire(m_MandataireSelect);
		m_pDoc->m_pNoyauCommande->m_TxtCommande=m_Commentaire;
		m_pDoc->m_pNoyauCommande->m_MailAuto = m_CheckMailAuto;


		// Sauvegarde du fichier commande sous un autre nom (nom_noversion.mlc)
		PathFicDoc = m_pDoc->GetPathName();
		FicCourant=  m_pDoc->GetTitle();
		int pos=PathFicDoc.Find(FicCourant);
		if(pos>0)PathFicDoc=PathFicDoc.Left(pos);

		CString PathCur = PathFicDoc.Left(pos);

		pos=FicCourant.Find(".");
		ExtSave.Format("%d",m_pDoc->m_NoVersionCommande); 
		SaveFic = FicCourant.Left(pos) + "_" + ExtSave + ".mlc";

		// Date cr�ation
		Campagne.m_DateCreation=COleDateTime::GetCurrentTime();

		// sauvegarde nom fichier et path
		Campagne.m_FicMultiloc=SaveFic;
		Campagne.m_PathFicMlc =PathCur;

		// Cree nouvel elmt campagne et Stocke Info Campagne
		CreerNouvelleCampagne(Campagne);

		// Copie du fichier
		::CopyFile(PathFicDoc + "\\" + FicCourant,PathFicDoc + "\\" +SaveFic,FileExist);
		if (FileExist==FALSE)
		{
			// Indique que l'on sauvegarde un historique commande
			m_pDoc->m_DossierHistorique = true;
			m_pDoc->m_CodeNoCampagne = Campagne.m_NumCampagne;
			m_pDoc->m_NoCampDossier.Format("%d%s%s",m_pDoc->m_CodeNoCampagne,"-",m_pDoc->m_pNoyauCommande->m_CodeCommandeCommercial);


			// Stocke info m_pDoc au noveau du fichier sauvegarde
			// sauve dossier xxx_noversion.mlc
			m_pDoc->OnSaveDocument(PathFicDoc + "\\" +SaveFic);

			// Debloque le dossier courant pour d'�ventuels modifs						
			m_pDoc->m_DossierHistorique = false;
			m_pDoc->m_BloqueDossier = FALSE;

			// Stocke nom ancienne version
			m_pDoc->m_FicMlcPrec = SaveFic;
		
			// Incr�mente le n� de version
			//m_pDoc->m_NoVersionCommande = m_NoVersion+1;
			m_pDoc->m_NoVersionCommande = atoi(m_NoVersion);
		}

		// Repositionne le flag modif dossier apres commande
		m_pDoc->m_FlagModifApresCommande = FALSE;

	}

	else if (m_pDoc->m_pNoyauCommande->m_EtatCommande == CNoyauCommande::m_CommandeEnCours ||
			 m_pDoc->m_pNoyauCommande->m_EtatCommande == CNoyauCommande::m_CommandeEtRemplace)
	{
		
		// Cas d'un dossier d�j� command� et modifi� > remplacement
		m_pDoc->m_pNoyauCommande->m_EtatCommande = CNoyauCommande::m_CommandeEtRemplace;

		// Enregistrement nvlle date commande dans dossier mlc
		m_pDoc->m_DateCommande=COleDateTime::GetCurrentTime();;
		
		// Enregistrement dans Noyau Commande du dossier
		m_pDoc->m_pNoyauCommande->m_CodeCommandeCommercial=m_pDoc->m_pNoyauCommande->GetCodeCommandeCommercial(m_CommercialSelect);
		m_pDoc->m_pNoyauCommande->m_CodeCommandeClient=m_pDoc->m_pNoyauCommande->GetCodeCommandeClient(m_ClientSelect);
		m_pDoc->m_pNoyauCommande->m_CodeCommandeAnnonceur=m_pDoc->m_pNoyauCommande->GetCodeCommandeAnnonceur(m_AnnonceurSelect);
		m_pDoc->m_pNoyauCommande->m_AnnonceurDirect=m_CheckAnnonceurDirect;
		m_pDoc->m_pNoyauCommande->m_CodeCommandeAgence=m_pDoc->m_pNoyauCommande->GetCodeCommandeAgence(m_AgenceSelect);
		m_pDoc->m_pNoyauCommande->m_CodeCommandeMandataire=m_pDoc->m_pNoyauCommande->GetCodeCommandeMandataire(m_MandataireSelect);
		m_pDoc->m_pNoyauCommande->m_TxtCommande=m_Commentaire;
		m_pDoc->m_pNoyauCommande->m_MailAuto = m_CheckMailAuto;

		// Recup Campagne et Stocke Nvlle Info Campagne
		m_pDoc->m_pNoyauCommande->GetCampagne(Campagne,m_pDoc->m_CodeNoCampagne);

		// Nom du fichier ou sera sauvegard� la campagne
		PathFicDoc = m_pDoc->GetPathName();
		FicCourant=  m_pDoc->GetTitle();
		int pos=PathFicDoc.Find(FicCourant);
		if(pos>0)PathFicDoc=PathFicDoc.Left(pos);

		CString PathCur = PathFicDoc.Left(pos);

		pos=FicCourant.Find(".");
		ExtSave.Format("%d",m_NoVersion); 
		SaveFic = FicCourant.Left(pos) + "_" + ExtSave + ".mlc";

		// sauvegarde nom fichier et path
		Campagne.m_FicMultiloc=SaveFic;
		Campagne.m_PathFicMlc = PathCur;
	
		if (MajCampagne(Campagne) == true)
		{
			// Sauvegarde de l'ancien fichier sous un autre nom (nom_noversion.mlc)
			::CopyFile(PathFicDoc + "\\" + FicCourant,PathFicDoc + "\\" +SaveFic,FileExist);
			if (FileExist==FALSE)
			{

				// Indique que l'on sauvegarde un historique commande
				m_pDoc->m_DossierHistorique = true;
				m_pDoc->m_CodeNoCampagne = Campagne.m_NumCampagne;
				m_pDoc->m_NoCampDossier.Format("%d%s%s",m_pDoc->m_CodeNoCampagne,"-",m_pDoc->m_pNoyauCommande->m_CodeCommandeCommercial);

				// Stocke info m_pDoc au noveau du fichier sauvegarde
				// sauve dossier xxx_noversion.mlc
				m_pDoc->OnSaveDocument(PathFicDoc + "\\" +SaveFic);

				// Debloque le dossier courant pour d'�ventuels modifs						
				m_pDoc->m_DossierHistorique = false;
				m_pDoc->m_BloqueDossier = FALSE;

				// Stocke nom ancienne version
				m_pDoc->m_FicMlcPrec = SaveFic;
			
				// Incr�mente le n� de version
				m_pDoc->m_NoVersionCommande = atoi(m_NoVersion);
			}

			// Repositionne le flag modif dossier apres commande
			m_pDoc->m_FlagModifApresCommande = FALSE;
		}

		else
			AfxMessageBox("Probl�me de copie, fichier " +PathFicDoc + "\\" +SaveFic+ "d�j� existant !!!",MB_ICONINFORMATION);

	
	}
}

// (CGV Multi-Villes PARIS)
// Creer nouvelle elmt campagne via saisie dialogue commande
bool CCommandeDlg::CreerNouvelleCampagne(CCampagne &Campagne)
{
	short InxTab;
	bool Ok;

	Campagne.m_Nom = m_NomCampagne;

	if (m_pDoc->m_pNoyauCommande->SelectionCommercial(m_pDoc->m_pNoyauCommande->m_CodeCommandeCommercial,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblCommercial.GetSize())
			Campagne.m_NumCommercial = m_pDoc->m_pNoyauCommande->m_TblCommercial[InxTab].m_NumCommercial;

	if (m_pDoc->m_pNoyauCommande->SelectionClient(m_pDoc->m_pNoyauCommande->m_CodeCommandeClient,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblClient.GetSize())
			Campagne.m_NumClient = m_pDoc->m_pNoyauCommande->m_TblClient[InxTab].m_NumClient;

	if (m_pDoc->m_pNoyauCommande->SelectionAnnonceur(m_pDoc->m_pNoyauCommande->m_CodeCommandeAnnonceur,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblAnnonceur.GetSize())
			Campagne.m_NumAnnonceur = m_pDoc->m_pNoyauCommande->m_TblAnnonceur[InxTab].m_NumAnnonceur;

	if (m_pDoc->m_pNoyauCommande->SelectionAgence(m_pDoc->m_pNoyauCommande->m_CodeCommandeAgence,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblAgence.GetSize())
			Campagne.m_NumAgence = m_pDoc->m_pNoyauCommande->m_TblAgence[InxTab].m_NumAgence;
	if (Campagne.m_NumAgence == 0) Campagne.m_NumAgence =1;

	if (m_pDoc->m_pNoyauCommande->SelectionMandataire(m_pDoc->m_pNoyauCommande->m_CodeCommandeMandataire,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblMandataire.GetSize())
			Campagne.m_NumMandataire = m_pDoc->m_pNoyauCommande->m_TblMandataire[InxTab].m_NumMandataire;
	if (Campagne.m_NumMandataire == 0) Campagne.m_NumMandataire =1;

	Campagne.m_DateCreation=m_pDoc->m_DateCreationCommande;
	Campagne.m_DateModification= m_pDoc->m_DateCreationCommande;

	Campagne.m_NoVersion=atoi(m_NoVersion);
	Campagne.m_DateDebut=m_DateDebCampagne;
	Campagne.m_DateFin=m_DateFinCampagne;
	Campagne.m_BudgetGlobal=m_pDoc->m_BBrut;
	Campagne.m_NbSpots=m_pDoc->m_NbSpot;
	Campagne.m_EtatCommande = "Command�e"; //CNoyauCommande::m_CommandeEnCours;

	// Type de campagne
	Campagne.m_CodeAchat=m_TypeCampagneSelect;

	// Region S�lectionn�e
	if (m_pDoc->m_pNoyauCommande->SelectionRegion(m_RegionSelect,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblRegion.GetSize())
			Campagne.m_NumRegion = m_pDoc->m_pNoyauCommande->m_TblRegion[InxTab].m_NumRegion;
	
	// Nom produit Secodip S�lectionn�e
	if (m_pDoc->m_pNoyauCommande->SelectionProduitSecodip(m_CodeSecodipSelect,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblCodeSecodip.GetSize())
			Campagne.m_NumCodeSecodip = m_pDoc->m_pNoyauCommande->m_TblCodeSecodip[InxTab].m_NumCode;
	
	// Pour Calcul NET
	Campagne.m_VolumeMessage= m_pDoc->m_DlgCascade.m_coeffNbMessages;
	Campagne.m_RemiseFinanciereCoeffDegressif = m_pDoc->m_DlgCascade.m_coeffDegressif/100;

	/*
	// Remise nouveau client
	if (m_pDoc->m_DlgCascade.m_checkNouveauClient == TRUE)
		Campagne.m_RemiseNouveauClient= m_pDoc->m_DlgCascade.m_coeffNouveauClient/100;
	else
		Campagne.m_RemiseNouveauClient = 0;
	*/

	/*
	// Remise renouvellement
	if (m_pDoc->m_DlgCascade.m_checkRenouvellement == TRUE)
		Campagne.m_RemiseRenouvellement= m_pDoc->m_DlgCascade.m_coeffRenouvellement/100;
	else
		Campagne.m_RemiseRenouvellement= 0;
	*/

	// Remise prime anticipation
	if (m_pDoc->m_DlgCascade.m_checkprimeanticipation == TRUE)
		Campagne.m_RemisePrimeAnticipation = m_pDoc->m_DlgCascade.m_primeanticipation/100;
	else
		Campagne.m_RemisePrimeAnticipation = 0;

	// Remise Multi-villes
	Campagne.m_RemisePrimeMultiVilles= m_pDoc->m_DlgCascade.m_coeffMultivilles;

	// Total abbattements
	Campagne.m_PrctTotalAbattement = m_pDoc->m_DlgCascade.m_coeffAbattements/100;

    // Total primes et remises
	Campagne.m_PrctCoeffTotal = m_pDoc->m_DlgCascade.m_coefftotal/100;
	
	// Taux de n�gociation
	if (m_pDoc->m_DlgCascade.m_checknegociation == TRUE)
		Campagne.m_TauxNegociation= m_pDoc->m_DlgCascade.m_coeffnegociation/100;
	else
		Campagne.m_TauxNegociation= 0;

	// Ca BRUT et CA NET
	Campagne.m_TotalCABrut= m_pDoc->m_DlgCascade.m_totalcabrut;
	Campagne.m_TotalCANet= m_pDoc->m_DlgCascade.m_totalnet;

	// Taux de r�gie
	Campagne.m_TauxRegie= m_pDoc->m_DlgCascade.m_TauxDeRegie/100;

	// Remise de mandat
	if (m_pDoc->m_DlgCascade.m_checkcumulmandatmanuel == TRUE)
		Campagne.m_RemiseDeMandat = m_pDoc->m_DlgCascade.m_coeffremise/100;
	else
		Campagne.m_RemiseDeMandat = m_pDoc->m_DlgCascade.m_coeffremiseauto/100;

	// Ca NET NET
	Campagne.m_TotalCANetNet = m_pDoc->m_DlgCascade.m_totalnetnet;
	
	// Frais Annonce Spot (Auto : stock� au niveau des spots, Non auto : montant global)
	Campagne.m_FraisAnnonceReel = m_pDoc->m_TotFraisAnnonce;
	if (m_pDoc->m_DlgCascade.m_checkfraisannoncemanuel == TRUE)
	{
		Campagne.m_FraisAnnonceAuto = false;
		Campagne.m_TotalFraisAnnonceNonAuto = m_pDoc->m_DlgCascade.m_TotalFraisAnnonce;
	}
	else
	{
		Campagne.m_FraisAnnonceAuto = true;			
		Campagne.m_TotalFraisAnnonceNonAuto = 0;
	}

	// Les frais de duplication : 
	Campagne.m_FraisDuplication = m_pDoc->m_DlgCascade.m_FraisDuplication;


	// Facturation non effectu�e
	Campagne.m_Facturee= FALSE;

	// Commentaires
	Campagne.m_TxtComplement = m_Commentaire; 

	// Ajoute la campagne
	Ok = m_pDoc->m_pNoyauCommande->AddCampagne(Campagne);

	// Ajoute toutes les infos campagnes (Station/Ville et spots)
	Ok = AjoutStationVilleSpotCommande(Campagne);

	return Ok;

}

// (CGV Multi-Villes PARIS)
// Mise � jour de la campagne avec nvlles infos saisis dans dialogue commande
bool CCommandeDlg::MajCampagne(CCampagne &Campagne)
{
	short InxTab;
	bool Ok = false;

	Campagne.m_Nom = m_NomCampagne;

	//Recherche code unique commercial
	if (m_pDoc->m_pNoyauCommande->SelectionCommercial(m_pDoc->m_pNoyauCommande->m_CodeCommandeCommercial,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblCommercial.GetSize())
			Campagne.m_NumCommercial = m_pDoc->m_pNoyauCommande->m_TblCommercial[InxTab].m_NumCommercial;

	//Recherche code unique client
	if (m_pDoc->m_pNoyauCommande->SelectionClient(m_pDoc->m_pNoyauCommande->m_CodeCommandeClient,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblClient.GetSize())
			Campagne.m_NumClient = m_pDoc->m_pNoyauCommande->m_TblClient[InxTab].m_NumClient;

	if (m_pDoc->m_pNoyauCommande->SelectionAnnonceur(m_pDoc->m_pNoyauCommande->m_CodeCommandeAnnonceur,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblAnnonceur.GetSize())
			Campagne.m_NumAnnonceur = m_pDoc->m_pNoyauCommande->m_TblAnnonceur[InxTab].m_NumAnnonceur;

	if (m_pDoc->m_pNoyauCommande->SelectionAgence(m_pDoc->m_pNoyauCommande->m_CodeCommandeAgence,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblAgence.GetSize())
			Campagne.m_NumAgence = m_pDoc->m_pNoyauCommande->m_TblAgence[InxTab].m_NumAgence;
	if (Campagne.m_NumAgence == 0) Campagne.m_NumAgence =1;

	if (m_pDoc->m_pNoyauCommande->SelectionMandataire(m_pDoc->m_pNoyauCommande->m_CodeCommandeMandataire,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblMandataire.GetSize())
			Campagne.m_NumMandataire = m_pDoc->m_pNoyauCommande->m_TblMandataire[InxTab].m_NumMandataire;
	if (Campagne.m_NumMandataire == 0) Campagne.m_NumMandataire =1;

    // Maj des diff�rents champs campagne
	Campagne.m_NoVersion=atoi(m_NoVersion);
	Campagne.m_DateDebut=m_DateDebCampagne;
	Campagne.m_DateFin=m_DateFinCampagne;
	Campagne.m_BudgetGlobal=m_pDoc->m_BBrut;
	Campagne.m_NbSpots=m_pDoc->m_NbSpot;
	Campagne.m_EtatCommande = "Remplac�e"; //CNoyauCommande::m_CommandeEtRemplace;

	// Type de campagne
	Campagne.m_CodeAchat=m_TypeCampagneSelect;

	// Region S�lectionn�e
	if (m_pDoc->m_pNoyauCommande->SelectionRegion(m_RegionSelect,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblRegion.GetSize())
			Campagne.m_NumRegion = m_pDoc->m_pNoyauCommande->m_TblRegion[InxTab].m_NumRegion;

	// Nom produit S�lectionn�e
	if (m_pDoc->m_pNoyauCommande->SelectionProduitSecodip(m_CodeSecodipSelect,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblCodeSecodip.GetSize())
			Campagne.m_NumCodeSecodip = m_pDoc->m_pNoyauCommande->m_TblCodeSecodip[InxTab].m_NumCode;
		
	// Les infos tarifications

	// Pour Calcul NET
	Campagne.m_VolumeMessage= m_pDoc->m_DlgCascade.m_coeffNbMessages;
	Campagne.m_RemiseFinanciereCoeffDegressif = m_pDoc->m_DlgCascade.m_coeffDegressif/100;

	/*
	// Remise nouveau client
	if (m_pDoc->m_DlgCascade.m_checkNouveauClient == TRUE)
		Campagne.m_RemiseNouveauClient= m_pDoc->m_DlgCascade.m_coeffNouveauClient/100;
	else
		Campagne.m_RemiseNouveauClient = 0;

	// Remise renouvellement
	if (m_pDoc->m_DlgCascade.m_checkRenouvellement == TRUE)
		Campagne.m_RemiseRenouvellement= m_pDoc->m_DlgCascade.m_coeffRenouvellement/100;
	else
		Campagne.m_RemiseRenouvellement= 0;

	// Remise prime anticipation
	if (m_pDoc->m_DlgCascade.m_checkprimeanticipation == TRUE)
		Campagne.m_RemisePrimeAnticipation = m_pDoc->m_DlgCascade.m_primeanticipation/100;
	else
		Campagne.m_RemisePrimeAnticipation = 0;

	// Remise Multi-villes
	Campagne.m_RemisePrimeMultiVilles= m_pDoc->m_DlgCascade.m_coeffMultivilles;
	*/

	// Total abbattements
	Campagne.m_PrctTotalAbattement = m_pDoc->m_DlgCascade.m_coeffAbattements/100;

    // Total primes et remises
	Campagne.m_PrctCoeffTotal = m_pDoc->m_DlgCascade.m_coefftotal/100;
	
	// Taux de n�gociation
	if (m_pDoc->m_DlgCascade.m_checknegociation == TRUE)
		Campagne.m_TauxNegociation= m_pDoc->m_DlgCascade.m_coeffnegociation/100;
	else
		Campagne.m_TauxNegociation= 0;

	// Ca BRUT et CA NET
	Campagne.m_TotalCABrut= m_pDoc->m_DlgCascade.m_totalcabrut;
	Campagne.m_TotalCANet= m_pDoc->m_DlgCascade.m_totalnet;

	// Taux de r�gie
	Campagne.m_TauxRegie= m_pDoc->m_DlgCascade.m_TauxDeRegie/100;

	// Remise de mandat
	if (m_pDoc->m_DlgCascade.m_checkcumulmandatmanuel == TRUE)
		Campagne.m_RemiseDeMandat = m_pDoc->m_DlgCascade.m_coeffremise/100;
	else
		Campagne.m_RemiseDeMandat = m_pDoc->m_DlgCascade.m_coeffremiseauto/100;

	// Ca NET NET
	Campagne.m_TotalCANetNet = m_pDoc->m_DlgCascade.m_totalnetnet;
	
	// Frais Annonce Spot (Auto : stock� au niveau des spots, Non auto : montant global)
	Campagne.m_FraisAnnonceReel = m_pDoc->m_TotFraisAnnonce;
	if (m_pDoc->m_DlgCascade.m_checkfraisannoncemanuel == TRUE)
	{
		Campagne.m_FraisAnnonceAuto = false;
		Campagne.m_TotalFraisAnnonceNonAuto = m_pDoc->m_DlgCascade.m_TotalFraisAnnonce;
	}
	else
	{
		Campagne.m_FraisAnnonceAuto = true;			
		Campagne.m_TotalFraisAnnonceNonAuto = 0;
	}

	// Les frais de duplication : 
	Campagne.m_FraisDuplication = m_pDoc->m_DlgCascade.m_FraisDuplication;


	// Facturation rien ne change !!!!
	
	// Commentaires
	Campagne.m_TxtComplement = m_Commentaire; 

	// Maj campagne dans la base access
	// recherche index campagne dans tableau des campagnes m_TblCampagne
	for (int i=0;i<m_pDoc->m_pNoyauCommande->m_TblCampagne.GetSize();i++)
	{
		if (m_pDoc->m_pNoyauCommande->m_TblCampagne[i].m_NumCampagne = Campagne.m_NumCampagne)
		{
			Ok = m_pDoc->m_pNoyauCommande->ModifierCampagne(Campagne,i);
			break;
		}
	}

	return Ok;
}

/*
// (CGV Multi-Villes REGION)
// Creer nouvelle elmt campagne via saisie dialogue commande 
bool CCommandeDlg::CreerNouvelleCampagneRegion(CCampagne &Campagne)
{
	short InxTab;
	bool Ok;

	Campagne.m_Nom = m_NomCampagne;

	if (m_pDoc->m_pNoyauCommande->SelectionCommercial(m_pDoc->m_pNoyauCommande->m_CodeCommandeCommercial,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblCommercial.GetSize())
			Campagne.m_NumCommercial = m_pDoc->m_pNoyauCommande->m_TblCommercial[InxTab].m_NumCommercial;

	if (m_pDoc->m_pNoyauCommande->SelectionClient(m_pDoc->m_pNoyauCommande->m_CodeCommandeClient,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblClient.GetSize())
			Campagne.m_NumClient = m_pDoc->m_pNoyauCommande->m_TblClient[InxTab].m_NumClient;

	if (m_pDoc->m_pNoyauCommande->SelectionAnnonceur(m_pDoc->m_pNoyauCommande->m_CodeCommandeAnnonceur,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblAnnonceur.GetSize())
			Campagne.m_NumAnnonceur = m_pDoc->m_pNoyauCommande->m_TblAnnonceur[InxTab].m_NumAnnonceur;

	if (m_pDoc->m_pNoyauCommande->SelectionAgence(m_pDoc->m_pNoyauCommande->m_CodeCommandeAgence,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblAgence.GetSize())
			Campagne.m_NumAgence = m_pDoc->m_pNoyauCommande->m_TblAgence[InxTab].m_NumAgence;
	if (Campagne.m_NumAgence == 0) Campagne.m_NumAgence =1;

	if (m_pDoc->m_pNoyauCommande->SelectionMandataire(m_pDoc->m_pNoyauCommande->m_CodeCommandeMandataire,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblMandataire.GetSize())
			Campagne.m_NumMandataire = m_pDoc->m_pNoyauCommande->m_TblMandataire[InxTab].m_NumMandataire;
	if (Campagne.m_NumMandataire == 0) Campagne.m_NumMandataire =1;

	Campagne.m_DateCreation=m_pDoc->m_DateCreationCommande;
	Campagne.m_DateModification= m_pDoc->m_DateCreationCommande;

	Campagne.m_NoVersion=atoi(m_NoVersion);
	Campagne.m_DateDebut=m_DateDebCampagne;
	Campagne.m_DateFin=m_DateFinCampagne;
	Campagne.m_BudgetGlobal=m_pDoc->m_BBrut;
	Campagne.m_NbSpots=m_pDoc->m_NbSpot;
	Campagne.m_EtatCommande = "Command�e"; //CNoyauCommande::m_CommandeEnCours;

	// Type de campagne
	Campagne.m_CodeAchat=m_TypeCampagneSelect;

	// Region S�lectionn�e
	if (m_pDoc->m_pNoyauCommande->SelectionRegion(m_RegionSelect,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblRegion.GetSize())
			Campagne.m_NumRegion = m_pDoc->m_pNoyauCommande->m_TblRegion[InxTab].m_NumRegion;
	
	// Nom produit Secodip S�lectionn�e
	if (m_pDoc->m_pNoyauCommande->SelectionProduitSecodip(m_CodeSecodipSelect,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblCodeSecodip.GetSize())
			Campagne.m_NumCodeSecodip = m_pDoc->m_pNoyauCommande->m_TblCodeSecodip[InxTab].m_NumCode;
	
	// Les infos tarifications
	// Pour Calcul NET
	Campagne.m_VolumeMessage= m_pDoc->m_DlgCascadeRegion.m_CoeffNbMessagesRegion;
	Campagne.m_RemiseFinanciereCoeffDegressif = m_pDoc->m_DlgCascadeRegion.m_CoeffDegressifRegion/100;

	// Remise nouveau client
	if (m_pDoc->m_DlgCascade.m_checkNouveauClient == TRUE)
		Campagne.m_RemiseNouveauClient= m_pDoc->m_DlgCascadeRegion.m_coeffNouveauClientRegion/100;
	else
		Campagne.m_RemiseNouveauClient = 0;

	// Remise renouvellement
	if (m_pDoc->m_DlgCascadeRegion.m_checkRenouvellementRegion == TRUE)
		Campagne.m_RemiseRenouvellement= m_pDoc->m_DlgCascadeRegion.m_CoeffRenouvellementRegion/100;
	else
		Campagne.m_RemiseRenouvellement= 0;

	// Remise prime anticipation
	if (m_pDoc->m_DlgCascadeRegion.m_checkAnticipationRegion == TRUE)
		Campagne.m_RemisePrimeAnticipation = m_pDoc->m_DlgCascadeRegion.m_primeanticipationregion/100;
	else
		Campagne.m_RemisePrimeAnticipation = 0;

	// Remise Multi-villes
	Campagne.m_RemisePrimeMultiVilles= m_pDoc->m_DlgCascadeRegion.m_CoeffMultiVillesRegion;

	// Remise Engagement/Abonnement
	Campagne.m_RemiseEngagementAbonnement = m_pDoc->m_DlgCascadeRegion.m_primeabonnementregion;

	// Total abbattements
	Campagne.m_PrctTotalAbattement = m_pDoc->m_DlgCascadeRegion.m_CoeffAbattementRegion/100;

    // Total primes et remises
	Campagne.m_PrctCoeffTotal = m_pDoc->m_DlgCascadeRegion.m_CoeffTotalRegion/100;
	
	// Taux de n�gociation
	if (m_pDoc->m_DlgCascadeRegion.m_checknegociationregion == TRUE)
		Campagne.m_TauxNegociation= m_pDoc->m_DlgCascadeRegion.m_coeffnegociationregion/100;
	else
		Campagne.m_TauxNegociation= 0;

	// Ca BRUT et CA NET
	Campagne.m_TotalCABrut= m_pDoc->m_DlgCascadeRegion.m_totalcabrutregion;
	Campagne.m_TotalCANet= m_pDoc->m_DlgCascadeRegion.m_totalnetregion;

	// Taux de r�gie
	Campagne.m_TauxRegie= m_pDoc->m_DlgCascadeRegion.m_TauxDeRegieRegion/100;

	// Remise de mandat en mode R�gion = Remise Professionnelle
	if (m_pDoc->m_DlgCascadeRegion.m_checkProfessionnel == TRUE)
		Campagne.m_RemiseDeMandat = m_pDoc->m_DlgCascadeRegion.m_coeffremiseregion/100;
	else
		Campagne.m_RemiseDeMandat = 0.0f;

	// Ca NET NET
	Campagne.m_TotalCANetNet = m_pDoc->m_DlgCascadeRegion.m_totalnetnetregion;
	
	// Frais Annonce Spot et Duplication = Frais mise en onde pour mode R�gion
	Campagne.m_FraisAnnonceReel = 0.0f;
	Campagne.m_FraisAnnonceAuto = false;
	Campagne.m_TotalFraisAnnonceNonAuto = m_pDoc->m_DlgCascadeRegion.m_TotalFraisAnnonceRegion;

	// Les frais de duplication en mode r�gion int�gr� dans Frais Annonce: 
	Campagne.m_FraisDuplication = 0.0f;

	// Facturation non effectu�e
	Campagne.m_Facturee= FALSE;

	// Commentaires
	Campagne.m_TxtComplement = m_Commentaire; 

	// Ajoute la campagne
	Ok = m_pDoc->m_pNoyauCommande->AddCampagne(Campagne);

	// Ajoute toutes les infos campagnes (Station/Ville et spots)
	Ok = AjoutStationVilleSpotCommande(Campagne);

	return Ok;

}
*/

/*
// (CGV Multi-Villes REGION)
// Mise � jour de la campagne avec nvlles infos saisis dans dialogue commande
bool CCommandeDlg::MajCampagneRegion(CCampagne &Campagne)
{
	short InxTab;
	bool Ok = false;

	Campagne.m_Nom = m_NomCampagne;

	//Recherche code unique commercial
	if (m_pDoc->m_pNoyauCommande->SelectionCommercial(m_pDoc->m_pNoyauCommande->m_CodeCommandeCommercial,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblCommercial.GetSize())
			Campagne.m_NumCommercial = m_pDoc->m_pNoyauCommande->m_TblCommercial[InxTab].m_NumCommercial;

	//Recherche code unique client
	if (m_pDoc->m_pNoyauCommande->SelectionClient(m_pDoc->m_pNoyauCommande->m_CodeCommandeClient,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblClient.GetSize())
			Campagne.m_NumClient = m_pDoc->m_pNoyauCommande->m_TblClient[InxTab].m_NumClient;

	if (m_pDoc->m_pNoyauCommande->SelectionAnnonceur(m_pDoc->m_pNoyauCommande->m_CodeCommandeAnnonceur,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblAnnonceur.GetSize())
			Campagne.m_NumAnnonceur = m_pDoc->m_pNoyauCommande->m_TblAnnonceur[InxTab].m_NumAnnonceur;

	if (m_pDoc->m_pNoyauCommande->SelectionAgence(m_pDoc->m_pNoyauCommande->m_CodeCommandeAgence,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblAgence.GetSize())
			Campagne.m_NumAgence = m_pDoc->m_pNoyauCommande->m_TblAgence[InxTab].m_NumAgence;
	if (Campagne.m_NumAgence == 0) Campagne.m_NumAgence =1;

	if (m_pDoc->m_pNoyauCommande->SelectionMandataire(m_pDoc->m_pNoyauCommande->m_CodeCommandeMandataire,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblMandataire.GetSize())
			Campagne.m_NumMandataire = m_pDoc->m_pNoyauCommande->m_TblMandataire[InxTab].m_NumMandataire;
	if (Campagne.m_NumMandataire == 0) Campagne.m_NumMandataire =1;

    // Maj des diff�rents champs campagne
	Campagne.m_NoVersion=atoi(m_NoVersion);
	Campagne.m_DateDebut=m_DateDebCampagne;
	Campagne.m_DateFin=m_DateFinCampagne;
	Campagne.m_BudgetGlobal=m_pDoc->m_BBrut;
	Campagne.m_NbSpots=m_pDoc->m_NbSpot;
	Campagne.m_EtatCommande = "Remplac�e"; //CNoyauCommande::m_CommandeEtRemplace;

	// Type de campagne
	Campagne.m_CodeAchat=m_TypeCampagneSelect;

	// Region S�lectionn�e
	if (m_pDoc->m_pNoyauCommande->SelectionRegion(m_RegionSelect,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblRegion.GetSize())
			Campagne.m_NumRegion = m_pDoc->m_pNoyauCommande->m_TblRegion[InxTab].m_NumRegion;

	// Nom produit S�lectionn�e
	if (m_pDoc->m_pNoyauCommande->SelectionProduitSecodip(m_CodeSecodipSelect,InxTab) == true)
		if (InxTab >=0 && InxTab <m_pDoc->m_pNoyauCommande->m_TblCodeSecodip.GetSize())
			Campagne.m_NumCodeSecodip = m_pDoc->m_pNoyauCommande->m_TblCodeSecodip[InxTab].m_NumCode;
		
	// Les infos tarifications

	// Pour Calcul NET
	Campagne.m_VolumeMessage= m_pDoc->m_DlgCascadeRegion.m_CoeffNbMessagesRegion;
	Campagne.m_RemiseFinanciereCoeffDegressif = m_pDoc->m_DlgCascadeRegion.m_CoeffDegressifRegion/100;

	// Remise nouveau client
	if (m_pDoc->m_DlgCascadeRegion.m_checkNouveauClientRegion == TRUE)
		Campagne.m_RemiseNouveauClient= m_pDoc->m_DlgCascadeRegion.m_coeffNouveauClientRegion/100;
	else
		Campagne.m_RemiseNouveauClient = 0;

	// Remise renouvellement
	if (m_pDoc->m_DlgCascadeRegion.m_checkRenouvellementRegion == TRUE)
		Campagne.m_RemiseRenouvellement= m_pDoc->m_DlgCascadeRegion.m_CoeffRenouvellementRegion/100;
	else
		Campagne.m_RemiseRenouvellement= 0;

	// Remise prime anticipation
	if (m_pDoc->m_DlgCascadeRegion.m_checkAnticipationRegion == TRUE)
		Campagne.m_RemisePrimeAnticipation = m_pDoc->m_DlgCascadeRegion.m_primeanticipationregion/100;
	else
		Campagne.m_RemisePrimeAnticipation = 0;

	// Remise Multi-villes
	Campagne.m_RemisePrimeMultiVilles= m_pDoc->m_DlgCascadeRegion.m_CoeffMultiVillesRegion;

	// Remise Engagement/Abonnement
	Campagne.m_RemiseEngagementAbonnement = m_pDoc->m_DlgCascadeRegion.m_primeabonnementregion;// Remise Engagement/Abonnement

	// Total abbattements
	Campagne.m_PrctTotalAbattement = m_pDoc->m_DlgCascadeRegion.m_CoeffAbattementRegion/100;

    // Total primes et remises
	Campagne.m_PrctCoeffTotal = m_pDoc->m_DlgCascadeRegion.m_CoeffTotalRegion/100;
	
	// Taux de n�gociation
	if (m_pDoc->m_DlgCascadeRegion.m_checknegociationregion == TRUE)
		Campagne.m_TauxNegociation= m_pDoc->m_DlgCascadeRegion.m_coeffnegociationregion/100;
	else
		Campagne.m_TauxNegociation= 0;

	// Ca BRUT et CA NET
	Campagne.m_TotalCABrut= m_pDoc->m_DlgCascadeRegion.m_totalcabrutregion;
	Campagne.m_TotalCANet= m_pDoc->m_DlgCascadeRegion.m_totalnetregion;

	// Taux de r�gie
	Campagne.m_TauxRegie= m_pDoc->m_DlgCascadeRegion.m_TauxDeRegieRegion/100;

	// Remise de mandat = Remise professionnel pour Mode R�gion
	if (m_pDoc->m_DlgCascadeRegion.m_checkProfessionnel == TRUE)
		Campagne.m_RemiseDeMandat = m_pDoc->m_DlgCascadeRegion.m_coeffremiseregion/100;
	else
		Campagne.m_RemiseDeMandat = 0.0f;

	// Ca NET NET
	Campagne.m_TotalCANetNet = m_pDoc->m_DlgCascadeRegion.m_totalnetnetregion;
	
	// Frais Annonce Spot et Duplication = Frais mise en onde pour mode R�gion
	Campagne.m_FraisAnnonceReel = 0.0f;
	Campagne.m_FraisAnnonceAuto = false;
	Campagne.m_TotalFraisAnnonceNonAuto = m_pDoc->m_DlgCascadeRegion.m_TotalFraisAnnonceRegion;

	// Les frais de duplication (int�gr� dans frais annonce pour mode r�gion)
	Campagne.m_FraisDuplication = 0.0f;

	// Commentaires
	Campagne.m_TxtComplement = m_Commentaire; 

	// Maj campagne dans la base access
	// recherche index campagne dans tableau des campagnes m_TblCampagne
	for (int i=0;i<m_pDoc->m_pNoyauCommande->m_TblCampagne.GetSize();i++)
	{
		if (m_pDoc->m_pNoyauCommande->m_TblCampagne[i].m_NumCampagne = Campagne.m_NumCampagne)
		{
			Ok = m_pDoc->m_pNoyauCommande->ModifierCampagne(Campagne,i);
			break;
		}
	}

	return Ok;
}
*/

bool CCommandeDlg::AjoutStationVilleSpotCommande(CCampagne &Campagne)
{


	bool Ok;
	int sta,vil,j,h;
	short InfoSpot;
	bool SpotStaVilTrouve;
	CCampStationVille CampStationVille;
	CSpot Spot;
	COleDateTime DateSpot;
	int Heure;
	int Minute;

	for(sta=0;sta<m_pDoc->m_NbStation;sta++)
	{
		for(vil=0;vil<m_pDoc->m_pNoyau->m_pTblVille[sta].GetSize() ;vil++)
		{

			long NoUniqueStation = long(m_pDoc->m_pNoyau->m_TblStation[sta].m_NrUnique);
			long NoUniqueVille   = long(m_pDoc->m_pNoyau->m_pTblVille[sta][vil].m_NrUnique);
			SpotStaVilTrouve = false;

			for(j=0;j<m_pDoc->m_Duree;j++)
			{
				for(h=0;h<m_pDoc->m_NbHoraire;h++)
				{
					InfoSpot = m_pDoc->m_Juke[sta][vil].m_SpotJH[j][h];
					if (InfoSpot != 0)
					{
						if (!SpotStaVilTrouve)
						{
							// 1er spot trouv� pour cette station-ville
							// On stocke alors cette station ville dans table access
							CampStationVille.m_NumCampagne = Campagne.m_NumCampagne;
							CampStationVille.m_NumStation = m_pDoc->m_pNoyau->m_TblStation[sta].m_NrUnique;
							CampStationVille.m_NumVille =m_pDoc->m_pNoyau->m_pTblVille[sta][vil].m_NrUnique;
							CampStationVille.m_RemCouplage = m_pDoc->m_Juke[sta][vil].m_RemiseCouplage/100;
							Ok = m_pDoc->m_pNoyauCommande->AddStationVilleCampagne(CampStationVille);
							SpotStaVilTrouve = true;
						}

						// Stocke les spots trouv�s pour ce couple Station/Ville (par 1/2heure)
						Heure = 5 + int(h/2);
						Minute = (h%2)*30;
						DateSpot.SetDate(m_pDoc->m_DateDebut.GetYear(),m_pDoc->m_DateDebut.GetMonth(),m_pDoc->m_DateDebut.GetDay());
						DateSpot = DateSpot + COleDateTimeSpan(j,Heure,Minute,0);
						Spot.m_Annee = DateSpot.GetYear();
						Spot.m_NoMois= DateSpot.GetMonth();
						Spot.m_DateHeure = DateSpot;
						//Spot.m_Frais = m_pDoc->m_pNoyau->DonneFraisAnnonceSpot(sta,vil,j);
						Spot.m_Frais = m_pDoc->m_pNoyau->DonneFraisAnnonceSpot(sta,vil,DateSpot);
						Spot.m_NumStationVille = CampStationVille.m_NumStationVille;
						//Spot.m_Tarif = m_pDoc->m_pNoyau->DonneTarif(long(sta), long(vil), 0, j, h);
						Spot.m_Tarif = long(m_pDoc->m_pNoyau->DonneTarif(NoUniqueStation, NoUniqueVille, 0, j, h,m_pDoc->m_ModeTarif,m_pDoc->m_ModeContratFidelite))/100;
						Ok = m_pDoc->m_pNoyauCommande->AddSpotCampagne(Spot);

					}
				}	
			}
		}
	}
	return Ok;

}



void CCommandeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCommandeDlg)
	DDX_Control(pDX, IDC_COMBO_CODESECODIP, m_ComboCodeSecodip);
	DDX_Control(pDX, IDC_COMBO_TYPECAMPAGNE, m_ComboTypeCampagne);
	DDX_Control(pDX, IDC_COMBO_REGION, m_ComboRegion);
	DDX_Control(pDX, IDC_BTN_SELMAIL, m_BtnSelectionMail);
	DDX_Control(pDX, IDC_CMB_CMDCOMMERCIAL, m_ComboCommercial);
	DDX_Control(pDX, IDC_CMB_CMDMANDATAIRE, m_ComboMandataire);
	DDX_Control(pDX, IDC_CMB_CMDANNONCEUR, m_ComboAnnonceur);
	DDX_Control(pDX, IDC_CMB_CMDAGENCE, m_ComboAgence);
	DDX_Control(pDX, IDC_CMB_CMD_CLIENT, m_ComboClient);
	DDX_CBString(pDX, IDC_CMB_CMD_CLIENT, m_ClientSelect);
	DDX_Text(pDX, IDC_CMD_COMMENTAIRE, m_Commentaire);
	DDX_Check(pDX, IDC_CHK_CMDANNONCEURDIRECT, m_CheckAnnonceurDirect);
	DDX_Text(pDX, IDC_CMDNOMCAMPAGNE, m_NomCampagne);
	DDV_MaxChars(pDX, m_NomCampagne, 60);
	DDX_CBString(pDX, IDC_CMB_CMDAGENCE, m_AgenceSelect);
	DDX_CBString(pDX, IDC_CMB_CMDANNONCEUR, m_AnnonceurSelect);
	DDX_CBString(pDX, IDC_CMB_CMDCOMMERCIAL, m_CommercialSelect);
	DDX_CBString(pDX, IDC_CMB_CMDMANDATAIRE, m_MandataireSelect);
	DDX_DateTimeCtrl(pDX, IDC_CMDDATEDEBUT, m_DateDebCampagne);
	DDX_DateTimeCtrl(pDX, IDC_CMDDATECREATION, m_DateCreationCampagne);
	DDX_DateTimeCtrl(pDX, IDC_CMDDATEDERNMODIF, m_DateDernModifCampagne);
	DDX_DateTimeCtrl(pDX, IDC_CMDDATEFIN, m_DateFinCampagne);
	DDX_Check(pDX, IDC_CHK_MAILAUTO, m_CheckMailAuto);
	DDX_CBString(pDX, IDC_COMBO_REGION, m_RegionSelect);
	DDX_CBString(pDX, IDC_COMBO_TYPECAMPAGNE, m_TypeCampagneSelect);
	DDX_Text(pDX, IDC_INFO_NOVERSION, m_NoVersion);
	DDX_Text(pDX, IDC_INFO_BUDGETGLOBAL, m_BudgetGlobal);
	DDX_Text(pDX, IDC_INFO_NBMODIF, m_NbModifCamp);
	DDX_Text(pDX, IDC_INFO_NOCAMP, m_NoCampagne);
	DDX_Text(pDX, IDC_INFO_NBSPOTS, m_NbSpots);
	DDX_CBString(pDX, IDC_COMBO_CODESECODIP, m_CodeSecodipSelect);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCommandeDlg, CDialog)
	//{{AFX_MSG_MAP(CCommandeDlg)
	ON_BN_CLICKED(IDC_CHK_CMDANNONCEURDIRECT, OnChkCmdannonceurdirect)
	ON_BN_CLICKED(IDC_CHK_MAILAUTO, OnChkMailauto)
	ON_WM_DESTROY()
	ON_CBN_SELCHANGE(IDC_CMB_CMD_CLIENT, OnSelchangeCmbCmdClient)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCommandeDlg message handlers

BOOL CCommandeDlg::OnInitDialog() 
{


	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CCommandeDlg::OnOK() 
{
	CCampagne Campagne;
	CCampagne CampagneEnCours;
	CString PathDossier;
	bool Ok;
	CSelMailDlg DlgSelMail(m_pDoc);
	

	// Recupere dans Dossier les derni�res infos commandes
	Ok = m_pDoc->m_pNoyauCommande->GetCampagne(CampagneEnCours,m_pDoc->m_CodeNoCampagne);

	UpdateData(true);   // mise � jour des variables value via controles
	if (CommandeComplete() == true)
	{

		if (
           // Test si nouvelle campagne et nom campagne non d�j� utilis� 
		   (m_pDoc->m_pNoyauCommande->m_EtatCommande == CNoyauCommande::m_AucuneCommande &&
	        m_pDoc->m_pNoyauCommande->GetCampagne(Campagne,m_NomCampagne) == true) 
           ||
		   // Test si modif campagne si non utilisation d'un nom campagne autre dossier
		   (m_pDoc->m_pNoyauCommande->m_EtatCommande >= CNoyauCommande::m_CommandeEnCours &&
			m_NomCampagne != CampagneEnCours.m_Nom &&
			m_pDoc->m_pNoyauCommande->GetCampagne(Campagne,m_NomCampagne) == true)
		   )	
			// La campagne existe d�j�, trouver un autre nom pour cette nouvelle campagne
			AfxMessageBox("Nom campagne d�j� existant !!!!",MB_ICONEXCLAMATION);

		else
		{	
			StockeNvInfoCommande();

			// Recup n� campagne pour dossier mlc apr�s insertion dans table
			if (m_pDoc->m_pNoyauCommande->GetCampagne(Campagne,m_NomCampagne) == true)
			{
				m_pDoc->m_CodeNoCampagne = Campagne.m_NumCampagne;
				m_pDoc->m_NoCampDossier.Format("%d%s%s",m_pDoc->m_CodeNoCampagne,"-",m_pDoc->m_pNoyauCommande->m_CodeCommandeCommercial);

				// sauve dossier mlc
				PathDossier = m_pDoc->GetPathName();
				m_pDoc->OnSaveDocument(PathDossier);

				// demande envoi automatique des infos plans aux stations-villes
				if (m_CheckMailAuto)
				{
					if (IDYES == AfxMessageBox("Envoi des infos plans � toutes les stations/villes concern�es ?", MB_YESNO | MB_ICONQUESTION))
					{
						// A FAIRE // pr�sentation panneau stations/villes avec adresse email
						// permettra de d�valider ou valider certains envois
						m_pDoc->ValideAllMailStationVille();

						// Puis on fabrique les fichiers � envoyer (format HTML)
						if (m_pDoc->NbStaVilEnvoiMail() > 0)
							if (!m_pDoc->FabriqueFicHTML())
								AfxMessageBox("Attention probl�me cr�ation des fichiers � envoyer !!!",MB_ICONINFORMATION);
							else
								m_pDoc->EnvoiMailStationVille();
					}
					else
					{
						// S�lection des adresses emails stations/villes
						if (DlgSelMail.DoModal() == IDOK)
							// Puis on fabrique les fichiers � envoyer (format HTML)
							if (m_pDoc->NbStaVilEnvoiMail() > 0)
								if (!m_pDoc->FabriqueFicHTML())
									AfxMessageBox("Attention probl�me cr�ation des fichiers � envoyer !!!",MB_ICONINFORMATION);
								else
									m_pDoc->EnvoiMailStationVille();
					
					}
				}
			}
			else
				AfxMessageBox("Pb Campagne non ins�r�e dans table campagne !!!!",MB_ICONEXCLAMATION);	

			CDialog::OnOK();
		}
	}

	else
		AfxMessageBox("Commande non enregistrable, certains champs n'ont pas �t� saisis",MB_ICONEXCLAMATION);


}

void CCommandeDlg::OnCancel() 
{
	// A FAIRE : Annulation de la commande
	CDialog::OnCancel();
}

void CCommandeDlg::OnChkCmdannonceurdirect() 
{
	UpdateData(true);
	if (m_CheckAnnonceurDirect)
	{
		m_ComboAgence.EnableWindow(FALSE);
		m_ComboMandataire.EnableWindow(FALSE);
	}
	else
	{
		m_ComboAgence.EnableWindow(TRUE);
		m_ComboMandataire.EnableWindow(TRUE);
	}
	
}

void CCommandeDlg::OnChkMailauto() 
{
	UpdateData(true);
	if (m_CheckMailAuto)
		m_BtnSelectionMail.EnableWindow(FALSE);
	else
		m_BtnSelectionMail.EnableWindow(TRUE);

}

void CCommandeDlg::OnSelchangeCmbCmdClient() 
{

	// Changement de client >> necessite recalcul cumul mandat si cumul mandat manuel auto
	UpdateData(1);

	// Uniquement si on est en mode CGV Multi-Villes PARIS
	if (!m_pDoc->m_DlgCascade.m_checkcumulmandatmanuel)
	{
		m_pDoc->m_pNoyauCommande->m_CodeCommandeClient = m_pDoc->m_pNoyauCommande->GetCodeCommandeClient(m_ClientSelect);
		m_pDoc->m_DlgCascade.CalculCumulMandat();
	}

	UpdateData(0);
	
}



