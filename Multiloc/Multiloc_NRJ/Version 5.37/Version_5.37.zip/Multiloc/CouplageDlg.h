#if !defined(AFX_COUPLAGEDLG_H__65A9EDF9_0B49_4288_90FF_B6A5913E4E37__INCLUDED_)
#define AFX_COUPLAGEDLG_H__65A9EDF9_0B49_4288_90FF_B6A5913E4E37__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CouplageDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCouplageDlg dialog

class CMultilocDoc;

class CCouplageDlg : public CDialog
{
// Construction
public:
	CCouplageDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCouplageDlg();
	void UpdateCouplageTest();
	void UpdateCouplage();
	bool Activate(CMultilocDoc * pDoc);

	CMultilocDoc * m_pDoc;

// Dialog Data
	//{{AFX_DATA(CCouplageDlg)
	enum { IDD = IDD_COUPLAGE };
	CObj_Gray	m_CadreCoupl;
	CListCtrl	m_ListCouplage;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCouplageDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	//CMultilocDoc * m_pDoc;

	// Generated message map functions
	//{{AFX_MSG(CCouplageDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnEndlabeleditListcouplage(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnItemchangingListcouplage(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnItemchangedListcouplage(NMHDR* pNMHDR, LRESULT* pResult);
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COUPLAGEDLG_H__65A9EDF9_0B49_4288_90FF_B6A5913E4E37__INCLUDED_)
