// CampStationVille.cpp: implementation of the CCampStationVille class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiloc.h"
#include "CampStationVille.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCampStationVille::CCampStationVille()
{

}

CCampStationVille::~CCampStationVille()
{

}

CCampStationVille   & CCampStationVille ::operator=(const CCampStationVille &Source)
{
	m_NumStationVille = Source.m_NumStationVille;
	m_NumCampagne= Source.m_NumCampagne;
	m_NumStation= Source.m_NumStation;
	m_NumVille= Source.m_NumVille;
	m_RemCouplage= Source.m_RemCouplage;

	return(*this);
}

CCampStationVille   & CCampStationVille ::operator=(const CTblCampStationVille &Source)
{
	m_NumStationVille = Source.m_NumStationVille;
	m_NumCampagne= Source.m_NumCampagne;
	m_NumStation= Source.m_NumStation;
	m_NumVille= Source.m_NumVille;
	m_RemCouplage= Source.m_RemCouplage;
	
	return(*this);
}


