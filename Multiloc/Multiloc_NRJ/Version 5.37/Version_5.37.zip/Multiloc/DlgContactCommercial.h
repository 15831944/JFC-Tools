#if !defined(AFX_DLGCONTACTCOMMERCIAL_H__063C1822_E28F_11D5_BA51_00D0592329A7__INCLUDED_)
#define AFX_DLGCONTACTCOMMERCIAL_H__063C1822_E28F_11D5_BA51_00D0592329A7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgContactCommercial.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgContactCommercial dialog

class CDlgContactCommercial : public CDialog
{
// Construction
public:
	CDlgContactCommercial(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgContactCommercial)
	enum { IDD = IDD_COORD_COMMERCIAL };
	CEdit	m_ValiditeDevis;
	CEdit	m_EditNvDateComm;
	CEdit	m_EditAnnuleRemplace;
	CButton	m_chkAnnuleRemplace;
	CEdit	m_TelCommercial;
	CEdit	m_NomCommercial;
	CEdit	m_EmailCommercial;
	CEdit	m_FaxCommercial;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgContactCommercial)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgContactCommercial)
	virtual void OnOK();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCONTACTCOMMERCIAL_H__063C1822_E28F_11D5_BA51_00D0592329A7__INCLUDED_)
