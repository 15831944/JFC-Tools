// Agence.cpp: implementation of the CAgence class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiloc.h"
#include "Agence.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAgence::CAgence()
{
	m_NumAgence=1;	// par d�faut enrgt 1 = "Aucune"
	m_Code= _T("");
	m_Nom= _T("");
	m_Adresse = _T("");
	m_Ville= _T("");
	m_CodePostal= 0;
	m_Contact= _T("");
	m_Tel= _T("");
	m_Fax= _T("");
	m_Email= _T("");
	m_Commentaire=_T("");
}

CAgence::~CAgence()
{

}

CAgence & CAgence::operator=(const CAgence &Source)
{
	m_NumAgence=Source.m_NumAgence;
	m_Code=Source.m_Code;
	m_Nom=Source.m_Nom;
	m_Adresse =Source.m_Adresse;
	m_Ville=Source.m_Ville;
	m_CodePostal=Source.m_CodePostal;
	m_Contact=Source.m_Contact;
	m_Tel=Source.m_Tel;
	m_Fax=Source.m_Fax;
	m_Email=Source.m_Email;
	m_Commentaire=Source.m_Commentaire;
	return(*this);
}

CAgence & CAgence::operator=(const CTblAgence &Source)
{
	m_NumAgence=Source.m_NumAgence;
	m_Code=Source.m_Code;
	m_Nom=Source.m_Nom;
	m_Adresse =Source.m_Adresse;
	m_Ville=Source.m_Ville;
	m_CodePostal=Source.m_CodePostal;
	m_Contact=Source.m_Contact;
	m_Tel=Source.m_Tel;
	m_Fax=Source.m_Fax;
	m_Email=Source.m_Email;
    m_Commentaire=Source.m_Commentaire;
	return(*this);
}

bool CAgence::operator<(const CAgence &Source)
{
	if(m_Nom<Source.m_Nom) return(TRUE);
	else return(FALSE);
}

