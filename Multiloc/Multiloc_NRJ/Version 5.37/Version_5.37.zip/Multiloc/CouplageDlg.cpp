// CouplageDlg.cpp : implementation file
//

#include "stdafx.h"
#include "multiloc.h"
#include "multilocdoc.h"
#include "CouplageDlg.h"

extern CMultilocApp theApp;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCouplageDlg dialog


CCouplageDlg::CCouplageDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCouplageDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCouplageDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	Create(IDD_COUPLAGE);
	m_pDoc=NULL;
}

CCouplageDlg::~CCouplageDlg()
{
	DestroyWindow();		
}

bool CCouplageDlg::Activate(CMultilocDoc * pDoc)
{
	if(pDoc)m_pDoc=pDoc;

	theApp.JoueMusic(5);

	ShowWindow(SW_SHOW);
	//MoveWindow( LPCRECT lpRect,
	UpdateCouplage();


	return true;
}

void CCouplageDlg::UpdateCouplage()
{

	char sbuffer[64];
	LV_ITEM LvItem;
	int iActualItem;
	CString StrStation;
	CString StrVille;
	float Remise;

	m_ListCouplage.DeleteAllItems();
	for(short i=0 ; i<m_pDoc->m_NbStationVille ; i++)
	{
		// Remise
		Remise = m_pDoc->m_Juke[m_pDoc->m_idxStation[i]][m_pDoc->m_idxVille[i]].m_RemiseCouplage;
		LvItem.mask = LVIF_TEXT;
		LvItem.iItem = i;		// item courant
		LvItem.iSubItem = 0;
		sprintf(sbuffer,"%2.2f",Remise);
		LvItem.pszText = sbuffer;
		LvItem.cchTextMax = 5;	// format max remise > 99.99
		m_ListCouplage.SetItem(&LvItem);
		iActualItem = m_ListCouplage.InsertItem(&LvItem);

		// Station
		StrStation = m_pDoc->m_pNoyau->m_TblStation[m_pDoc->m_idxStation[i]].m_Libelle;
		LvItem.mask = LVIF_TEXT;
		LvItem.iItem = iActualItem;				// new item
		LvItem.iSubItem = 1;
		sprintf(sbuffer,StrStation);
		LvItem.pszText = sbuffer;
		LvItem.cchTextMax = strlen(sbuffer);
		m_ListCouplage.SetItem(&LvItem);		

		// Ville
		StrVille = m_pDoc->m_pNoyau->m_pTblVille[m_pDoc->m_idxStation[i]][m_pDoc->m_idxVille[i]].m_Libelle;
		LvItem.mask = LVIF_TEXT;
		LvItem.iItem = iActualItem;		// item courant
		LvItem.iSubItem = 2;
		sprintf(sbuffer,StrVille);
		LvItem.pszText = sbuffer;
		LvItem.cchTextMax = strlen(sbuffer);
		m_ListCouplage.SetItem(&LvItem);


	}
	UpdateData(false);

}

void CCouplageDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCouplageDlg)
	DDX_Control(pDX, IDC_CADRECOUPL1, m_CadreCoupl);
	DDX_Control(pDX, IDC_LISTCOUPLAGE, m_ListCouplage);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCouplageDlg, CDialog)
	//{{AFX_MSG_MAP(CCouplageDlg)
	ON_NOTIFY(LVN_ENDLABELEDIT, IDC_LISTCOUPLAGE, OnEndlabeleditListcouplage)
	ON_NOTIFY(LVN_ITEMCHANGING, IDC_LISTCOUPLAGE, OnItemchangingListcouplage)
	ON_NOTIFY(HDN_ITEMCHANGED, IDC_LISTCOUPLAGE, OnItemchangedListcouplage)
	ON_NOTIFY(HDN_ITEMCHANGING, IDC_LISTCOUPLAGE, OnItemchangingListcouplage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCouplageDlg message handlers

BOOL CCouplageDlg::OnInitDialog() 
{

	CString StrItemCol1 = _T("Station");
	CString StrItemCol2 = _T("Ville");
	CString StrItemCol3 = _T("Remise en %");
	CRect RectList;
	long LgListCol;

	CDialog::OnInitDialog();

	// Remplissage des entetes liste couplages (station/ville/% remise)
	m_ListCouplage.GetClientRect(&RectList);
	LgListCol = (long)((RectList.right - RectList.left)/7);

	m_ListCouplage.InsertColumn(0,StrItemCol3,LVCFMT_LEFT,2*LgListCol,0);
	m_ListCouplage.InsertColumn(1,StrItemCol1,LVCFMT_LEFT,2*LgListCol,1);
	m_ListCouplage.InsertColumn(2,StrItemCol2,LVCFMT_LEFT,3*LgListCol,2);

	// Ordonnancement des colonnes	
	INT ordre[3];
	ordre[0] = 1;
	ordre[1] = 2;
	ordre[2] = 0;
	BOOL succes = m_ListCouplage.SetColumnOrderArray(3,ordre);

	// Tri vertical sur la colonne Station
	//m_ListCouplage.SortItems();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCouplageDlg::OnEndlabeleditListcouplage(NMHDR* pNMHDR, LRESULT* pResult) 
{
	float Remise;
	CString TxtRem;

	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)pNMHDR;

	*pResult = 0;

	if (pDispInfo != NULL)
	{
		TxtRem =  pDispInfo->item.pszText;
		Remise = atof(TxtRem);

		if (TxtRem != "" && TxtRem != "0" && TxtRem != "0.0" && TxtRem != "0,0" && Remise == 0)
		{
			AfxMessageBox("Ici on attend une valeur type 5,2");
			*pResult = 0;
		}
		else if (Remise >=0.0 && Remise <100.0)
		{
			//m_pDoc->m_Juke[m_pDoc->m_idxStation[pDispInfo->item.iItem]][m_pDoc->m_idxVille[pDispInfo->item.iItem]].m_RemiseCouplage = Remise;
			*pResult = 1;
		}
		else
		{
			AfxMessageBox("Attention valeur maximum 99.99");
			*pResult = 0;
		}
	}

}


void CCouplageDlg::OnItemchangingListcouplage(NMHDR* pNMHDR, LRESULT* pResult) 
{
	

	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	/*
	if (pNMListView != NULL)
	{
		for (short i=0 ; i<m_pDoc->m_NbStationVille ; i++)
		{
			// Remise
			Txt.Format("%2.2f",m_pDoc->m_Juke[m_pDoc->m_idxStation[i]][m_pDoc->m_idxVille[i]].m_RemiseCouplage);
			m_ListCouplage.SetItemText(i,0,Txt);
		}	
	}	
	*/

	*pResult = 0;
}

void CCouplageDlg::OnItemchangedListcouplage(NMHDR* pNMHDR, LRESULT* pResult) 
{
	HD_NOTIFY *phdn = (HD_NOTIFY *) pNMHDR;
	// TODO: Add your control notification handler code here
	
	*pResult = 0;
}

void CCouplageDlg::OnOK() 
{

	CString TxtRem;
	float Remise;
	bool RemiseOk = true;
	float MaxRemiseRegion = 0.0f;

	if (RemiseOk)
	{	
		// Validation de toutes les remises
		for (short i=0 ; i<m_pDoc->m_NbStationVille ; i++)
		{
			// Remise
			TxtRem = m_ListCouplage.GetItemText(i,0);
			Remise = atof(TxtRem);
			m_pDoc->m_Juke[m_pDoc->m_idxStation[i]][m_pDoc->m_idxVille[i]].m_RemiseCouplage = Remise;
		}	

		// Recalcul avec les nouvelles remises
		m_pDoc->CalculPlan();
		m_pDoc->UpdateAllViews(NULL,1);

		CDialog::OnOK();
	}
	else
		AfxMessageBox ("Remise couplage trop importante, total remise autoris� d�pass�");

}
