// Campagne.h: interface for the CCampagne class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CAMPAGNE_H__838AE4C1_4513_11D4_8658_0080C708A895__INCLUDED_)
#define AFX_CAMPAGNE_H__838AE4C1_4513_11D4_8658_0080C708A895__INCLUDED_


#include "TblCamp.h"
#include <afxtempl.h>		// MFC template library

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCampagne  
{
public:
	


	CString	m_Nom;
	COleDateTime	m_DateCreation;
	long	m_NoVersion;
	CString	m_FicMultiloc;
	CString m_PathFicMlc;
	COleDateTime	m_DateDebut;
	COleDateTime	m_DateFin;
	
	long	m_NbSpots;
	CString	m_EtatCommande;
	CString	m_CodeAchat;
	COleDateTime	m_DateModification;
	long	m_NumAgence;
	long	m_NumAnnonceur;
	long	m_NumCampagne;
	long	m_NumClient;
	long	m_NumCommercial;
	long	m_NumMandataire;
	long	m_NumRegion;
	long	m_NumCodeSecodip;

	// Info tarification (ordre de la cascade)
	long	m_BudgetGlobal;

	// Calcul du net
	float	m_VolumeMessage;
	float	m_RemiseFinanciereCoeffDegressif;
	float	m_RemiseNouveauClient;
	float	m_RemiseRenouvellement;
	float	m_RemisePrimeAnticipation;
	float	m_RemisePrimeMultiVilles;
	float   m_RemiseEngagementAbonnement;  // (pour mode Multivilles R�gion) 
	float	m_PrctTotalAbattement;
	float	m_PrctCoeffTotal;
	float	m_TauxNegociation;
	double	m_TotalCABrut;
	double	m_TotalCANet;
	
	// Taux de r�gie
	float	m_TauxRegie;

	// Calcul du net net
	float	m_RemiseDeMandat;
	double	m_TotalCANetNet;

	// Calcul frais divers
	BOOL	m_FraisAnnonceAuto;
	double	m_TotalFraisAnnonceNonAuto;
	double	m_FraisAnnonceReel;
	double	m_FraisDuplication;

	// Facturation
	BOOL m_Facturee;
	COleDateTime	m_DateFacturation;

	// Informations compl�mentaires
	CString	m_TxtComplement;
	

	CCampagne();
	virtual ~CCampagne();

	CCampagne & operator=(const CCampagne &Source);
	CCampagne & operator=(const CTblCamp &Source);
	bool operator<(const CCampagne &Source);


};

typedef CArray<CCampagne,CCampagne&> CCampagneArray;

#endif // !defined(AFX_CAMPAGNE_H__838AE4C1_4513_11D4_8658_0080C708A895__INCLUDED_)
