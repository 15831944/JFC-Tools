#if !defined(AFX_DLGINITPLANRADIO_H__DDA139D9_FD91_4679_A230_94B45A985611__INCLUDED_)
#define AFX_DLGINITPLANRADIO_H__DDA139D9_FD91_4679_A230_94B45A985611__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgInitPlanRadio.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgInitPlanRadio dialog

class CDlgInitPlanRadio : public CDialog
{
// Construction
public:
	CDlgInitPlanRadio(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgInitPlanRadio)
	enum { IDD = IDD_INITPLAN };
	CButton	m_BtnTypeContratFidelite;
	CButton	m_CtrlPlanStandard;
	CObj_Gray	m_Cadre1;
	int	m_PlanStandard;
	BOOL	m_ContratFidelite;
	int		m_TypeContratFidelite;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgInitPlanRadio)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgInitPlanRadio)
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnPaint();
	virtual BOOL OnInitDialog();
	afx_msg void OnChkContratfidelite();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGINITPLANRADIO_H__DDA139D9_FD91_4679_A230_94B45A985611__INCLUDED_)
