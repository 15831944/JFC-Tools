// Campagne.cpp: implementation of the CCampagne class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiloc.h"
#include "Campagne.h"
#include "NoyauCommande.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCampagne::CCampagne()
{
	m_NumCampagne=0;
	m_Nom = _T("");
	m_NumCommercial=0;
	m_NumClient=0;
    m_NumAnnonceur=0;
    m_NumAgence=1;
	m_NumMandataire=1;
	m_DateCreation=COleDateTime::GetCurrentTime();
	m_NoVersion=1;
	m_FicMultiloc=_T("");
	m_PathFicMlc=_T("");
	m_DateDebut=COleDateTime::GetCurrentTime();
	m_DateFin=COleDateTime::GetCurrentTime();
	
	m_NbSpots=0;
	m_EtatCommande = G_TxtCommandeAucune;
	m_CodeAchat=_T("");
	m_NumRegion=1;
	m_NumCodeSecodip = 1;
	//m_DateAnnulation=

	// Info tarification
	m_BudgetGlobal=0;

	// Calcul du net
	m_VolumeMessage = 0.0f;
	m_RemiseFinanciereCoeffDegressif = 0.0f;
	m_RemiseNouveauClient = 0.0f;
	m_RemiseRenouvellement = 0.0f;
	m_RemisePrimeAnticipation = 0.0f;
	m_RemisePrimeMultiVilles = 0.0f;
	m_RemiseEngagementAbonnement = 0.0f; 
	m_PrctTotalAbattement = 0.0f;
	m_PrctCoeffTotal = 0.0f;
	m_TauxNegociation = 0.0f;
	m_TotalCABrut = 0.0;
	m_TotalCANet = 0.0;
	
	// Taux de r�gie
	m_TauxRegie = 0.0f;

	// Calcul du net net
	m_RemiseDeMandat = 0.0f;
	m_TotalCANetNet = 0.0;

	// Calcul frais divers
	m_FraisAnnonceAuto = true;
	m_TotalFraisAnnonceNonAuto = 0.0;
	m_FraisAnnonceReel = 0.0;
	m_FraisDuplication= 0;

	// Facturation
	m_DateFacturation = (DATE)0;
	m_Facturee = FALSE;

	// Infos compl�mentaires
	m_TxtComplement = _T("");


}

CCampagne::~CCampagne()
{

}

CCampagne & CCampagne::operator=(const CCampagne &Source)
{
	m_NumCampagne=Source.m_NumCampagne;
	m_Nom=Source.m_Nom;
	m_NumCommercial=Source.m_NumCommercial;
	m_NumClient=Source.m_NumClient;
	m_NumAnnonceur=Source.m_NumAnnonceur;
	m_NumAgence=Source.m_NumAgence;
    m_NumMandataire=Source.m_NumMandataire;
	m_DateCreation=Source.m_DateCreation;
	m_NoVersion=Source.m_NoVersion;
	m_FicMultiloc=Source.m_FicMultiloc;
	m_PathFicMlc=Source.m_PathFicMlc;
	m_DateDebut=Source.m_DateDebut;
	m_DateFin=Source.m_DateFin;
	m_BudgetGlobal=Source.m_BudgetGlobal;
	m_NbSpots=Source.m_NbSpots;
	m_EtatCommande=Source.m_EtatCommande;
	m_CodeAchat=Source.m_CodeAchat;
	m_NumRegion=Source.m_NumRegion;
	m_NumCodeSecodip =Source.m_NumCodeSecodip;
	m_DateModification=Source.m_DateModification;

	// Net
	m_VolumeMessage = Source.m_VolumeMessage;
	m_RemiseFinanciereCoeffDegressif = Source.m_RemiseFinanciereCoeffDegressif;
	m_RemiseNouveauClient = Source.m_RemiseNouveauClient;
	m_RemiseRenouvellement= Source.m_RemiseRenouvellement;
	m_RemisePrimeAnticipation= Source.m_RemisePrimeAnticipation;
	m_RemisePrimeMultiVilles = Source.m_RemisePrimeMultiVilles;
	m_RemiseEngagementAbonnement = Source.m_RemiseEngagementAbonnement; 
	m_PrctTotalAbattement = Source.m_PrctTotalAbattement ;
	m_PrctCoeffTotal = Source.m_PrctCoeffTotal;
	m_TauxNegociation = Source.m_TauxNegociation;
	m_TotalCABrut = Source.m_TotalCABrut;
	m_TotalCANet = Source.m_TotalCANet;
	
	// Taux de r�gie
	m_TauxRegie = Source.m_TauxRegie;

	// Net net
	m_RemiseDeMandat = Source.m_RemiseDeMandat;
	m_TotalCANetNet = Source.m_TotalCANetNet;

	// Frais divers
	m_FraisAnnonceAuto = Source.m_FraisAnnonceAuto;
	m_TotalFraisAnnonceNonAuto = Source.m_TotalFraisAnnonceNonAuto;
	m_FraisAnnonceReel = Source.m_FraisAnnonceReel;
	m_FraisDuplication= Source.m_FraisDuplication;

	// Facturation
	m_Facturee = Source.m_Facturee;
	m_DateFacturation = Source.m_DateFacturation;

	// Informations compl�mentaires
	m_TxtComplement = Source.m_TxtComplement;
	

	return(*this);
}

CCampagne & CCampagne::operator=(const CTblCamp &Source)
{
	m_NumCampagne=Source.m_NumCampagne;
	m_Nom=Source.m_Nom;
	m_NumCommercial=Source.m_NumCommercial;
	m_NumClient=Source.m_NumClient;
	m_NumAnnonceur=Source.m_NumAnnonceur;
	m_NumAgence=Source.m_NumAgence;
    m_NumMandataire=Source.m_NumMandataire;
	m_DateCreation=Source.m_DateCreation;
	m_NoVersion=Source.m_NoVersion;
	m_FicMultiloc=Source.m_FicMultiloc;
	m_PathFicMlc=Source.m_PathFicMlc;
	m_DateDebut=Source.m_DateDebut;
	m_DateFin=Source.m_DateFin;
	m_BudgetGlobal=Source.m_BudgetGlobal;
	m_NbSpots=Source.m_NbSpots;
	m_EtatCommande=Source.m_EtatCommande;
	m_CodeAchat=Source.m_CodeAchat;
	m_NumRegion=Source.m_NumRegion;
	m_NumCodeSecodip=Source.m_NumCodeSecodip;
	m_DateModification=Source.m_DateModification;

	// Net
	m_VolumeMessage = Source.m_VolumeMessage;
	m_RemiseFinanciereCoeffDegressif = Source.m_RemiseFinanciereCoeffDegressif;
	m_RemiseNouveauClient = Source.m_RemiseNouveauClient;
	m_RemiseRenouvellement= Source.m_RemiseRenouvellement;
	m_RemisePrimeAnticipation= Source.m_RemisePrimeAnticipation;
	m_RemisePrimeMultiVilles = Source.m_RemisePrimeMultiVilles;
	m_RemiseEngagementAbonnement = Source.m_RemiseEngagementAbonnement; 
	m_PrctTotalAbattement = Source.m_PrctTotalAbattement ;
	m_PrctCoeffTotal = Source.m_PrctCoeffTotal;
	m_TauxNegociation = Source.m_TauxNegociation;
	m_TotalCABrut = Source.m_TotalCABrut;
	m_TotalCANet = Source.m_TotalCANet;
	
	// Taux de r�gie
	m_TauxRegie = Source.m_TauxRegie;

	// Net net
	m_RemiseDeMandat = Source.m_RemiseDeMandat;
	m_TotalCANetNet = Source.m_TotalCANetNet;

	// Frais divers
	m_FraisAnnonceAuto = Source.m_FraisAnnonceAuto;
	m_TotalFraisAnnonceNonAuto = Source.m_TotalFraisAnnonceNonAuto;
	m_FraisAnnonceReel = Source.m_FraisAnnonceReel;
	m_FraisDuplication= Source.m_FraisDuplication;

	// Facturation
	m_Facturee = Source.m_Facturee;
	m_DateFacturation = Source.m_DateFacturation;

	// Informations compl�mentaires
	m_TxtComplement = Source.m_TxtComplement;

	return(*this);
}

bool CCampagne::operator<(const CCampagne &Source)
{
	// ici on classe les campagnes selon leur code unique
	if(m_NumCampagne<Source.m_NumCampagne) return(TRUE);
	else return(FALSE);
}
