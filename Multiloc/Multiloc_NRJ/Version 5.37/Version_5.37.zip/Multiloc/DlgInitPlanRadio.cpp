// DlgInitPlanRadio.cpp : implementation file
//

#include "stdafx.h"
#include "multiloc.h"
#include "DlgInitPlanRadio.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgInitPlanRadio dialog


CDlgInitPlanRadio::CDlgInitPlanRadio(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgInitPlanRadio::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgInitPlanRadio)
	m_PlanStandard = 0;
	m_ContratFidelite = FALSE;
	m_TypeContratFidelite = -1;
	//}}AFX_DATA_INIT
}


void CDlgInitPlanRadio::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgInitPlanRadio)
	DDX_Control(pDX, IDC_CF_NONPLANIF, m_BtnTypeContratFidelite);
	DDX_Control(pDX, IDC_PLAN_STANDARD, m_CtrlPlanStandard);
	DDX_Control(pDX, IDC_CADRE1, m_Cadre1);
	DDX_Radio(pDX, IDC_PLAN_STANDARD, m_PlanStandard);
	DDX_Check(pDX, IDC_CHK_CONTRATFIDELITE, m_ContratFidelite);
	DDX_Radio(pDX, IDC_CF_NONPLANIF, m_TypeContratFidelite);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgInitPlanRadio, CDialog)
	//{{AFX_MSG_MAP(CDlgInitPlanRadio)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_CHK_CONTRATFIDELITE, OnChkContratfidelite)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgInitPlanRadio message handlers

void CDlgInitPlanRadio::OnOK() 
{
	// R�cup�re valeur Type planification
	UpdateData(true);
	
	
	CDialog::OnOK();
}

void CDlgInitPlanRadio::OnCancel() 
{
	CDialog::OnCancel();
}

void CDlgInitPlanRadio::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CBrush b;
	CRect r;

	GetClientRect(&r);
	b.CreateSolidBrush(RGB(0,92,141));
	dc.FillRect(r,&b);
	
	/* Couleur JFC
	#define RGB_BleuJFC RGB(0,92,141)
	*/
}

BOOL CDlgInitPlanRadio::OnInitDialog() 
{
	CDialog::OnInitDialog();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgInitPlanRadio::OnChkContratfidelite() 
{
	UpdateData(true);

	if (m_ContratFidelite == TRUE)
	{
		// � partir de 2005, ne reste plus que la remise de 10%
		m_TypeContratFidelite = 1;		
	}
	else
	{
		m_TypeContratFidelite = -1;
	}
	
	UpdateData(false);
}
