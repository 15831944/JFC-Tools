// DlgComposer.cpp : implementation file
//

#include "stdafx.h"
#include "multiloc.h"
#include "DlgComposer.h"
#include "DlgSelection.h"
extern CMultilocApp theApp;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgComposer dialog


CDlgComposer::CDlgComposer(CMultilocDoc *pDoc,CWnd* pParent /*=NULL*/)
	: CDialog(CDlgComposer::IDD, pParent)
{
	m_pDoc=pDoc;
	m_ObjGrille.m_pDoc = pDoc;
	m_NrSymbolActif=0;

	//{{AFX_DATA_INIT(CDlgComposer)
	m_txt = _T("");
	//}}AFX_DATA_INIT
}



void CDlgComposer::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgComposer)
	DDX_Control(pDX, IDC_COMBOBOXEX_MELODIE, m_ComboMelodie);
	DDX_Control(pDX, IDC_COMBOBOXEX1, m_ComboFormat);
	DDX_Control(pDX, IDC_EDIT1, m_EditNbSpot);
	DDX_Control(pDX, IDC_COLONE, m_ObjColone);
	DDX_Control(pDX, IDC_SCROLLBAR2, m_VScroll);
	DDX_Control(pDX, IDC_GRILLE, m_ObjGrille);
	DDX_Text(pDX, IDC_EDIT_MELODIE, m_txt);
	DDV_MaxChars(pDX, m_txt, 10);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgComposer, CDialog)
	//{{AFX_MSG_MAP(CDlgComposer)
	ON_WM_CANCELMODE()
	ON_WM_VSCROLL()
	ON_BN_CLICKED(IDC_ADD, OnAddMelodie)
	ON_BN_CLICKED(IDC_SUB, OnDeleteMelodie)
	ON_CBN_SELCHANGE(IDC_COMBOBOXEX1, OnSelchangeComboboFormat)
	ON_CBN_SELCHANGE(IDC_COMBOBOXEX_MELODIE, OnComboboxMelodieSelchange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgComposer message handlers

BOOL CDlgComposer::OnInitDialog() 
{
	m_fInit=true;
	theApp.JoueMusic(7);
	CDialog::OnInitDialog();
	m_Melodie.Copy(m_pDoc->m_Melodie);

	if (m_pDoc->m_ModeTarif == 0)
		// Initialisation de la grille mode tranche horaire
		m_ObjGrille.Initialise(STYLE_GRIL_PIGE,7,m_pDoc->m_NbHoraire,16,16,0,0);
	else
		// Initialisation de la grille mode floating
		m_ObjGrille.Initialise(STYLE_GRIL_PIGE,7,m_pDoc->m_NbFormat,16,16,0,0);

	m_ObjGrille.InitScrollBar(NULL,&m_VScroll);
	m_ObjGrille.m_pEditNbSpot=&m_EditNbSpot;
	
	// Init de la combo des m�lodies
	if(m_Melodie.GetSize()>0)m_NrSymbolActif=0;
	else m_NrSymbolActif=-1;
	m_ComboMelodie.SetImageList(&m_pDoc->m_ImageMelodie);
	RefreshCombo();

	// Initialise le bloc colonne de droite (tranche horaire ou format)
	m_ObjColone.InitModeColonne(m_pDoc->m_ModeTarif,m_pDoc->m_pNoyau->m_TblFormat);

	if (m_pDoc->m_ModeTarif == 0)
		// mode classique colonne = tranches horaires
		m_ObjColone.Initialise(STYLE_COL_DEFAUT,m_pDoc->m_NbHoraire,16,0);
	else
		// mode classique colonne = tranches horaires
		m_ObjColone.Initialise(STYLE_COL_DEFAUT,m_pDoc->m_NbFormat,16,0);

	if (m_pDoc->m_ModeTarif == 0)
	{
		// en mode classique >> init de la combo format
		m_ComboFormat.EnableWindow(TRUE); 
		m_ComboFormat.SetImageList(&m_pDoc->m_ImageFormat);
		COMBOBOXEXITEM cbi;
		memset(&cbi,0,sizeof(cbi));
		cbi.mask = CBEIF_IMAGE | CBEIF_OVERLAY | CBEIF_SELECTEDIMAGE | CBEIF_TEXT;
		for(int i=0;i<m_pDoc->m_Combin.GetSize();i++){
			cbi.iItem = i;
			cbi.iImage = m_pDoc->m_Combin[i].m_NrSymbol;
			cbi.iSelectedImage = m_pDoc->m_Combin[i].m_NrSymbol;
			cbi.iOverlay = m_pDoc->m_Combin[i].m_NrSymbol;

			cbi.pszText = (LPTSTR)(LPCTSTR)m_pDoc->m_Combin[i].m_txt;
			cbi.cchTextMax = m_pDoc->m_Combin[i].m_txt.GetLength();
			m_ComboFormat.InsertItem(&cbi);
		}
		m_ComboFormat.SetCurSel(0);
	}
	else
	{
		// pas de coix format en mode floating
		m_ComboFormat.EnableWindow(FALSE); 
	}

	m_ObjGrille.SetSymbolActif(0);
	m_ObjGrille.SetTabIcon((void*)&m_pDoc->m_hIconF);
	if(m_Melodie.GetSize()==0)SendMessage(WM_COMMAND,IDC_ADD);
	m_ObjGrille.UpdateNbSpot();
	m_fInit=false;
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgComposer::OnCancelMode() 
{
	CDialog::OnCancelMode();
}

void CDlgComposer::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	short pos=m_ObjGrille.MAJPosScrollV(nSBCode,nPos,1); 	
	m_ObjColone.SetPosition(pos,1);
	CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}


void CDlgComposer::OnAddMelodie() 
{
	UpdateData(1);
	if(m_NrSymbolActif>=0)m_Melodie[m_NrSymbolActif].m_txt=m_txt;
	
	CDlgSelection Dlg;
	Dlg.m_pIL=&m_pDoc->m_ImageMelodie;
	int i;
	for(i=0;i<Dlg.m_pIL->GetImageCount();i++)Dlg.m_Use.Add(0);
	for(i=0;i<m_Melodie.GetSize();i++)Dlg.m_Use[m_Melodie[i].m_NrSymbol]++;
	if(Dlg.DoModal()!=IDOK){
		if(m_fInit)EndDialog(IDCANCEL);
		else return;
	}


	SMelodie Melodie;
	Melodie.m_NrSymbol=Dlg.m_Sel;
	short idx=m_Melodie.Add(Melodie);
	m_ObjGrille.m_pSpotJH=m_Melodie[idx].m_SpotJH;

	m_ObjGrille.InvalidateRect(NULL);
	m_NrSymbolActif=idx;
	RefreshCombo();
}

void CDlgComposer::OnDeleteMelodie() 
{
	if(m_NrSymbolActif<0)return;
	if(m_NrSymbolActif>=m_Melodie.GetSize())return;
	m_Melodie.RemoveAt(m_NrSymbolActif);
	if(m_Melodie.GetSize()>0)m_NrSymbolActif=0;
	else m_NrSymbolActif=-1;
	RefreshCombo();
}


void CDlgComposer::OnSelchangeComboboFormat() 
{
	int FormatActif=m_ComboFormat.GetCurSel();
	int NrSymbolActif=m_pDoc->m_Combin[FormatActif].m_NrSymbol;
	m_ObjGrille.SetSymbolActif(NrSymbolActif);
	
}

void CDlgComposer::RefreshCombo(){
	COMBOBOXEXITEM cbi;
	memset(&cbi,0,sizeof(cbi));
	cbi.mask = CBEIF_IMAGE | CBEIF_OVERLAY |CBEIF_SELECTEDIMAGE;//| CBEIF_INDENT ;
	m_ComboMelodie.ResetContent();
	for(int i=0;i<m_Melodie.GetSize();i++){
		cbi.iItem = i;
		cbi.iImage = m_Melodie[i].m_NrSymbol;
		cbi.iSelectedImage = m_Melodie[i].m_NrSymbol;
		cbi.iOverlay = m_Melodie[i].m_NrSymbol;
		m_ComboMelodie.InsertItem(&cbi);
	}
	if(m_NrSymbolActif>=0){
		m_ComboMelodie.SetCurSel(m_NrSymbolActif);
		m_ObjGrille.m_pSpotJH=m_Melodie[m_NrSymbolActif].m_SpotJH;
		m_ObjGrille.InvalidateRect(NULL);
		m_txt=m_Melodie[m_NrSymbolActif].m_txt;
	}
	else {
		m_ObjGrille.m_pSpotJH=NULL;
		m_ObjGrille.InvalidateRect(NULL);
		m_txt="";
	}
	UpdateData(0);
}


void CDlgComposer::OnComboboxMelodieSelchange() 
{
	UpdateData(1);
	m_Melodie[m_NrSymbolActif].m_txt=m_txt;
	m_NrSymbolActif=m_ComboMelodie.GetCurSel();	
	m_ObjGrille.m_pSpotJH=m_Melodie[m_NrSymbolActif].m_SpotJH;

	m_ObjGrille.InvalidateRect(NULL);
	m_txt=m_Melodie[m_NrSymbolActif].m_txt;
	UpdateData(0);
}

void CDlgComposer::OnOK() 
{
	UpdateData(1);
	if(m_NrSymbolActif>=0)m_Melodie[m_NrSymbolActif].m_txt=m_txt;
	m_pDoc->m_Melodie.Copy(m_Melodie);
	
	CDialog::OnOK();
}
