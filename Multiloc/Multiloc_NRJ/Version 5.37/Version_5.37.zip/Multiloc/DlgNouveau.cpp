// DlgNouveau.cpp : implementation file
//

#include "stdafx.h"
#include "multiloc.h"
#include "DlgNouveau.h"
//#include "DlgCalendrier.h"
extern CMultilocApp theApp;


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgNouveau dialog


CDlgNouveau::CDlgNouveau(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgNouveau::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgNouveau)
	m_CibleSelect = _T("");
	m_Duree = 0;
	m_DateDebut = COleDateTime::GetCurrentTime();
	m_DateFin = COleDateTime::GetCurrentTime();
	m_ClientSelect = _T("");
	m_CommercialSelect = _T("");
	m_NomCommercialODP = _T("");
	m_Enseigne = _T("");
	m_ChkClientNRL = FALSE;
	//}}AFX_DATA_INIT
	m_pNoyau=new CNoyau(theApp.m_DataBasePath);
	m_pNoyauCommande=new CNoyauCommande(theApp.m_DataBaseCommandePath);

}

CDlgNouveau::~CDlgNouveau()
{
	if(m_pNoyau) delete m_pNoyau;
	if(m_pNoyauCommande) delete m_pNoyauCommande;
}

void CDlgNouveau::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgNouveau)
	DDX_Control(pDX, IDC_CBNOMCLIENT, m_ComboClient);
	DDX_Control(pDX, IDC_CBCOMMERCIAL, m_ComboCommercial);
	DDX_Control(pDX, IDC_CBCIBLE, m_ComboCible);
	DDX_CBString(pDX, IDC_CBCIBLE, m_CibleSelect);
	DDX_Text(pDX, IDC_EDIT_DUREE, m_Duree);
	DDX_DateTimeCtrl(pDX, IDC_DATE_DEBUT, m_DateDebut);
	DDX_DateTimeCtrl(pDX, IDC_DATE_FIN, m_DateFin);
	DDX_CBString(pDX, IDC_CBNOMCLIENT, m_ClientSelect);
	DDX_CBString(pDX, IDC_CBCOMMERCIAL, m_CommercialSelect);
	DDX_Text(pDX, IDC_ODP_NOMCOMMERCIAL, m_NomCommercialODP);
	DDX_Text(pDX, IDC_ENSEIGNE, m_Enseigne);
	DDX_Check(pDX, IDC_CHK_CLIENTNRL, m_ChkClientNRL);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgNouveau, CDialog)
	//{{AFX_MSG_MAP(CDlgNouveau)
	ON_WM_CANCELMODE()
	ON_EN_CHANGE(IDC_EDIT_DUREE, OnChangeEditDuree)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_DUREE, OnDeltaposSpinDuree)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_DATE_DEBUT, OnDateDebutChange)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_DATE_FIN, OnDateFinChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgNouveau message handlers

BOOL CDlgNouveau::OnInitDialog() 
{
	short nr;

	theApp.JoueMusic(7);
	CDialog::OnInitDialog();
	
	// Init des cibles
	for(nr=0;nr<m_pNoyau->m_TblCible.GetSize();nr++)
		m_ComboCible.AddString(m_pNoyau->m_TblCible[nr].m_Libelle);

	m_CibleSelect=m_pNoyau->m_TblCible[0].m_Libelle;

	// Affichage date courante (dur�e par d�faut 28 jours)
	m_DateDebut=COleDateTime::GetCurrentTime();
	m_Duree=28;
	m_DateFin=m_DateDebut+COleDateTimeSpan(m_Duree-1,0,0,0);

	// Init des clients possibles
	for(nr=0;nr<m_pNoyauCommande->m_TblClient.GetSize();nr++)
	{
		m_ComboClient.AddString(m_pNoyauCommande->m_TblClient[nr].m_Nom);
	}
	if (m_pNoyauCommande->m_TblClient.GetSize())
		m_ClientSelect= m_pNoyauCommande->m_TblClient[0].m_Nom;

	// Init des commerciaux possibles
	for(nr=0;nr<m_pNoyauCommande->m_TblCommercial.GetSize();nr++)
	{
		m_ComboCommercial.AddString(m_pNoyauCommande->m_TblCommercial[nr].m_Nom);
	}
	if (m_pNoyauCommande->m_TblCommercial.GetSize())
		m_CommercialSelect= m_pNoyauCommande->m_TblCommercial[0].m_Nom;

	// Nom du commercial ODP  (par d�faut celui dans base registre)
	m_NomCommercialODP = theApp.m_NomCommercial;

	// Type de client (non NRL par d�faut)
	m_ChkClientNRL = FALSE;

	// Enseigne (vide par d�faut)
	m_Enseigne = "";

	// Mise � jour
	UpdateData(0);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgNouveau::OnCancelMode() 
{
	CDialog::OnCancelMode();
	
	// TODO: Add your message handler code here
	
}

void CDlgNouveau::OnOK() 
{
	short nr;

	// on r�cup�re et on test les valeurs
	UpdateData(1);
	if(m_CibleSelect.IsEmpty()){
		MessageBox("La s�lection de la cible est invalide","Message",MB_ICONWARNING | MB_OK);
		return;
	}
	for(nr=0;nr<m_pNoyau->m_TblCible.GetSize();nr++)
		if(m_pNoyau->m_TblCible[nr].m_Libelle==m_CibleSelect)break;
	m_NrCibleSelect=nr;

	// v�rification de la dur�e
	if(m_Duree<1 || m_Duree>366){
		MessageBox("La dur�e du plan est invalide","Message",MB_ICONWARNING | MB_OK);
		return;
	}

	// v�rification de la date de d�but
	COleDateTime Minimum(2000, 1, 1, 0, 0, 0);
	if (m_DateDebut < Minimum)
	{
		if (IDNO == AfxMessageBox("Attention, cette version du logiciel utilise les CGV 2000.\nVoulez-vous continuer ?", MB_YESNO | MB_ICONQUESTION))
			return;
	}


	// Verification au moins 1 client existant et s�lectionnable
	if (m_pNoyauCommande->m_TblClient.GetSize() == 0)
	{
		MessageBox("Attention, vous devez au moins avoir 1 client dans votre base de donn�e multicom.mdb","Message",MB_ICONWARNING | MB_OK);
		return;
	}

	// Et vous devez au moins s�lectionner 1 client
	if (m_ClientSelect.IsEmpty())
	{
		MessageBox("La s�lection d'un client est obligatoire","Message",MB_ICONWARNING | MB_OK);
		return;
	}

	if(m_CommercialSelect.IsEmpty())   //  || m_ClientSelect.IsEmpty() )
	{
		// commercial non s�lectionn�
		if (IDNO == AfxMessageBox("Attention, commercial non d�fini.\nVous pourrez les d�finir plus tard.\nVoulez-vous continuer ?", MB_YESNO | MB_ICONQUESTION))
			return;
	}
	
	// sauve index nr unique du client et du commercial s�lectionn�e
	if (!m_ClientSelect.IsEmpty())
	{
		for(nr=0;nr<m_pNoyauCommande->m_TblClient.GetSize();nr++)
			if(m_pNoyauCommande->m_TblClient[nr].m_Nom==m_ClientSelect)
				break;
		m_CodeClientSelect=m_pNoyauCommande->m_TblClient[nr].m_Code;
		m_pNoyauCommande->m_CodeCommandeClient = m_CodeClientSelect;
	}
		
	if (!m_CommercialSelect.IsEmpty())
	{
		for(nr=0;nr<m_pNoyauCommande->m_TblCommercial.GetSize();nr++)
			if(m_pNoyauCommande->m_TblCommercial[nr].m_Nom==m_CommercialSelect)
				break;
		m_CodeCommercialSelect=m_pNoyauCommande->m_TblCommercial[nr].m_Code;
		m_pNoyauCommande->m_CodeCommandeCommercial = m_CodeCommercialSelect;
	}

	if (m_ChkClientNRL == TRUE && m_Enseigne == "")
	{	
		// Si Client NRL, on doit rentrer l'enseigne)
		AfxMessageBox("Attention vous devez entrer l'enseigne pour un Client NRL",MB_ICONEXCLAMATION);
		return;
	}

	m_NomCommercialODP.TrimLeft();
	if (m_NomCommercialODP.GetLength() > 4 )
	{
		// Recup le nom courant commercial
		theApp.m_NomCommercial = m_NomCommercialODP;
		EndDialog(IDOK);
	}	
	else
	{
		// Nom pour ODP au moins 4 caract�res
		AfxMessageBox("Attention vous devez entrer un nom commercial pour Code ODP (minimum 4 caract�res)",MB_ICONEXCLAMATION);
	}
}

void CDlgNouveau::OnChangeEditDuree() 
{
	UpdateData(1);
	m_DateFin=m_DateDebut+COleDateTimeSpan(m_Duree-1,0,0,0);
	UpdateData(0);
}

void CDlgNouveau::OnDeltaposSpinDuree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN*  pNMUpDown= (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	UpdateData(1);
	m_Duree-=pNMUpDown->iDelta;
	if(m_Duree<1)m_Duree=1;
	if(m_Duree>365)m_Duree=365;
	m_DateFin=m_DateDebut+COleDateTimeSpan(m_Duree-1,0,0,0);

	UpdateData(0);
	
	*pResult = 0;
}

void CDlgNouveau::OnDateDebutChange(NMHDR* pNMHDR, LRESULT* pResult) 
{
	UpdateData(1);
	m_Duree=1+m_DateFin-m_DateDebut;
	UpdateData(0);
	
	*pResult = 0;
}

void CDlgNouveau::OnDateFinChange(NMHDR* pNMHDR, LRESULT* pResult) 
{
	UpdateData(1);
	m_Duree=1+m_DateFin-m_DateDebut;
	UpdateData(0);
	
	*pResult = 0;
}




