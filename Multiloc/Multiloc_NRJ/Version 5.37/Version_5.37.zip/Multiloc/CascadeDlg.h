#if !defined(AFX_CASCADEDLG_H__E15680E2_7E28_11D2_BCC3_006052017E36__INCLUDED_)
#define AFX_CASCADEDLG_H__E15680E2_7E28_11D2_BCC3_006052017E36__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CascadeDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCascadeDlg dialog


class CMultilocDoc;

class CCascadeDlg : public CDialog
{

/*
#define TAUXNOUVEAUCLIENT		10.0f
#define TAUXRENOUVELLEMENT		10.0f
#define TAUXANTICIPATION		10.0f
#define TAUXMULTIVILLES			10.0f
#define TAUXMAXIABATTEMENTS		20.0f
#define TAUXMAXI				45.0f
#define TAUXREMISEMANDATS		 2.0f
*/

// Plafond des nouveaux taux CGV 2003
#define TAUXFREQUENCE				10.0f		// Taux fr�quence (applicable que pour les contrats fid�lit�)
#define TAUXOFFREGLOBALE_RN_2P		10.0f		// Taux Offre Globale R�gie Networks (2 produits)
#define TAUXOFFREGLOBALE_RN_3P		15.0f		// Taux Offre Globale R�gie Networks (3 produits et +)
#define TAUXREMISE_MV_MAX30			20.0f		// Taux Remise Multiville 4 villes et moins de 30 spots
#define TAUXREMISE_MV_SUP30			25.0f		// Taux Remise Multiville 4 villes et plus de 30 spots
#define TAUXREMISEPROFESSIONNELLE	12.0f		// Taux Remise Professionnelle

#define TAUXANTICIPATION			10.0f
#define TAUXREMISEMANDATS			 2.0f

// Taux maxi applicable (jusqu'� la remise professionnelle)
#define TAUXMAXI_ACHATCLASSIQUE		45.0f
#define TAUXMAXI_CONTRATFIDELITE_NP	55.0f
#define TAUXMAXI_CONTRATFIDELITE_P	55.0f

// #define TAUXNOUVEAUCLIENT		10.0f
#define TAUXMAXI_RENOUVELLEMENT		 5.0f

// Taux coefficient frais annonce classique
#define TAUXFRAISANNONCE1			 2.3f
#define TAUXFRAISANNONCE2			 1.2f
#define TAUXFRAISANNONCE3			 0.8f

/*
#define TAUXMULTIVILLES				10.0f
#define TAUXMAXIABATTEMENTS			20.0f
#define TAUXMAXI					45.0f
#define TAUXREMISEMANDATS			2.0f
*/

// Construction
public:
	void SetDoc(CMultilocDoc * pDoc);
	CCascadeDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCascadeDlg();   // standard destructor

	void Activate(CMultilocDoc* m_pDoc=NULL,float budget=-1, COleDateTime * date=NULL);
	float UpdateCascade(float budget, COleDateTime * date=NULL);
	float DonneBudgetNet(void);
	void CalculCumulMandat();
	void MajTxtDevise();
	void MajMontantEuroFranc();

	// Calcul Remise Multi-villes ou Offre Globale
	void CalculRemiseMV_ou_OffreGlobale();   

	// Calcul frais automatique en mode Floating
	double FraisAnnonceFloating();

	// Calcul Frais automatique en mode contrat classique
	double FraisAnnonceClassique(int NbSpot);

	// V�rif si tous les couples station/ville ont atteint limite spots
	bool InfSpotStationVille(int LimNbSpot);

// Dialog Data
	//{{AFX_DATA(CCascadeDlg)
	enum { IDD = IDD_CASCADE };
	CButton	m_CtrlCheckRemiseRenfort;
	CButton	m_CtrlCheckRemiseNatiocal;
	CButton	m_CtrCheckHorsMedia;
	CButton	m_CtrlCheckProductionPub;
	CButton	m_CtrlCheckParrainage;
	CButton	m_CtrlRemiseMultiVilles;
	CButton	m_CtrlOffreGlobale;
	CComboBox	m_combocoeffrenouvellement;
	CButton	m_CtrCheckRenouvellement;
	CButton	m_CtrlCheckRemiseFrequence;
	CStatic	m_CtrlFraisAnnonceClassique;
	CStatic	m_CtrlFraisAnnonceFloating;
	CComboBox	m_combocoeffmiseenonde;
	CStatic	m_TxtDevise8;
	CStatic	m_TxtDevise7;
	CStatic	m_TxtDevise6;
	CStatic	m_TxtDevise5;
	CStatic	m_TxtDevise4;
	CStatic	m_TxtDevise3;
	CStatic	m_TxtDevise2;
	CStatic	m_TxtDevise1;
	CStatic	m_TitreDevise;
	CEdit	m_EditRemiseSigEtGC;
	CButton	m_CtrlcheckremiseSigetGC;
	CEdit	m_editcoeffremise;
	CEdit	m_EditFraisAnnonce;
	BOOL	m_checknegociation;
	BOOL	m_checkprimeanticipation;
	float	m_coeffremise;
	float	m_coefftotal;
	float	m_coeffnegociation;
	COleDateTime	m_datediffusion;
	float	m_TauxDeRegie;
	float	m_primeanticipation;
	float	m_coeffNbMessages;
	float	m_coeffMultivilles;
	float	m_coeffAbattements;
	float	m_coeffDegressif;
	float	m_totalnetnet;
	float	m_totalnet;
	float	m_totalcabrut;
	float	m_totalbrut;
	float	m_brut;
	float	m_brutht;
	double	m_FraisDuplication;
	double	m_TotalFraisAnnonce;
	BOOL	m_checkfraisannoncemanuel;
	CString	m_fraisannoncereel;
	float	m_coeffremiseauto;
	BOOL	m_checkcumulmandatmanuel;
	CString	m_cumulmandat;
	BOOL	m_checkremiseSigEtGC;
	float	m_coeffFrequence;
	double	m_FraisAcheminementRepiquage;
	double	m_FraisAcheminement;
	double	m_FraisRepiquage;
	CString	m_fraisannoncefloating;
	CString	m_fraisannonceclassique;
	float	m_coeffSigEtGC;
	BOOL	m_checkprofessionnelle;
	float	m_remiseprofessionnelle;
	BOOL	m_checkremisefrequence;
	float	m_coeffrenouvellement;
	BOOL	m_checkrenouvellement;
	float	m_coeffMvOuOffreGlob;
	BOOL	m_checkparrainage;
	BOOL	m_checkproductionpub;
	BOOL	m_checkoffreglobale;
	BOOL	m_checkremisemultivilles;
	float	m_TotRemiseCouplage;
	float	m_brutremisecouplage;
	BOOL	m_checkhorsmedia;
	BOOL	m_checkremisenatiocal;
	BOOL	m_checkremiserenfort;
	float	m_coeffremisenatiocal;
	float	m_coeffremiserenfort;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCascadeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CMultilocDoc * m_pDoc;

	// Generated message map functions
	//{{AFX_MSG(CCascadeDlg)
	afx_msg void OnChecknegociation();
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeBrutht();
	afx_msg void OnChangeCoeffnegociation();
	afx_msg void OnChangeCoeffremise();
	afx_msg void OnChangeEditTauxderegie();
	afx_msg void OnChangeFraisannonce();
	afx_msg void OnChangeFraisDuplication();
	afx_msg void OnCheckFraisannoncemanuel();
	afx_msg void OnCheckCumulmandatmanuel();
	afx_msg void OnChecksiggrandescauses();
	afx_msg void OnCheckremisemultivilles();
	afx_msg void OnCheckoffreglobale();
	afx_msg void OnCheckprodpub();
	afx_msg void OnCheckparrainage();
	afx_msg void OnCheckremisefrequence();
	afx_msg void OnCheckprofessionnelle();
	afx_msg void OnCheckrenouvellement();
	afx_msg void OnSelchangeComborenouvellement();
	afx_msg void OnSelchangeComboCoeffmiseenonde();
	afx_msg void OnEditchangeComboCoeffmiseenonde();
	afx_msg void OnEditupdateComboCoeffmiseenonde();
	afx_msg void OnChangeFraisAchemRepiq();
	afx_msg void OnChangeFraisAcheminement();
	afx_msg void OnChangeFraisRepiquage();
	afx_msg void OnClose();
	afx_msg void OnCheckhorsmedia();
	afx_msg void OnCheckremiserenfort();
	afx_msg void OnCheckremisenatiocal();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	bool m_flagMultiVille;
	void UpdateAffichage(bool update);
	float CheckBudgetNet(void);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CASCADEDLG_H__E15680E2_7E28_11D2_BCC3_006052017E36__INCLUDED_)
