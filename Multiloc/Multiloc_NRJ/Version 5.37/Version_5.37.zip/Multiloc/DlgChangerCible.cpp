// DlgChangerCible.cpp : implementation file
//

#include "stdafx.h"
#include "multiloc.h"
#include "DlgChangerCible.h"
extern CMultilocApp theApp;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgChangerCible dialog


CDlgChangerCible::CDlgChangerCible(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgChangerCible::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgChangerCible)
	//}}AFX_DATA_INIT
	m_pNoyau=new CNoyau(theApp.m_DataBasePath);
	m_pNoyauCommande=new CNoyauCommande(theApp.m_DataBaseCommandePath);
	m_NrCible=0;
}

CDlgChangerCible::~CDlgChangerCible()
{
	if(m_pNoyau) delete m_pNoyau;
	if(m_pNoyauCommande) delete m_pNoyauCommande;
}


void CDlgChangerCible::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgChangerCible)
	DDX_Control(pDX, IDC_LISTCIBLE, m_ListCible);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgChangerCible, CDialog)
	//{{AFX_MSG_MAP(CDlgChangerCible)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgChangerCible message handlers

BOOL CDlgChangerCible::OnInitDialog() 
{
	theApp.JoueMusic(7);
	
	CDialog::OnInitDialog();
	
	for(short nr=0;nr<m_pNoyau->m_TblCible.GetSize();nr++)
		m_ListCible.AddString(m_pNoyau->m_TblCible[nr].m_Libelle);
	m_ListCible.SelectString(-1,m_pNoyau->m_TblCible[m_NrCible].m_Libelle);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgChangerCible::OnOK() 
{
	CString txt;
	m_ListCible.GetText(m_ListCible.GetCurSel(),txt);	
	for(short nr=0;nr<m_pNoyau->m_TblCible.GetSize();nr++)
		if(txt==m_pNoyau->m_TblCible[nr].m_Libelle)break;
	if(nr>=m_pNoyau->m_TblCible.GetSize())return;
	m_NrCible=nr;
	CDialog::OnOK();
}

