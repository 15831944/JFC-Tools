// DlgAjouter.cpp : implementation file
//

#include "stdafx.h"
#include "multiloc.h"
#include "DlgAjouter.h"
extern CMultilocApp theApp;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CDlgAjouter dialog


CDlgAjouter::CDlgAjouter(CNoyau * pNoyau)
	: CDialog(CDlgAjouter::IDD, NULL)
{
	m_pNoyau=pNoyau;
	m_fSupress=0;
//	m_TblSelection=selection;
}


void CDlgAjouter::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgAjouter)
	DDX_Control(pDX, IDC_VILLE, m_ListVille);
	DDX_Control(pDX, IDC_STATION, m_ListStation);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgAjouter, CDialog)
	//{{AFX_MSG_MAP(CDlgAjouter)
	ON_LBN_SELCHANGE(IDC_STATION, OnSelchangeStation)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgAjouter message handlers

BOOL CDlgAjouter::OnInitDialog() 
{
	theApp.JoueMusic(7);
	CDialog::OnInitDialog();

	if(m_fSupress){	// cas de SUPPRIMER
		SetWindowText("Supprimer des station et des villes");
		m_NrLienStation.RemoveAll();
		short nr;
		for(nr=0;nr<m_pNoyau->m_TblStation.GetSize();nr++){
			// cette station est-elle dans la s�lection ??
			for(short i=0;i<m_Selection.GetSize();i++){
				short sta=LOWORD(m_Selection[i]);
				if(nr==sta){
					m_ListStation.AddString(m_pNoyau->m_TblStation[nr].m_Libelle);
					m_NrLienStation.Add(nr);
					break;
				}
			}
		}
		return TRUE;
	}

	
	// cas de AJOUTER
	// on informe de la liste des stations
	short nr;
	for(nr=0;nr<m_pNoyau->m_TblStation.GetSize();nr++)
		m_ListStation.AddString(m_pNoyau->m_TblStation[nr].m_Libelle);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgAjouter::ActualiseListVille()
{
	m_ListVille.ResetContent();
	//m_NrVille=0;
	for(short nr=0;nr<m_pNoyau->m_pTblVille[m_NrStation].GetSize();nr++)
		m_ListVille.AddString(m_pNoyau->m_pTblVille[m_NrStation][nr].m_Libelle);
}

void CDlgAjouter::ActualiseListVilleSupress()
{
	m_ListVille.ResetContent();
	m_NrLienVille.RemoveAll();
	for(short nr=0;nr<m_pNoyau->m_pTblVille[m_NrStation].GetSize();nr++){
		// cette ville est-elle dans la s�lection de cette station ?
		for(short i=0;i<m_Selection.GetSize();i++){
			short sta=LOWORD(m_Selection[i]);
			if(sta!=m_NrStation)continue;
			short vil=HIWORD(m_Selection[i]);
			if(vil==nr){
				m_ListVille.AddString(m_pNoyau->m_pTblVille[m_NrStation][nr].m_Libelle);
				m_NrLienVille.Add(nr);
				break;
			}
		}
	}
}

void CDlgAjouter::OnSelchangeStation() 
{
	if(!m_fSupress){
		m_NrStation=m_ListStation.GetCurSel();
		ActualiseListVille();
	}
	else {
		m_NrStation=m_NrLienStation[m_ListStation.GetCurSel()];
		ActualiseListVilleSupress();
	}
}

void CDlgAjouter::OnOK() 
{
	int nb,*sel;
	m_NrVille.RemoveAll();
	nb=m_ListVille.GetSelCount();
	if(nb<=0){
		MessageBox("La s�lection est invalide");
		return;
	}
	sel = (int*)malloc(sizeof(int)*nb);
	m_ListVille.GetSelItems(nb,sel);
	for(int i=0;i<nb;i++){
		if(m_fSupress)m_NrVille.Add(m_NrLienVille[sel[i]]);
		else m_NrVille.Add(sel[i]);
	}
	free(sel);
	CDialog::OnOK();
}
