#if !defined(AFX_DLGCHANGERCIBLE_H__4BEA6AA0_851F_11D2_AC40_0080C708A895__INCLUDED_)
#define AFX_DLGCHANGERCIBLE_H__4BEA6AA0_851F_11D2_AC40_0080C708A895__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgChangerCible.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgChangerCible dialog

#include "noyau.h"
#include "noyaucommande.h"
class CDlgChangerCible : public CDialog
{
// Construction
public:
	CNoyauCommande *m_pNoyauCommande;
	~CDlgChangerCible();
	CDlgChangerCible(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgChangerCible)
	enum { IDD = IDD_CHANGERCIBLE };
	CListBox	m_ListCible;
	//}}AFX_DATA
	CNoyau *m_pNoyau;
	short m_NrCible;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgChangerCible)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgChangerCible)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCHANGERCIBLE_H__4BEA6AA0_851F_11D2_AC40_0080C708A895__INCLUDED_)
