// DataCampagne.h: interface for the CDataCampagne class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATACAMPAGNE_H__DFD19B02_4826_11D4_8658_0080C708A895__INCLUDED_)
#define AFX_DATACAMPAGNE_H__DFD19B02_4826_11D4_8658_0080C708A895__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataCampagne  
{
public:
	CDataCampagne();
	virtual ~CDataCampagne();
};

#endif // !defined(AFX_DATACAMPAGNE_H__DFD19B02_4826_11D4_8658_0080C708A895__INCLUDED_)
