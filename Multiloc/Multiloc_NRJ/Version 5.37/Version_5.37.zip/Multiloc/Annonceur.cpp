// Annonceur.cpp: implementation of the CAnnonceur class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "multiloc.h"
#include "Annonceur.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAnnonceur::CAnnonceur()
{
	m_NumAnnonceur=0;
	m_Code= _T("");
	m_Nom= _T("");
	m_Adresse = _T("");
	m_Ville= _T("");
	m_CodePostal= 0;
	m_Contact= _T("");
	m_Tel= _T("");
	m_Fax= _T("");
	m_Email= _T("");
	m_Commentaire=_T("");
}

CAnnonceur::~CAnnonceur()
{

}

CAnnonceur & CAnnonceur::operator=(const CAnnonceur &Source)
{
	m_NumAnnonceur=Source.m_NumAnnonceur;
	m_Code=Source.m_Code;
	m_Nom=Source.m_Nom;
	m_Adresse =Source.m_Adresse;
	m_Ville=Source.m_Ville;
	m_CodePostal=Source.m_CodePostal;
	m_Contact=Source.m_Contact;
	m_Tel=Source.m_Tel;
	m_Fax=Source.m_Fax;
	m_Email=Source.m_Email;
	return(*this);
}

CAnnonceur & CAnnonceur::operator=(const CTblAnnonceur &Source)
{
	m_NumAnnonceur=Source.m_NumAnnonceur;
	m_Code=Source.m_Code;
	m_Nom=Source.m_Nom;
	m_Adresse =Source.m_Adresse;
	m_Ville=Source.m_Ville;
	m_CodePostal=Source.m_CodePostal;
	m_Contact=Source.m_Contact;
	m_Tel=Source.m_Tel;
	m_Fax=Source.m_Fax;
	m_Email=Source.m_Email;
	m_Commentaire=Source.m_Commentaire;
	return(*this);
}

bool CAnnonceur::operator<(const CAnnonceur &Source)
{
	if(m_Nom<Source.m_Nom) return(TRUE);
	else return(FALSE);
}