//===============================
// fichier: JFCColorManager.h
//
// date: 08/03/2002
// auteur: JB
//-------------------------------

// on teste si la macro qui identifie le fichier est d�j� d�finie
#ifndef _JFCCOLORMANAGER_H_

// on d�finit une macro pour identifier le fichier
#define _JFCCOLORMANAGER_H_


class ColorManager
{
public:
	// le constructeur
	ColorManager();

	// la fonction pour fixer le nombre de couleurs
	static void SetNbColor(long nbcolor);

	// la fonction pour r�cup�rer le nombre de couleurs
	static long GetNbColor();

	// la fonction pour fixer la couleur de l'indice n
	static void SetColor (long indice, COLORREF couleur);

	// la fonction pour r�cup�rer une couleur en fonction de son indice
	static COLORREF GetColor   (long indice);
	static COLORREF GetLumColor(long indice);

	// la fonction pour fixer la luminosit� de la couleur
	static void SetLuminosite(long luminosite);

	// la fonction pour r�cup�rer les bornes de la luminosite
	static long GetLuminositeMin();
	static long GetLuminositeMax();

	// le destructeur
	~ColorManager();
protected:
	// la luminosite
	static long m_Luminosite;

	// le tableau
	static COLORREF * m_TabColor;

	//le nombre de couleurs
	static long m_NbColor;
};
// fin du test sur la macro
#endif
