//============================
// fichier: CEtatDeSortie.h
//
// date: 27/02/2002
// auteur: JB
//============================

// on teste si la macro qui identifie le fichier est d�j� d�finie
#ifndef _CETATDESORTIE_H_

// on d�finit une macro pour identifier le fichier
#define _CETATDESORTIE_H_

// on inclut les fichiers n�cessaires
#include "JFCBitmap.h"
#include "JFCFont.h"
#include "JFCDraw.h"

/////////////////////////////////

//Orientation
#define	PORTRAIT		1
#define	PAYSAGE			2

//Nb lignes du corps de la page
#define	NBLIGNES_PORTRAIT	77
#define	NBLIGNES_PAYSAGE	53
#define	NBCOLONNES_PORTRAIT	80
#define	NBCOLONNES_PAYSAGE	130

//marge Feuille
#define MARGE_COL           1	// x% de la page  ds colonne
#ifndef MARGE_PAGE_G
#define MARGE_PAGE_G		5	// x% de la page  gauche
#endif
#ifndef MARGE_PAGE_D
#define MARGE_PAGE_D		5	// x% de la page  droit
#endif
#define MARGE_PAGE_H		2	// x% de la page  en haut
#define MARGE_PAGE_B		2	// x% de la page  en bas
//section d'un tableau
#define PRINT_INTERLIGNE	0
#define PRINT_TITRE			1
#define PRINT_TETE			2
#define PRINT_CORPS			3
#define PRINT_PIEDS			4
#define PRINT_TOTAL			5


class CEtatDeSortie
{
public:
// les structures internes:
//-------------------------
	// la structure qui contient les informations d'un tableau:
	//---------------------------------------------------------
	struct SInfoTab
	{
		// le constructeur
		SInfoTab();
		// le constructeur de recopie
		SInfoTab(const SInfoTab & source);
		// l'op�rateur d'affectation
		SInfoTab & operator=(const SInfoTab & operande);

		char       m_fColonne;          // 1:1appel par ligne  2:1appel par colonne
		char       m_NbLigneGarantie;   // nb lignes successives garanties
		short      m_NbLigneTitre;      // nb lignes pour titre tableau
		short      m_NbLigneTete;       // nb lignes pour entete tableau
		short      m_NbLigneCorps;      // nb lignes pour corps tableau
		short      m_NbLignePieds;      // nb lignes pour pied tableau
		short      m_NbLigneTotal;      // nb lignes pour un total tableau
		short      m_NbLigneInterLigne; // nb lignes pour interligne entre tableau
		short      m_NbCarGauche;       // nb caracteres pour colonnes de gauche
		short      m_NbCarDroit;        // nb caracteres pour colonnes de droite
		CWordArray m_CarColonne;        // nb de caracteres pour chacune des colonnes
	};
	typedef CArray<SInfoTab, SInfoTab> CInfoTabArray;

	//Variables renseign�es lors de l'initialisation:
	//-----------------------------------------------
	struct SIniPrint
	{
		CInfoTabArray m_InfoTab; // stucture de tableau(x)
		short m_NbLigneTete;     // nombre de ligne d'entete de page
		short m_NbLignePieds;    // nombre de ligne de pieds de page
		short m_Marge[4];        // Marge haut(0) bas(1) gauche(2) droite(3) en % de la page
//		CFont * m_PoliceDef;     // police par defaut
		short m_fOrientation;    // 0:libre 1:Paysage 2:Portrait
	};
	
	//description de chacune des lignes du tableau:
	//---------------------------------------------
	struct SMappTab
	{
		unsigned short m_Reel;   // index 1 � n ligne
		unsigned short m_Tab;    // numero du tableau
		unsigned short m_Type;   // 1:Titre 2:tete 3:corps 4:pieds 5:total
		unsigned short m_Lig;    // numero de la ligne
		unsigned short m_NbLig;  // nb ligne du type
		unsigned short m_NrCol;  // numero de la colonne
		unsigned short m_NbCol;  // nombre de colonne

		unsigned short m_Rappel; // numero de ligne pour tracer les traits verticaux
	};
	typedef CArray<SMappTab, SMappTab> CMappTabArray;

	// le type tableau de bitmaps:
	typedef CArray<JFCBitmap, JFCBitmap&> CBitmapArray;

public:
	// le constructeur
	CEtatDeSortie();

	// la fonction pour fixer l'orientation
	void SetOrientation(long orientation);

// les fonction virtuelles pures:
//-------------------------------
	// la fonction d'initialisation
	virtual void Initialise() = 0;

	// les fonctions de dessin de l'ent�te
	virtual bool DrawTete(JFCDraw * pDraw, CRect * pR, long NrPage, long NrLig, long PremierNrTab, long DernierNrTab);
	virtual bool DrawTete(JFCDraw * pDraw, CRect * pR, long NrPage, long NrLig);

	// la fonction de dessin du pied de page
	virtual bool DrawPieds(JFCDraw * pDraw, CRect * pR, long NrPage, long NrLig);

	// la fonction de dessin d'un tableau en mode tableau
	virtual bool DrawTab(JFCDraw * pDraw, CRect * pR, long NrTab, long NrType, long NrLig);

	// la fonction de dessin d'un tableau en mode colonne
	virtual bool DrawCol(JFCDraw * pDraw, CRect * pR, long NrTab, long NrType, long NrLig, long NrCol, long NbCol);

	// la fonction de dessin d'un tableau vertical (?? jamais essay� donc d�finition bas�e sur le nom (JB))
	virtual bool DrawVTab(JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long NrTab);

	// la fonction de dessin du fond d'�cran
	virtual bool DrawBk(JFCDraw * pDraw, CRect * pR);

// les autres fonctions:
//----------------------
	// la fonction pour vider le document
	void Reset();

	// la fonction de calcul du nombre de page
	long CalculNbPage ();

	// le destructeur
	virtual ~CEtatDeSortie();

	// la fonction qui g�re l'impression
	void Draw(JFCDraw * pDraw, CRect * Rect, long numpage);

// les fonctions de dessin de l'objet printer:
//--------------------------------------------
protected:
	void TraitH           (JFCDraw * pDraw, CRect * pR, long PDebut, long PFin, long linewidth = -1, long idxColor = -1);
	void TraitHtop        (JFCDraw * pDraw, CRect * pR, long PDebut, long PFin, long linewidth = -1, long idxColor = -1);
	void TraitHbottom     (JFCDraw * pDraw, CRect * pR, long PDebut, long PFin, long linewidth = -1, long idxColor = -1);
	void TraitDoubleH     (JFCDraw * pDraw, CRect * pR, long PDebut, long PFin, long linewidth = -1, long idxColor = -1);
	void TraitV           (JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long PDebut=0, long PFin=100, long linewidth = -1, long idxColor = -1);
	void TraitVfull       (JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long PDebut=0, long PFin=100, long linewidth = -1, long idxColor = -1);
	void TraitDoubleV     (JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long Position, long linewidth = -1, long idxColor = -1);
	void TraitDoubleVfull (JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long Position, long linewidth = -1, long idxColor = -1);

	void TraitVG          (JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long PDebut=0, long PFin=100, long linewidth=-1, long idxColor = -1);
	void TraitVGfull      (JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long PDebut=0, long PFin=100, long linewidth=-1, long idxColor = -1);
	void TraitVD          (JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long PDebut=0, long PFin=100, long linewidth=-1, long idxColor = -1);
	void TraitVDfull      (JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long PDebut=0, long PFin=100, long linewidth=-1, long idxColor = -1);
	void EcritG           (JFCDraw * pDraw, const CString & txt, CRect * pR, long PDebut=0, long PFin=100, long Offset=0, long idxFont=-1, long idxTextColor=-1);
	void EcritD           (JFCDraw * pDraw, const CString & txt, CRect * pR, long PDebut=0, long PFin=100, long Offset=0, long idxFont=-1, long idxTextColor=-1);
	void EcritC           (JFCDraw * pDraw, const CString & txt, CRect * pR, long PDebut=0, long PFin=100, long idxFont=-1, long idxTextColor=-1);
	void RemplisRect      (JFCDraw * pDraw, CRect * pR, long idxColor, long PDebut=0, long PFin=100);
	void ShadowRect       (JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long idxColor, long PDebut=0, long PFin=100);
	void DessineCadre     (JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long PDebut=0, long PFin=100, long linewidth=-1, long idxColor = -1);
	void DessineCadre2    (JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long PDebut=0, long PFin=100, long linewidth=-1, long idxColor = -1);
	void DessineBitmap    (JFCDraw * pDraw, const CString & filename, CRect * pR, short PDebut=0, short PFin=100);
	
	
// fonctions utilitaires:
//-----------------------
private:
	CPoint CalcPointMilieuG (CRect * pR);
	CPoint CalcPointMilieuD (CRect * pR);
	CRect  CalcRect         (CRect * pR, long P100Debut=0, long P100Fin=100);
		
	bool YAPasPLace(short reel,short place);
	bool NouvellePage(short &reel);

public:
	//Variables calcul�es AVANT l'initialisation
	long m_Orientation;

	//Variables calcul�es APRES l'initialisation
	short m_NbLignePage;  // Nombre de ligne par page
	short m_NbLigneCorps; // Nombre de ligne dans le corps de la page
	short m_HLig;         // hauteur de ligne
	short m_LCol;         // largeur d'une colonne (car)
	short m_NbColPage;    // nombre de colonne par page
	short m_NbPage;       // nombre de page

	CMappTabArray m_Mapping; // 
	CBitmapArray  m_Bitmaps; // le tableau de bitmaps
	SIniPrint     m_Init;    // la structure d'initialisation du document � imprimer
};

// fin du test sur la macro
#endif