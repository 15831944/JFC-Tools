//==============================
// fichier: CEtatDeSortie.cpp
//
// date: 27/02/2002
// auteur: JB
//==============================


// on inclut les fichiers n�cessaires
#include "stdafx.h"
#include "CEtatDeSortie.h"

//=============================================================================
// le code des structures internes:
//
//-----------------------------------------------------------------------------

// SInfoTab:
//----------

//=============================================================================
// le constructeur:
//-----------------------------------------------------------------------------
CEtatDeSortie::SInfoTab::SInfoTab()
{
	// on initialise les membres
	m_NbLigneTitre      = 0;
	m_NbLigneTete       = 0;
	m_NbLigneCorps      = 0;
	m_NbLignePieds      = 0;
	m_NbLigneTotal      = 0;
	m_NbLigneInterLigne = 0;
	m_NbCarGauche       = 0;
	m_NbCarDroit        = 0;
	m_fColonne          = 0;
	m_NbLigneGarantie   = 1;
}

CEtatDeSortie::SInfoTab::SInfoTab(const SInfoTab & source)
{
	// on reccopie les valeurs des membres
	m_NbLigneTitre      = source.m_NbLigneTitre;
	m_NbLigneTete       = source.m_NbLigneTete;
	m_NbLigneCorps      = source.m_NbLigneCorps;
	m_NbLignePieds      = source.m_NbLignePieds;
	m_NbLigneTotal      = source.m_NbLigneTotal;
	m_NbLigneInterLigne = source.m_NbLigneInterLigne;
	m_NbCarGauche       = source.m_NbCarGauche;
	m_NbCarDroit        = source.m_NbCarDroit;
	m_fColonne          = source.m_fColonne;
	m_NbLigneGarantie   = source.m_NbLigneGarantie;
	m_CarColonne.Copy(source.m_CarColonne);
}

CEtatDeSortie::SInfoTab & CEtatDeSortie::SInfoTab::operator=(const SInfoTab & operande)
{
	// on teste l'op�rande
	if (&operande != this)
	{
		// on recopie les valeurs de l'op�rande
		m_NbLigneTitre      = operande.m_NbLigneTitre;
		m_NbLigneTete       = operande.m_NbLigneTete;
		m_NbLigneCorps      = operande.m_NbLigneCorps;
		m_NbLignePieds      = operande.m_NbLignePieds;
		m_NbLigneTotal      = operande.m_NbLigneTotal;
		m_NbLigneInterLigne = operande.m_NbLigneInterLigne;
		m_NbCarGauche       = operande.m_NbCarGauche;
		m_NbCarDroit        = operande.m_NbCarDroit;
		m_fColonne          = operande.m_fColonne;
		m_NbLigneGarantie   = operande.m_NbLigneGarantie;
		m_CarColonne.Copy(operande.m_CarColonne);
	}
	// on renvoie la r�f�rence
	return (*this);
}

//=============================================================================
//                                                                           //
//               le code de la classe CEtatDeSortie:                         //
//                                                                           //
//-----------------------------------------------------------------------------

//=============================================================================
// le constructeur:
//-----------------------------------------------------------------------------
CEtatDeSortie::CEtatDeSortie()
{
	// on initialise les membres
	m_Orientation  = 0;
	m_NbLignePage  = 0;
	m_NbLigneCorps = 0;
	m_HLig         = 0;
	m_LCol         = 0;
	m_NbColPage    = 0;
	m_NbPage       = 0;
	m_Bitmaps.SetSize(0,1);
}

//=============================================================================
// la fonction pour g�rer l'impression:
//-----------------------------------------------------------------------------
void CEtatDeSortie::Draw(JFCDraw * pDraw, CRect * pRect, long NrPage)
{
	// on modifie la taille du rectangle en fonction des marges
	pRect->top    += (pRect->bottom - pRect->top) * m_Init.m_Marge[0]  / 100;
	pRect->bottom -= (pRect->bottom - pRect->top) * m_Init.m_Marge[1]  / 100;
	pRect->left   += (pRect->right  - pRect->left) * m_Init.m_Marge[2] / 100;
	pRect->right  -= (pRect->right  - pRect->left) * m_Init.m_Marge[3] / 100;

	// on calcule les hauteurs de ligne et largeurs de colonnes
	m_HLig = (pRect->bottom - pRect->top) / m_NbLignePage;
	m_LCol = (pRect->right  - pRect->left) / m_NbColPage;

	// on dessine le fond d'�cran
	DrawBk(pDraw, pRect);

	// on r�cup�re la taille du mapping
	long maxi = m_Mapping.GetSize();

	long NrLig = 0;
	int FirstLine = min(NrPage*m_NbLigneCorps,maxi-1);
	int LastLine  = min(((NrPage+1)*m_NbLigneCorps)-1,maxi-1);

	CRect r = *pRect;

	// on boucle sur les lignes de l'ent�te
	for(long i = 0; i < m_Init.m_NbLigneTete; i++, NrLig++)
	{
		r.top  = pRect->top + m_HLig*NrLig;
		r.bottom = r.top + m_HLig;
		// on lance la fonction de dessin de l'ent�te pour cette ligne
		int VAlTab = m_Mapping[LastLine].m_Tab;
		DrawTete(pDraw,&r,NrPage,i,m_Mapping[FirstLine].m_Tab,m_Mapping[LastLine].m_Tab);
	}

	// on boucle sur les lignes du corps
	for(i=0; i < m_NbLigneCorps; i++, NrLig++)
	{
		r.top    = pRect->top + m_HLig * NrLig;
		r.bottom = r.top + m_HLig;
		long idx = NrPage * m_NbLigneCorps + i;
		if( idx >= maxi)break;
		int tab=m_Mapping[idx].m_Tab;

		int NoLig = m_Mapping[idx].m_Lig;

		if (tab == 3 && NoLig == 2)
		{
			int stop = 0;
		}

		

		switch(m_Init.m_InfoTab[tab].m_fColonne)
		{
		case 0:	//tableau ligne/ligne
			DrawTab(pDraw, &r, tab, m_Mapping[idx].m_Type, m_Mapping[idx].m_Lig);
			break;
		case 1:
			{	
				//tableau colonne/ligne
				int nb,d;
				nb=m_Mapping[idx].m_NbCol;
				d=m_Mapping[idx].m_NrCol;
				DrawCol(pDraw,&r,tab,m_Mapping[idx].m_Type,m_Mapping[idx].m_Lig,d,nb);
			}
			break;
		case 2:
			{	//tableau ligne/colonne
				// les cas des colones
//				tab=m_Mapping[idx].m_Tab;
				int nb,c,d;
				nb=m_Init.m_InfoTab[tab].m_NbCarGauche;
				r.left=pRect->left;
				r.right=r.left+nb*m_LCol;
				if(nb>0){ // la colonne de gauche
					DrawCol(pDraw,&r,tab,m_Mapping[idx].m_Type,m_Mapping[idx].m_Lig,-1,-1);
				}
				nb=m_Mapping[idx].m_NbCol;
				d=m_Mapping[idx].m_NrCol;
				if(nb>0){ // les colonnes du centre
					for(c=0;c<nb;c++){
						r.left=r.right;
						r.right=r.left+m_LCol*m_Init.m_InfoTab[tab].m_CarColonne[c+d];
						if(DrawCol(pDraw, &r, tab,m_Mapping[idx].m_Type,m_Mapping[idx].m_Lig,c+d,nb))break;
					}
				}
				nb=m_Init.m_InfoTab[tab].m_NbCarDroit;
				r.left=pRect->right-(nb*m_LCol);
				r.right=pRect->right;
				if(nb>0){ // la colonne de droite
					DrawCol(pDraw,&r,tab,m_Mapping[idx].m_Type,m_Mapping[idx].m_Lig,999,999);
				}
			}
			break;
		}
		if(m_Mapping[idx].m_Rappel)
		{
			// Cas des traits verticaux � dessiner
			CRect rh=r;
			rh.top=pRect->top+m_HLig*(m_Mapping[idx].m_Rappel-1+m_Init.m_NbLigneTete);
			rh.bottom=rh.top+m_HLig;
			DrawVTab(pDraw,&rh, &r,tab);
		}
	}
	// Lancement des dessins du pieds de page
	NrLig=m_NbLignePage-m_Init.m_NbLignePieds;
	for(i=0;i<m_Init.m_NbLignePieds;i++,NrLig++)
	{
		r.top=pRect->top+m_HLig*NrLig;
		r.bottom=r.top+m_HLig;
		DrawPieds(pDraw,&r,NrPage,i);
	}
}

//=============================================================================
// les fonctions de dessin des parties de page
//-----------------------------------------------------------------------------

// les fonctions de dessins de la t�te
bool CEtatDeSortie::DrawTete(JFCDraw * pDraw, CRect * pR, long NrPage, long NrLig, long PremierNrTab, long DernierNrTab)
{
	DrawTete(pDraw, pR, NrPage, NrLig);
	return (true);
}
bool CEtatDeSortie::DrawTete(JFCDraw * pDraw, CRect * pR, long NrPage, long NrLig)
{
	return (false);
}

// la fonction de dessin du pied de page
bool CEtatDeSortie::DrawPieds(JFCDraw * pDraw, CRect * pR, long NrPage, long NrLig)
{
	// la fonction doit �tre d�riv�e, on renvoie donc un code d'echec
	return (false);
}

// la fonction de dessin d'un tableau en mode tableau
bool CEtatDeSortie::DrawTab(JFCDraw * pDraw, CRect * pR, long NrTab, long NrType, long NrLig)
{
	// la fonction doit �tre d�riv�e, on renvoie donc un code d'echec
	return (false);
}

// la fonction de dessin d'un tableau en mode colonne
bool CEtatDeSortie::DrawCol(JFCDraw * pDraw, CRect * pR, long NrTab, long NrType, long NrLig, long NrCol, long NbCol)
{
	// la fonction doit �tre d�riv�e, on renvoie donc un code d'echec
	return (false);
}

// la fonction de dessin d'un tableau vertical (?? jamais essay� donc d�finition bas�e sur le nom (JB))
bool CEtatDeSortie::DrawVTab(JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long NrTab)
{
	// la fonction doit �tre d�riv�e, on renvoie donc un code d'echec
	return (false);
}

// la fonction de dessin du fond d'�cran
bool CEtatDeSortie::DrawBk(JFCDraw * pDraw, CRect * pR)
{
	// la fonction doit �tre d�riv�e, on renvoie donc un code d'echec
	return (false);
}

//=============================================================================
// le destructeur:
//-----------------------------------------------------------------------------
CEtatDeSortie::~CEtatDeSortie()
{
	// on ne fait rien
}

void CEtatDeSortie::SetOrientation(long orientation)
{
	// on fixe le flag d'orientation
	m_Orientation = orientation;

	// on teste l'orientation
	switch(orientation)
	{
	case PORTRAIT:
		// on d�termine les nombres de ligne/colonne
		m_NbLignePage=NBLIGNES_PORTRAIT;
		m_NbColPage=NBCOLONNES_PORTRAIT;
		break;
	case PAYSAGE:
		// on d�termine les nombres de ligne/colonne
		m_NbLignePage=NBLIGNES_PAYSAGE;
		m_NbColPage=NBCOLONNES_PAYSAGE;
		break;
	default:
		// on d�termine les nombres de ligne/colonne
		m_NbLignePage=NBLIGNES_PORTRAIT;
		m_NbColPage=NBCOLONNES_PORTRAIT;
		break;
	}
	// on fixe le nombre de ligne du corps
	m_NbLigneCorps=m_NbLignePage-(m_Init.m_NbLignePieds+m_Init.m_NbLigneTete);
}

/////////////////////////////////////////////////////////////////////////////////
// FONCTIONS DE DESSINS
/////////////////////////////////////////////////////////////////////////////////
// les fonctions de trac� de trait:
//---------------------------------
void CEtatDeSortie::TraitH(JFCDraw * pDraw, CRect * pR, long PDebut, long PFin, long linewidth, long idxColor)
{
	CPoint Pg, Pd;
	Pg=CalcPointMilieuG(&CalcRect(pR, PDebut, PFin));
	Pd=CalcPointMilieuD(&CalcRect(pR, PDebut, PFin));

	// on teste la couleur
	if (idxColor >= 0) pDraw->SetColor(idxColor);
	
	// on teste la largeur de ligne
	if (linewidth >= 0) pDraw->SetLineWidth(linewidth);

	// on dessine le trait
	pDraw->MoveTo(Pg.x, Pg.y);
	pDraw->LineTo(Pd.x, Pg.y);
}

void CEtatDeSortie::TraitHtop(JFCDraw * pDraw, CRect * pR, long PDebut, long PFin, long linewidth, long idxColor)
{
	CPoint Pg, Pd;
	Pg=CalcPointMilieuG(&CalcRect(pR, PDebut, PFin));
	Pd=CalcPointMilieuD(&CalcRect(pR, PDebut, PFin));
	Pg.y=Pd.y=pR->top;

	// on teste la couleur
	if (idxColor >= 0) pDraw->SetColor(idxColor);

	// on teste la largeur de ligne
	if (linewidth >= 0) pDraw->SetLineWidth(linewidth);
	// on dessine le trait
	pDraw->MoveTo(Pg.x, Pg.y);
	pDraw->LineTo(Pd.x, Pg.y);
}

void CEtatDeSortie::TraitHbottom(JFCDraw * pDraw, CRect * pR, long PDebut, long PFin, long linewidth, long idxColor)
{
	CPoint Pg, Pd;
	Pg=CalcPointMilieuG(&CalcRect(pR, PDebut, PFin));
	Pd=CalcPointMilieuD(&CalcRect(pR, PDebut, PFin));
	Pg.y=Pd.y=pR->bottom;

	// on teste la couleur
	if (idxColor >= 0) pDraw->SetColor(idxColor);
	
	// on teste la largeur de ligne
	if (linewidth >= 0) pDraw->SetLineWidth(linewidth);
	
	// on trace le trait
	pDraw->MoveTo(Pg.x, Pg.y);
	pDraw->LineTo(Pd.x, Pd.y);
}

void CEtatDeSortie::TraitDoubleH(JFCDraw * pDraw, CRect * pR, long PDebut, long PFin, long linewidth, long idxColor)
{
	CPoint Pg, Pd;
	Pg=CalcPointMilieuG(&CalcRect(pR, PDebut, PFin));
	Pd=CalcPointMilieuD(&CalcRect(pR, PDebut, PFin));
	Pg.y-=5;	Pd.y-=5;

	// on teste la couleur
	if (idxColor  >= 0) pDraw->SetColor(idxColor);
	if (linewidth >= 0) pDraw->SetLineWidth(linewidth);
	
	// on trace le premier trait
	pDraw->MoveTo(Pg.x, Pg.y);
	pDraw->LineTo(Pd.x, Pg.y);

	// on d�place les coordonn�es
	Pg.y+=10;	Pd.y+=10;

	// on trace le trait
	pDraw->MoveTo(Pg.x, Pg.y);
	pDraw->LineTo(Pd.x, Pg.y);	
}

void CEtatDeSortie::TraitV(JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long PDebut, long PFin, long linewidth, long idxColor)
{
	// on trace les traits gauche et droit
	TraitVG(pDraw, pR_haut, pR_bas, PDebut, PFin, linewidth, idxColor);
	TraitVD(pDraw, pR_haut, pR_bas, PDebut, PFin, linewidth, idxColor);
}

void CEtatDeSortie::TraitVfull(JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long PDebut, long PFin, long linewidth, long idxColor)
{
	TraitVGfull(pDraw, pR_haut, pR_bas, PDebut, PFin, linewidth, idxColor);
	TraitVDfull(pDraw, pR_haut, pR_bas, PDebut, PFin, linewidth, idxColor);
}

void CEtatDeSortie::TraitDoubleV(JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long Position, long linewidth, long idxColor)
{
	CPoint Ph, Pb;
	Ph=CalcPointMilieuG(&CalcRect(pR_haut, Position,  Position));
	Pb=CalcPointMilieuG(&CalcRect(pR_bas, Position, Position));
	Ph.x-=5;
	Pb.x-=5;
	
	// on teste la couleur
	if (idxColor >= 0) pDraw->SetColor(idxColor);
	
	// on trace le trait
	pDraw->MoveTo(Ph.x, Ph.y);
	pDraw->LineTo(Pb.x, Ph.y);
	Ph.x+=10;
	Pb.x+=10;
	pDraw->MoveTo(Ph.x, Ph.y);
	pDraw->LineTo(Pb.x, Pb.y);
}

void CEtatDeSortie::TraitDoubleVfull(JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long Position, long linewidth, long idxColor)
{
	CPoint Ph, Pb;
	Ph=CalcPointMilieuG(&CalcRect(pR_haut, Position,  Position));
	Pb=CalcPointMilieuG(&CalcRect(pR_bas, Position, Position));
	Ph.y=pR_haut->top;
	Pb.y=pR_bas->bottom;
	Ph.x-=5;
	Pb.x-=5;
	// on teste la couleur
	if (idxColor >= 0) pDraw->SetColor(idxColor);
	
	// on trace le trait
	pDraw->MoveTo(Ph.x, Ph.y);
	pDraw->LineTo(Pb.x, Pb.y);
	Ph.x+=10;
	Pb.x+=10;
	pDraw->MoveTo(Ph.x, Ph.y);
	pDraw->LineTo(Pb.x, Pb.y);
}

void CEtatDeSortie::TraitVG(JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long PDebut, long PFin, long linewidth, long idxColor)
{
	CPoint Ph, Pb;
	Ph=CalcPointMilieuG(&CalcRect(pR_haut, PDebut, PFin));
	Pb=CalcPointMilieuG(&CalcRect(pR_bas, PDebut, PFin));

	// on teste la couleur
	if (idxColor >= 0) pDraw->SetColor(idxColor);
	
	// on trace le trait
	pDraw->MoveTo(Ph.x, Ph.y);
	pDraw->LineTo(Pb.x, Pb.y);
}

void CEtatDeSortie::TraitVGfull(JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long PDebut, long PFin, long linewidth, long idxColor)
{
	CPoint Ph, Pb;
	Ph=CalcPointMilieuG(&CalcRect(pR_haut, PDebut, PFin));
	Pb=CalcPointMilieuG(&CalcRect(pR_bas, PDebut, PFin));
	Ph.y=pR_haut->top;
	Pb.y=pR_bas->bottom;
	
	// on teste la couleur
	if (idxColor >= 0) pDraw->SetColor(idxColor);

	// on trace le trait
	pDraw->MoveTo(Ph.x, Ph.y);
	pDraw->LineTo(Pb.x, Pb.y);
}

void CEtatDeSortie::TraitVD(JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long PDebut, long PFin, long linewidth, long idxColor)
{
	CPoint Ph, Pb;
	Ph=CalcPointMilieuD(&CalcRect(pR_haut, PDebut, PFin));
	Pb=CalcPointMilieuD(&CalcRect(pR_bas, PDebut, PFin));
	
	// on teste la couleur
	if (idxColor >= 0) pDraw->SetColor(idxColor);
	
	// on trace le trait
	pDraw->MoveTo(Ph.x, Ph.y);
	pDraw->LineTo(Pb.x, Pb.y);
}

void CEtatDeSortie::TraitVDfull(JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long PDebut, long PFin, long linewidth, long idxColor)
{
	CPoint Ph, Pb;
	Ph=CalcPointMilieuD(&CalcRect(pR_haut, PDebut, PFin));
	Pb=CalcPointMilieuD(&CalcRect(pR_bas, PDebut, PFin));
	Ph.y=pR_haut->top;
	Pb.y=pR_bas->bottom;
	
	// on teste la couleur
	if (idxColor >= 0) pDraw->SetColor(idxColor);
	
	// on trace le trait
	pDraw->MoveTo(Ph.x, Ph.y);
	pDraw->LineTo(Pb.x, Pb.y);
}

// les fonctions pour �crire du texte:
//------------------------------------
void CEtatDeSortie::EcritG(JFCDraw * pDraw, const CString & txt, CRect * pR, long PDebut, long PFin, long Offset, long idxFont, long idxTextColor)
{

	// test si zone �criture Ok
	if (PFin > PDebut)
	{

	// on teste l'indice de la police
	if (idxFont >= 0) pDraw->SetFont(idxFont);

	// on teste la couleur du texte
	if (idxTextColor >= 0) pDraw->SetColor(idxTextColor);

	CRect R=*pR;
	R.left=pR->left+(pR->Width()*Offset/100)+(pR->Width()*PDebut/100);
	R.right=pR->left+(pR->Width()*PFin/100);

	// on d�place le curseur
	pDraw->MoveTo(R.left, R.top + (R.bottom - R.top)/2);

	// on �crit le texte
	pDraw->Text(txt, LEFT, CENTER);
}
}

void CEtatDeSortie::EcritD(JFCDraw * pDraw, const CString & txt, CRect * pR, long PDebut, long PFin, long Offset, long idxFont, long idxTextColor)
{
	// test si zone �criture Ok
	if (PFin > PDebut)
	{
		// on teste l'indice de la police
		if (idxFont >= 0) pDraw->SetFont(idxFont);

		// on teste la couleur du texte
		if (idxTextColor >= 0) pDraw->SetColor(idxTextColor);

		CRect R=*pR;
		R.left=pR->left+(pR->Width()*PDebut/100);
		R.right=pR->left-(pR->Width()*Offset/100)+(pR->Width()*PFin/100);

		// on d�place le curseur
		pDraw->MoveTo(R.right, R.top + (R.bottom - R.top)/2);

		// on �crit le texte
		pDraw->Text(txt, RIGHT, CENTER);
	}
}

void CEtatDeSortie::EcritC(JFCDraw * pDraw, const CString & txt, CRect * pR, long PDebut, long PFin, long idxFont, long idxTextColor)
{
	// test si zone �criture Ok
	if (PFin > PDebut)
	{
		// on teste l'indice de la police
		if (idxFont >= 0) pDraw->SetFont(idxFont);

		// on teste la couleur du texte
		if (idxTextColor >= 0) pDraw->SetColor(idxTextColor);

		CRect R=*pR;
		R.left=pR->left  + (pR->Width() * PDebut / 100);
		R.right=pR->left + (pR->Width() * PFin   / 100);

		// on positionne le curseur
		pDraw->MoveTo(R.left+(R.right - R.left)/2, R.top+(R.bottom - R.top)/2);

		// on �crit le texte
		pDraw->Text(txt, CENTER, CENTER);
	}
}

// la fonction pour dessiner une image:
//-------------------------------------

void CEtatDeSortie::DessineBitmap(JFCDraw * pDraw, const CString & filename, CRect * pR, short PDebut, short PFin)
{
	// on calcule le rectangle en fonction des pourcentages
	CRect R=&CalcRect(pR, PDebut, PFin);

	// on d�place le curseur
	pDraw->MoveTo(R.left, R.top);

	// on dessine le bitmap
	pDraw->SetPicture(filename, R.right-R.left, R.bottom-R.top);	
}

// les fonctions pour g�rer les rectangles:
//-----------------------------------------
void CEtatDeSortie::RemplisRect(JFCDraw * pDraw, CRect * pR, long idxColor, long PDebut, long PFin)
{
	//pDraw->FillRect(&CalcRect(pR, PDebut, PFin), &brush);

	CRect rect = *pR;
	rect.left  += ((pR->right-pR->left)*PDebut) / 100;
	rect.right -= ((pR->right-pR->left)*(100-PFin)) / 100;
	
	pDraw->SetFillColor(idxColor);
	pDraw->BeginPath();
	pDraw->MoveTo(rect.left,  rect.top);
	pDraw->LineTo(rect.right, rect.top);
	pDraw->LineTo(rect.right, rect.bottom);
	pDraw->LineTo(rect.left,  rect.bottom);
	pDraw->LineTo(rect.left,  rect.top);
	pDraw->EndPath();
}

void CEtatDeSortie::ShadowRect(JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long idxColor, long PDebut, long PFin)
{
	// on dessine le cadre
	DessineCadre(pDraw,pR_haut,pR_bas,PDebut,PFin,-1,idxColor);

	CRect r1=CalcRect(pR_haut, PDebut, PFin);
	CRect r2=CalcRect(pR_bas, PDebut, PFin);

	r2.top = (CalcPointMilieuD(&r2)).y;
	r2.bottom = r2.top + m_HLig/8;
	r2.left+=m_HLig/8;
	r2.right+=m_HLig/8;

	RemplisRect(pDraw,&r2,idxColor,0,100);

	r1.top += 5*m_HLig/8;
	r1.bottom = r2.bottom;
	r1.left = r1.right;
	r1.right+=m_HLig/8;

	RemplisRect(pDraw,&r1,idxColor,0,100);
}

void CEtatDeSortie::DessineCadre(JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long PDebut, long PFin, long linewidth, long idxColor)
{
	// on dessine les traits horizontaux
	TraitH(pDraw, pR_haut, PDebut, PFin, linewidth, idxColor);
	TraitH(pDraw, pR_bas,  PDebut, PFin, linewidth, idxColor);

	// on dessine les traits verticaux
	TraitV(pDraw, pR_haut, pR_bas, PDebut, PFin, linewidth, idxColor);
}

void CEtatDeSortie::DessineCadre2(JFCDraw * pDraw, CRect * pR_haut, CRect * pR_bas, long PDebut, long PFin, long linewidth, long idxColor)
{
	CRect r1=CalcRect(pR_haut, PDebut, PFin);
	CRect r2=CalcRect(pR_bas, PDebut, PFin);
	CPoint Ph = CalcPointMilieuD(&r1);
	CRect r=r2;
	r.top=Ph.y;

	// on teste la couleur
	if (idxColor >= 0) pDraw->SetColor(idxColor);

	// on teste la largeur de ligne
	if (linewidth >= 0) pDraw->SetLineWidth(linewidth);

	// on trace le rectangle
	pDraw->MoveTo(r.left,  r.top);
	pDraw->LineTo(r.right, r.top);
	pDraw->LineTo(r.right, r.bottom);
	pDraw->LineTo(r.left,  r.bottom);
	pDraw->LineTo(r.left,  r.top);	
}

// les fonctions de calcul internes:
//----------------------------------
bool CEtatDeSortie::YAPasPLace(short reel,short place)
{
	short r=m_NbLigneCorps-reel;
	if(r<=place)return true;
	else return false;
}

bool CEtatDeSortie::NouvellePage(short &reel)
{
	if(reel>=m_NbLigneCorps){
		reel=0;
		return true;
	}
	else return false;
}


CRect CEtatDeSortie::CalcRect(CRect * pR, long Debut, long Fin)
{
	CRect R=*pR;
	R.left=pR->left+(pR->Width()*Debut/100);
	R.right=pR->left+(pR->Width()*Fin/100);
	return R;
}

CPoint CEtatDeSortie::CalcPointMilieuG(CRect * pR)
{
	CPoint pt(pR->left, pR->top+pR->Height()/2);
	return pt;
}

CPoint CEtatDeSortie::CalcPointMilieuD(CRect * pR)
{
	CPoint pt(pR->right, pR->top+pR->Height()/2);
	return pt;
}

long CEtatDeSortie::CalculNbPage()
{
	// on teste le nombre de tableaux
	if(!m_Init.m_InfoTab.GetSize())
	{
		return (1);
	}

	// 
	SMappTab M;
	short reel=0, tab=0, stab=0, lig=0;
	short i,idx=0, MemoLigCorps=0,MemoLigDebut,place,memoidx,ligdebut;
	bool fCoupureCorps=false,fCoupureColonne=false;
	bool fNouvellePage;
	m_NbPage=1;
	while(1)
	{
		M.m_Rappel=0;
		M.m_NbLig=0;
		//titre
		lig=0;
		for(i=0 ; i<m_Init.m_InfoTab[tab].m_NbLigneTitre ; i++){
			M.m_Reel=reel++;
			M.m_Tab=tab;
			M.m_Type=PRINT_TITRE;
			M.m_Lig=lig++;
			m_Mapping.Add(M);
		}

		// cas du multicolonne
multicolonne:
		if(fCoupureColonne==false){
			M.m_NrCol=0;
			M.m_NbCol=0;
			MemoLigCorps=0;
		}
		else {
			fCoupureColonne=false;
			M.m_NrCol+=M.m_NbCol;
		}
multicolonne2:
		if(m_Init.m_InfoTab[tab].m_CarColonne.GetSize()>=1){
			int taille=m_Init.m_InfoTab[tab].m_NbCarGauche+m_Init.m_InfoTab[tab].m_NbCarDroit;
			for(i=M.m_NrCol;i<m_Init.m_InfoTab[tab].m_CarColonne.GetSize();i++){
				if(taille+m_Init.m_InfoTab[tab].m_CarColonne[i]>m_NbColPage+1){
					fCoupureColonne=true;
					break;
				}
				taille+=m_Init.m_InfoTab[tab].m_CarColonne[i];
			}
			M.m_NbCol=i-M.m_NrCol;
		}

tete:
		if(m_NbPage>500)
		{
			AfxMessageBox("Cet �tat de sortie est trop volumineux.\nSeul les 500 premi�res pages seront imprim�es.");
			m_NbPage=500;
			break;
		}

		// Tete de tableau
		lig=0;
		MemoLigDebut=reel+1;

		int NbLE = m_Init.m_InfoTab[tab].m_NbLigneTete;

		for(i=0 ; i<m_Init.m_InfoTab[tab].m_NbLigneTete ; i++){
			M.m_Reel=reel++;
			M.m_Tab=tab;
			M.m_Type=PRINT_TETE;
			M.m_Lig=lig++;
			idx=m_Mapping.Add(M);
		}
		
		//corps
		lig=MemoLigCorps;
		fCoupureCorps=false;
		memoidx=-1;
		M.m_NbLig=0;
		for(i=MemoLigCorps ; i<m_Init.m_InfoTab[tab].m_NbLigneCorps ; i+=m_Init.m_InfoTab[tab].m_NbLigneGarantie){
			for(int subline=0;subline<m_Init.m_InfoTab[tab].m_NbLigneGarantie;subline++){
				// on ajoute les lignes par paquets
				M.m_Reel=reel++;
				M.m_Tab=tab;
				M.m_Type=PRINT_CORPS;
				M.m_Lig=lig++;
				idx=m_Mapping.Add(M);
				if(memoidx<0){
					memoidx=idx;
					ligdebut=lig-1;
				}
			}
			if(lig<m_Init.m_InfoTab[tab].m_NbLigneCorps){
				place=m_Init.m_InfoTab[tab].m_NbLignePieds+m_Init.m_InfoTab[tab].m_NbLigneTotal;
				place+=m_Init.m_InfoTab[tab].m_NbLigneGarantie-1;
				if(YAPasPLace(reel,place)){
					place=m_Init.m_InfoTab[tab].m_NbLignePieds;
					place+=m_Init.m_InfoTab[tab].m_NbLigneGarantie-1;
					if(YAPasPLace(reel,place)){
						MemoLigCorps=lig;
						fCoupureCorps=true;
						break;
					}
				}
			}
		}

		// place pour le total ?
		if(i==m_Init.m_InfoTab[tab].m_NbLigneCorps && !fCoupureCorps){
			place=m_Init.m_InfoTab[tab].m_NbLigneTotal;
					if(place!=0 && YAPasPLace(reel,place)){
						MemoLigCorps=lig;
						fCoupureCorps=true;
					}
		}

		// pour le multicolonne (type 1)
		if(memoidx>=0){
			M=m_Mapping[memoidx];
			M.m_NbLig=lig-ligdebut-1;
			m_Mapping.SetAt(memoidx, M);
		}

		//pieds
		lig=0;
		for(i=0 ; i<m_Init.m_InfoTab[tab].m_NbLignePieds ; i++){
			M.m_Reel=reel++;
			M.m_Tab=tab;
			M.m_Type=PRINT_PIEDS;
			M.m_Lig=lig++;
			idx=m_Mapping.Add(M);
		}

		if(fCoupureCorps){
			m_Mapping[idx].m_Rappel=MemoLigDebut;
			
			//  (25/9/00) InterLigne dans les cas des tableaux avec des 
			// garanties; il est possible que le tableau, m�me coup�,
			// n'atteigne pas exactement le bas de la page.
			// Il faut donc dans ce cas ajouter des interlignes
			lig=0;
			while(1){
				if(NouvellePage(reel))break;
				M.m_Reel=reel++;
				M.m_Tab=tab;
				M.m_Type=PRINT_INTERLIGNE;
				M.m_Lig=lig++;
				m_Mapping.Add(M);
			}
			// fin de l'insertion des interlignes (25/9/00)

			m_NbPage++;
			if(fCoupureColonne){
//				MemoLigCorps-=M.m_NbLig;
				MemoLigCorps-=M.m_NbLig+1;
				goto multicolonne;
			}
			else{
				M.m_NrCol=0;
				M.m_NbCol=0;
				goto multicolonne2;
			}
			goto tete;
		}

		//Total
		lig=0;
		for(i=0 ; i<m_Init.m_InfoTab[tab].m_NbLigneTotal ; i++){
			M.m_Reel=reel++;
			M.m_Tab=tab;
			M.m_Type=PRINT_TOTAL;
			M.m_Lig=lig++;
			idx=m_Mapping.Add(M);
		}
		m_Mapping[idx].m_Rappel=MemoLigDebut;
		

		//InterLigne
		lig=0;
		fNouvellePage=0;
		for(i=0 ; i<m_Init.m_InfoTab[tab].m_NbLigneInterLigne ; i++){
			if(NouvellePage(reel)){
				m_NbPage++;
				fNouvellePage=1;
				break; // Fin des interlignes
			}
			M.m_Reel=reel++;
			M.m_Tab=tab;
			M.m_Type=PRINT_INTERLIGNE;
			M.m_Lig=lig++;
			m_Mapping.Add(M);
		}

		if(fCoupureColonne){
			if(fCoupureCorps)	MemoLigCorps=0;
		}
		else{
			tab++; // On passe au tableau suivant
			MemoLigCorps = 0;
			fCoupureColonne = false;
			if(tab>=m_Init.m_InfoTab.GetSize()){
				// Si on avais pr�vue une nouvelle page, on l'annule
				if(fNouvellePage)m_NbPage--;
				break; // Fin
			}
		}

		// le prochain tableau tiend-t-il sur cette page ?
		place=m_Init.m_InfoTab[tab].m_NbLigneTitre+
			  m_Init.m_InfoTab[tab].m_NbLigneTete+
              (m_Init.m_InfoTab[tab].m_NbLigneCorps-MemoLigCorps)+
			  m_Init.m_InfoTab[tab].m_NbLignePieds+
			  m_Init.m_InfoTab[tab].m_NbLigneTotal;
		
		if(YAPasPLace(reel,place) && reel != 0){
			//InterLigne
			lig=0;
			while(1){
				if(NouvellePage(reel))break;
				M.m_Reel=reel++;
				M.m_Tab=tab;
				M.m_Type=PRINT_INTERLIGNE;
				M.m_Lig=lig++;
				m_Mapping.Add(M);
			}
			m_NbPage++;
		}
	} // while(1)

	// Calcul du nombre de pages
	//m_NbPage=1+m_Mapping.GetSize()/m_NbLigneCorps;
	return (m_NbPage);
}

void CEtatDeSortie::Reset()
{
	// on initialise les membres
	m_Orientation  = 0;
	m_NbLignePage  = 0;
	m_NbLigneCorps = 0;
	m_HLig         = 0;
	m_LCol         = 0;
	m_NbColPage    = 0;
	m_NbPage       = 0;
	m_Bitmaps.SetSize(0,1);
	m_Mapping.RemoveAll();
	m_Init.m_InfoTab.RemoveAll();
}