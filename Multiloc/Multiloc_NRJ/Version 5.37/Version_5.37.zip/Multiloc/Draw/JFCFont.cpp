//========================
// fichier: JFCFont.cpp
//
// date: 11/03/2002
// auteur: JB
//------------------------

// on inclut les fichiers n�cessaires
#include "stdafx.h"
#include "JFCFont.h"

// les noms GDI
const char * JFCFont::m_GDITimes     = "times new roman";
const char * JFCFont::m_GDICourier   = "courier new";
const char * JFCFont::m_GDIHelvetica = "helvetica";

// les noms PDF
const char * JFCFont::m_PDFTimes               = "Times-Roman";
const char * JFCFont::m_PDFTimesBold           = "Times-Bold";
const char * JFCFont::m_PDFTimesItalic         = "Times-Italic";
const char * JFCFont::m_PDFTimesBoldItalic     = "Times-BoldItalic";

const char * JFCFont::m_PDFCourier             = "Courier";
const char * JFCFont::m_PDFCourierBold         = "Courier-Bold";
const char * JFCFont::m_PDFCourierItalic       = "Courier-Oblique";
const char * JFCFont::m_PDFCourierBoldItalic   = "Courier-BoldOblique";

const char * JFCFont::m_PDFHelvetica           = "Helvetica";
const char * JFCFont::m_PDFHelveticaBold       = "Helvetica-Bold";
const char * JFCFont::m_PDFHelveticaItalic     = "Helvetica-Oblique";
const char * JFCFont::m_PDFHelveticaBoldItalic = "Helvetica-BoldOblique";

//==========================================================================
// les constructeurs:
//--------------------------------------------------------------------------
JFCFont::JFCFont()
{
	// on initialise les param�tres
	m_Fontname = 4;
	m_Size     = 0;
	m_Bold     = false;
	m_Italic   = false;
}

JFCFont::JFCFont(long fontname, long size, bool bold, bool italic)
{
	// on initialise les param�tres
	m_Fontname = fontname;
	m_Size     = size;
	m_Bold     = bold;
	m_Italic   = italic;
}

//==========================================================================
// le constructeur de recopie:
//--------------------------------------------------------------------------
JFCFont::JFCFont(const JFCFont & source)
{
	// on recopie les param�tres de la source
	m_Fontname = source.m_Fontname;
	m_Size     = source.m_Size;
	m_Bold     = source.m_Bold;
	m_Italic   = source.m_Italic;
}

//==========================================================================
// l'op�rateur d'affectation:
//--------------------------------------------------------------------------
JFCFont & JFCFont::operator = (const JFCFont & operande)
{
	// on teste l'op�rande
	if (&operande != this)
	{
		// on recopie les param�tres de l'op�rande
		m_Fontname = operande.m_Fontname;
		m_Size     = operande.m_Size;
		m_Bold     = operande.m_Bold;
		m_Italic   = operande.m_Italic;
	}
	// on renvoie la r�f�rence
	return (*this);
}

//==========================================================================
// la fonction pour renvoyer le nom de la fonte:
//--------------------------------------------------------------------------
// pour le GDI:
//-------------
const char * JFCFont::GetGDIName()
{
	// on teste le nom de la fonte
	switch (m_Fontname)
	{
	case 0:
		// on renvoie le nom GDI de la fonte Times
		return (m_GDITimes);
	case 1:
		// on renvoie le nom GDI de la fonte Courier
		return (m_GDICourier);
	case 2:
		// on renvoie le nom GDI de la fonte Helvetica
		return (m_GDIHelvetica);
	}
	// on renvoie le code d'erreur
	return (0);
}

// pour le PDF:
//-------------
const char * JFCFont::GetPDFName()
{
	// on teste le nom de la fonte
	switch (m_Fontname)
	{
	case 0:
		// on teste le param�tre de poids
		if (m_Bold)
		{
			if (m_Italic) return (m_PDFTimesBoldItalic);
			else return (m_PDFTimesBold);
		}
		else
		{
			if (m_Italic) return (m_PDFTimesItalic);
			else return (m_PDFTimes);
		}
	case 1:
		// on teste le param�tre de poids
		if (m_Bold)
		{
			if (m_Italic) return (m_PDFCourierBoldItalic);
			else return (m_PDFCourierBold);
		}
		else
		{
			if (m_Italic) return (m_PDFCourierItalic);
			else return (m_PDFCourier);
		}
	case 2:
		// on teste le param�tre de poids
		if (m_Bold)
		{
			if (m_Italic) return (m_PDFHelveticaBoldItalic);
			else return (m_PDFHelveticaItalic);
		}
		else
		{
			if (m_Italic) return (m_PDFHelveticaItalic);
			else return (m_PDFHelvetica);
		}
	}
	// on renvoie le code d'erreur
	return (0);
}

//==========================================================================
// la fonction pour r�cup�rer la taille de la fonte:
//--------------------------------------------------------------------------
long JFCFont::GetSize()
{
	// on renvoie la taille
	return (m_Size);
}

//==========================================================================
// la fonction pour tester le param�tre gras:
//--------------------------------------------------------------------------
bool JFCFont::IsBold()
{
	// on renvoie le param�tre gras
	return (m_Bold);
}

//==========================================================================
// la fonction pour tester le param�tre italique:
//--------------------------------------------------------------------------
bool JFCFont::IsItalic()
{
	// on renvoie la valeur du param�tre italique
	return (m_Italic);
}

//==========================================================================
// le destructeur:
//--------------------------------------------------------------------------
JFCFont::~JFCFont()
{
	// on ne fait rien
}
