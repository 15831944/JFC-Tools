// DataClient.h: interface for the CDataClient class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATACLIENT_H__919877A7_439A_11D4_8658_0080C708A895__INCLUDED_)
#define AFX_DATACLIENT_H__919877A7_439A_11D4_8658_0080C708A895__INCLUDED_

#include "Client.h"	// Added by ClassView

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDataClient  
{
public:
	CDataClient();
	virtual ~CDataClient();
	bool Load();
	CClientArray m_TabClients;
};

#endif // !defined(AFX_DATACLIENT_H__919877A7_439A_11D4_8658_0080C708A895__INCLUDED_)
