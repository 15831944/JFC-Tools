// DlgEditer.cpp : implementation file
//

#include "stdafx.h"
#include "multiloc.h"
#include "multilocdoc.h"
#include "DlgContactCommercial.h"
//#include "DlgEditer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgEditer dialog


CDlgEditer::CDlgEditer(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgEditer::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgEditer)
	m_calendrier = -1;
	m_listevilles = 0;
	m_synthese = -1;
	m_edvillenet = FALSE;
	m_edvillecpm = FALSE;
	m_BonPourAccord = FALSE;
	m_checknetsta = FALSE;
	m_RepartitionMois = FALSE;
	m_checkinforemise = TRUE;
	m_CalendCompact = FALSE;
	m_VilleDepResa = _T("");
	m_NoODP = _T("");
	m_EditGrise = FALSE;
	m_PlanType = FALSE;
	//}}AFX_DATA_INIT
	m_pDoc=NULL;
}


void CDlgEditer::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgEditer)
	DDX_Control(pDX, IDC_N0_ODP, m_BtnODP);
	DDX_Control(pDX, IDC_VILLE_DEP_RESA, m_BtnVilleDepResa);
	DDX_Control(pDX, IDC_CHECKINFOREMISES, m_BtnInfoRemise);
	DDX_Control(pDX, IDC_CHECKNETSTA, m_BtnNetStation);
	DDX_Control(pDX, IDC_CALENDRIERS, m_BtnCalendrier);
	DDX_Control(pDX, IDC_SYNTHESE, m_BtnSynthese);
	DDX_Control(pDX, IDC_LISTEVILLES, m_BtnListeVilles);
	DDX_Control(pDX, IDC_LISTSTATION, m_liststation);
	DDX_Control(pDX, IDC_LISTVILLES, m_listvilles);
	DDX_Radio(pDX, IDC_CALENDRIERS, m_calendrier);
	DDX_Radio(pDX, IDC_LISTEVILLES, m_listevilles);
	DDX_Radio(pDX, IDC_SYNTHESE, m_synthese);
	DDX_Check(pDX, IDC_EDVILLEBNET, m_edvillenet);
	DDX_Check(pDX, IDC_EDVILLECPM, m_edvillecpm);
	DDX_Check(pDX, IDC_CHECK1, m_BonPourAccord);
	DDX_Check(pDX, IDC_CHECKNETSTA, m_checknetsta);
	DDX_Check(pDX, IDC_CHECK_REPARTIMOIS, m_RepartitionMois);
	DDX_Check(pDX, IDC_CHECKINFOREMISES, m_checkinforemise);
	DDX_Check(pDX, IDC_CHECKCALENDCOMPACT, m_CalendCompact);
	DDX_Text(pDX, IDC_VILLE_DEP_RESA, m_VilleDepResa);
	DDX_Text(pDX, IDC_N0_ODP, m_NoODP);
	DDX_Check(pDX, IDC_CHECK_EDITGRISE, m_EditGrise);
	DDX_Check(pDX, IDC_CHECK_PLANTYPE, m_PlanType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgEditer, CDialog)
	//{{AFX_MSG_MAP(CDlgEditer)
	ON_BN_CLICKED(IDC_CALENDRIERS, OnCalendriers)
	ON_BN_CLICKED(IDC_LISTEVILLES, OnListevilles)
	ON_BN_CLICKED(IDC_SYNTHESE, OnSynthese)
	ON_BN_CLICKED(IDC_CHECK_REPARTIMOIS, OnCheckRepartimois)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgEditer message handlers

void CDlgEditer::OnCalendriers() 
{
	UpdateData(true);
	m_calendrier = 0;
	m_listevilles = -1;
	m_synthese = -1;
	UpdateData(false);
}

void CDlgEditer::OnListevilles() 
{
	UpdateData(true);
	m_calendrier = -1;
	m_listevilles = 0;
	m_synthese = -1;
	UpdateData(false);
}

void CDlgEditer::OnSynthese() 
{
	UpdateData(true);
	m_calendrier = -1;
	m_listevilles = -1;
	m_synthese = 0;
	UpdateData(false);
}

BOOL CDlgEditer::OnInitDialog()
{
	CDialog::OnInitDialog();	
	CMap <short, short, bool,bool> Selection;
	bool x;

	// Attention si processus plan type d�valider cetaines option
	// Seul plan m�dia possible
	//if (m_pDoc->NbSpotPlanType() > 0)
	m_PlanType = false;
	if (m_PlanType)
	{
		// Uniquement Calendrier plan type sans info prix
		m_checkinforemise = FALSE;
		m_BtnListeVilles.EnableWindow(FALSE);
		m_BtnSynthese.EnableWindow(FALSE);
		m_BtnCalendrier.EnableWindow(TRUE);
		m_BtnNetStation.EnableWindow(FALSE);
		m_BtnInfoRemise.EnableWindow(FALSE);
		m_BtnVilleDepResa.EnableWindow(FALSE);
		m_BtnODP.EnableWindow(FALSE);
		m_listevilles = -1;
		m_synthese = -1;
		m_calendrier = 0;
	}		
	else
	{
		// Revenir � toutes les options possibles
		m_BtnListeVilles.EnableWindow(TRUE);
		m_BtnSynthese.EnableWindow(TRUE);
		m_BtnCalendrier.EnableWindow(TRUE);
		m_BtnNetStation.EnableWindow(TRUE);
		m_BtnInfoRemise.EnableWindow(TRUE);
		m_BtnVilleDepResa.EnableWindow(TRUE);
		m_BtnODP.EnableWindow(TRUE);
		m_listevilles = 0;
		m_synthese = -1;
		m_calendrier = -1;
		m_checkinforemise = TRUE;
	}		

	// edition calendrier mensuel
	m_RepartitionMois = FALSE;

	// Infos panneau remise  
	//m_checkinforemise = TRUE;

	// Par d�faut, �dition calendrier compact�e
	m_CalendCompact = TRUE;

	for(short i=0 ; i<m_pDoc->m_NbStationVille ; i++){
		if(Selection.Lookup(m_pDoc->m_idxStation[i], x))	continue;
		Selection.SetAt(m_pDoc->m_idxStation[i], true);
		m_liststation.AddString(m_pDoc->m_pNoyau->m_TblStation[m_pDoc->m_idxStation[i]].m_Libelle);
	}
	Selection.RemoveAll();
	for(i=0 ; i<m_pDoc->m_NbStationVille ; i++){
		if(Selection.Lookup(m_pDoc->m_pNoyau->m_pTblVille[m_pDoc->m_idxStation[i]][m_pDoc->m_idxVille[i]].m_NrUnique, x))	continue;
		Selection.SetAt(m_pDoc->m_pNoyau->m_pTblVille[m_pDoc->m_idxStation[i]][m_pDoc->m_idxVille[i]].m_NrUnique, true);
		m_listvilles.AddString(m_pDoc->m_pNoyau->m_pTblVille[m_pDoc->m_idxStation[i]][m_pDoc->m_idxVille[i]].m_Libelle);
	}

	// Par d�faut Edition en gris�
	m_EditGrise = true;

	// N� ODP
	if (m_pDoc->m_NumODP != "")
	{
		// No d'ODP d�j� attribu� (depuis Version 15 Doc)
		m_NoODP = m_pDoc->m_NumODP; 
		m_BtnODP.EnableWindow(FALSE); 
	}
	else
		// pour les anciennes versions on autorise l'entr�e manuelle
		m_BtnODP.EnableWindow(TRUE); 

	UpdateData(false);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgEditer::OnOK() 
{
	// on met � jour le vecteur des idxStation et idxVille
	// avec le filtre station-ville d'impression

	int nb,*sel;
	CMap <int, int, bool,bool> SelStation,SelVille;
	bool fStation=true,fVille=true,b;


	// Test info spots
	//m_pDoc->RecupInfoSpots();


	// Boite de dialogue infos commercial si synthese demand�e
	CDlgContactCommercial DlgCommercial;
	if (m_synthese == 0)	DlgCommercial.DoModal();

	
	// le filtre sur les stations
	nb=m_liststation.GetSelCount();
	if(nb<=0){
		// toutes les stations sont valides
		fStation=false;
	}
	else {
		sel = (int*)malloc(sizeof(int)*nb);
		m_liststation.GetSelItems(nb,sel);
		for(int i=0;i<nb;i++){
			CString lib;
			m_liststation.GetText(sel[i],lib);
			for(int z=0;z<m_pDoc->m_pNoyau->m_TblStation.GetSize();z++){
				if(lib==m_pDoc->m_pNoyau->m_TblStation[z].m_Libelle){
					SelStation.SetAt(m_pDoc->m_pNoyau->m_TblStation[z].m_NrUnique,true);
					break;
				}
			}
		}

		free(sel);
	}

	// le filtre sur les villes
	nb=m_listvilles.GetSelCount();
	if(nb<=0){
		// toutes les stations sont valides
		fVille=false;
	}
	else {
		sel = (int*)malloc(sizeof(int)*nb);
		m_listvilles.GetSelItems(nb,sel);
		for(int i=0;i<nb;i++)
		{
			CString lib;
			m_listvilles.GetText(sel[i],lib);

			for(int z=0;z<m_pDoc->m_pNoyau->m_Ville.GetSize();z++)
			{

				CString libVille =m_pDoc->m_pNoyau->m_Ville[z].m_Libelle;
	
				if(lib==m_pDoc->m_pNoyau->m_Ville[z].m_Libelle)
				{
					int noville = m_pDoc->m_pNoyau->m_Ville[z].m_NrUnique;

					SelVille.SetAt(m_pDoc->m_pNoyau->m_Ville[z].m_NrUnique,true);
					break;
				}
			}
		}
		free(sel);
	}

	// reconstruction du nouveau vecteur
	nb=0;
	for(short i=0 ; i<m_pDoc->m_NbStationVille ; i++){
		if(fStation){
			int nr=m_pDoc->m_pNoyau->m_TblStation[m_pDoc->m_idxStation[i]].m_NrUnique;
			if(!SelStation.Lookup(nr,b))continue;
		}
		if(fVille){
			int nr=m_pDoc->m_pNoyau->m_pTblVille[m_pDoc->m_idxStation[i]][m_pDoc->m_idxVille[i]].m_NrUnique;
			if(!SelVille.Lookup(nr,b))continue;
		}

		// OK on le prend
		m_pDoc->m_idxStationPrint[nb]=m_pDoc->m_idxStation[i];
		m_pDoc->m_idxVillePrint[nb]=m_pDoc->m_idxVille[i];
		nb++;
	}

	m_pDoc->m_NbStationVillePrint=nb;
	//if(!nb)CDialog::OnCancel();
	if(!nb)
	{
		CDialog::OnCancel();
		return;
	}

	CDialog::OnOK();
}

void CDlgEditer::OnCheckRepartimois() 
{
	// TODO: Add your control notification handler code here
	//UpdateData(false);
	
}

void CDlgEditer::OnPdf() 
{
	// TODO: Add your control notification handler code here
	
}
