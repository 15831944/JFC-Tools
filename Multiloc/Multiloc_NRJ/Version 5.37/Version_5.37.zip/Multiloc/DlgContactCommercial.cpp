// DlgContactCommercial.cpp : implementation file
//

#include "stdafx.h"
#include "multiloc.h"
#include "DlgContactCommercial.h"
#include <direct.h>

extern CMultilocApp theApp;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgContactCommercial dialog


CDlgContactCommercial::CDlgContactCommercial(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgContactCommercial::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgContactCommercial)
	//}}AFX_DATA_INIT
}


void CDlgContactCommercial::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgContactCommercial)
	DDX_Control(pDX, IDC_EDIT_VALIDITEDEVIS, m_ValiditeDevis);
	DDX_Control(pDX, IDC_EDIT_NVDATECOMM, m_EditNvDateComm);
	DDX_Control(pDX, IDC_EDIT_ANNULEREMPLACE, m_EditAnnuleRemplace);
	DDX_Control(pDX, IDC_EDIT_TELCOMMERCIAL, m_TelCommercial);
	DDX_Control(pDX, IDC_EDIT_NOMCOMMERCIAL, m_NomCommercial);
	DDX_Control(pDX, IDC_EDIT_EMAILCOMMERCIAL, m_EmailCommercial);
	DDX_Control(pDX, IDC_EDIT_FAXCOMMERCIAL, m_FaxCommercial);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgContactCommercial, CDialog)
	//{{AFX_MSG_MAP(CDlgContactCommercial)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgContactCommercial message handlers

void CDlgContactCommercial::OnOK() 
{
	CString txt;

	char tampon[100];
	CString DefaultTxt;
	_getcwd(tampon,100);
	DefaultTxt=tampon;

	// Stockage Infos Commercial courant
	m_NomCommercial.GetWindowText(DefaultTxt);
	WriteProfileString("Configuration", "Nom_Commercial", DefaultTxt);
	theApp.m_NomCommercial=DefaultTxt;
			
	m_TelCommercial.GetWindowText(DefaultTxt);
	WriteProfileString("Configuration", "Tel_Commercial", DefaultTxt);
	theApp.m_TelCommercial=DefaultTxt;
	
	m_FaxCommercial.GetWindowText(DefaultTxt);
	WriteProfileString("Configuration", "Fax_Commercial", DefaultTxt);
	theApp.m_FaxCommercial=DefaultTxt;

	m_EmailCommercial.GetWindowText(DefaultTxt);
	WriteProfileString("Configuration", "Email_Commercial", DefaultTxt);
	theApp.m_EmailCommercial=DefaultTxt;

	// Recup date validit� devis
	m_ValiditeDevis.GetWindowText(DefaultTxt);
	theApp.m_ValiditeDevis = DefaultTxt;

	// Recup nvlle dates communication perso
	m_EditAnnuleRemplace.GetWindowText(theApp.m_AnnuleRemplaceDateComm);
	m_EditNvDateComm.GetWindowText(theApp.m_NvDateComm);
		
	CDialog::OnOK();
}

void CDlgContactCommercial::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}

BOOL CDlgContactCommercial::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_NomCommercial.SetWindowText(theApp.m_NomCommercial);
	m_TelCommercial.SetWindowText(theApp.m_TelCommercial);
	m_FaxCommercial.SetWindowText(theApp.m_FaxCommercial);
	m_EmailCommercial.SetWindowText(theApp.m_EmailCommercial);

	m_EditAnnuleRemplace.SetWindowText("");
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
