// Commercial.h: interface for the CCommercial class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COMMERCIAL_H__9F1381A1_4399_11D4_8658_0080C708A895__INCLUDED_)
#define AFX_COMMERCIAL_H__9F1381A1_4399_11D4_8658_0080C708A895__INCLUDED_

#include "TblCommercial.h"	// Added by ClassView
#include <afxtempl.h>		// MFC template library

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CCommercial  
{
public:
	long m_NumCommercial;
	CString m_Nom;
	CString m_Fax;
	CString m_Tel;
	CString m_Email;
	CString m_Code;
	CString m_Commentaire;

	CCommercial();
	virtual ~CCommercial();

	CCommercial & operator=(const CCommercial &Source);
	CCommercial & operator=(const CTblCommercial &Source);
	bool operator<(const CCommercial &Source);
	
};

typedef CArray<CCommercial,CCommercial&> CCommercialArray;

#endif // !defined(AFX_COMMERCIAL_H__9F1381A1_4399_11D4_8658_0080C708A895__INCLUDED_)

