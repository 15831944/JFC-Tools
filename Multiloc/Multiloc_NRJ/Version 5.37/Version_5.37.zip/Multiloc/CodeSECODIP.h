// CodeSECODIP.h: interface for the CCodeSECODIP class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CODESECODIP_H__19060BA1_B34C_11D4_BA4F_00D0592329A7__INCLUDED_)
#define AFX_CODESECODIP_H__19060BA1_B34C_11D4_BA4F_00D0592329A7__INCLUDED_

#include "TblCodeSecodip.h"
#include <afxtempl.h>		// MFC template library

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCodeSECODIP  
{
public:
	CCodeSECODIP();
	virtual ~CCodeSECODIP();

	long	m_NumCode;
	CString	m_NomProduit;
	CString	m_CodeSecodip;
	CString	m_SecteurActiv;

	CCodeSECODIP & operator=(const CCodeSECODIP &Source);
	CCodeSECODIP & operator=(const CTblCodeSecodip &Source);
	bool operator<(const CCodeSECODIP &Source);

};

typedef CArray<CCodeSECODIP,CCodeSECODIP&> CCCodeSECODIPArray;

#endif // !defined(AFX_CODESECODIP_H__19060BA1_B34C_11D4_BA4F_00D0592329A7__INCLUDED_)
