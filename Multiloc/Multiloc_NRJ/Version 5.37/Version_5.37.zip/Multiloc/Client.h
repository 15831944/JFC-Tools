// Client.h: interface for the CClient class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CLIENT_H__9F1381A0_4399_11D4_8658_0080C708A895__INCLUDED_)
#define AFX_CLIENT_H__9F1381A0_4399_11D4_8658_0080C708A895__INCLUDED_

#include "TblClient.h"
#include <afxtempl.h>		// MFC template library

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CClient  
{
public:
	long m_NumClient;
	CString m_Nom;
	CString m_Fax;
	CString m_Email;
	CString m_Contact;
	long m_CodePostal;
	CString m_Code;
	CString m_Adresse;
	CString m_Ville;
	CString m_Tel;
	CString m_Commentaire;
	double	m_AvoirClient;

	CClient();
	virtual ~CClient();

	CClient & operator=(const CClient &Source);
	CClient & operator=(const CTblClient &Source);
	bool operator<(const CClient &Source);

};

typedef CArray<CClient,CClient&> CClientArray;

#endif // !defined(AFX_CLIENT_H__9F1381A0_4399_11D4_8658_0080C708A895__INCLUDED_)
