// CascadeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "multiloc.h"
#include "MultilocDoc.h"
//#include "CascadeDlg.h"
extern CMultilocApp theApp;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCascadeDlg dialog


CCascadeDlg::CCascadeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCascadeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCascadeDlg)
	m_checknegociation = FALSE;
	m_checkprimeanticipation = FALSE;
	m_coeffremise = TAUXREMISEMANDATS;
	m_coefftotal = 0.0f;
	m_coeffnegociation = 0.0f;
	m_datediffusion = COleDateTime::GetCurrentTime();
	m_TauxDeRegie = 30.0f;
	m_primeanticipation = TAUXANTICIPATION;
	m_coeffNbMessages = 0.0f;
	m_coeffAbattements = 0.0f;
	m_coeffDegressif = 0.0f;
	m_totalnetnet = 0.0;
	m_totalnet = 0.0;
	m_totalcabrut = 0.0;
	m_totalbrut = 0.0;
	m_brut = 0.0;
	m_brutht = 0.0;
	m_FraisDuplication = 0.0;
	m_TotalFraisAnnonce = 0.0;
	m_checkfraisannoncemanuel = FALSE;
	m_fraisannoncereel = _T("");
	m_coeffremiseauto = 0.0f;
	m_checkcumulmandatmanuel = FALSE;
	m_cumulmandat = _T("");
	m_checkremiseSigEtGC = FALSE;
	m_coeffFrequence = 0.0f;
	m_FraisAcheminementRepiquage = 0.0;
	m_FraisAcheminement = 0.0;
	m_FraisRepiquage = 0.0;
	m_fraisannoncefloating = _T("");
	m_fraisannonceclassique = _T("");
	m_coeffSigEtGC = 0.0f;
	m_checkprofessionnelle = FALSE;
	m_remiseprofessionnelle = 0.0f;
	m_checkremisefrequence = FALSE;
	m_coeffrenouvellement = 0.0f;
	m_checkrenouvellement = FALSE;
	m_coeffMvOuOffreGlob = 0.0f;
	m_checkparrainage = FALSE;
	m_checkproductionpub = FALSE;
	m_checkoffreglobale = FALSE;
	m_checkremisemultivilles = FALSE;
	m_TotRemiseCouplage = 0.0f;
	m_brutremisecouplage = 0.0f;
	m_checkhorsmedia = FALSE;
	m_checkremisenatiocal = FALSE;
	m_checkremiserenfort = FALSE;
	m_pDoc= NULL;
	m_coeffremisenatiocal = 0.0f;
	m_coeffremiserenfort = 0.0f;
	//}}AFX_DATA_INIT

	m_pDoc=NULL;
	if (theApp.m_MultilocRegion == 0)
	{
		Create(IDD_CASCADE);
	}
	
}

CCascadeDlg::~CCascadeDlg()
{
	DestroyWindow();
}

void CCascadeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCascadeDlg)
	DDX_Control(pDX, IDC_CHECKREMISERENFORT, m_CtrlCheckRemiseRenfort);
	DDX_Control(pDX, IDC_CHECKREMISENATIOCAL, m_CtrlCheckRemiseNatiocal);
	DDX_Control(pDX, IDC_CHECKHORSMEDIA, m_CtrCheckHorsMedia);
	DDX_Control(pDX, IDC_CHECKPRODPUB, m_CtrlCheckProductionPub);
	DDX_Control(pDX, IDC_CHECKPARRAINAGE, m_CtrlCheckParrainage);
	DDX_Control(pDX, IDC_CHECKREMISEMULTIVILLES, m_CtrlRemiseMultiVilles);
	DDX_Control(pDX, IDC_CHECKOFFREGLOBALE, m_CtrlOffreGlobale);
	DDX_Control(pDX, IDC_COMBORENOUVELLEMENT, m_combocoeffrenouvellement);
	DDX_Control(pDX, IDC_CHECKRENOUVELLEMENT, m_CtrCheckRenouvellement);
	DDX_Control(pDX, IDC_CHECKREMISEFREQUENCE, m_CtrlCheckRemiseFrequence);
	DDX_Control(pDX, IDC_FRAISANNONCEREELCLASSIQUE, m_CtrlFraisAnnonceClassique);
	DDX_Control(pDX, IDC_FRAISANNONCEREELFLOATING, m_CtrlFraisAnnonceFloating);
	DDX_Control(pDX, IDC_COMBO_COEFFMISEENONDE, m_combocoeffmiseenonde);
	DDX_Control(pDX, IDC_TXTDEVISE8, m_TxtDevise8);
	DDX_Control(pDX, IDC_TXTDEVISE7, m_TxtDevise7);
	DDX_Control(pDX, IDC_TXTDEVISE6, m_TxtDevise6);
	DDX_Control(pDX, IDC_TXTDEVISE5, m_TxtDevise5);
	DDX_Control(pDX, IDC_TXTDEVISE4, m_TxtDevise4);
	DDX_Control(pDX, IDC_TXTDEVISE3, m_TxtDevise3);
	DDX_Control(pDX, IDC_TXTDEVISE2, m_TxtDevise2);
	DDX_Control(pDX, IDC_TXTDEVISE1, m_TxtDevise1);
	DDX_Control(pDX, IDC_EDITCOEFFSIGETGC, m_EditRemiseSigEtGC);
	DDX_Control(pDX, IDC_CHECKSIGGRANDESCAUSES, m_CtrlcheckremiseSigetGC);
	DDX_Control(pDX, IDC_COEFFREMISE, m_editcoeffremise);
	DDX_Control(pDX, IDC_FRAISANNONCE, m_EditFraisAnnonce);
	DDX_Check(pDX, IDC_CHECKNEGOCIATION, m_checknegociation);
	DDX_Text(pDX, IDC_COEFFREMISE, m_coeffremise);
	DDV_MinMaxFloat(pDX, m_coeffremise, 0.f, 100.f);
	DDX_Text(pDX, IDC_COEFFTOTAL, m_coefftotal);
	DDV_MinMaxFloat(pDX, m_coefftotal, 0.f, 100.f);
	DDX_Text(pDX, IDC_COEFFNEGOCIATION, m_coeffnegociation);
	DDV_MinMaxFloat(pDX, m_coeffnegociation, 0.f, 100.f);
	DDX_DateTimeCtrl(pDX, IDC_DATETIMEPICKER, m_datediffusion);
	DDX_Text(pDX, IDC_EDIT_TAUXDEREGIE, m_TauxDeRegie);
	DDV_MinMaxFloat(pDX, m_TauxDeRegie, 0.f, 100.f);
	DDX_Text(pDX, IDC_REMISEMESSAGE, m_coeffNbMessages);
	DDX_Text(pDX, IDC_COEFFABATTEMENT, m_coeffAbattements);
	DDV_MinMaxFloat(pDX, m_coeffAbattements, 0.f, 100.f);
	DDX_Text(pDX, IDC_REMISEFINANCIERE, m_coeffDegressif);
	DDV_MinMaxFloat(pDX, m_coeffDegressif, 0.f, 100.f);
	DDX_Text(pDX, IDC_TOTALNETNET, m_totalnetnet);
	DDX_Text(pDX, IDC_TOTALNET, m_totalnet);
	DDX_Text(pDX, IDC_TOTALCABRUT, m_totalcabrut);
	DDX_Text(pDX, IDC_TOTALBRUT, m_totalbrut);
	DDX_Text(pDX, IDC_BRUT, m_brut);
	DDX_Text(pDX, IDC_BRUTHT, m_brutht);
	DDV_MinMaxDouble(pDX, m_brutht, 0., 9999999.);
	DDX_Text(pDX, IDC_FRAIS_DUPLICATION, m_FraisDuplication);
	DDV_MinMaxDouble(pDX, m_FraisDuplication, 0., 9999999.);
	DDX_Text(pDX, IDC_FRAISANNONCE, m_TotalFraisAnnonce);
	DDV_MinMaxDouble(pDX, m_TotalFraisAnnonce, 0., 9999999.);
	DDX_Check(pDX, IDC_CHECK_FRAISANNONCEMANUEL, m_checkfraisannoncemanuel);
	DDX_Text(pDX, IDC_FRAISANNONCEREEL, m_fraisannoncereel);
	DDX_Text(pDX, IDC_COEFFREMISEAUTO, m_coeffremiseauto);
	DDV_MinMaxFloat(pDX, m_coeffremiseauto, 0.f, 100.f);
	DDX_Check(pDX, IDC_CHECK_CUMULMANDATMANUEL, m_checkcumulmandatmanuel);
	DDX_Text(pDX, IDC_CUMULMANDAT, m_cumulmandat);
	DDX_Check(pDX, IDC_CHECKSIGGRANDESCAUSES, m_checkremiseSigEtGC);
	DDX_Text(pDX, IDC_REMISEFREQUENCE, m_coeffFrequence);
	DDX_Text(pDX, IDC_FRAIS_ACHEM_REPIQ, m_FraisAcheminementRepiquage);
	DDX_Text(pDX, IDC_FRAIS_ACHEMINEMENT, m_FraisAcheminement);
	DDX_Text(pDX, IDC_FRAIS_REPIQUAGE, m_FraisRepiquage);
	DDX_Text(pDX, IDC_FRAISANNONCEREELFLOATING, m_fraisannoncefloating);
	DDX_Text(pDX, IDC_FRAISANNONCEREELCLASSIQUE, m_fraisannonceclassique);
	DDX_Text(pDX, IDC_COEFFSIGETGC, m_coeffSigEtGC);
	DDV_MinMaxFloat(pDX, m_coeffSigEtGC, 0.f, 100.f);
	DDX_Check(pDX, IDC_CHECKPROFESSIONNELLE, m_checkprofessionnelle);
	DDX_Text(pDX, IDC_REMISEPROFESSIONNELLE, m_remiseprofessionnelle);
	DDX_Check(pDX, IDC_CHECKREMISEFREQUENCE, m_checkremisefrequence);
	DDX_Check(pDX, IDC_CHECKRENOUVELLEMENT, m_checkrenouvellement);
	DDX_Text(pDX, IDC_REMISEMV_OU_OFFREGLOB, m_coeffMvOuOffreGlob);
	DDV_MinMaxFloat(pDX, m_coeffMvOuOffreGlob, 0.f, 100.f);
	DDX_Check(pDX, IDC_CHECKPARRAINAGE, m_checkparrainage);
	DDX_Check(pDX, IDC_CHECKPRODPUB, m_checkproductionpub);
	DDX_Check(pDX, IDC_CHECKOFFREGLOBALE, m_checkoffreglobale);
	DDX_Check(pDX, IDC_CHECKREMISEMULTIVILLES, m_checkremisemultivilles);
	DDX_Text(pDX, IDC_REMISECOUPLAGE, m_TotRemiseCouplage);
	DDX_Text(pDX, IDC_TOTALREMISECOUPL, m_brutremisecouplage);
	DDX_Check(pDX, IDC_CHECKHORSMEDIA, m_checkhorsmedia);
	DDX_Check(pDX, IDC_CHECKREMISENATIOCAL, m_checkremisenatiocal);
	DDX_Check(pDX, IDC_CHECKREMISERENFORT, m_checkremiserenfort);
	DDX_Text(pDX, IDC_COEFFREMISENATIOCAL, m_coeffremisenatiocal);
	DDX_Text(pDX, IDC_COEFFREMISERENFORT, m_coeffremiserenfort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCascadeDlg, CDialog)
	//{{AFX_MSG_MAP(CCascadeDlg)
	ON_BN_CLICKED(IDC_CHECKNEGOCIATION, OnChecknegociation)
	ON_EN_CHANGE(IDC_BRUTHT, OnChangeBrutht)
	ON_EN_CHANGE(IDC_COEFFNEGOCIATION, OnChangeCoeffnegociation)
	ON_EN_CHANGE(IDC_COEFFREMISE, OnChangeCoeffremise)
	ON_EN_CHANGE(IDC_EDIT_TAUXDEREGIE, OnChangeEditTauxderegie)
	ON_EN_CHANGE(IDC_FRAISANNONCE, OnChangeFraisannonce)
	ON_EN_CHANGE(IDC_FRAIS_DUPLICATION, OnChangeFraisDuplication)
	ON_BN_CLICKED(IDC_CHECK_FRAISANNONCEMANUEL, OnCheckFraisannoncemanuel)
	ON_BN_CLICKED(IDC_CHECK_CUMULMANDATMANUEL, OnCheckCumulmandatmanuel)
	ON_BN_CLICKED(IDC_CHECKSIGGRANDESCAUSES, OnChecksiggrandescauses)
	ON_BN_CLICKED(IDC_CHECKREMISEMULTIVILLES, OnCheckremisemultivilles)
	ON_BN_CLICKED(IDC_CHECKOFFREGLOBALE, OnCheckoffreglobale)
	ON_BN_CLICKED(IDC_CHECKPRODPUB, OnCheckprodpub)
	ON_BN_CLICKED(IDC_CHECKPARRAINAGE, OnCheckparrainage)
	ON_BN_CLICKED(IDC_CHECKREMISEFREQUENCE, OnCheckremisefrequence)
	ON_BN_CLICKED(IDC_CHECKPROFESSIONNELLE, OnCheckprofessionnelle)
	ON_BN_CLICKED(IDC_CHECKRENOUVELLEMENT, OnCheckrenouvellement)
	ON_CBN_SELCHANGE(IDC_COMBORENOUVELLEMENT, OnSelchangeComborenouvellement)
	ON_CBN_SELCHANGE(IDC_COMBO_COEFFMISEENONDE, OnSelchangeComboCoeffmiseenonde)
	ON_CBN_EDITCHANGE(IDC_COMBO_COEFFMISEENONDE, OnEditchangeComboCoeffmiseenonde)
	ON_CBN_EDITUPDATE(IDC_COMBO_COEFFMISEENONDE, OnEditupdateComboCoeffmiseenonde)
	ON_EN_CHANGE(IDC_FRAIS_ACHEM_REPIQ, OnChangeFraisAchemRepiq)
	ON_EN_CHANGE(IDC_FRAIS_ACHEMINEMENT, OnChangeFraisAcheminement)
	ON_EN_CHANGE(IDC_FRAIS_REPIQUAGE, OnChangeFraisRepiquage)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_CHECKHORSMEDIA, OnCheckhorsmedia)
	ON_BN_CLICKED(IDC_CHECKREMISERENFORT, OnCheckremiserenfort)
	ON_BN_CLICKED(IDC_CHECKREMISENATIOCAL, OnCheckremisenatiocal)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCascadeDlg message handlers
BOOL CCascadeDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// Remplissage Coeff frais annonce classique
	m_combocoeffmiseenonde.AddString("2,4 euros"); 
	m_combocoeffmiseenonde.AddString("1,3 euros"); 
	m_combocoeffmiseenonde.AddString("0,85 euros"); 

	// Par d�faut on affiche le 1er �l�ment co�t le plus cher par spot
	m_combocoeffmiseenonde.SetCurSel(0);

	// Remplissage Coeff Remise Renouvellement (de 1% � 5%)
	for (int i=1;i<6;i++)
	{
		CString Coeff;
		Coeff.Format("%d",i);
		m_combocoeffrenouvellement.AddString(Coeff);
	}
	m_combocoeffrenouvellement.SetCurSel(0);

	
	// Par d�faut on met les frais d'annonce en mode classique
	m_CtrlFraisAnnonceClassique.EnableWindow(TRUE);
	m_fraisannonceclassique = "* Frais Classique = ";
	m_CtrlFraisAnnonceFloating.EnableWindow(FALSE);
	m_fraisannoncefloating  = "* Frais Floating  = ";
	
	UpdateAffichage(true);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCascadeDlg::Activate(CMultilocDoc * pDoc,float budget, COleDateTime * date)
{
	if(pDoc)m_pDoc=pDoc;

	theApp.JoueMusic(4);
	ShowWindow(SW_SHOW);
	UpdateCascade(budget, date);
	return;
}

float CCascadeDlg::UpdateCascade(float budget, COleDateTime * date)
{
	float m_totalEnEuro;
	float m_totalEnEuro2;
	
	if(!m_pDoc)	return 0;

	if (m_pDoc->m_ModeTarif == 0 || m_pDoc->m_ModeContratFidelite != 0)
	{
		// frais annonce classique ou Contrat Fid�lit�
		m_combocoeffmiseenonde.EnableWindow(TRUE);
		m_CtrlFraisAnnonceClassique.EnableWindow(TRUE);
		m_CtrlFraisAnnonceFloating.EnableWindow(FALSE);
	}
	else
	{
		// en floating pas de combo coeff frais antenne
		m_combocoeffmiseenonde.EnableWindow(FALSE);
		m_CtrlFraisAnnonceFloating.EnableWindow(TRUE);
		m_CtrlFraisAnnonceClassique.EnableWindow(FALSE);
	}

	// Inhiber la remise Frequence et la remise renouvellement si non contrat fid�lit�
	if (m_pDoc->m_ModeContratFidelite == 0)
	{
		m_CtrlCheckRemiseFrequence.EnableWindow(FALSE);
		m_CtrCheckRenouvellement.EnableWindow(FALSE);
		m_combocoeffrenouvellement.EnableWindow(FALSE);
	}
	else
	{
		m_CtrlCheckRemiseFrequence.EnableWindow(TRUE);
		m_CtrCheckRenouvellement.EnableWindow(TRUE);
		m_combocoeffrenouvellement.EnableWindow(TRUE);
	}

	// Multi-villes ou Offre Globale
	if (m_checkremisemultivilles == TRUE)
		m_checkoffreglobale = FALSE;
	else if (m_checkoffreglobale == TRUE)
		m_checkremisemultivilles = FALSE;


	if(budget>=0)	m_brut=m_totalcabrut=budget;

	if(date!=NULL)	m_datediffusion=*date;
	UpdateAffichage(false);


	if(m_pDoc->m_NbSpotCascade>0)
	{
		int NbSpotMoyen=m_pDoc->m_NbSpotCascade/m_pDoc->m_NbStationVilleCascade;
		m_coeffNbMessages=m_pDoc->m_pNoyau->DonneRemiseSpot(0,NbSpotMoyen);
	}
	else m_coeffNbMessages=0.0f;

	// Attention si total d�j� converti en francs	
	m_totalEnEuro = m_totalbrut;

	// @@@ attention pour remise financi�re ne pas tenir compte de l'historique client
	m_totalEnEuro = m_totalEnEuro - m_brutht;

	// Calcul remise financi�re apres d�duction remise volume
	m_totalEnEuro2   = (float)(m_totalEnEuro * (100.0-m_coeffNbMessages)/100);
	m_totalEnEuro2   -= (float)m_pDoc->m_TotRemCpl;  
	m_coeffDegressif = m_pDoc->m_pNoyau->DonneRemiseFinanciere(0,m_totalEnEuro2,m_pDoc->m_PrixEnEuro,m_pDoc->m_TauxEuroFranc);

	#if(0)
	    // plus de multivilles dans les CGV 2000
		// calcul du nb de villes de - 50000
		CMap <short, short, bool,bool> SelVille;
		for(short i=0 ; i<m_pDoc->m_NbStationVille ; i++){
			if(m_pDoc->m_pNoyau->m_pTblVille[m_pDoc->m_idxStation[i]][m_pDoc->m_idxVille[i]].m_NbHabitantsInsee>=50000)continue;
			// A FAIRE: v�rifier qu'il y a au moins 1 spot non gracieux...

			int nr=m_pDoc->m_pNoyau->m_pTblVille[m_pDoc->m_idxStation[i]][m_pDoc->m_idxVille[i]].m_NrUnique;
			SelVille.SetAt(nr,true);
		}
		if(SelVille.GetCount()>=5)
			m_flagMultiVille=true;
		else
			m_flagMultiVille=false;
	#endif  // plus de multivilles dans les CGV 2000

	m_flagMultiVille=false;

	UpdateAffichage(true);
	return CheckBudgetNet();
}

void CCascadeDlg::UpdateAffichage(bool update)
{
	COleDateTime DateCampagne;
	CCampagne Campagne;
	CString CodeClient;
	double TotalBrutAnneeClient = 0;

	// Titre avec info mode tarif
	CString TitreFen;
	TitreFen = "Cascade de calcul du budget net (CGV 2007) - ";

	if (m_pDoc != NULL)
	{
		if (m_pDoc->m_ModeTarif == 1)
			// Mode floating avec ou sans contrat fid�lit�
			if (m_pDoc->m_ModeContratFidelite == 1)
				TitreFen += " Mode Floating-Jour - Contrat Fidelit� non planifi�";
			else if (m_pDoc->m_ModeContratFidelite == 2)
				TitreFen += " Mode Floating-Jour - Contrat Fidelit� planifi�";
			else
				TitreFen += " Mode Floating-Jour";

		else if (m_pDoc->m_ModeTarif == 2)
			// Mode floating + avec ou sans contrat fid�lit�
			if (m_pDoc->m_ModeContratFidelite == 1)
				TitreFen += " Mode Floating-Semaine - Contrat Fidelit� non planifi�";
			else if (m_pDoc->m_ModeContratFidelite == 2)
				TitreFen += " Mode Floating-Semaine - Contrat Fidelit� planifi�";
			else
				TitreFen += " Mode Floating-Semaine";
		else
			// mode classique avec ou sans contrat fid�lit�
			if (m_pDoc->m_ModeContratFidelite == 1)
				TitreFen += "Contrat Fidelit� non planifi�";
			else if (m_pDoc->m_ModeContratFidelite == 2)
				TitreFen += "Contrat Fidelit� planifi�";
			else
				TitreFen += "Tarification classique";
	}
	this->SetWindowText(TitreFen);
	
	// Mise � jour Devise courante
	MajTxtDevise();

	// Init Coeff Abattement
	m_coeffAbattements = 0.0f;

	// Remise Sig et grandes causes
	m_CtrlcheckremiseSigetGC.EnableWindow(TRUE);
	m_coeffSigEtGC = 40.0f;

	// Remise Compl�mentarit�
	// m_CtrlCheckComplementarite.EnableWindow(TRUE);
	// m_coeffComplementarite = 45.0f;

	// Remise de renfort
	m_CtrlCheckRemiseRenfort.EnableWindow(TRUE);
	m_coeffremiserenfort = 50.0f;

	// Remise Natiocal
	m_CtrlCheckRemiseNatiocal.EnableWindow(TRUE);
	m_coeffremisenatiocal = 50.0f;

	// Affichage montant total remise couplage/triplage
	if (m_pDoc != NULL)
		m_TotRemiseCouplage = m_pDoc->m_TotRemCpl; 

	// Remise Frequence
	if (m_pDoc != NULL)
	{
		if (m_pDoc->m_ModeContratFidelite == 1)
			// Avec contrat fid�lit� non planifi�
			m_coeffFrequence = 5.f;

		else if (m_pDoc->m_ModeContratFidelite == 2)
			// Avec contrat fid�lit� planifi�
			m_coeffFrequence = 10.f;
		else
			// Pas de contrat fid�lit�
			m_coeffFrequence = 0.f;
	}

	if (m_pDoc != NULL)
	{
		if (m_pDoc->m_ModeContratFidelite != 0)
			m_CtrlCheckRemiseFrequence.EnableWindow(TRUE);
		else
			m_CtrlCheckRemiseFrequence.EnableWindow(FALSE);
	}

	if (m_checkremisefrequence == TRUE && m_pDoc->m_ModeContratFidelite != 0)
	{
		// attention remise fr�quence si contrat fid�lit� et tous les couples
		// ont atteint limite spots
		if (InfSpotStationVille(142) == false)
			m_coeffAbattements += m_coeffFrequence;
	}

	if (m_pDoc != NULL)
	{
		if (m_pDoc->m_ModeContratFidelite != 0 || m_pDoc->m_ModeTarif == 0)
		{
			// Remise Offre Gloable ssi offre classique ou Contrat Fid�lit�
			m_CtrlOffreGlobale.EnableWindow(TRUE);
			m_CtrlCheckProductionPub.EnableWindow(TRUE);
			m_CtrCheckHorsMedia.EnableWindow(TRUE);
			//m_CtrlCheckOpeSpeciale.EnableWindow(TRUE);
			m_CtrlCheckParrainage.EnableWindow(TRUE);
			//m_CtrlCheckAchatInternet.EnableWindow(TRUE);
		}
		else
		{
			// � voir mais aussi pour Floating et Floating+
			m_CtrlOffreGlobale.EnableWindow(TRUE);
			m_CtrlCheckProductionPub.EnableWindow(TRUE);
			m_CtrCheckHorsMedia.EnableWindow(TRUE);
			//m_CtrlCheckOpeSpeciale.EnableWindow(TRUE);
			m_CtrlCheckParrainage.EnableWindow(TRUE);
			//m_CtrlCheckAchatInternet.EnableWindow(TRUE);
		}
	}		

	// Calcul Remise Multi-villes ou Offre Globale
	m_coeffMvOuOffreGlob = 0.0;
	CalculRemiseMV_ou_OffreGlobale();   
	if (m_checkremisemultivilles == TRUE || m_checkoffreglobale == TRUE)
		m_coeffAbattements += m_coeffMvOuOffreGlob;

	// Remise professionnelle
	m_remiseprofessionnelle = 12.0f;
	if (m_checkprofessionnelle == TRUE)
		m_coeffAbattements += m_remiseprofessionnelle;
	
	//calcul du Total prime et remise
	m_coefftotal=100.0f;

    // coefficient global des remises couplages
	//float m_coeffremisecouplage = (m_TotRemiseCouplage / m_totalcabrut * 100.0);

	//m_coefftotal -= m_coeffremisecouplage	* m_coefftotal*0.01;
	m_coefftotal -= m_coeffNbMessages       * m_coefftotal*0.01;
	m_coefftotal -= m_coeffDegressif        * m_coefftotal*0.01;

	// remise fr�quence
	if (m_checkremisefrequence == TRUE && m_pDoc->m_ModeContratFidelite != 0)
		if (InfSpotStationVille(142) == false)
			m_coefftotal -= m_coeffFrequence    * m_coefftotal*0.01;

	// remise MV ou Offre globale
	m_coefftotal -= m_coeffMvOuOffreGlob    * m_coefftotal*0.01;

	// remise professionnelle
	if (m_checkprofessionnelle == TRUE)
		m_coefftotal -= m_remiseprofessionnelle * m_coefftotal*0.01;

	m_coefftotal  = 100-m_coefftotal;

	// Limite Coefficient Remise Totale
	if (m_pDoc != NULL)
	{
		if (m_pDoc->m_ModeContratFidelite != 0)
		{
			// Limite Remise Contrat Fid�lit�
			if (InfSpotStationVille(142) == false)
			{	
				// Contrat fid�lit� et limite spot non atteinte pour tous les couples villes
				if (m_pDoc->m_ModeContratFidelite == 1)
				{
					// contrat fid�lit� non planifi�
					if (m_coefftotal > TAUXMAXI_CONTRATFIDELITE_NP) 
						m_coefftotal = TAUXMAXI_CONTRATFIDELITE_NP;
				}
				else if (m_pDoc->m_ModeContratFidelite == 2)
				{
					// contrat fid�lit� planifi�
					if (m_coefftotal > TAUXMAXI_CONTRATFIDELITE_P) 
						m_coefftotal = TAUXMAXI_CONTRATFIDELITE_P;
				}

			}
			else
			{
				// Contrat fid�lit� mais limite spot non atteinte pour tous les couples villes
				if (m_coefftotal > TAUXMAXI_ACHATCLASSIQUE) 
					m_coefftotal = TAUXMAXI_ACHATCLASSIQUE;
			}	
		}
		else
		{
			// Limite Remise Contrat Clasiique
			if (m_coefftotal > TAUXMAXI_ACHATCLASSIQUE) 
				m_coefftotal = TAUXMAXI_ACHATCLASSIQUE;
		}
	}

	// arrondir le coeff au point supp
	m_coefftotal=((int)(0.49999999+m_coefftotal*100))/100.0;

	//Total CA net modif MULTILOC3 (tiens compte des frais annonces spots)
	if(m_checknegociation  || m_checkremiserenfort || m_checkremisenatiocal || m_checkremiseSigEtGC)
	{
	   if (m_checknegociation)
	   {
		   m_totalnet=(m_totalcabrut-m_TotRemiseCouplage)-((m_totalcabrut-m_TotRemiseCouplage)*m_coeffnegociation/100);
	   }
	   else if (m_checkremiserenfort) 
	   {
			m_totalnet=(m_totalcabrut-m_TotRemiseCouplage)-((m_totalcabrut-m_TotRemiseCouplage)*m_coeffremiserenfort/100);
	   }
	   else if (m_checkremisenatiocal) 
	   {
			m_totalnet=(m_totalcabrut-m_TotRemiseCouplage)-((m_totalcabrut-m_TotRemiseCouplage)*m_coeffremisenatiocal/100);
	   }
	   else if (m_checkremiseSigEtGC)
	   {
			//m_totalnet=(int)(0.499999+m_totalcabrut-(m_totalcabrut*m_coeffSigetGC/100));
			m_totalnet=(m_totalcabrut-m_TotRemiseCouplage)-((m_totalcabrut-m_TotRemiseCouplage)*m_coeffSigEtGC/100);
	   }

	  
	}
	else
	{
		//m_totalnet=(int)(0.4999999+m_totalcabrut-(m_totalcabrut*m_coefftotal/100));
		double dbl = m_totalcabrut*m_coefftotal/100;
		m_totalnet=(m_totalcabrut-m_TotRemiseCouplage)-((m_totalcabrut-m_TotRemiseCouplage)*m_coefftotal/100);
	}

	// Remise Renouvellement
	if (m_pDoc != NULL)
	{
		// Positionne check renouvellement
		if (m_pDoc->m_ModeContratFidelite != 0)
			m_CtrCheckRenouvellement.EnableWindow(TRUE);
		else
			m_CtrCheckRenouvellement.EnableWindow(FALSE);

		if (m_checkrenouvellement == TRUE && m_pDoc->m_ModeContratFidelite != 0)
		{
			// R�cup coeff renouvellement en cours
			CString CoeffRenouvellement;
			int CurSel;
			CurSel = m_combocoeffrenouvellement.GetCurSel();
			m_combocoeffrenouvellement.GetLBText(CurSel,CoeffRenouvellement);

			// calcul nouveau total net
			m_coeffrenouvellement = atof(CoeffRenouvellement);

			// On remet la remise renouvellement sur le Net ??? 18/03/2004
			m_totalnet = m_totalnet - (m_totalnet*m_coeffrenouvellement/100);					
		}
	}

	// Calcul Total Net
	m_totalnet = int((m_totalnet+0.005)*100);
	m_totalnet = m_totalnet/100;

	// Total brut
	m_totalbrut=m_brutht+m_brut;

	// Total remise couplage/triplage
	m_brutremisecouplage = m_brut - m_TotRemiseCouplage;
  
	// CUMUL DE MANDAT (CGV 2002) >> theApp.m_CGV
	if (m_checkcumulmandatmanuel == FALSE)
	{
		if (m_pDoc != NULL)
		{
			// Taux cumul de mandat 2004 
			if (theApp.m_CGV > 2003)
			{
				// CGV 2004 modif 29/12/2003
				if (m_pDoc->m_PrixEnEuro == false)
				{	
					// remise calcul� � partir des francs
					if (m_totalnet < 3016022)
						m_coeffremise = 2.0f;
					else if (m_totalnet <= 6034804)
						m_coeffremise = 2.25f;
					else if (m_totalnet <= 9183398)
						m_coeffremise = 2.5f;
					else if (m_totalnet <= 13119140)
						m_coeffremise = 2.75f;
					else
						m_coeffremise = 3.0f;	
				}
				else
				{
					// remise calcul� � partir des euros (CGV 2004 + arrondi uniquement)
					if (m_totalnet < 460000)
						m_coeffremise = 2.0f;
					else if (m_totalnet <= 920000)
						m_coeffremise = 2.25f;
					else if (m_totalnet <= 1400000)
						m_coeffremise = 2.5f;
					else if (m_totalnet <= 2000000)
						m_coeffremise = 2.75f;
					else
						m_coeffremise = 3.0f;	
				}
			}

			// Taux cumul mandat 2003
			else if (theApp.m_CGV > 2002)
			{
				// CGV 2003 modif 15/01/2003
				if (m_pDoc->m_PrixEnEuro == false)
				{	
					// remise calcul� � partir des francs
					if (m_totalnet < 2999954)
						m_coeffremise = 2.0f;
					else if (m_totalnet <= 5999973)
						m_coeffremise = 2.25f;
					else if (m_totalnet <= 8999992)
						m_coeffremise = 2.5f;
					else if (m_totalnet <= 12000012)
						m_coeffremise = 2.75f;
					else
						m_coeffremise = 3.0f;	
				}
				else
				{
					// remise calcul� � partir des euros (CGV 2003 + arrondi uniquement)
					if (m_totalnet < 457340)
						m_coeffremise = 2.0f;
					else if (m_totalnet <= 914690)
						m_coeffremise = 2.25f;
					else if (m_totalnet <= 1372040)
						m_coeffremise = 2.5f;
					else if (m_totalnet <= 1829390)
						m_coeffremise = 2.75f;
					else
						m_coeffremise = 3.0f;	
				}
			}

			else if (theApp.m_CGV > 2001)
			{
				// CGV 2002 
				if (m_pDoc->m_PrixEnEuro == false)
				{	
					// remise calcul� � partir des francs
					if (m_totalnet < 2999954)
						m_coeffremise = 2.0f;
					else if (m_totalnet <= 5999973)
						m_coeffremise = 2.25f;
					else if (m_totalnet <= 8999992)
						m_coeffremise = 2.5f;
					else if (m_totalnet <= 12000012)
						m_coeffremise = 2.75f;
					else
						m_coeffremise = 3.0f;	
				}
				else
				{
					// remise calcul� � partir des euros (CGV 2002 + arrondi uniquement)
					if (m_totalnet < 457340)
						m_coeffremise = 2.0f;
					else if (m_totalnet <= 914690)
						m_coeffremise = 2.25f;
					else if (m_totalnet <= 1372040)
						m_coeffremise = 2.5f;
					else if (m_totalnet <= 1829390)
						m_coeffremise = 2.75f;
					else
						m_coeffremise = 3.0f;	
				}
			}
			// CGV 2001
			else if (theApp.m_CGV > 2000)
			{
				if (m_pDoc->m_PrixEnEuro == false)
				{	
					// remise calcul� � partir des francs
					if (m_totalnet < 3000000)
						m_coeffremise = 2.0f;
					else if (m_totalnet < 6000000)
						m_coeffremise = 2.25f;
					else if (m_totalnet < 9000000)
						m_coeffremise = 2.5f;
					else if (m_totalnet < 12000000)
						m_coeffremise = 2.75f;
					else
						m_coeffremise = 3.0f;	
				}
				else
				{
					// remise calcul� � partir des euros
					if (m_totalnet < 457347)
						m_coeffremise = 2.0f;
					else if (m_totalnet < 914694)
						m_coeffremise = 2.25f;
					else if (m_totalnet < 1372041)
						m_coeffremise = 2.5f;
					else if (m_totalnet < 1829388)
						m_coeffremise = 2.75f;
					else
						m_coeffremise = 3.0f;	
				}
			}
		}
	}

	// Frais d'annonce automatique O/N
	if (m_checkfraisannoncemanuel)
		m_EditFraisAnnonce.EnableWindow(TRUE);
	else
		m_EditFraisAnnonce.EnableWindow(FALSE);

	// Frais d'annonce r�el
	if (m_pDoc != NULL)
	{
		if (m_pDoc->m_ModeTarif == 0)
		{
			// Frais d'annonce en mode classique
			// On remet les frais d'annonce pour les spots
			// float Frais = FraisAnnonceClassique(m_pDoc->m_NbSpotCascade);

			// Les gracieux aussi ont des frais d'annonce (modif 02/03/2004 : ANNULEE)
			float Frais = FraisAnnonceClassique(m_pDoc->m_NbSpot);
			m_fraisannoncereel.Format("%7.2f",Frais);
			m_fraisannoncereel.TrimLeft();
			m_fraisannonceclassique  = "* Frais Classique = " + m_fraisannoncereel;
		}
		else
		{
			// Frais d'annonce en mode floating
			float Frais = FraisAnnonceFloating();
			m_fraisannoncereel.Format("%7.2f",Frais);
			m_fraisannoncereel.TrimLeft();
			m_fraisannoncefloating  = "* Frais Floating  = " + m_fraisannoncereel;
		}
	}

	// Calul auto de la remise cumul de mandat (m_TotalBrutAnneeClient)
	if(m_pDoc)
	{
		CodeClient = m_pDoc->m_pNoyauCommande->m_CodeCommandeClient;
		TotalBrutAnneeClient = m_pDoc->m_pNoyauCommande->CumulMandat(m_pDoc->m_DateDebut,CodeClient,m_pDoc->m_CodeNoCampagne);

		//ajout montant brut campagne en cours si non d�j� command� ou remplac�
		TotalBrutAnneeClient= TotalBrutAnneeClient + m_totalbrut;

		if (m_pDoc->m_PrixEnEuro == false)
			TotalBrutAnneeClient *= m_pDoc->m_TauxEuroFranc;
	}

	// puis recherche du taux automatique cumul de mandat
	m_cumulmandat.Format("%s%7.2f","cumul mandat= ",TotalBrutAnneeClient);

	if (CodeClient != "")
		m_coeffremiseauto = m_pDoc->m_pNoyauCommande->TauxCumulMandat(TotalBrutAnneeClient,CodeClient);

	if (m_checkcumulmandatmanuel)
		m_editcoeffremise.EnableWindow(TRUE);
	else
		m_editcoeffremise.EnableWindow(FALSE);


	/* On retire la remise renouvellement sur le NetNet ??? 18/03/2004
	//if (m_checkrenouvellement == TRUE && m_pDoc->m_ModeContratFidelite != 0 && (InfSpotStationVille(142) == false))
	if (m_checkrenouvellement == TRUE && m_pDoc->m_ModeContratFidelite != 0)
	{
		// R�cup coeff renouvellement en cours
		CString CoeffRenouvellement;
		int CurSel;
		CurSel = m_combocoeffrenouvellement.GetCurSel();
		m_combocoeffrenouvellement.GetLBText(CurSel,CoeffRenouvellement);

		// calcul nouveau total net
		m_coeffrenouvellement = atof(CoeffRenouvellement);
		m_totalnetnet = m_totalnet - (m_totalnet*m_coeffrenouvellement/100);					
	}
	else
		m_totalnetnet = m_totalnet;
	*/
	m_totalnetnet = m_totalnet;

	//total net net (avec cumul de mandat)
	if (m_checkcumulmandatmanuel == TRUE)
		m_totalnetnet=m_totalnetnet-(m_totalnetnet*m_coeffremise/100);
	else
		m_totalnetnet=m_totalnetnet-(m_totalnetnet*m_coeffremiseauto/100);


	m_totalnetnet = int((m_totalnetnet+0.005)*100);
	m_totalnetnet = m_totalnetnet/100;
	if(update)
		UpdateData(false);

}

// Mise � jour texte devise
void CCascadeDlg::MajTxtDevise()
{
	if (m_pDoc)
	{
		// Les labels devis budget
		if (m_pDoc->m_PrixEnEuro == true)
		{
			m_TxtDevise1.SetWindowText("Euros");
			m_TxtDevise2.SetWindowText("Euros");
			m_TxtDevise3.SetWindowText("Euros");
			m_TxtDevise4.SetWindowText("Euros");
			m_TxtDevise5.SetWindowText("Euros");
			m_TxtDevise6.SetWindowText("Euros");
			m_TxtDevise7.SetWindowText("Euros");
			m_TxtDevise8.SetWindowText("Euros");
		}
		else
		{
			m_TxtDevise1.SetWindowText("Frs");
			m_TxtDevise2.SetWindowText("Frs");
			m_TxtDevise3.SetWindowText("Frs");
			m_TxtDevise4.SetWindowText("Frs");
			m_TxtDevise5.SetWindowText("Frs");
			m_TxtDevise6.SetWindowText("Frs");
			m_TxtDevise7.SetWindowText("Frs");
			m_TxtDevise8.SetWindowText("Frs");
		}
	

	}

	return;
		
}

// Mise � jour montant en euro franc
void CCascadeDlg :: MajMontantEuroFranc()
{
	// Mise � jour des Frais Annonce non auto et Frais duplication
	if (m_pDoc != NULL)
	{
		if (m_pDoc->m_PrixEnEuro)
		{
			if (!m_pDoc->m_FraisDuplicationEnEuro)
				//m_FraisDuplication = int(m_FraisDuplication * m_pDoc->m_TauxFrancEuro + 0.5);
				m_FraisDuplication = m_FraisDuplication * m_pDoc->m_TauxFrancEuro;

			if (!m_pDoc->m_TotalFraisAnnonceEnEuro)
				//m_TotalFraisAnnonce = int(m_TotalFraisAnnonce * m_pDoc->m_TauxFrancEuro + 0.5);
				m_TotalFraisAnnonce = m_TotalFraisAnnonce * m_pDoc->m_TauxFrancEuro;

		
			if (!m_pDoc->m_CAHistoriqueEnEuro)
				m_brutht = m_brutht * m_pDoc->m_TauxFrancEuro;

			m_pDoc->m_FraisDuplicationEnEuro = TRUE;
			m_pDoc->m_TotalFraisAnnonceEnEuro = TRUE;
			m_pDoc->m_CAHistoriqueEnEuro = TRUE;


		}
		else
		{
			if (m_pDoc->m_FraisDuplicationEnEuro)
				//m_FraisDuplication = int(m_FraisDuplication * m_pDoc->m_TauxEuroFranc + 0.5);
				m_FraisDuplication = m_FraisDuplication * m_pDoc->m_TauxEuroFranc;

			if (m_pDoc->m_TotalFraisAnnonceEnEuro)
				//m_TotalFraisAnnonce = int(m_TotalFraisAnnonce * m_pDoc->m_TauxEuroFranc + 0.5);
				m_TotalFraisAnnonce = m_TotalFraisAnnonce * m_pDoc->m_TauxEuroFranc;

			if (m_pDoc->m_CAHistoriqueEnEuro)
				m_brutht = m_brutht * m_pDoc->m_TauxEuroFranc;

			m_pDoc->m_CAHistoriqueEnEuro = FALSE;
			m_pDoc->m_FraisDuplicationEnEuro = FALSE;
			m_pDoc->m_TotalFraisAnnonceEnEuro = FALSE;
		}
	}	

	UpdateAffichage(false);  // A virer par la suite ??????????????

	UpdateData(false);

	return;
}	

float CCascadeDlg::CheckBudgetNet(void)
{
//	if(m_checkremise)	return m_totalnetnet;
	return m_totalnet;
}

float CCascadeDlg::DonneBudgetNet(void)
{
	return CheckBudgetNet();
}

void CCascadeDlg::CalculCumulMandat()
{
	UpdateAffichage(true);
}

void CCascadeDlg::OnChecknegociation()
{
	UpdateData(true);
	
	if (theApp.m_CGV > 2000)
	{
		if (m_checknegociation==TRUE)
		{
			m_checkremiseSigEtGC  = FALSE;
			m_checkremiserenfort  = FALSE;
			m_checkremisenatiocal = FALSE;
			UpdateData(false);
		}
		else
		{
			m_checknegociation=FALSE;
			UpdateData(false);
		}

	}
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);
}

/*
void CCascadeDlg::OnCheckprimeanticip() 
{
	UpdateData(true);
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);
}
*/

void CCascadeDlg::SetDoc(CMultilocDoc *pDoc)
{
	m_pDoc=pDoc;
}

void CCascadeDlg::OnChangeBrutht() 
{
	UpdateData(true);
	UpdateCascade(-1,NULL);
	m_pDoc->UpdateAllViews(NULL, 2);
	m_pDoc->m_CAHistoriqueEnEuro = m_pDoc->m_PrixEnEuro;
}

void CCascadeDlg::OnChangeCoeffnegociation() 
{
	/*
	if (UpdateData(true))
	{
		UpdateAffichage(false);
		m_pDoc->UpdateAllViews(NULL, 2);
	}
	*/

	// Attention au probl�me de la virgule en float !!!!
	CWnd* pEdit = GetDlgItem(IDC_COEFFNEGOCIATION);
	if (pEdit != NULL)
	{
		CString Text; pEdit->GetWindowText(Text);
		if (Text.Right(1) != "," && Text.Right(1) != ".")
		{
			UpdateData(true);
			UpdateAffichage(false);
			m_pDoc->UpdateAllViews(NULL, 2);
		}
	}
}

void CCascadeDlg::OnChangeCoeffremise() 
{
	/*
	if (UpdateData(true))
	{
		UpdateCascade(-1,NULL);
		m_pDoc->UpdateAllViews(NULL, 2);
	}
	*/
	// Attention au probl�me de la virgule en float !!!!
	CWnd* pEdit = GetDlgItem(IDC_COEFFREMISE);
	if (pEdit != NULL)
	{
		CString Text; pEdit->GetWindowText(Text);
		if (Text.Right(1) != "," && Text.Right(1) != ".")
		{
			UpdateData(true);
			UpdateAffichage(false);
			m_pDoc->UpdateAllViews(NULL, 2);
		}
	}
}

void CCascadeDlg::OnChangeEditTauxderegie() 
{
	UpdateData(true);
	if(m_pDoc) m_pDoc->UpdateAllViews(NULL, 2);
}

/*
void CCascadeDlg::OnNouveauclient() 
{
	UpdateData(true);
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);
}
*/

/*
void CCascadeDlg::OnRenouvellement() 
{
	UpdateData(true);
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);
}
*/

void CCascadeDlg::OnChangeFraisannonce() 
{
	//MULTILOC3
	UpdateData(true);
	UpdateAffichage(false);
	m_pDoc->UpdateAllViews(NULL, 2);
	m_pDoc->m_TotalFraisAnnonceEnEuro = m_pDoc->m_PrixEnEuro;
}

void CCascadeDlg::OnChangeFraisDuplication() 
{
	//MULTILOC3
	UpdateData(true);
	UpdateAffichage(false);
	m_pDoc->UpdateAllViews(NULL, 2);
	m_pDoc->m_FraisDuplicationEnEuro = m_pDoc->m_PrixEnEuro;
}

void CCascadeDlg::OnCheckFraisannoncemanuel() 
{
	// MULTILOC3
	UpdateData(true);
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);

}

void CCascadeDlg::OnCheckCumulmandatmanuel() 
{
	UpdateData(true);
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);
	
}

void CCascadeDlg::OnChecksiggrandescauses() 
{
	UpdateData(true);

	// CGV 2003
	if (m_checkremiseSigEtGC ==TRUE)
	{
		m_checknegociation		= FALSE;
		m_checkremiserenfort	= FALSE;
		m_checkremisenatiocal   = FALSE;
	}			
	else
	{
		m_checkremiseSigEtGC = FALSE;
		UpdateData(false);
	}
	
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);	

}

void CCascadeDlg::OnCheckremiserenfort() 
{
	UpdateData(true);

	// CGV 2001
	if (m_checkremiserenfort == TRUE)
	{
		m_checknegociation		= FALSE;
		m_checkremiseSigEtGC	= FALSE;
		m_checkremisenatiocal   = FALSE;
	}			
	else
	{
		m_checkremiserenfort	= FALSE;
		UpdateData(false);
	}

	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);
	
}

void CCascadeDlg::OnCheckremisenatiocal() 
{

	UpdateData(true);

	// CGV 2001
	if (m_checkremisenatiocal  == TRUE)
	{
		m_checknegociation		= FALSE;
		m_checkremiseSigEtGC	= FALSE;
		m_checkremiserenfort    = FALSE;
	}			
	else
	{
		m_checkremisenatiocal 	= FALSE;
		UpdateData(false);
	}

	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);
}

/*
void CCascadeDlg::OnCheckcomplementarite() 
{
	UpdateData(true);

	// CGV 2001
	if (m_checkcomplementarite == TRUE)
	{
		m_checknegociation		= FALSE;
		m_checkremiseSigEtGC	= FALSE;
	}			
	else
	{
		m_checkcomplementarite = FALSE;
		UpdateData(false);
	}

	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);
	
}
*/

// Calcul Remise Multi-villes ou Offre Globale
void CCascadeDlg::CalculRemiseMV_ou_OffreGlobale()
{
	// Ni de remise Multi villes, ni de remise Offre Globale
	m_coeffMvOuOffreGlob = 0.0f;

	if (m_checkremisemultivilles == TRUE)
	{
		// Si mode classique
		if (m_pDoc->m_ModeTarif == 0)
		{
			// Choix remise multivilles 
			// Calcul nb villes et nb spots
			int CplStaVil   = 0;
			int NbVilles    = 0;
			int NbSpots     = 0;
			int NbSpotVille = 0;
			CMap <int,int,bool,bool> TabVilleActive;

			// boucle sur toutes les stations
			for(int sta=0;sta<m_pDoc->m_NbStation;sta++)
			{
				// boucle sur toutes les villes dsipo de la station
				for(int vil=0;vil<m_pDoc->m_pNoyau->m_pTblVille[sta].GetSize() ;vil++)
				{
					// Init Nb spots ville
					NbSpotVille = 0;

					// No ident ville
					int NoVille = m_pDoc->m_pNoyau->m_pTblVille[sta][vil].m_NrUnique;

					// boucle sur toute la p�riode
					for(int j=0;j<m_pDoc->m_Duree;j++)
					{
						// boucle sur toutes les tranches horaires
						for(int h=0;h<m_pDoc->m_NbHoraire;h++)
						{
							short *SPOT;
							SPOT=&m_pDoc->m_Juke[sta][vil].m_SpotJH[j][h];
							*SPOT = (*SPOT) % 200;
							NbSpots     += (*SPOT) % 100;
							NbSpotVille += (*SPOT) % 100;
						}
					}

					// si au moins 1 spot
					if (NbSpotVille != 0)
					{
						TabVilleActive.SetAt(NoVille,true);
						CplStaVil++;
					}
				}
			}

			// Nombre de villes actives
			NbVilles = TabVilleActive.GetCount();

			// Calcul du coeff remise Multi-villes
			if (NbVilles < 4)
				// pas de remise
				m_coeffMvOuOffreGlob = 0.0f;
			else
			{	
				if (CplStaVil < 30)
					// moins de 30 couples <station,ville> au total
					m_coeffMvOuOffreGlob = 20.0f;
				else
					// 30 30 couples <station,ville> ou plus au total
					m_coeffMvOuOffreGlob = 25.0f;
			}
		}
		
		else
		{
			// Mode floating
			// Choix remise multivilles 
			// Calcul nb villes et nb spots
			int CplStaVil   = 0;
			int NbVilles    = 0;
			int NbSpots     = 0;
			int NbSpotVille = 0;
			CMap <int,int,bool,bool> TabVilleActive;

			// boucle sur toutes les stations
			for(int sta=0;sta<m_pDoc->m_NbStation;sta++)
			{
				// boucle sur toutes les villes dsipo de la station
				for(int vil=0;vil<m_pDoc->m_pNoyau->m_pTblVille[sta].GetSize() ;vil++)
				{
					// Init Nb spots ville
					NbSpotVille = 0;

					// No ident ville
					int NoVille = m_pDoc->m_pNoyau->m_pTblVille[sta][vil].m_NrUnique;

					// boucle sur toute la p�riode
					for(int j=0;j<m_pDoc->m_Duree;j++)
					{
						// boucle sur toutes les tranches horaires
						for(int ff=0;ff<m_pDoc->m_NbFormat;ff++)
						{
							short *SPOT;
							SPOT=&m_pDoc->m_Juke[sta][vil].m_SpotJH[j][ff];
							*SPOT = (*SPOT) % 200;
							NbSpots     += (*SPOT) % 100;
							NbSpotVille += (*SPOT) % 100;
						}
					}

					// si au moins 1 spot
					if (NbSpotVille != 0)
					{
						TabVilleActive.SetAt(NoVille,true);
						CplStaVil++;
					}
				}
			}

			// Nombre de villes actives
			NbVilles = TabVilleActive.GetCount();

			// Calcul du coeff remise Multi-villes
			if (NbVilles < 4)
				// pas de remise
				m_coeffMvOuOffreGlob = 0.0f;
			else
			{	
				if (CplStaVil < 30)
					// moins de 30 couples <station,ville> au total
					m_coeffMvOuOffreGlob = 20.0f;
				else
					// 30 30 couples <station,ville> ou plus au total
					m_coeffMvOuOffreGlob = 25.0f;

			}
		}								
	}
	else if (m_checkoffreglobale == TRUE)

	{
		// Choix remise offre globale
		int NbProduit = 1;				// la radio est d�j� 1 produit
		if (m_checkproductionpub		== TRUE) NbProduit++;
		if (m_checkhorsmedia   		    == TRUE) NbProduit++;
		//if (m_checkoperationspeciale	== TRUE) NbProduit++; 
		if (m_checkparrainage			== TRUE) NbProduit++;
		//if (m_checkachatinternet		== TRUE) NbProduit++;				
		
		/*
		if (NbProduit == 2)
			m_coeffMvOuOffreGlob = 10.0f;
		else if (NbProduit >= 3)
			m_coeffMvOuOffreGlob = 15.0f;
		*/
		if (m_checkproductionpub)
			m_coeffMvOuOffreGlob = 10.0f;
		else if (m_checkhorsmedia)
			m_coeffMvOuOffreGlob = 15.0f;

	}
	
}


bool CCascadeDlg::InfSpotStationVille(int LimNbSpot)
{

	int MinSpotCouple = 32000;
	int NbSpotCouple;

	// boucle sur toutes les stations
	for(int sta=0;sta<m_pDoc->m_NbStation;sta++)
	{
		// boucle sur toutes les villes dsipo de la station
		for(int vil=0;vil<m_pDoc->m_pNoyau->m_pTblVille[sta].GetSize() ;vil++)
		{
			// Init Nb spots ville
			NbSpotCouple = 0;

			// No ident ville
			int NoVille = m_pDoc->m_pNoyau->m_pTblVille[sta][vil].m_NrUnique;

			// boucle sur toute la p�riode
			for(int j=0;j<m_pDoc->m_Duree;j++)
			{
				// boucle sur toutes les tranches horaires
				for(int h=0;h<m_pDoc->m_NbHoraire;h++)
				{
					short *SPOT;
					SPOT=&m_pDoc->m_Juke[sta][vil].m_SpotJH[j][h];
					*SPOT = (*SPOT) % 200;
					NbSpotCouple += (*SPOT) % 100;
				}
			}

			// Test si nombre de spots station/ville a atteint la limite
			if (NbSpotCouple < MinSpotCouple && NbSpotCouple != 0)
			{
				MinSpotCouple = NbSpotCouple;
			}

		}
	}

	// Voir si les couples station/ville ont atteint cette limite
	/*
	if (MinSpotCouple < LimNbSpot)
		return true;
	else
		return false;
	*/
	
	// On revient sur la modif / on autorise remise dans tous les cas (18/02/2004)
	return false;
}
		

// S�lection remise Multivilles > d�selection Offre globale si s�lectionn�e
void CCascadeDlg::OnCheckremisemultivilles() 
{
	UpdateData(true);

	if (m_checkremisemultivilles == TRUE)
		m_checkoffreglobale = FALSE;

	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);	
}

// S�lection Offre Globale > d�selection remise Multivilles si s�lectionn�e
void CCascadeDlg::OnCheckoffreglobale() 
{
	UpdateData(true);

	if (m_checkoffreglobale == TRUE)
		m_checkremisemultivilles = FALSE;

	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);	
}

void CCascadeDlg::OnCheckprodpub() 
{
	
	// Relance calcul remise
	UpdateData(true);

	// D�validation du check Hors Media
	if (m_checkproductionpub == TRUE)
		m_checkhorsmedia = FALSE;

	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);	
}

void CCascadeDlg::OnCheckparrainage() 
{
	
	// Relance calcul remise
	UpdateData(true);
	UpdateAffichage(true);	
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);	
}

/*
void CCascadeDlg::OnCheckopespe() 
{
	// Relance calcul remise
	UpdateData(true);
	UpdateAffichage(true);	
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);	
}
*/


void CCascadeDlg::OnCheckhorsmedia() 
{
	// Relance calcul remise
	UpdateData(true);

	// D�validation du check production pub
	if (m_checkhorsmedia == TRUE)
		m_checkproductionpub = FALSE;

	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);	
}

void CCascadeDlg::OnCheckremisefrequence() 
{
	// Relance calcul remise
	UpdateData(true);
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);	
}

void CCascadeDlg::OnCheckprofessionnelle() 
{
	// Relance calcul remise
	UpdateData(true);
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);		
}

void CCascadeDlg::OnCheckrenouvellement() 
{
	// Relance calcul remise
	UpdateData(true);
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);
}

void CCascadeDlg::OnSelchangeComborenouvellement() 
{
	// Relance calcul remise
	UpdateData(true);
	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);
}

// Calcul frais automatique en mode Floating
double CCascadeDlg::FraisAnnonceFloating()
{
	// Calcul frais annonce (= Nb stations * Frais Unitaire)
	// double FraisAnnonceSta = 30.0f;
	double FraisAnnonceSta = 40.0f;
	return double(m_pDoc->m_NbStationVilleAvecSpot) * FraisAnnonceSta;

}

// Calcul Frais automatique en mode contrat classique
double CCascadeDlg::FraisAnnonceClassique(int NbSpot)
{
	// Calcul frais annonce (= Nb spots * Frais Unitaire)
	double FraisAnnonceSta = 30.0f;

	// Coeff frais d'annonce par spot
	CString Coeff;
	int CurSel = m_combocoeffmiseenonde.GetCurSel();
	m_combocoeffmiseenonde.GetLBText(CurSel,Coeff); 


	
	int Pos = Coeff.Find(" ");
	if (Pos > 0) 
		Coeff = Coeff.Left(Pos);
	else
		Coeff = "0.0";

	// Bidouille pour �viter probl�me con du atof (avec ou sans "." ou ",")
	// Bateau mais au moins c'est s�r
	double ValCoeff = 0.0;			
	if (Coeff == "2.4" || Coeff == "2,4")
		ValCoeff = 2.4;
	else if (Coeff == "1.3" || Coeff == "1,3")
		ValCoeff = 1.3;
	else if (Coeff == "0.85" || Coeff == "0,85")
		ValCoeff = 0.85;

	/*
	// Ne marche pas ???
	double ValCoeff = 0.0;			
	Coeff.Replace(",","."); 
	ValCoeff = atof(Coeff);
	*/
	
	double Frais = double(NbSpot) * ValCoeff;
	return Frais ;
}

void CCascadeDlg::OnSelchangeComboCoeffmiseenonde() 
{
	// Relance calcul remise
	UpdateData(true);

	UpdateAffichage(true);
	if(m_pDoc)	m_pDoc->UpdateAllViews(NULL, 2);	
}

void CCascadeDlg::OnEditchangeComboCoeffmiseenonde() 
{

}

void CCascadeDlg::OnEditupdateComboCoeffmiseenonde() 
{
}

void CCascadeDlg::OnChangeFraisAchemRepiq() 
{
	// Mise � jour des frais d'acheminement repiquage
	UpdateData(true);
	UpdateAffichage(false);
	m_pDoc->UpdateAllViews(NULL, 2);
}

void CCascadeDlg::OnChangeFraisAcheminement() 
{
	// Mise � jour des frais d'acheminement
	UpdateData(true);
	UpdateAffichage(false);
	m_pDoc->UpdateAllViews(NULL, 2);
}

void CCascadeDlg::OnChangeFraisRepiquage() 
{
	// Mise � jour des frais de repiquage
	UpdateData(true);
	UpdateAffichage(false);
	m_pDoc->UpdateAllViews(NULL, 2);
}






void CCascadeDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	
	CDialog::OnClose();
}




